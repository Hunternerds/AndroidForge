// Forwards the usual tasks to the :app module of the included android/ build, so
// `android/gradlew assembleDebug` works from the repository root as well as from
// android/. Outputs stay where they always were: android/app/build/outputs/.
//
// To forward another task, add its name to the list.
val appBuild = gradle.includedBuilds.single()

listOf(
    "assembleDebug",
    "assembleRelease",
    "bundleDebug",
    "bundleRelease",
    "testDebugUnitTest",
    "lintDebug",
).forEach { taskName ->
    tasks.register(taskName) {
        group = "android"
        description = "Runs :app:$taskName in the android/ build."
        dependsOn(appBuild.task(":app:$taskName"))
    }
}
