// Root shim. The real Gradle build lives in android/, but some build runners
// (AndroidForge among them) start Gradle from the repository root, where it
// finds no settings file and stops with "does not contain a Gradle build".
//
// This makes the root a thin composite build that includes android/ as-is.
// android/ keeps its own settings, wrapper, version catalog and gradle.properties,
// and android/app/build.gradle.kts still sees the repository root as
// rootProject.projectDir.parentFile, which it relies on for patches/, scripts/,
// branding/ and the notice documents.
rootProject.name = "hunt-root"

includeBuild("android")
