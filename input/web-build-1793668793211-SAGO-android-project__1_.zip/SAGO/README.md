# SAGO — Android AI companion

Native Kotlin + Jetpack Compose app. Groq for AI, offline Vosk wake word ("Sago"), your supplied face artwork as the animated avatar.

> **Status: written, not yet compiled.** This project was authored in an environment with no Android SDK or Gradle, so it has
> never been built or run. Expect to fix a few compile errors on the first sync, then test on a real phone (see "Testing checklist").

## Open and build
1. Android Studio Ladybug (2024.2) or newer, JDK 17.
2. File → Open → this folder. Studio downloads Gradle 8.9 from `gradle/wrapper/gradle-wrapper.properties`.
   (`gradle-wrapper.jar` / `gradlew` couldn't be generated here. For the command line run `gradle wrapper --gradle-version 8.9` once.)
3. Run on a device (minSdk 26, targetSdk 35). The emulator works for chat; use a real device for wake word and voice.
4. First launch: paste your Groq key (console.groq.com/keys). It is validated with a real request and stored with an Android Keystore AES-GCM key. Nothing is hardcoded.

## Groq models (verified against Groq docs, Nov 2026)
Several older defaults (Llama 3.3 70B, Llama 3.1 8B, Llama 4 Scout, Qwen3 32B) are deprecated. SAGO therefore:
- defaults to `openai/gpt-oss-120b` (chat) and `qwen/qwen3.6-27b` (vision), chosen on first launch only if they appear in your live `/models` list;
- lets you pick any chat model in **Settings → AI** (list is fetched live; non-chat models are filtered out);
- sends reasoning/JSON-mode parameters only where useful and automatically retries without them if a model rejects them;
- sends photos as base64 JPEG (max side 1600 px, under 2.5 MB; Groq's base64 limit is 4 MB) and never claims to have seen an image that wasn't sent. If the vision model fails you get an explicit error.

## Wake word "Sago" (offline)
- `WakeWordService` is a microphone-type foreground service with a persistent notification and a "Stop listening" action.
- Detection: Vosk with a grammar limited to "sago" (+ phonetic variants) or unknown. Audio never leaves the device. Sensitivity (Settings → Voice) tunes stability frames and an energy gate.
- After detection the same mic stream, seeded with ~1.6 s of audio from before the wake word, is transcribed by Vosk's full model, so "Sago remember my project is StudyOS" works in one breath. A follow-up window lets you keep talking without saying "Sago" again.
- The ~40 MB English model (`vosk-model-small-en-us-0.15`) is downloaded once from alphacephei.com (Settings → Voice) and stored in app-private storage.
- Limits (Android, not bugs): Android 14+ only lets a microphone service start while the app is visible, so SAGO can't auto-start on boot; OEM battery managers may kill the service; accuracy drops in noise or at distance; the speaker can't be heard over itself, so listening pauses while SAGO talks (tap the avatar or Stop to interrupt).

## Voice, avatar, memory
- **Pipeline:** mic → (Vosk or Android SpeechRecognizer, which does the end-of-speech detection) → `ConversationEngine` → Groq → `ReplyParser` → Android TTS → avatar. Text and voice share one engine and history.
- **Avatar:** all nine supplied expressions, silent/talking frames, and the supplied in-between transition frames (converted to WebP; 4.9 MB total). Android's TTS exposes no audio amplitude, so the mouth follows TTS word-boundary callbacks (real playback progress). If a TTS engine doesn't send them, a speech-rhythm cadence is used only while audio is actually playing.
- **Emotion:** each reply is JSON (`response`, `emotion`, `intent`, `avatar`, `voice`, `memories`). Only `response` is shown/spoken; the rest drives avatar/voice. Your personality prompt is kept verbatim (editable in Settings); a short technical output contract is appended after it.
- **Memory:** local Room DB, per profile. "Sago remember …" (also typed, and common mishearings like "say go remember") saves immediately. Automatic memories come from the same reply (no extra API call), are filtered for sensitivity/temporary info, de-duplicated and updated when a fact changes. Only ≤6 relevant notes (~700 chars) are sent per request. View/edit/delete/clear in Settings → Memory.
- **Privacy:** photos use the system camera app (no CAMERA permission). Backups are disabled.

## Code map (`app/src/main/java/com/sago/app`)
`data/groq` client+errors · `data/db` Room · `data/prefs` DataStore · `domain/ai` prompt, parser, engine · `domain/memory` · `voice` TTS, STT, `AssistantController` · `wake` Vosk engine, service, model manager · `avatar` frames + view · `vision` · `ui` Compose screens/ViewModels.

## Testing checklist (on a real device)
Invalid key → error · airplane mode → error + Retry · chat + history restore after app kill · "Sago remember I prefer short answers" then a new chat · photo (camera + gallery) · mic button · enable wake word, say "Sago", lock screen, pocket test · Stop listening from the notification · deny mic permission · TTS interrupt.
