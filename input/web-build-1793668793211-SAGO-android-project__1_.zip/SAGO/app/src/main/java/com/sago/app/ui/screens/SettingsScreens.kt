package com.sago.app.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sago.app.BuildConfig
import com.sago.app.avatar.AvatarMode
import com.sago.app.avatar.AvatarUi
import com.sago.app.avatar.AvatarView
import com.sago.app.avatar.Expression
import com.sago.app.data.db.MemoryEntity
import com.sago.app.data.groq.GroqClient
import com.sago.app.data.prefs.Keys
import com.sago.app.domain.ai.PersonalityDefaults
import com.sago.app.ui.components.*
import com.sago.app.ui.theme.LocalSagoUi
import com.sago.app.ui.viewmodel.SettingsViewModel
import com.sago.app.ui.viewmodel.TestResult
import com.sago.app.wake.ModelState
import com.sago.app.wake.WakeStatus
import com.sago.app.wake.WakeWordService

private fun has(ctx: android.content.Context, perm: String) = ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

@Composable
fun SettingsHubScreen(onBack: () -> Unit, onNav: (String) -> Unit) {
    val ui = LocalSagoUi.current
    SettingsScaffold("Settings", onBack) {
        Section("Customize SAGO") {
            ActionRow("AI", "Groq key, models, personality prompt", Icons.Default.AutoAwesome) { onNav("settings/ai") }
            ActionRow("Voice", "Wake word, speech, voice and speed", Icons.Default.RecordVoiceOver) { onNav("settings/voice") }
            ActionRow("Appearance", "Theme, avatar and animations", Icons.Default.Palette) { onNav("settings/appearance") }
            ActionRow("Memory", "What SAGO remembers, profiles", Icons.Default.Psychology) { onNav("settings/memory") }
            ActionRow("Privacy", "Permissions, listening status, local data", Icons.Default.Shield) { onNav("settings/privacy") }
        }
        Text("SAGO ${BuildConfig.VERSION_NAME} · AI responses come from Groq under your own account's limits and policies.", style = MaterialTheme.typography.labelSmall, color = ui.subtext)
    }
}

// ───────────────────────── AI ─────────────────────────

@Composable
fun AiSettingsScreen(vm: SettingsViewModel, onBack: () -> Unit) {
    val ui = LocalSagoUi.current
    val s by vm.settings.collectAsStateWithLifecycle()
    val models by vm.models.collectAsStateWithLifecycle()
    val busy by vm.modelsBusy.collectAsStateWithLifecycle()
    val testing by vm.testing.collectAsStateWithLifecycle()
    val test by vm.testResult.collectAsStateWithLifecycle()
    val mask by vm.keyMask.collectAsStateWithLifecycle()
    val keyMsg by vm.keyMessage.collectAsStateWithLifecycle()
    var newKey by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var prompt by remember(s.systemPrompt) { mutableStateOf(s.systemPrompt.ifBlank { PersonalityDefaults.SYSTEM_PROMPT }) }
    LaunchedEffect(Unit) { if (vm.models.value.isEmpty()) vm.refreshModels() }

    val ids = models.map { it.id }
    val textOptions = (if (s.textModel !in ids) listOf(s.textModel) else emptyList()).plus(ids).map { it to it }
    val visionIds = ids.filter { GroqClient.looksVisionCapable(it) }
    val visionOptions = (if (s.visionModel !in visionIds) listOf(s.visionModel) else emptyList()).plus(visionIds.ifEmpty { ids }).map { it to it }

    SettingsScaffold("AI", onBack) {
        Section("Groq connection") {
            Text("Current key: ${mask.ifBlank { "none" }}", color = ui.text)
            OutlinedTextField(
                newKey, { newKey = it }, label = { Text("New API key") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = { IconButton({ show = !show }) { Icon(if (show) Icons.Default.VisibilityOff else Icons.Default.Visibility, if (show) "Hide key" else "Show key") } },
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ vm.saveKey(newKey); newKey = "" }, enabled = newKey.isNotBlank()) { Text("Save & verify") }
                OutlinedButton({ vm.testConnection() }, enabled = !testing) { Text(if (testing) "Testing…" else "Test connection") }
            }
            ResultText(keyMsg); ResultText(test)
            Text("Keys are checked with a real Groq request and stored encrypted. Usage is subject to your Groq account's limits and policies.", style = MaterialTheme.typography.labelSmall, color = ui.subtext)
        }
        Section("Models") {
            DropdownRow("Chat model", s.textModel, textOptions) { vm.set(Keys.TEXT_MODEL, it) }
            DropdownRow("Vision model (photos)", s.visionModel, visionOptions) { vm.set(Keys.VISION_MODEL, it) }
            OutlinedButton({ vm.refreshModels() }, enabled = !busy) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text(if (busy) "Loading…" else "Refresh model list") }
            Text("The list comes live from your Groq account. Groq doesn't flag image support in its model list, so the vision list shows known vision models; if photo analysis fails, pick another here.", style = MaterialTheme.typography.labelSmall, color = ui.subtext)
        }
        Section("Personality (system prompt)") {
            OutlinedTextField(prompt, { prompt = it }, Modifier.fillMaxWidth(), minLines = 6, maxLines = 12)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({
                    if (prompt.trim() == PersonalityDefaults.SYSTEM_PROMPT.trim() || prompt.isBlank()) vm.resetPrompt() else vm.set(Keys.SYSTEM_PROMPT, prompt.trim())
                }) { Text("Save") }
                OutlinedButton({ vm.resetPrompt() }) { Text("Reset to default") }
            }
            Text("SAGO adds a short technical format block after your prompt so replies can carry emotion and avatar data. It never changes your wording.", style = MaterialTheme.typography.labelSmall, color = ui.subtext)
        }
        Section("AI configuration") {
            SliderRow("Creativity (temperature)", "%.1f".format(s.temperature), s.temperature, 0f..1.2f, 11) { vm.set(Keys.TEMPERATURE, it) }
            SliderRow("Max reply length", "${s.maxTokens} tokens", s.maxTokens.toFloat(), 200f..2000f, 17) { vm.set(Keys.MAX_TOKENS, (it / 100).toInt() * 100) }
            SliderRow("Conversation context", "${s.historyLimit} messages", s.historyLimit.toFloat(), 2f..30f, 27) { vm.set(Keys.HISTORY_LIMIT, it.toInt()) }
            Text("Shorter context and replies use fewer tokens.", style = MaterialTheme.typography.labelSmall, color = ui.subtext)
        }
    }
}

@Composable
private fun ResultText(r: TestResult?) {
    r?.let { Text(it.message, color = if (it.ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
}

// ───────────────────────── Voice ─────────────────────────

@Composable
fun VoiceSettingsScreen(vm: SettingsViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val ui = LocalSagoUi.current
    val s by vm.settings.collectAsStateWithLifecycle()
    val voices by vm.voices.collectAsStateWithLifecycle()
    val modelState by vm.modelState.collectAsStateWithLifecycle()
    val wakeStatus by vm.wakeStatus.collectAsStateWithLifecycle()
    val wakeDetail by vm.wakeDetail.collectAsStateWithLifecycle()
    var hint by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { vm.loadVoices() }
    DisposableEffect(Unit) { onDispose { vm.stopVoiceTest() } }

    fun enableWake() {
        if (!vm.modelState.value.let { it is ModelState.Ready }) { hint = "Download the offline voice model first (button below)."; return }
        hint = null
        vm.set(Keys.WAKE_ENABLED, true)
        try { WakeWordService.start(ctx) } catch (e: Exception) { hint = "Android didn't allow background listening to start: ${e.message}" }
    }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.RECORD_AUDIO] == true || has(ctx, Manifest.permission.RECORD_AUDIO)) enableWake()
        else hint = "Microphone permission is required for the wake word."
    }
    fun onWakeToggle(on: Boolean) {
        if (!on) { vm.set(Keys.WAKE_ENABLED, false); WakeWordService.stop(ctx); hint = null; return }
        if (has(ctx, Manifest.permission.RECORD_AUDIO)) enableWake()
        else perms.launch(buildList { add(Manifest.permission.RECORD_AUDIO); if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS) }.toTypedArray())
    }

    SettingsScaffold("Voice", onBack) {
        Section("Wake word “Sago”") {
            SwitchRow("Background listening", "Say “Sago” to wake SAGO hands-free. Runs as a foreground service with a visible notification.", s.wakeEnabled, ::onWakeToggle)
            Text(
                when (wakeStatus) {
                    WakeStatus.OFF -> "Status: off"
                    WakeStatus.STARTING -> "Status: starting…"
                    WakeStatus.LISTENING -> "Status: listening for “Sago”"
                    WakeStatus.ENGAGED -> "Status: heard you"
                    else -> "Status: ${wakeDetail.ifBlank { "stopped" }}"
                }, color = ui.subtext,
            )
            hint?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            SliderRow("Sensitivity", when { s.wakeSensitivity > 0.7f -> "High"; s.wakeSensitivity > 0.35f -> "Medium"; else -> "Low" }, s.wakeSensitivity, 0f..1f) { vm.set(Keys.WAKE_SENSITIVITY, it) }
            Text("Higher catches “Sago” more easily but may trigger by mistake. Restart listening after changing it.", style = MaterialTheme.typography.labelSmall, color = ui.subtext)
            SliderRow("Follow-up window", if (s.followUpSeconds == 0) "Off" else "${s.followUpSeconds} s", s.followUpSeconds.toFloat(), 0f..15f, 14) { vm.set(Keys.FOLLOW_UP_SECONDS, it.toInt()) }
            Text("After SAGO answers, it keeps listening this long so you can reply without saying “Sago” again.", style = MaterialTheme.typography.labelSmall, color = ui.subtext)
        }
        Section("Offline voice model") {
            when (val m = modelState) {
                is ModelState.Ready -> {
                    Text("Installed. Wake-word detection runs fully on this device.", color = ui.text)
                    OutlinedButton({ WakeWordService.stop(ctx); vm.set(Keys.WAKE_ENABLED, false); vm.deleteVoiceModel() }) { Text("Remove model") }
                }
                is ModelState.Downloading -> { LinearProgressIndicator(progress = { m.progress }, Modifier.fillMaxWidth()); Text("Downloading… ${(m.progress * 100).toInt()}%", color = ui.subtext) }
                is ModelState.Installing -> { LinearProgressIndicator(Modifier.fillMaxWidth()); Text("Installing…", color = ui.subtext) }
                else -> {
                    if (m is ModelState.Failed) Text(m.message, color = MaterialTheme.colorScheme.error)
                    Text("The wake word uses a small speech model (about 40 MB) that is downloaded once and then works offline.", color = ui.subtext)
                    Button({ vm.downloadVoiceModel() }) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(6.dp)); Text("Download model") }
                }
            }
        }
        Section("Speech") {
            SwitchRow("Speak replies aloud", null, s.speakReplies) { vm.set(Keys.SPEAK_REPLIES, it) }
            DropdownRow("Voice", s.ttsVoice.ifBlank { "System default" }, listOf("" to "System default") + voices.map { it.name to (it.label + if (it.offline) "" else " (online)") }) { vm.set(Keys.TTS_VOICE, it) }
            SliderRow("Speech rate", "%.2f×".format(s.speechRate), s.speechRate, 0.6f..1.6f) { vm.set(Keys.SPEECH_RATE, it) }
            SliderRow("Pitch", "%.2f".format(s.speechPitch), s.speechPitch, 0.7f..1.5f) { vm.set(Keys.SPEECH_PITCH, it) }
            OutlinedButton({ vm.testVoice() }) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Test voice") }
            SwitchRow("Prefer offline speech recognition", "For the mic button. Needs an offline language pack on some devices; otherwise Android may use an online service.", s.preferOfflineStt) { vm.set(Keys.PREFER_OFFLINE_STT, it) }
        }
        Section("Reliability") {
            Text("Android may stop background listening to save battery, especially on some phone brands. If it stops, exclude SAGO from battery optimisation. Detection can be less reliable in noisy places or far from the mic.", color = ui.subtext, style = MaterialTheme.typography.bodyMedium)
            OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
                Icon(Icons.Default.BatteryChargingFull, null); Spacer(Modifier.width(6.dp)); Text("Battery optimisation settings")
            }
        }
    }
}

// ───────────────────────── Appearance ─────────────────────────

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun AppearanceSettingsScreen(vm: SettingsViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    var preview by remember { mutableStateOf(Expression.HAPPY) }
    SettingsScaffold("Appearance", onBack) {
        Section("Theme") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("system" to "System", "light" to "Light", "dark" to "Dark").forEach { (k, label) ->
                    FilterChip(s.theme == k, { vm.set(Keys.THEME, k) }, label = { Text(label) })
                }
            }
            SwitchRow("Café background", "Show the supplied café-room artwork.", s.showBackground) { vm.set(Keys.SHOW_BACKGROUND, it) }
        }
        Section("Avatar") {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                AvatarView(AvatarUi(preview, AvatarMode.IDLE), false, 0f, (s.avatarSizeDp * 0.7f).dp, s.avatarAnimations, false)
            }
            Text("Preview an expression", style = MaterialTheme.typography.bodyMedium, color = LocalSagoUi.current.subtext)
            androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Expression.entries.forEach { e -> FilterChip(preview == e, { preview = e }, label = { Text(e.name.lowercase().replaceFirstChar { it.uppercase() }) }) }
            }
            SliderRow("Avatar size", "${s.avatarSizeDp} dp", s.avatarSizeDp.toFloat(), 140f..280f, 13) { vm.set(Keys.AVATAR_SIZE, it.toInt()) }
            SwitchRow("Animations", "Breathing, expression transitions and speaking motion.", s.avatarAnimations) { vm.set(Keys.AVATAR_ANIM, it) }
            SwitchRow("Emotion visualisation", "Tint the avatar glow and show a small emotion label. This reflects the tone of SAGO's reply, not a diagnosis of you.", s.showEmotion) { vm.set(Keys.SHOW_EMOTION, it) }
        }
    }
}

// ───────────────────────── Memory ─────────────────────────

@Composable
fun MemorySettingsScreen(vm: SettingsViewModel, onBack: () -> Unit) {
    val ui = LocalSagoUi.current
    val s by vm.settings.collectAsStateWithLifecycle()
    val memories by vm.memories.collectAsStateWithLifecycle()
    val profiles by vm.profiles.collectAsStateWithLifecycle()
    var adding by remember { mutableStateOf(false) }
    var addingProfile by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<MemoryEntity?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    var profileToDelete by remember { mutableStateOf<String?>(null) }

    SettingsScaffold("Memory", onBack) {
        Section("Automatic memory") {
            SwitchRow("Remember important things", "SAGO saves only short, long-term facts (preferences, projects). Sensitive details are never saved automatically.", s.autoMemory) { vm.set(Keys.AUTO_MEMORY, it) }
            Text("Tip: say or type “Sago remember …” to save something on purpose.", style = MaterialTheme.typography.labelSmall, color = ui.subtext)
        }
        Section("Saved memories (${memories.size})") {
            if (memories.isEmpty()) Text("Nothing saved yet.", color = ui.subtext)
            memories.forEach { m ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(m.text, color = ui.text)
                        Text(when (m.source) { "explicit" -> "You asked me to remember"; "manual" -> "Added by you"; else -> "Noticed automatically" }, style = MaterialTheme.typography.labelSmall, color = ui.subtext)
                    }
                    IconButton({ editing = m }) { Icon(Icons.Default.Edit, "Edit memory") }
                    IconButton({ vm.deleteMemory(m.id) }) { Icon(Icons.Default.Delete, "Delete memory") }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ adding = true }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("Add") }
                OutlinedButton({ confirmClear = true }, enabled = memories.isNotEmpty()) { Text("Clear all") }
            }
        }
        Section("Profiles") {
            Text("Each profile has its own memories and conversations; they are never mixed.", style = MaterialTheme.typography.labelSmall, color = ui.subtext)
            profiles.forEach { p ->
                Row(Modifier.fillMaxWidth().selectable(p.id == s.activeProfile, role = Role.RadioButton) { vm.switchProfile(p.id) }, verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(p.id == s.activeProfile, null)
                    Text(p.name, Modifier.weight(1f).padding(start = 12.dp), color = ui.text)
                    if (profiles.size > 1) IconButton({ profileToDelete = p.id }) { Icon(Icons.Default.Delete, "Delete profile") }
                }
            }
            OutlinedButton({ addingProfile = true }) { Icon(Icons.Default.PersonAdd, null); Spacer(Modifier.width(4.dp)); Text("Add profile") }
        }
    }
    if (adding) TextInputDialog("Add memory", "", "Something to remember", { vm.addMemory(it) }) { adding = false }
    if (addingProfile) TextInputDialog("New profile", "", "Name", { vm.createProfile(it) }) { addingProfile = false }
    editing?.let { m -> TextInputDialog("Edit memory", m.text, "Memory", { vm.editMemory(m, it) }) { editing = null } }
    if (confirmClear) ConfirmDialog("Clear all memories?", "Everything SAGO remembers for this profile will be deleted.", "Clear", onConfirm = { vm.clearMemories() }, onDismiss = { confirmClear = false })
    profileToDelete?.let { id ->
        ConfirmDialog("Delete profile?", "Its conversations and memories will be permanently deleted.", "Delete", onConfirm = { vm.deleteProfile(id) }, onDismiss = { profileToDelete = null })
    }
}

// ───────────────────────── Privacy ─────────────────────────

@Composable
fun PrivacySettingsScreen(vm: SettingsViewModel, onBack: () -> Unit, onSignedOut: () -> Unit) {
    val ctx = LocalContext.current
    val ui = LocalSagoUi.current
    val wakeStatus by vm.wakeStatus.collectAsStateWithLifecycle()
    var tick by remember { mutableIntStateOf(0) }
    LifecycleResumeEffect(Unit) { tick++; onPauseOrDispose { } }
    val micOk = remember(tick) { has(ctx, Manifest.permission.RECORD_AUDIO) }
    val notifOk = remember(tick) { Build.VERSION.SDK_INT < 33 || has(ctx, Manifest.permission.POST_NOTIFICATIONS) }
    var dialog by remember { mutableStateOf<String?>(null) }
    val listening = wakeStatus == WakeStatus.LISTENING || wakeStatus == WakeStatus.ENGAGED || wakeStatus == WakeStatus.STARTING

    fun appSettings() = ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    SettingsScaffold("Privacy", onBack) {
        Section("Listening") {
            Text(if (listening) "SAGO is listening for the wake word right now." else "SAGO is not listening in the background.", color = ui.text)
            Button({ WakeWordService.stop(ctx); vm.set(Keys.WAKE_ENABLED, false) }, enabled = listening) { Icon(Icons.Default.MicOff, null); Spacer(Modifier.width(6.dp)); Text("Stop listening now") }
            Text("Wake-word audio is processed on this device and discarded. Only the text of a request is sent to Groq, and only after you've addressed SAGO. Android shows its own microphone indicator whenever the mic is active.", style = MaterialTheme.typography.labelSmall, color = ui.subtext)
        }
        Section("Permissions") {
            ActionRow("Microphone", if (micOk) "Allowed" else "Not allowed. Tap to change", Icons.Default.Mic) { appSettings() }
            ActionRow("Notifications", if (notifOk) "Allowed" else "Not allowed. The listening notification may be hidden", Icons.Default.Notifications) { appSettings() }
            ActionRow("Camera", "SAGO uses your camera app to take photos, so it never holds camera permission", Icons.Default.PhotoCamera) { appSettings() }
        }
        Section("Your data (stored on this device)") {
            ActionRow("Delete all conversations", "For the current profile", Icons.Default.DeleteSweep, danger = true) { dialog = "conversations" }
            ActionRow("Remove Groq API key", "You'll be asked for a key again", Icons.Default.Key, danger = true) { dialog = "key" }
            ActionRow("Erase everything", "Conversations, memories, profiles, key, voice model and settings", Icons.Default.DeleteForever, danger = true) { dialog = "all" }
        }
    }
    when (dialog) {
        "conversations" -> ConfirmDialog("Delete all conversations?", "Every conversation for this profile will be permanently deleted.", "Delete", onConfirm = { vm.deleteConversations() }, onDismiss = { dialog = null })
        "key" -> ConfirmDialog("Remove API key?", "SAGO won't be able to answer until you add a key again.", "Remove", onConfirm = { WakeWordService.stop(ctx); vm.deleteApiKey(onSignedOut) }, onDismiss = { dialog = null })
        "all" -> ConfirmDialog("Erase everything?", "This permanently deletes all SAGO data on this device and cannot be undone.", "Erase", onConfirm = { WakeWordService.stop(ctx); vm.resetEverything(onSignedOut) }, onDismiss = { dialog = null })
    }
}
