package com.sago.app.avatar

import android.content.Context
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sago.app.domain.model.Emotion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** Small in-memory cache so frame swaps (mouth open/closed, transitions) never hit the disk mid-animation. */
object AvatarBitmaps {
    private val cache = LruCache<Int, ImageBitmap>(48)
    fun peek(id: Int): ImageBitmap? = cache.get(id)
    suspend fun load(ctx: Context, id: Int): ImageBitmap? {
        cache.get(id)?.let { return it }
        return withContext(Dispatchers.IO) {
            runCatching { BitmapFactory.decodeResource(ctx.resources, id)?.asImageBitmap() }.getOrNull()?.also { cache.put(id, it) }
        }
    }
}

fun emotionColor(e: Emotion): Color = when (e) {
    Emotion.HAPPY -> Color(0xFFF472B6); Emotion.EXCITED -> Color(0xFFFBBF24); Emotion.SAD -> Color(0xFF93C5FD)
    Emotion.SERIOUS -> Color(0xFFA78BFA); Emotion.CURIOUS -> Color(0xFF5EEAD4); Emotion.CONFUSED -> Color(0xFFFDBA74)
    Emotion.FRUSTRATED -> Color(0xFFF87171); Emotion.CALM -> Color(0xFF86EFAC); Emotion.SURPRISED -> Color(0xFFFDE047)
    Emotion.PLAYFUL -> Color(0xFFF9A8D4); Emotion.NEUTRAL -> Color(0xFFE9D5FF)
}

/**
 * Draws SAGO's supplied face artwork. Expression changes play the two supplied in-between frames; while speaking the
 * mouth swaps between the silent and talking frames in step with TTS word boundaries ([mouthOpen]).
 */
@Composable
fun AvatarView(
    ui: AvatarUi, mouthOpen: Boolean, micLevel: Float, avatarSize: Dp, animations: Boolean, emotionGlow: Boolean,
    modifier: Modifier = Modifier,
) {
    val ctx = LocalContext.current
    val sizePx = with(LocalDensity.current) { avatarSize.toPx() }
    var shown by remember { mutableStateOf(ui.expression) }
    var transitionRes by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(ui.expression, animations) {
        if (ui.expression == shown) return@LaunchedEffect
        if (animations) {
            val frames = AvatarFrames.transitions[shown to ui.expression].orEmpty()
            frames.forEach { AvatarBitmaps.load(ctx, it) }
            for (f in frames) { transitionRes = f; delay(75) }
        }
        transitionRes = null
        shown = ui.expression
    }
    LaunchedEffect(shown) {
        AvatarBitmaps.load(ctx, AvatarFrames.silent.getValue(shown))
        AvatarBitmaps.load(ctx, AvatarFrames.talk.getValue(shown))
    }

    val talking = mouthOpen && ui.mode == AvatarMode.SPEAKING && transitionRes == null
    val resId = transitionRes ?: (if (talking) AvatarFrames.talk else AvatarFrames.silent).getValue(shown)
    val fallback = remember { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(resId) { AvatarBitmaps.load(ctx, resId)?.let { fallback.value = it } }
    val bitmap = AvatarBitmaps.peek(resId) ?: fallback.value

    val inf = rememberInfiniteTransition(label = "avatar")
    val breathe by inf.animateFloat(1f, 1.025f, infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breathe")
    val sway by inf.animateFloat(-2.2f, 2.2f, infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "sway")
    val pulse by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1500, easing = LinearEasing)), label = "pulse")
    val speakScale by animateFloatAsState(if (talking && animations) 1.03f else 1f, tween(90), label = "speak")
    val glow = if (emotionGlow) emotionColor(ui.emotion) else Color(0xFFF472B6)

    Box(modifier.size(avatarSize * 1.3f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(avatarSize * 1.3f)) {
            val c = Offset(this.size.width / 2, this.size.height / 2)
            val base = sizePx * 0.5f
            when (ui.mode) {
                AvatarMode.LISTENING -> {
                    for (i in 0..1) {
                        val p = (pulse + i * 0.5f) % 1f
                        drawCircle(glow.copy(alpha = (1f - p) * 0.5f), base * (1.02f + 0.28f * p + micLevel * 0.12f), c, style = Stroke(4.dp.toPx()))
                    }
                }
                AvatarMode.THINKING -> {
                    val r = base * 1.12f
                    drawArc(glow.copy(0.85f), pulse * 360f, 80f, false, Offset(c.x - r, c.y - r), Size(r * 2, r * 2), style = Stroke(5.dp.toPx()))
                    drawArc(glow.copy(0.4f), pulse * 360f + 180f, 50f, false, Offset(c.x - r, c.y - r), Size(r * 2, r * 2), style = Stroke(5.dp.toPx()))
                }
                AvatarMode.SPEAKING -> drawCircle(glow.copy(alpha = if (talking) 0.34f else 0.2f), base * 1.14f, c)
                AvatarMode.IDLE -> if (emotionGlow && ui.emotion != Emotion.NEUTRAL) drawCircle(glow.copy(alpha = 0.16f), base * 1.1f, c)
            }
        }
        bitmap?.let {
            Image(
                bitmap = it, contentDescription = "SAGO, ${ui.expression.name.lowercase()} expression", contentScale = ContentScale.Fit,
                modifier = Modifier.size(avatarSize).graphicsLayer {
                    val s = if (animations) breathe * speakScale else 1f
                    scaleX = s; scaleY = s
                    rotationZ = if (animations && ui.mode == AvatarMode.THINKING) sway else 0f
                    translationY = if (animations && ui.mode == AvatarMode.IDLE) (breathe - 1f) * -sizePx * 1.6f else 0f
                },
            )
        }
    }
}
