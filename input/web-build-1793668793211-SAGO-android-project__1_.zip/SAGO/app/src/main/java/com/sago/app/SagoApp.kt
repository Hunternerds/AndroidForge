package com.sago.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager

class SagoApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_WAKE, getString(R.string.notif_channel_listening), NotificationManager.IMPORTANCE_LOW).apply {
                description = getString(R.string.notif_channel_listening_desc)
                setShowBadge(false)
            }
        )
    }

    companion object { const val CHANNEL_WAKE = "sago_wake_listening" }
}
