package com.sago.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sago.app.R
import com.sago.app.ui.theme.LocalSagoUi
import com.sago.app.ui.theme.Palette

/** The supplied café-room artwork with a theme-aware scrim so text stays readable. */
@Composable
fun Backdrop(show: Boolean, heavy: Boolean = false) {
    val ui = LocalSagoUi.current
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        if (show) {
            Image(painterResource(R.drawable.bg_cafe), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(ui.scrim.copy(alpha = if (heavy) 0.8f else 0.35f), ui.scrim.copy(alpha = if (heavy) 0.9f else 0.78f)))))
        }
    }
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val ui = LocalSagoUi.current
    Surface(modifier, shape = RoundedCornerShape(20.dp), color = ui.glass, border = BorderStroke(1.dp, ui.glassBorder), contentColor = ui.text) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScaffold(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val ui = LocalSagoUi.current
    Box(Modifier.fillMaxSize()) {
        Backdrop(show = true, heavy = true)
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = { Text(title, fontWeight = FontWeight.Bold) },
                    navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent, titleContentColor = ui.text, navigationIconContentColor = ui.text),
                )
            },
        ) { pad ->
            Column(
                Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp).navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(14.dp), content = content,
            )
        }
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    GlassCard(Modifier.fillMaxWidth()) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        content()
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    val ui = LocalSagoUi.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = ui.text)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = ui.subtext)
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked, onChange)
    }
}

@Composable
fun SliderRow(title: String, valueText: String, value: Float, range: ClosedFloatingPointRange<Float>, steps: Int = 0, onCommit: (Float) -> Unit) {
    val ui = LocalSagoUi.current
    var v by remember(value) { mutableFloatStateOf(value) }
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = ui.text); Text(valueText, color = ui.subtext)
        }
        Slider(v, { v = it }, valueRange = range, steps = steps, onValueChangeFinished = { onCommit(v) })
    }
}

@Composable
fun DropdownRow(title: String, selectedLabel: String, options: List<Pair<String, String>>, enabled: Boolean = true, onSelect: (String) -> Unit) {
    val ui = LocalSagoUi.current
    var open by remember { mutableStateOf(false) }
    Column {
        Text(title, color = ui.subtext, style = MaterialTheme.typography.bodyMedium)
        Box {
            OutlinedButton(onClick = { open = true }, enabled = enabled && options.isNotEmpty(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Text(selectedLabel.ifBlank { "Default" }, Modifier.weight(1f), maxLines = 1, color = ui.text)
                Icon(Icons.Default.ArrowDropDown, null, tint = ui.text)
            }
            DropdownMenu(open, { open = false }) {
                options.forEach { (value, label) -> DropdownMenuItem(text = { Text(label) }, onClick = { open = false; onSelect(value) }) }
            }
        }
    }
}

@Composable
fun ActionRow(title: String, subtitle: String? = null, icon: ImageVector, danger: Boolean = false, onClick: () -> Unit) {
    val ui = LocalSagoUi.current
    val tint = if (danger) MaterialTheme.colorScheme.error else ui.text
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = if (danger) tint else Palette.Pink)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = tint)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = ui.subtext)
        }
    }
}

@Composable
fun ConfirmDialog(title: String, text: String, confirmLabel: String, danger: Boolean = true, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) }, text = { Text(text) },
        confirmButton = { TextButton(onClick = { onConfirm(); onDismiss() }) { Text(confirmLabel, color = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun TextInputDialog(title: String, initial: String, label: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, label = { Text(label) }, minLines = 1, maxLines = 4, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { if (text.isNotBlank()) { onSave(text); onDismiss() } }, enabled = text.isNotBlank()) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
