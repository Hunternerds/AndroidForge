package com.sago.app.avatar

/** The nine face artworks supplied with the project. */
enum class Expression {
    NORMAL, HAPPY, PLAYFUL, THINKING, SURPRISED, ANGRY, BLUSHING, SLEEPY, STUDY;

    companion object {
        fun parse(raw: String?): Expression? = entries.firstOrNull { it.name.equals(raw?.trim(), ignoreCase = true) }
    }
}

enum class AvatarMode { IDLE, LISTENING, THINKING, SPEAKING }
