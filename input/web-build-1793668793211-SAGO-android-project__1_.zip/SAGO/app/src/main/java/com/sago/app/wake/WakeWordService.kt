package com.sago.app.wake

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.sago.app.MainActivity
import com.sago.app.R
import com.sago.app.SagoApp
import com.sago.app.data.prefs.Keys
import com.sago.app.domain.memory.MemoryCommandParser
import com.sago.app.voice.AssistantState
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

/**
 * Foreground (microphone-type) service hosting the offline "Sago" wake-word loop.
 * Wake detection is local; nothing is uploaded until a request has been transcribed and sent as text to Groq.
 */
class WakeWordService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loop: Job? = null
    private val container get() = (application as SagoApp).container

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { userStop(); return START_NOT_STICKY }
        container.wake.status.value = WakeStatus.STARTING
        try {
            val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
            ServiceCompat.startForeground(this, NOTIF_ID, buildNotification("Starting…"), type)
        } catch (e: Exception) {
            // e.g. Android 14+ forbids starting a microphone service while the app is in the background.
            fail(WakeStatus.ERROR, "Android didn't allow background listening to start. Open SAGO and turn it on again.")
            return START_NOT_STICKY
        }
        if (loop?.isActive != true) loop = scope.launch { runLoop() }
        scope.launch { observeForNotification() }
        return START_STICKY
    }

    private suspend fun runLoop() {
        val c = container
        if (!c.settings.snapshot().wakeEnabled) { stopSelfClean(); return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            fail(WakeStatus.NO_PERMISSION, "Microphone permission is needed for wake-word listening."); return
        }
        if (!c.wakeModel.installed()) { fail(WakeStatus.MODEL_MISSING, "Download the offline voice model in Settings → Voice first."); return }

        val engine = try { withContext(Dispatchers.IO) { VoskWakeEngine(c.wakeModel.modelDir.absolutePath) } }
        catch (e: Throwable) { fail(WakeStatus.ERROR, "The offline voice model couldn't be loaded. Re-download it in Settings → Voice."); return }

        try {
            while (currentCoroutineContext().isActive) {
                // Only listen when nothing else is using the mic or speaking (so SAGO never hears itself).
                c.assistant.state.first { it == AssistantState.IDLE }
                c.wake.manualMic.first { !it }
                val s = c.settings.snapshot()
                if (!s.wakeEnabled) break

                var preRoll: ShortArray? = null
                var text: String? = null
                var woke = false
                try {
                    val mic = MicStream()
                    mic.use {
                        c.wake.status.value = WakeStatus.LISTENING
                        woke = withContext(Dispatchers.IO) {
                            engine.awaitWake(it, s.wakeSensitivity) {
                                !isActive || c.assistant.state.value != AssistantState.IDLE || c.wake.manualMic.value
                            }
                        }
                        if (woke) {
                            preRoll = it.preRoll(1600)
                            c.wake.status.value = WakeStatus.ENGAGED
                            c.assistant.onWakeDetected()
                            text = captureCommand(engine, it, preRoll, 6_000)
                        }
                    }
                } catch (e: CancellationException) { throw e }
                catch (e: Exception) {
                    c.wake.detail.value = "Microphone problem: ${e.message}. Retrying…"
                    c.assistant.onWakeEnded()
                    delay(2_000); continue
                }
                if (!woke) { delay(150); continue }
                if (text.isNullOrBlank()) { c.assistant.onWakeEnded() } else { c.assistant.handleWakeTranscript(text!!) }

                // Follow-up window: keep the conversation going without needing the wake word again.
                var follow = text?.isNotBlank() == true
                while (follow && currentCoroutineContext().isActive && s.followUpSeconds > 0 && c.settings.snapshot().wakeEnabled) {
                    delay(400) // let the speaker tail die out so SAGO doesn't transcribe itself
                    if (c.assistant.state.value != AssistantState.IDLE || c.wake.manualMic.value) break
                    var next: String? = null
                    try {
                        MicStream().use {
                            c.assistant.onFollowUpListening()
                            next = captureCommand(engine, it, null, s.followUpSeconds * 1000L)
                        }
                    } catch (e: CancellationException) { throw e } catch (e: Exception) { break }
                    if (next.isNullOrBlank()) { c.assistant.onWakeEnded(); follow = false } else c.assistant.handleWakeTranscript(next!!)
                }
            }
        } finally {
            engine.close()
        }
    }

    private suspend fun captureCommand(engine: VoskWakeEngine, mic: MicStream, preRoll: ShortArray?, noSpeechMs: Long): String? {
        val c = container
        val raw = withContext(Dispatchers.IO) {
            engine.capture(
                mic, preRoll, noSpeechMs, 20_000,
                onPartial = { c.assistant.onWakePartial(it) }, onLevel = { c.assistant.onWakeLevel(it) },
                isMeaningful = { t -> if (preRoll != null) t.isNotBlank() && !MemoryCommandParser.isOnlyWake(t) else t.isNotBlank() },
                cancelled = { !isActive || c.assistant.state.value != AssistantState.LISTENING },
            )
        }
        return raw?.let { if (preRoll != null) MemoryCommandParser.dropThroughWake(it) else it }
    }

    private suspend fun observeForNotification() {
        val c = container
        kotlinx.coroutines.flow.combine(c.assistant.state, c.wake.status) { a, w -> a to w }.collect { (a, w) ->
            val text = when {
                a == AssistantState.THINKING -> "Thinking…"
                a == AssistantState.SPEAKING -> "Speaking…"
                a == AssistantState.LISTENING -> "Listening to you…"
                w == WakeStatus.LISTENING -> "Listening for “Sago”"
                else -> "Starting…"
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification(text))
        }
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WakeWordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, SagoApp.CHANNEL_WAKE)
            .setSmallIcon(R.drawable.ic_stat_sago).setContentTitle("SAGO").setContentText(text)
            .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE).setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .addAction(0, "Stop listening", stop).build()
    }

    private fun fail(status: WakeStatus, detail: String) {
        container.wake.status.value = status; container.wake.detail.value = detail
        container.scope.launch { container.settings.set(Keys.WAKE_ENABLED, false) }
        stopSelfClean()
    }

    private fun userStop() {
        container.scope.launch { container.settings.set(Keys.WAKE_ENABLED, false) }
        container.wake.status.value = WakeStatus.OFF
        container.assistant.onWakeEnded()
        stopSelfClean()
    }

    private fun stopSelfClean() {
        loop?.cancel()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        scope.cancel()
        if (container.wake.status.value == WakeStatus.LISTENING || container.wake.status.value == WakeStatus.ENGAGED || container.wake.status.value == WakeStatus.STARTING)
            container.wake.status.value = WakeStatus.OFF
        super.onDestroy()
    }

    companion object {
        private const val NOTIF_ID = 4201
        private const val ACTION_STOP = "com.sago.app.STOP_LISTENING"

        fun start(context: Context) { ContextCompat.startForegroundService(context, Intent(context, WakeWordService::class.java)) }
        fun stop(context: Context) { context.startService(Intent(context, WakeWordService::class.java).setAction(ACTION_STOP)) }
    }
}
