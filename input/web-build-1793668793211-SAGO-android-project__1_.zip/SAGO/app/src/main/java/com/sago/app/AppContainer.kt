package com.sago.app

import android.app.Application
import com.sago.app.core.SecureStore
import com.sago.app.data.ChatRepository
import com.sago.app.data.db.SagoDatabase
import com.sago.app.data.groq.GroqClient
import com.sago.app.data.prefs.DEFAULT_PROFILE_ID
import com.sago.app.data.prefs.SettingsStore
import com.sago.app.domain.ai.ConversationEngine
import com.sago.app.domain.memory.MemoryEngine
import com.sago.app.vision.ImageProcessor
import com.sago.app.voice.AssistantController
import com.sago.app.voice.SpeechRecognizerController
import com.sago.app.voice.TtsController
import com.sago.app.wake.WakeCoordinator
import com.sago.app.wake.WakeWordModelManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Hand-wired dependency container (small enough that a DI framework would add more weight than value). */
class AppContainer(private val app: Application) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val secure = SecureStore(app)
    @Volatile private var apiKey: String? = secure.getString(KEY_NAME)

    val settings = SettingsStore(app)
    val http = GroqClient.newHttpClient()
    val groq = GroqClient(http) { apiKey }

    val db: SagoDatabase by lazy { SagoDatabase.build(app) }
    val repo: ChatRepository by lazy { ChatRepository(db) }
    val memory: MemoryEngine by lazy { MemoryEngine(db.memories()) }
    val engine: ConversationEngine by lazy { ConversationEngine(settings, groq, repo, memory) }

    val tts = TtsController(app)
    val stt = SpeechRecognizerController(app)
    val wake = WakeCoordinator()
    val wakeModel = WakeWordModelManager(app, http)
    val images = ImageProcessor(app)
    val assistant: AssistantController by lazy { AssistantController(app, scope, settings, engine, tts, stt, wake) }

    fun appFilesDir(): java.io.File = app.filesDir

    fun hasApiKey(): Boolean = !apiKey.isNullOrBlank()
    fun maskedKey(): String = apiKey?.let { if (it.length > 10) it.take(4) + "••••••••" + it.takeLast(4) else "••••••••" }.orEmpty()

    /** @return false if the key couldn't be stored securely. */
    fun saveApiKey(key: String): Boolean {
        val ok = secure.putString(KEY_NAME, key.trim())
        if (ok) apiKey = key.trim()
        return ok
    }

    fun clearApiKey() { secure.remove(KEY_NAME); apiKey = null }

    suspend fun ensureProfile() = repo.ensureDefaultProfile(DEFAULT_PROFILE_ID, "Me")

    private companion object { const val KEY_NAME = "groq_api_key" }
}
