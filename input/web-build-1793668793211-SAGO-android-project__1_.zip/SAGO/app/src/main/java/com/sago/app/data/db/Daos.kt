package com.sago.app.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profiles ORDER BY createdAt") fun observeAll(): Flow<List<ProfileEntity>>
    @Query("SELECT COUNT(*) FROM profiles") suspend fun count(): Int
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(p: ProfileEntity)
    @Query("DELETE FROM profiles WHERE id = :id") suspend fun delete(id: String)
}

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations WHERE profileId = :profileId ORDER BY updatedAt DESC")
    fun observeAll(profileId: String): Flow<List<ConversationEntity>>
    @Query("SELECT * FROM conversations WHERE id = :id") suspend fun get(id: Long): ConversationEntity?
    @Insert suspend fun insert(c: ConversationEntity): Long
    @Query("UPDATE conversations SET updatedAt = :t WHERE id = :id") suspend fun touch(id: Long, t: Long)
    @Query("DELETE FROM conversations WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM conversations WHERE profileId = :profileId") suspend fun deleteAllFor(profileId: String)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :cid ORDER BY createdAt, id")
    fun observe(cid: Long): Flow<List<MessageEntity>>
    @Query("SELECT * FROM (SELECT * FROM messages WHERE conversationId = :cid ORDER BY createdAt DESC, id DESC LIMIT :limit) ORDER BY createdAt, id")
    suspend fun recent(cid: Long, limit: Int): List<MessageEntity>
    @Insert suspend fun insert(m: MessageEntity): Long
    @Query("SELECT imagePath FROM messages WHERE imagePath IS NOT NULL AND conversationId IN (SELECT id FROM conversations WHERE profileId = :profileId)")
    suspend fun imagePathsFor(profileId: String): List<String>
    @Query("SELECT imagePath FROM messages WHERE imagePath IS NOT NULL AND conversationId = :cid")
    suspend fun imagePathsIn(cid: Long): List<String>
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories WHERE profileId = :profileId ORDER BY updatedAt DESC")
    fun observe(profileId: String): Flow<List<MemoryEntity>>
    @Query("SELECT * FROM memories WHERE profileId = :profileId") suspend fun all(profileId: String): List<MemoryEntity>
    @Insert suspend fun insert(m: MemoryEntity): Long
    @Update suspend fun update(m: MemoryEntity)
    @Query("UPDATE memories SET lastUsedAt = :t WHERE id IN (:ids)") suspend fun markUsed(ids: List<Long>, t: Long)
    @Query("DELETE FROM memories WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM memories WHERE profileId = :profileId") suspend fun clear(profileId: String)
}
