package com.sago.app.data

import com.sago.app.data.db.*
import com.sago.app.domain.model.ChatMessage
import com.sago.app.domain.model.Emotion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/** Conversations, messages and profiles. Every operation is scoped to a profile so data never crosses accounts. */
class ChatRepository(private val db: SagoDatabase) {

    fun conversations(profileId: String): Flow<List<ConversationEntity>> = db.conversations().observeAll(profileId)

    fun messages(conversationId: Long): Flow<List<ChatMessage>> =
        db.messages().observe(conversationId).map { list -> list.map { it.toModel() } }

    suspend fun conversation(id: Long, profileId: String): ConversationEntity? =
        db.conversations().get(id)?.takeIf { it.profileId == profileId }

    suspend fun createConversation(profileId: String, firstText: String): Long {
        val now = System.currentTimeMillis()
        val title = firstText.trim().replace(Regex("\\s+"), " ").take(48).ifBlank { "New conversation" }
        return db.conversations().insert(ConversationEntity(profileId = profileId, title = title, createdAt = now, updatedAt = now))
    }

    suspend fun addMessage(conversationId: Long, role: ChatMessage.Role, text: String, emotion: Emotion? = null, imagePath: String? = null): Long {
        val now = System.currentTimeMillis()
        val id = db.messages().insert(
            MessageEntity(conversationId = conversationId, role = role.name, text = text, emotion = emotion?.name, imagePath = imagePath, createdAt = now)
        )
        db.conversations().touch(conversationId, now)
        return id
    }

    suspend fun recent(conversationId: Long, limit: Int): List<ChatMessage> = db.messages().recent(conversationId, limit).map { it.toModel() }

    suspend fun deleteConversation(id: Long) = withContext(Dispatchers.IO) {
        db.messages().imagePathsIn(id).forEach { runCatching { File(it).delete() } }
        db.conversations().delete(id)
    }

    suspend fun deleteAllConversations(profileId: String) = withContext(Dispatchers.IO) {
        db.messages().imagePathsFor(profileId).forEach { runCatching { File(it).delete() } }
        db.conversations().deleteAllFor(profileId)
    }

    // ---- profiles ----
    fun profiles(): Flow<List<ProfileEntity>> = db.profiles().observeAll()

    suspend fun ensureDefaultProfile(id: String, name: String) {
        if (db.profiles().count() == 0) db.profiles().insert(ProfileEntity(id, name, System.currentTimeMillis()))
    }

    suspend fun createProfile(name: String): String {
        val id = UUID.randomUUID().toString()
        db.profiles().insert(ProfileEntity(id, name.trim().take(24).ifBlank { "Profile" }, System.currentTimeMillis()))
        return id
    }

    /** Deletes the profile together with its conversations and memories. */
    suspend fun deleteProfile(id: String) {
        deleteAllConversations(id)
        db.memories().clear(id)
        db.profiles().delete(id)
    }

    private fun MessageEntity.toModel() = ChatMessage(
        id = id, conversationId = conversationId,
        role = if (role == ChatMessage.Role.USER.name) ChatMessage.Role.USER else ChatMessage.Role.ASSISTANT,
        text = text, emotion = emotion?.let { Emotion.parse(it) }, imagePath = imagePath, createdAt = createdAt,
    )
}
