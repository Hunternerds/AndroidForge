package com.sago.app.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.*
import java.io.IOException

private val Context.sagoDataStore: DataStore<Preferences> by preferencesDataStore("sago_settings")

object Keys {
    val ONBOARDED = booleanPreferencesKey("onboarded")
    val TEXT_MODEL = stringPreferencesKey("text_model")
    val VISION_MODEL = stringPreferencesKey("vision_model")
    val SYSTEM_PROMPT = stringPreferencesKey("system_prompt")
    val TEMPERATURE = floatPreferencesKey("temperature")
    val MAX_TOKENS = intPreferencesKey("max_tokens")
    val HISTORY_LIMIT = intPreferencesKey("history_limit")
    val AUTO_MEMORY = booleanPreferencesKey("auto_memory")
    val SPEAK_REPLIES = booleanPreferencesKey("speak_replies")
    val TTS_VOICE = stringPreferencesKey("tts_voice")
    val SPEECH_RATE = floatPreferencesKey("speech_rate")
    val SPEECH_PITCH = floatPreferencesKey("speech_pitch")
    val PREFER_OFFLINE_STT = booleanPreferencesKey("offline_stt")
    val WAKE_ENABLED = booleanPreferencesKey("wake_enabled")
    val WAKE_SENSITIVITY = floatPreferencesKey("wake_sensitivity")
    val FOLLOW_UP_SECONDS = intPreferencesKey("follow_up_seconds")
    val THEME = stringPreferencesKey("theme")
    val SHOW_EMOTION = booleanPreferencesKey("show_emotion")
    val AVATAR_ANIM = booleanPreferencesKey("avatar_anim")
    val AVATAR_SIZE = intPreferencesKey("avatar_size_dp")
    val SHOW_BACKGROUND = booleanPreferencesKey("show_bg")
    val ACTIVE_PROFILE = stringPreferencesKey("active_profile")
    val ACTIVE_CONVERSATION = longPreferencesKey("active_conversation")
}

const val DEFAULT_TEXT_MODEL = "openai/gpt-oss-120b"
const val DEFAULT_VISION_MODEL = "qwen/qwen3.6-27b"
const val DEFAULT_PROFILE_ID = "default"

data class AppSettings(
    val onboarded: Boolean = false,
    val textModel: String = DEFAULT_TEXT_MODEL,
    val visionModel: String = DEFAULT_VISION_MODEL,
    /** Empty = use the built-in SAGO personality prompt. */
    val systemPrompt: String = "",
    val temperature: Float = 0.8f,
    val maxTokens: Int = 700,
    val historyLimit: Int = 12,
    val autoMemory: Boolean = true,
    val speakReplies: Boolean = true,
    val ttsVoice: String = "",
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.1f,
    val preferOfflineStt: Boolean = false,
    val wakeEnabled: Boolean = false,
    val wakeSensitivity: Float = 0.5f,
    val followUpSeconds: Int = 6,
    val theme: String = "dark",
    val showEmotion: Boolean = true,
    val avatarAnimations: Boolean = true,
    val avatarSizeDp: Int = 210,
    val showBackground: Boolean = true,
    val activeProfile: String = DEFAULT_PROFILE_ID,
    val activeConversation: Long = 0L,
)

class SettingsStore(private val context: Context) {
    val flow: Flow<AppSettings> = context.sagoDataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            val d = AppSettings()
            AppSettings(
                onboarded = p[Keys.ONBOARDED] ?: d.onboarded,
                textModel = p[Keys.TEXT_MODEL] ?: d.textModel,
                visionModel = p[Keys.VISION_MODEL] ?: d.visionModel,
                systemPrompt = p[Keys.SYSTEM_PROMPT] ?: d.systemPrompt,
                temperature = p[Keys.TEMPERATURE] ?: d.temperature,
                maxTokens = p[Keys.MAX_TOKENS] ?: d.maxTokens,
                historyLimit = p[Keys.HISTORY_LIMIT] ?: d.historyLimit,
                autoMemory = p[Keys.AUTO_MEMORY] ?: d.autoMemory,
                speakReplies = p[Keys.SPEAK_REPLIES] ?: d.speakReplies,
                ttsVoice = p[Keys.TTS_VOICE] ?: d.ttsVoice,
                speechRate = p[Keys.SPEECH_RATE] ?: d.speechRate,
                speechPitch = p[Keys.SPEECH_PITCH] ?: d.speechPitch,
                preferOfflineStt = p[Keys.PREFER_OFFLINE_STT] ?: d.preferOfflineStt,
                wakeEnabled = p[Keys.WAKE_ENABLED] ?: d.wakeEnabled,
                wakeSensitivity = p[Keys.WAKE_SENSITIVITY] ?: d.wakeSensitivity,
                followUpSeconds = p[Keys.FOLLOW_UP_SECONDS] ?: d.followUpSeconds,
                theme = p[Keys.THEME] ?: d.theme,
                showEmotion = p[Keys.SHOW_EMOTION] ?: d.showEmotion,
                avatarAnimations = p[Keys.AVATAR_ANIM] ?: d.avatarAnimations,
                avatarSizeDp = p[Keys.AVATAR_SIZE] ?: d.avatarSizeDp,
                showBackground = p[Keys.SHOW_BACKGROUND] ?: d.showBackground,
                activeProfile = p[Keys.ACTIVE_PROFILE] ?: d.activeProfile,
                activeConversation = p[Keys.ACTIVE_CONVERSATION] ?: d.activeConversation,
            )
        }

    suspend fun snapshot(): AppSettings = flow.first()

    suspend fun <T> set(key: Preferences.Key<T>, value: T) {
        runCatching { context.sagoDataStore.edit { it[key] = value } }
    }

    suspend fun <T> remove(key: Preferences.Key<T>) {
        runCatching { context.sagoDataStore.edit { it.remove(key) } }
    }

    suspend fun clearAll() { runCatching { context.sagoDataStore.edit { it.clear() } } }
}
