package com.sago.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ProfileEntity::class, ConversationEntity::class, MessageEntity::class, MemoryEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class SagoDatabase : RoomDatabase() {
    abstract fun profiles(): ProfileDao
    abstract fun conversations(): ConversationDao
    abstract fun messages(): MessageDao
    abstract fun memories(): MemoryDao

    companion object {
        fun build(context: Context): SagoDatabase =
            Room.databaseBuilder(context, SagoDatabase::class.java, "sago.db").build()
    }
}
