package com.sago.app.vision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.sago.app.domain.model.PickedImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.util.UUID
import kotlin.math.max

/**
 * Prepares a user-chosen photo for Groq vision: fixes EXIF rotation, downsizes (max 1600 px) and re-encodes as JPEG
 * well under Groq's 4 MB limit for base64 requests. A small copy is kept locally so the chat can show it.
 */
class ImageProcessor(private val context: Context) {

    suspend fun fromUri(uri: Uri): PickedImage = withContext(Dispatchers.IO) {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IOException("Couldn't open that image.")
        process(bytes)
    }

    suspend fun fromFile(file: File): PickedImage = withContext(Dispatchers.IO) { process(file.readBytes()) }

    private fun process(src: ByteArray): PickedImage {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(src, 0, src.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException("That file isn't a supported image.")

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE * 2) sample *= 2
        val decoded = BitmapFactory.decodeByteArray(src, 0, src.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: throw IOException("Couldn't decode that image.")

        val degrees = runCatching {
            when (ExifInterface(ByteArrayInputStream(src)).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        }.getOrDefault(0f)

        val scale = (MAX_SIDE.toFloat() / max(decoded.width, decoded.height)).coerceAtMost(1f)
        val matrix = Matrix().apply { postRotate(degrees); postScale(scale, scale) }
        val bmp = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)

        var quality = 85
        var jpeg: ByteArray
        do {
            jpeg = ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }.toByteArray()
            quality -= 10
        } while (jpeg.size > MAX_BYTES && quality >= 45)
        if (jpeg.size > MAX_BYTES) throw IOException("That image is too large to send. Try a smaller one.")

        val thumbScale = (THUMB_SIDE.toFloat() / max(bmp.width, bmp.height)).coerceAtMost(1f)
        val thumb = Bitmap.createScaledBitmap(bmp, (bmp.width * thumbScale).toInt().coerceAtLeast(1), (bmp.height * thumbScale).toInt().coerceAtLeast(1), true)
        val dir = File(context.filesDir, "images").apply { mkdirs() }
        val out = File(dir, UUID.randomUUID().toString() + ".jpg")
        out.outputStream().use { thumb.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        return PickedImage(jpeg, out.absolutePath)
    }

    private companion object {
        const val MAX_SIDE = 1600
        const val THUMB_SIDE = 720
        const val MAX_BYTES = 2_500_000
    }
}
