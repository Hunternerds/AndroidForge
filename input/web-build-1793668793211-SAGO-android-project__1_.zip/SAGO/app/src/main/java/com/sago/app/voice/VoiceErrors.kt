package com.sago.app.voice

class SpeechError(message: String) : Exception(message)
