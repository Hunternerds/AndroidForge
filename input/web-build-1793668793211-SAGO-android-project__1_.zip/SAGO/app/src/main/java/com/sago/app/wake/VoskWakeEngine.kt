package com.sago.app.wake

import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.IOException

/**
 * Offline wake-word + command capture on top of Vosk.
 *
 *  1. [awaitWake] runs a *grammar-restricted* recogniser that can only output "sago" (plus a few phonetic
 *     variants) or [unk]. This is tiny, fully on-device, and never sends audio anywhere.
 *  2. [capture] then runs a normal recogniser on the SAME microphone stream, seeded with the audio just before
 *     the wake word, so "Sago remember my project is StudyOS" works in one breath without a mic hand-off gap.
 *
 * All methods block; call them from a background dispatcher.
 */
class VoskWakeEngine(modelPath: String) : AutoCloseable {
    private val model: Model

    init {
        LibVosk.setLogLevel(LogLevel.WARNINGS)
        model = Model(modelPath)
    }

    /** @return true if the wake word was heard, false if [shouldStop] asked us to yield the microphone. */
    fun awaitWake(mic: MicStream, sensitivity: Float, shouldStop: () -> Boolean): Boolean {
        val needed = when { sensitivity > 0.75f -> 1; sensitivity > 0.35f -> 2; else -> 3 }
        val minPeak = (1200 - 900 * sensitivity).toInt()          // energy gate: ignore near-silent "hallucinations"
        val recent = IntArray(6); var ri = 0
        var consecutive = 0
        Recognizer(model, MicStream.SAMPLE_RATE.toFloat(), GRAMMAR).use { rec ->
            while (!shouldStop()) {
                val n = mic.read()
                if (n < 0) throw IOException("Microphone read failed ($n)")
                if (n == 0) continue
                recent[ri++ % recent.size] = mic.lastPeak
                val energetic = recent.max() >= minPeak
                val isFinal = rec.acceptWaveForm(mic.buffer, n)
                val text = if (isFinal) field(rec.result, "text") else field(rec.partialResult, "partial")
                val padded = " $text "
                val hit = WAKE_WORDS.any { " $it " in padded }
                if (hit && energetic) consecutive++ else if (!hit) consecutive = 0
                if (consecutive >= needed || (isFinal && hit && energetic)) return true
            }
        }
        return false
    }

    /**
     * @param preRoll audio that preceded the wake word (null for follow-ups)
     * @param isMeaningful false for transcripts that contain only the wake word itself; capture then keeps listening
     * @return the transcript, or null if the user said nothing before [noSpeechMs] / was cancelled.
     */
    fun capture(
        mic: MicStream, preRoll: ShortArray?, noSpeechMs: Long, maxMs: Long,
        onPartial: (String) -> Unit, onLevel: (Float) -> Unit,
        isMeaningful: (String) -> Boolean, cancelled: () -> Boolean,
    ): String? {
        val started = System.currentTimeMillis()
        var heard = false
        var lastPartial = ""
        Recognizer(model, MicStream.SAMPLE_RATE.toFloat()).use { rec ->
            fun handleFinal(): String? {
                val t = field(rec.result, "text")
                if (t.isNotBlank() && isMeaningful(t)) return t
                heard = false; lastPartial = ""; onPartial("")
                return null
            }
            preRoll?.let { pr ->
                var i = 0
                while (i < pr.size) {
                    val len = minOf(MicStream.FRAME, pr.size - i)
                    val chunk = pr.copyOfRange(i, i + len)
                    if (rec.acceptWaveForm(chunk, len)) handleFinal()?.let { return it }
                    i += len
                }
            }
            while (!cancelled()) {
                val n = mic.read()
                if (n < 0) throw IOException("Microphone read failed ($n)")
                if (n == 0) continue
                onLevel((mic.lastPeak / 9000f).coerceIn(0f, 1f))
                if (rec.acceptWaveForm(mic.buffer, n)) {
                    handleFinal()?.let { return it }
                } else {
                    val p = field(rec.partialResult, "partial")
                    if (p.isNotBlank()) { heard = true; if (p != lastPartial) { lastPartial = p; onPartial(p) } }
                }
                val elapsed = System.currentTimeMillis() - started
                if (!heard && elapsed > noSpeechMs) return null
                if (elapsed > maxMs) {
                    val t = field(rec.finalResult, "text").ifBlank { lastPartial }
                    return t.takeIf { it.isNotBlank() && isMeaningful(it) }
                }
            }
        }
        return null
    }

    override fun close() { runCatching { model.close() } }

    private fun field(json: String, key: String): String = runCatching { JSONObject(json).optString(key) }.getOrDefault("").trim()

    private companion object {
        // Phonetic variants widen recognition of "Sago" (/ˈseɪɡoʊ/) across accents; all map to the one wake word.
        val WAKE_WORDS = setOf("sago", "saigo", "say go")
        const val GRAMMAR = "[\"sago\", \"saigo\", \"say go\", \"[unk]\"]"
    }
}
