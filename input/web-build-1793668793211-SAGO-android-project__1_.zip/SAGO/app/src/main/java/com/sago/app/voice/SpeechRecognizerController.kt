package com.sago.app.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Push-to-talk speech recognition using Android's SpeechRecognizer. The recogniser performs the voice-activity
 * detection (end-of-speech silence); [level] exposes the live mic level for the UI.
 */
class SpeechRecognizerController(private val context: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null

    val level = MutableStateFlow(0f)
    val partial = MutableStateFlow("")

    /** @return the final transcript, or null if nothing was heard. */
    suspend fun listen(preferOffline: Boolean): String? = withContext(Dispatchers.Main) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            throw SpeechError("No speech-recognition service is installed. Install or enable Google speech services, or type instead.")
        }
        suspendCancellableCoroutine { cont ->
            destroy()
            val r = if (preferOffline && Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context))
                SpeechRecognizer.createOnDeviceSpeechRecognizer(context) else SpeechRecognizer.createSpeechRecognizer(context)
            recognizer = r
            partial.value = ""
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onEndOfSpeech() { level.value = 0f }
                override fun onRmsChanged(rmsdB: Float) { level.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
                override fun onPartialResults(partialResults: Bundle?) {
                    partial.value = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                }
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    finish { cont.resume(text?.takeIf { it.isNotBlank() }) }
                }
                override fun onError(error: Int) {
                    finish {
                        when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> cont.resume(null)
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> cont.resumeWithException(SpeechError("SAGO needs microphone permission to listen. Allow it in Settings → Privacy."))
                            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
                                cont.resumeWithException(SpeechError("Speech recognition needs a connection right now. Turn on “Prefer offline recognition” in Settings → Voice, or type instead."))
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> cont.resumeWithException(SpeechError("The speech recogniser is busy. Try again in a moment."))
                            SpeechRecognizer.ERROR_AUDIO, SpeechRecognizer.ERROR_CLIENT -> cont.resumeWithException(SpeechError("Couldn't use the microphone. Another app may be using it."))
                            else -> cont.resumeWithException(SpeechError("Speech recognition failed (code $error). Try again or type instead."))
                        }
                    }
                }
                private fun finish(block: () -> Unit) {
                    level.value = 0f
                    if (cont.isActive) block()
                    destroy()
                }
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1400L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            }
            r.startListening(intent)
            cont.invokeOnCancellation { main.post { destroy() } }
        }
    }

    fun cancel() { main.post { destroy() } }

    private fun destroy() {
        recognizer?.let { runCatching { it.cancel() }; runCatching { it.destroy() } }
        recognizer = null
        level.value = 0f
    }
}
