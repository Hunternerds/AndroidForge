package com.sago.app.wake

import kotlinx.coroutines.flow.MutableStateFlow

enum class WakeStatus { OFF, STARTING, LISTENING, ENGAGED, MODEL_MISSING, NO_PERMISSION, ERROR }

/** Shared state between the UI, the assistant and the foreground wake-word service. */
class WakeCoordinator {
    val status = MutableStateFlow(WakeStatus.OFF)
    val detail = MutableStateFlow("")
    /** True while the user is using the push-to-talk mic, so the wake loop releases the microphone. */
    val manualMic = MutableStateFlow(false)
}
