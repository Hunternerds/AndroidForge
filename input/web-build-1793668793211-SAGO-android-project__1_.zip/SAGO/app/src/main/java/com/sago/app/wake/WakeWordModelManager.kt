package com.sago.app.wake

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.util.zip.ZipInputStream

sealed interface ModelState {
    data object Missing : ModelState
    data class Downloading(val progress: Float) : ModelState
    data object Installing : ModelState
    data object Ready : ModelState
    data class Failed(val message: String) : ModelState
}

/**
 * Downloads and installs the small offline Vosk speech model (~40 MB) used by the wake-word engine.
 * The model is fetched once, stored privately in app storage, and used fully offline afterwards.
 */
class WakeWordModelManager(private val context: Context, private val http: OkHttpClient) {
    val modelDir: File get() = File(context.filesDir, "vosk-model")
    val state = MutableStateFlow<ModelState>(if (installed()) ModelState.Ready else ModelState.Missing)

    fun installed(): Boolean = File(modelDir, "am/final.mdl").exists()

    suspend fun download() = withContext(Dispatchers.IO) {
        if (state.value is ModelState.Downloading || state.value is ModelState.Installing) return@withContext
        val zip = File(context.cacheDir, "vosk-model.zip")
        val tmp = File(context.filesDir, "vosk-model-tmp")
        try {
            state.value = ModelState.Downloading(0f)
            http.newBuilder().readTimeout(java.time.Duration.ofSeconds(60)).callTimeout(java.time.Duration.ZERO).build()
                .newCall(Request.Builder().url(MODEL_URL).build()).execute().use { resp ->
                    if (!resp.isSuccessful) throw IOException("Download failed (HTTP ${resp.code}).")
                    val body = resp.body ?: throw IOException("Empty download.")
                    val total = body.contentLength().takeIf { it > 0 } ?: EXPECTED_BYTES
                    zip.outputStream().use { out ->
                        body.byteStream().use { input ->
                            val buf = ByteArray(64 * 1024); var done = 0L; var n: Int
                            while (input.read(buf).also { n = it } >= 0) {
                                ensureActive()
                                out.write(buf, 0, n); done += n
                                state.value = ModelState.Downloading((done.toFloat() / total).coerceIn(0f, 0.99f))
                            }
                        }
                    }
                }
            state.value = ModelState.Installing
            tmp.deleteRecursively(); tmp.mkdirs()
            unzipStrippingRoot(zip, tmp)
            if (!File(tmp, "am/final.mdl").exists()) throw IOException("The downloaded model looks incomplete.")
            modelDir.deleteRecursively()
            if (!tmp.renameTo(modelDir)) throw IOException("Couldn't install the model.")
            state.value = ModelState.Ready
        } catch (e: kotlinx.coroutines.CancellationException) {
            tmp.deleteRecursively(); state.value = if (installed()) ModelState.Ready else ModelState.Missing; throw e
        } catch (e: Exception) {
            tmp.deleteRecursively()
            state.value = ModelState.Failed(
                if (e is IOException && e.message?.startsWith("Download") == false) "Couldn't download the voice model. Check your connection and try again."
                else e.message ?: "Couldn't install the voice model."
            )
        } finally {
            zip.delete()
        }
    }

    fun delete() {
        modelDir.deleteRecursively()
        state.value = ModelState.Missing
    }

    private fun unzipStrippingRoot(zip: File, dest: File) {
        val destCanonical = dest.canonicalPath + File.separator
        ZipInputStream(zip.inputStream().buffered()).use { zin ->
            var entry = zin.nextEntry
            while (entry != null) {
                val name = entry.name.substringAfter('/', "") // drop "vosk-model-small-en-us-0.15/"
                if (name.isNotEmpty()) {
                    val target = File(dest, name)
                    if (!target.canonicalPath.startsWith(destCanonical)) throw IOException("Unsafe path in model archive.") // zip-slip guard
                    if (entry.isDirectory) target.mkdirs()
                    else { target.parentFile?.mkdirs(); target.outputStream().use { zin.copyTo(it) } }
                }
                zin.closeEntry(); entry = zin.nextEntry
            }
        }
    }

    companion object {
        const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
        private const val EXPECTED_BYTES = 40_000_000L
    }
}
