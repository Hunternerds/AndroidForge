package com.sago.app.wake

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.IOException
import kotlin.math.abs
import kotlin.math.max

/** 16 kHz mono PCM microphone stream with a short rolling pre-roll buffer. */
class MicStream @SuppressLint("MissingPermission") constructor() : AutoCloseable {
    private val recorder: AudioRecord
    val buffer = ShortArray(FRAME)
    @Volatile var lastPeak = 0
        private set

    private val ring = ShortArray(SAMPLE_RATE * 3)
    private var ringPos = 0
    private var ringCount = 0

    init {
        val min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        recorder = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, max(min, FRAME * 4) * 2,
        )
        if (recorder.state != AudioRecord.STATE_INITIALIZED) { recorder.release(); throw IOException("Microphone unavailable") }
        recorder.startRecording()
        if (recorder.recordingState != AudioRecord.RECORDSTATE_RECORDING) { recorder.release(); throw IOException("Microphone is in use by another app") }
    }

    /** Blocks for one ~128 ms frame. Returns the sample count, or a negative value on error. */
    fun read(): Int {
        val n = recorder.read(buffer, 0, buffer.size)
        if (n > 0) {
            var peak = 0
            for (i in 0 until n) {
                peak = max(peak, abs(buffer[i].toInt()))
                ring[ringPos] = buffer[i]; ringPos = (ringPos + 1) % ring.size
            }
            ringCount = minOf(ring.size, ringCount + n)
            lastPeak = peak
        }
        return n
    }

    /** The most recent [millis] of audio, oldest first. */
    fun preRoll(millis: Int): ShortArray {
        val want = minOf(ringCount, SAMPLE_RATE * millis / 1000)
        val out = ShortArray(want)
        val start = (ringPos - want + ring.size) % ring.size
        for (i in 0 until want) out[i] = ring[(start + i) % ring.size]
        return out
    }

    override fun close() { runCatching { recorder.stop() }; runCatching { recorder.release() } }

    companion object {
        const val SAMPLE_RATE = 16000
        const val FRAME = 2048
    }
}
