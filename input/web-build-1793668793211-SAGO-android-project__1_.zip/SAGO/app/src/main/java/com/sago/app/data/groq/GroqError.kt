package com.sago.app.data.groq

/** Every failure the Groq layer can report, each with a message safe to show to the user. */
sealed class GroqError(val userMessage: String, cause: Throwable? = null) : Exception(userMessage, cause) {
    class MissingKey : GroqError("No Groq API key is saved. Add one in Settings → AI.")
    class InvalidKey : GroqError("Groq rejected this API key. Check it at console.groq.com/keys and try again.")
    class RateLimited(val retryAfterMs: Long?) :
        GroqError("Groq's rate limit was reached. Wait a moment and try again (limits depend on your Groq account).")
    class ModelUnavailable(val model: String) :
        GroqError("The model “$model” isn't available on your Groq account any more. Pick another one in Settings → AI.")
    class PayloadTooLarge : GroqError("That request was too large for Groq. Try a smaller image or a shorter message.")
    class BadRequest(val detail: String, val paramRelated: Boolean) : GroqError("Groq couldn't process the request: $detail")
    class Server(val code: Int) : GroqError("Groq is having trouble right now (HTTP $code). Please try again shortly.")
    class Network(cause: Throwable?) : GroqError("Couldn't reach Groq. Check your internet connection and try again.", cause)
    class Timeout : GroqError("Groq took too long to answer. Please try again.")
    class EmptyReply : GroqError("Groq returned an empty reply. Please try again.")
    class Unknown(detail: String) : GroqError("Something unexpected went wrong: $detail")
}
