package com.sago.app.voice

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.sago.app.avatar.AvatarMode
import com.sago.app.avatar.AvatarUi
import com.sago.app.avatar.Expression
import com.sago.app.data.groq.GroqError
import com.sago.app.data.prefs.Keys
import com.sago.app.data.prefs.SettingsStore
import com.sago.app.domain.ai.ConversationEngine
import com.sago.app.domain.ai.Turn
import com.sago.app.domain.model.AiReply
import com.sago.app.domain.model.PickedImage
import com.sago.app.wake.WakeCoordinator
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

enum class AssistantState { IDLE, LISTENING, THINKING, SPEAKING }

data class UiError(val message: String, val canRetry: Boolean = false, val openAiSettings: Boolean = false)

/**
 * App-wide orchestrator for the pipeline  mic → recogniser → conversation engine → Groq → reply → TTS → avatar.
 * Text and voice (push-to-talk and wake-word) all run through [runTurn], so they share one engine and one history.
 * It lives at application scope so a wake-word session can complete even when the UI isn't visible.
 */
class AssistantController(
    private val context: Context,
    private val scope: CoroutineScope,
    private val settings: SettingsStore,
    private val engine: ConversationEngine,
    val tts: TtsController,
    private val stt: SpeechRecognizerController,
    private val wake: WakeCoordinator,
) {
    val state = MutableStateFlow(AssistantState.IDLE)
    val avatar = MutableStateFlow(AvatarUi())
    val partial = MutableStateFlow("")
    val micLevel = MutableStateFlow(0f)
    val error = MutableStateFlow<UiError?>(null)
    val activeConversation = MutableStateFlow(0L)
    val mouthOpen get() = tts.mouthOpen

    private var job: Job? = null
    private var decayJob: Job? = null
    private var lastTurn: Turn? = null

    init {
        scope.launch { activeConversation.value = settings.snapshot().activeConversation }
        scope.launch { stt.level.collect { micLevel.value = it } }
        scope.launch { stt.partial.collect { if (state.value == AssistantState.LISTENING) partial.value = it } }
        scheduleDecay()
    }

    // ───────── public actions ─────────

    fun sendText(text: String, image: PickedImage?) {
        if (text.isBlank() && image == null) return
        launchTurn {
            setState(AssistantState.THINKING)
            val turn = engine.begin(activeConversation.value, text, image, viaWake = false)
            setActive(turn.conversationId)
            runTurn(turn)
        }
    }

    /** Push-to-talk. Requires RECORD_AUDIO (checked by the UI). */
    fun startVoice() {
        launchTurn {
            wake.manualMic.value = true
            try {
                setState(AssistantState.LISTENING)
                val transcript = stt.listen(settings.snapshot().preferOfflineStt)
                if (transcript.isNullOrBlank()) {
                    error.value = UiError("I didn't catch anything. Tap the mic and try again.")
                    return@launchTurn
                }
                processTranscript(transcript, viaWake = false)
            } finally {
                wake.manualMic.value = false
            }
        }
    }

    fun retry() {
        val t = lastTurn ?: return
        launchTurn { setState(AssistantState.THINKING); runTurn(t) }
    }

    /** Interrupts listening, thinking or speaking immediately. */
    fun stop() {
        job?.cancel(); job = null
        tts.stop(); stt.cancel()
        wake.manualMic.value = false
        resetIdle()
    }

    fun newConversation() { stop(); setActive(0L); error.value = null }

    fun openConversation(id: Long) { stop(); setActive(id); error.value = null }

    fun dismissError() { error.value = null }

    // ───────── wake-word session hooks (called by WakeWordService) ─────────

    fun onWakeDetected() {
        job?.cancel(); tts.stop(); error.value = null; partial.value = ""
        setState(AssistantState.LISTENING)
        buzz()
    }

    fun onFollowUpListening() { partial.value = ""; setState(AssistantState.LISTENING) }
    fun onWakePartial(text: String) { partial.value = text }
    fun onWakeLevel(level: Float) { micLevel.value = level }
    fun onWakeEnded() { if (state.value == AssistantState.LISTENING) { partial.value = ""; micLevel.value = 0f; setState(AssistantState.IDLE); scheduleDecay() } }

    /** Processes text captured by the offline engine and suspends until SAGO has finished answering. */
    suspend fun handleWakeTranscript(text: String) {
        launchTurn { processTranscript(text, viaWake = true) }.join()
    }

    // ───────── internals ─────────

    private suspend fun processTranscript(text: String, viaWake: Boolean) {
        partial.value = ""
        setState(AssistantState.THINKING)
        val turn = engine.begin(activeConversation.value, text, null, viaWake)
        setActive(turn.conversationId)
        runTurn(turn)
    }

    private suspend fun runTurn(turn: Turn) {
        lastTurn = turn
        val reply = engine.complete(turn)
        present(reply)
    }

    private suspend fun present(reply: AiReply) {
        val s = settings.snapshot()
        avatar.update { it.copy(expression = reply.expression, emotion = reply.emotion) }
        if (s.speakReplies) {
            setState(AssistantState.SPEAKING)
            try {
                tts.speak(reply.text, s.speechRate * reply.voice.rate, s.speechPitch * reply.voice.pitch, s.ttsVoice)
            } catch (e: SpeechError) {
                error.value = UiError(e.message ?: "Couldn't speak the reply.")
            }
        }
        setState(AssistantState.IDLE)
        scheduleDecay()
    }

    private fun launchTurn(block: suspend () -> Unit): Job {
        job?.cancel(); tts.stop(); stt.cancel()
        error.value = null
        val j = scope.launch {
            try { block() }
            catch (e: CancellationException) { throw e }
            catch (e: Throwable) { reportError(e) }
        }
        job = j
        j.invokeOnCompletion { if (job === j) { wake.manualMic.value = false; scope.launch { resetIdle() } } }
        return j
    }

    private fun reportError(e: Throwable) {
        error.value = when (e) {
            is GroqError.InvalidKey, is GroqError.MissingKey -> UiError(e.message.orEmpty(), canRetry = false, openAiSettings = true)
            is GroqError.ModelUnavailable -> UiError(e.message.orEmpty(), canRetry = false, openAiSettings = true)
            is GroqError -> UiError(e.userMessage, canRetry = true)
            is SpeechError -> UiError(e.message.orEmpty())
            else -> UiError("Something went wrong: ${e.message ?: e::class.simpleName}", canRetry = lastTurn != null)
        }
    }

    private fun resetIdle() {
        partial.value = ""; micLevel.value = 0f
        if (state.value != AssistantState.IDLE) setState(AssistantState.IDLE)
        scheduleDecay()
    }

    private fun setActive(id: Long) {
        activeConversation.value = id
        scope.launch { settings.set(Keys.ACTIVE_CONVERSATION, id) }
    }

    private fun setState(s: AssistantState) {
        state.value = s
        avatar.update {
            val mode = when (s) {
                AssistantState.IDLE -> AvatarMode.IDLE; AssistantState.LISTENING -> AvatarMode.LISTENING
                AssistantState.THINKING -> AvatarMode.THINKING; AssistantState.SPEAKING -> AvatarMode.SPEAKING
            }
            val expr = when (s) { AssistantState.THINKING -> Expression.THINKING; AssistantState.LISTENING -> Expression.NORMAL; else -> it.expression }
            it.copy(mode = mode, expression = expr)
        }
        if (s != AssistantState.IDLE) decayJob?.cancel()
    }

    /** After a reply the face relaxes to neutral, and after a long quiet spell SAGO looks sleepy. */
    private fun scheduleDecay() {
        decayJob?.cancel()
        decayJob = scope.launch {
            delay(4_000)
            if (state.value == AssistantState.IDLE) avatar.update { it.copy(expression = Expression.NORMAL, emotion = com.sago.app.domain.model.Emotion.NEUTRAL) }
            delay(120_000)
            if (state.value == AssistantState.IDLE) avatar.update { it.copy(expression = Expression.SLEEPY) }
        }
    }

    @Suppress("DEPRECATION")
    private fun buzz() = runCatching {
        val v = if (Build.VERSION.SDK_INT >= 31)
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        else context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        v.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
    }
}
