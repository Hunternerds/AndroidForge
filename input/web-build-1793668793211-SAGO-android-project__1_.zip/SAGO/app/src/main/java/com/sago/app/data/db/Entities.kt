package com.sago.app.data.db

import androidx.room.*

@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey val id: String,
    val name: String,
    val createdAt: Long,
)

@Entity(tableName = "conversations", indices = [Index("profileId")])
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
)

@Entity(
    tableName = "messages",
    foreignKeys = [ForeignKey(
        entity = ConversationEntity::class, parentColumns = ["id"], childColumns = ["conversationId"],
        onDelete = ForeignKey.CASCADE,
    )],
    indices = [Index("conversationId")],
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: Long,
    val role: String,
    val text: String,
    val emotion: String? = null,
    val imagePath: String? = null,
    val createdAt: Long,
)

@Entity(tableName = "memories", indices = [Index("profileId")])
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: String,
    val text: String,
    /** "explicit" (Sago remember…), "auto" (model-suggested) or "manual" (added in Settings). */
    val source: String,
    val createdAt: Long,
    val updatedAt: Long,
    val lastUsedAt: Long,
)
