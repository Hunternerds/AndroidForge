package com.sago.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sago.app.data.db.ConversationEntity
import com.sago.app.ui.components.Backdrop
import com.sago.app.ui.components.ConfirmDialog
import com.sago.app.ui.theme.LocalSagoUi
import com.sago.app.ui.viewmodel.HistoryViewModel
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(vm: HistoryViewModel, onBack: () -> Unit) {
    val ui = LocalSagoUi.current
    val list by vm.conversations.collectAsStateWithLifecycle()
    val active by vm.activeId.collectAsStateWithLifecycle()
    var toDelete by remember { mutableStateOf<ConversationEntity?>(null) }

    Box(Modifier.fillMaxSize()) {
        Backdrop(true, heavy = true)
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = { Text("Conversations", fontWeight = FontWeight.Bold) },
                    navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                    actions = { IconButton({ vm.newChat(); onBack() }) { Icon(Icons.Default.Add, "New conversation") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent, titleContentColor = ui.text, navigationIconContentColor = ui.text, actionIconContentColor = ui.text),
                )
            },
        ) { pad ->
            if (list.isEmpty()) {
                Box(Modifier.padding(pad).fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("No conversations yet.\nStart one from the main screen and it will show up here.", color = ui.subtext, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            } else {
                LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(list, key = { it.id }) { c ->
                        Surface(
                            shape = RoundedCornerShape(16.dp), color = ui.glass, contentColor = ui.text,
                            border = BorderStroke(if (c.id == active) 2.dp else 1.dp, if (c.id == active) MaterialTheme.colorScheme.primary else ui.glassBorder),
                            modifier = Modifier.fillMaxWidth().clickable { vm.open(c.id); onBack() },
                        ) {
                            Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(c.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                                    Text("Updated " + DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(c.updatedAt)), style = MaterialTheme.typography.bodyMedium, color = ui.subtext)
                                }
                                IconButton({ toDelete = c }) { Icon(Icons.Default.Delete, "Delete conversation", tint = ui.subtext) }
                            }
                        }
                    }
                }
            }
        }
    }
    toDelete?.let { c ->
        ConfirmDialog("Delete conversation?", "“${c.title}” and all its messages will be permanently removed from this device.", "Delete", onConfirm = { vm.delete(c.id) }, onDismiss = { toDelete = null })
    }
}
