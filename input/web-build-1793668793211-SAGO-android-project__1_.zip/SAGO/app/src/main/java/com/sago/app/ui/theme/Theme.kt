package com.sago.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object Palette {
    val Pink = Color(0xFFF472B6)
    val PinkDeep = Color(0xFFEC4899)
    val Plum = Color(0xFF1B1030)
    val PlumSoft = Color(0xFF2A1A45)
    val Lavender = Color(0xFFC4B5FD)
    val Cream = Color(0xFFFFF1F7)
}

/** Extra tokens for the translucent "glass" look shared by every screen. */
data class SagoUi(val dark: Boolean, val glass: Color, val glassBorder: Color, val scrim: Color, val text: Color, val subtext: Color)

val LocalSagoUi = staticCompositionLocalOf {
    SagoUi(true, Color.White.copy(0.14f), Color.White.copy(0.2f), Palette.Plum.copy(0.55f), Color.White, Color.White.copy(0.72f))
}

@Composable
fun SagoTheme(mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) { "light" -> false; "system" -> isSystemInDarkTheme(); else -> true }
    val scheme = if (dark) darkColorScheme(
        primary = Palette.Pink, onPrimary = Palette.Plum, secondary = Palette.Lavender, background = Palette.Plum,
        surface = Palette.PlumSoft, onSurface = Color.White, onBackground = Color.White, surfaceVariant = Color(0xFF3A2760),
        onSurfaceVariant = Color.White.copy(0.75f), error = Color(0xFFFF8A9B),
    ) else lightColorScheme(
        primary = Palette.PinkDeep, onPrimary = Color.White, secondary = Color(0xFF7C3AED), background = Palette.Cream,
        surface = Color.White, onSurface = Palette.Plum, onBackground = Palette.Plum, surfaceVariant = Color(0xFFFCE7F3),
        onSurfaceVariant = Palette.Plum.copy(0.7f), error = Color(0xFFB3261E),
    )
    val ui = if (dark) SagoUi(true, Color.White.copy(0.14f), Color.White.copy(0.2f), Palette.Plum.copy(0.58f), Color.White, Color.White.copy(0.72f))
    else SagoUi(false, Color.White.copy(0.72f), Palette.PinkDeep.copy(0.25f), Color.White.copy(0.45f), Palette.Plum, Palette.Plum.copy(0.7f))
    val type = Typography().run {
        copy(
            titleLarge = titleLarge.copy(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold),
            titleMedium = titleMedium.copy(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold),
            bodyLarge = bodyLarge.copy(fontFamily = FontFamily.SansSerif, fontSize = 16.sp, lineHeight = 23.sp),
            bodyMedium = bodyMedium.copy(fontFamily = FontFamily.SansSerif),
            labelSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 11.sp),
        )
    }
    CompositionLocalProvider(LocalSagoUi provides ui) {
        MaterialTheme(colorScheme = scheme, typography = type, content = content)
    }
}
