package com.sago.app.avatar

import com.sago.app.domain.model.Emotion

/** Everything the avatar view needs, produced by the assistant controller. The mouth signal comes from TTS playback. */
data class AvatarUi(
    val expression: Expression = Expression.NORMAL,
    val mode: AvatarMode = AvatarMode.IDLE,
    val emotion: Emotion = Emotion.NEUTRAL,
)
