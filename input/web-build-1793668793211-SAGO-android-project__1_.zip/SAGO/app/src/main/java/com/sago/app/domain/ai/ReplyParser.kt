package com.sago.app.domain.ai

import com.sago.app.avatar.Expression
import com.sago.app.domain.model.AiReply
import com.sago.app.domain.model.Emotion
import com.sago.app.domain.model.VoiceStyle
import org.json.JSONObject

/** Turns raw model output into an [AiReply]. Metadata never leaks into [AiReply.text]. */
object ReplyParser {
    private val thinkBlock = Regex("<think>.*?</think>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
    private val fence = Regex("^```(?:json)?\\s*|\\s*```$", RegexOption.IGNORE_CASE)

    fun parse(raw: String): AiReply {
        val cleaned = raw.replace(thinkBlock, "").trim().replace(fence, "").trim()
        val json = extractJson(cleaned)
        if (json != null) {
            val text = listOf("response", "reply", "text", "message").firstNotNullOfOrNull { k ->
                json.optString(k).takeIf { it.isNotBlank() }
            }
            if (text != null) {
                val emotion = Emotion.parse(json.optString("emotion"))
                val voice = json.optJSONObject("voice")
                val mem = json.optJSONArray("memories")
                return AiReply(
                    text = text.trim(),
                    emotion = emotion,
                    intent = json.optString("intent").ifBlank { "chat" },
                    expression = Expression.parse(json.optString("avatar")) ?: emotion.defaultExpression,
                    voice = VoiceStyle(
                        rate = when (voice?.optString("rate")?.lowercase()) { "slow" -> 0.9f; "fast" -> 1.12f; else -> 1f },
                        pitch = when (voice?.optString("pitch")?.lowercase()) { "low" -> 0.92f; "high" -> 1.08f; else -> 1f },
                    ),
                    memories = (0 until (mem?.length() ?: 0)).mapNotNull { mem?.optString(it)?.trim()?.takeIf { s -> s.isNotEmpty() } }.take(3),
                )
            }
        }
        // Fallback: the model ignored the format. Show prose only, never raw JSON-looking metadata.
        val prose = cleaned.lines().filterNot { it.trim().startsWith("{") || it.trim().startsWith("\"emotion\"") }.joinToString("\n").trim()
        return AiReply(text = prose.ifBlank { "…" })
    }

    private fun extractJson(s: String): JSONObject? {
        val start = s.indexOf('{'); val end = s.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        return runCatching { JSONObject(s.substring(start, end + 1)) }.getOrNull()
    }
}
