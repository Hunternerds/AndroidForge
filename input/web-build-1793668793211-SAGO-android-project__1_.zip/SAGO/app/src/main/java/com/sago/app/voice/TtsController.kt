package com.sago.app.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class VoiceInfo(val name: String, val label: String, val offline: Boolean)

/**
 * Android TextToSpeech with audio focus, interruptible playback and mouth-sync signals.
 *
 * Android's TTS API exposes no audio amplitude. Mouth sync therefore uses word-boundary callbacks
 * ([UtteranceProgressListener.onRangeStart]) which fire in step with the real audio. If an engine doesn't
 * send them, a speech-rhythm cadence is used instead while the audio is genuinely playing.
 */
class TtsController(private val context: Context) {
    private val main = Handler(Looper.getMainLooper())
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()

    private var tts: TextToSpeech? = null
    private var focus: AudioFocusRequest? = null
    private val ids = AtomicInteger()

    val speaking = MutableStateFlow(false)
    val mouthOpen = MutableStateFlow(false)

    private class Session(val cont: CancellableContinuation<Unit>, var remaining: Int)
    @Volatile private var session: Session? = null
    @Volatile private var rangesSeen = false

    private val closeMouth = Runnable { mouthOpen.value = false }
    private val cadence = object : Runnable {
        var open = false
        override fun run() {
            if (!speaking.value || rangesSeen) { mouthOpen.value = false; return }
            open = !open
            mouthOpen.value = open
            main.postDelayed(this, if (open) 140L else 95L)
        }
    }

    private suspend fun ensureReady(): TextToSpeech? {
        tts?.let { return it }
        return suspendCancellableCoroutine { cont ->
            var engine: TextToSpeech? = null
            engine = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    engine?.setAudioAttributes(attrs)
                    engine?.setOnUtteranceProgressListener(listener)
                    tts = engine
                    if (cont.isActive) cont.resume(engine)
                } else if (cont.isActive) cont.resume(null)
            }
        }
    }

    suspend fun voices(): List<VoiceInfo> {
        val engine = ensureReady() ?: return emptyList()
        val lang = Locale.getDefault().language
        return runCatching {
            engine.voices.orEmpty().filter { it.locale.language == lang || it.locale.language == "en" }
                .sortedWith(compareBy({ it.locale.toString() }, { it.name }))
                .map { VoiceInfo(it.name, "${it.locale.displayName} · ${it.name}", !it.isNetworkConnectionRequired) }
        }.getOrDefault(emptyList())
    }

    /** Speaks [text] and returns when playback ends. Cancelling the coroutine (or [stop]) interrupts it. */
    suspend fun speak(text: String, rate: Float, pitch: Float, voiceName: String) {
        val clean = sanitize(text)
        if (clean.isBlank()) return
        val engine = ensureReady() ?: throw SpeechError("Text-to-speech isn't available on this device. Install a TTS engine in Android settings.")
        engine.setSpeechRate(rate.coerceIn(0.5f, 2f))
        engine.setPitch(pitch.coerceIn(0.5f, 2f))
        selectVoice(engine, voiceName)
        val chunks = chunk(clean, (TextToSpeech.getMaxSpeechInputLength() - 100).coerceIn(500, 3500))
        requestFocus()
        rangesSeen = false
        try {
            suspendCancellableCoroutine<Unit> { cont ->
                val s = Session(cont, chunks.size)
                session = s
                cont.invokeOnCancellation { engine.stop() }
                val base = ids.incrementAndGet()
                chunks.forEachIndexed { i, c ->
                    val r = engine.speak(c, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "sago-$base-$i")
                    if (r == TextToSpeech.ERROR && cont.isActive) { cont.resumeWithException(SpeechError("Text-to-speech failed to start.")); return@suspendCancellableCoroutine }
                }
            }
        } finally {
            session = null
            main.removeCallbacks(cadence); main.removeCallbacks(closeMouth)
            speaking.value = false; mouthOpen.value = false
            abandonFocus()
        }
    }

    fun stop() {
        runCatching { tts?.stop() }
        val s = session
        if (s != null && s.cont.isActive) runCatching { s.cont.resume(Unit) }
    }

    fun shutdown() { runCatching { tts?.shutdown() }; tts = null }

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
            main.post {
                speaking.value = true
                main.removeCallbacks(cadence)
                main.postDelayed(cadence, 450L) // only takes over if no word-boundary events arrive
            }
        }
        override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
            rangesSeen = true
            val dur = ((end - start) * 58L).coerceIn(90L, 380L)
            main.post { mouthOpen.value = true; main.removeCallbacks(closeMouth); main.postDelayed(closeMouth, dur) }
        }
        override fun onDone(utteranceId: String?) = chunkFinished(null)
        @Deprecated("Deprecated in Java") override fun onError(utteranceId: String?) = chunkFinished(SpeechError("Text-to-speech failed."))
        override fun onError(utteranceId: String?, errorCode: Int) = chunkFinished(SpeechError("Text-to-speech failed (code $errorCode)."))
        override fun onStop(utteranceId: String?, interrupted: Boolean) = chunkFinished(null, force = true)
    }

    private fun chunkFinished(error: SpeechError?, force: Boolean = false) {
        val s = session ?: return
        if (error != null) { if (s.cont.isActive) runCatching { s.cont.resumeWithException(error) }; return }
        synchronized(s) { s.remaining -= 1 }
        if ((force || s.remaining <= 0) && s.cont.isActive) runCatching { s.cont.resume(Unit) }
    }

    private fun selectVoice(engine: TextToSpeech, name: String) {
        runCatching {
            val chosen: Voice? = engine.voices?.firstOrNull { it.name == name }
            if (chosen != null) engine.setVoice(chosen)
            else if (engine.isLanguageAvailable(Locale.getDefault()) < TextToSpeech.LANG_AVAILABLE) engine.setLanguage(Locale.US)
            else engine.setLanguage(Locale.getDefault())
        }
    }

    private fun requestFocus() {
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener { if (it == AudioManager.AUDIOFOCUS_LOSS) main.post { stop() } }
            .build()
        focus = req
        audio.requestAudioFocus(req)
    }

    private fun abandonFocus() { focus?.let { audio.abandonAudioFocusRequest(it) }; focus = null }

    companion object {
        /** Strips emoji, markdown symbols and URLs so they aren't read aloud. */
        fun sanitize(text: String): String = text
            .replace(Regex("https?://\\S+"), " link ")
            .replace(Regex("[\\p{So}\\u200d\\ufe0f]"), "")
            .replace(Regex("[*_#`~>|]+"), "")
            .replace(Regex("\\s+"), " ").trim()

        fun chunk(text: String, max: Int): List<String> {
            if (text.length <= max) return listOf(text)
            val out = mutableListOf<String>(); var cur = StringBuilder()
            text.split(Regex("(?<=[.!?])\\s+")).forEach { sentence ->
                if (cur.length + sentence.length + 1 > max && cur.isNotEmpty()) { out += cur.toString(); cur = StringBuilder() }
                cur.append(sentence).append(' ')
            }
            if (cur.isNotBlank()) out += cur.toString().trim()
            return out
        }
    }
}
