package com.sago.app.domain.model

import com.sago.app.avatar.Expression

enum class Emotion(val label: String) {
    HAPPY("Happy"), EXCITED("Excited"), SAD("Sad"), SERIOUS("Serious"), CURIOUS("Curious"),
    CONFUSED("Confused"), FRUSTRATED("Frustrated"), CALM("Calm"), SURPRISED("Surprised"),
    PLAYFUL("Playful"), NEUTRAL("Neutral");

    /** Default face for this emotion; the model may override with a more specific one. */
    val defaultExpression: Expression
        get() = when (this) {
            HAPPY, EXCITED -> Expression.HAPPY
            SAD, CALM -> Expression.SLEEPY
            SERIOUS -> Expression.STUDY
            CURIOUS, CONFUSED -> Expression.THINKING
            FRUSTRATED -> Expression.ANGRY
            SURPRISED -> Expression.SURPRISED
            PLAYFUL -> Expression.PLAYFUL
            NEUTRAL -> Expression.NORMAL
        }

    companion object {
        fun parse(raw: String?): Emotion = entries.firstOrNull { it.name.equals(raw?.trim(), ignoreCase = true) } ?: NEUTRAL
    }
}

/** Optional delivery hints from the model; applied as multipliers on the user's own speech settings. */
data class VoiceStyle(val rate: Float = 1f, val pitch: Float = 1f)

/** Structured, parsed model reply. Only [text] is ever shown or spoken; the rest is metadata. */
data class AiReply(
    val text: String,
    val emotion: Emotion = Emotion.NEUTRAL,
    val intent: String = "chat",
    val expression: Expression = Expression.NORMAL,
    val voice: VoiceStyle = VoiceStyle(),
    val memories: List<String> = emptyList(),
)

data class ChatMessage(
    val id: Long,
    val conversationId: Long,
    val role: Role,
    val text: String,
    val emotion: Emotion?,
    val imagePath: String?,
    val createdAt: Long,
) { enum class Role { USER, ASSISTANT } }

data class PickedImage(val jpeg: ByteArray, val savedPath: String)
