package com.sago.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.sago.app.ui.SagoRoot
import com.sago.app.wake.WakeStatus
import com.sago.app.wake.WakeWordService
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val container get() = (application as SagoApp).container

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { SagoRoot(container) }
    }

    /**
     * Service recovery: if background listening is enabled but the service isn't running (the system may have
     * stopped it), restart it now. Android 14+ only allows starting a microphone service while the app is visible.
     */
    override fun onStart() {
        super.onStart()
        lifecycleScope.launch {
            val s = container.settings.snapshot()
            val micOk = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (s.wakeEnabled && s.onboarded && micOk && container.wakeModel.installed() && container.wake.status.value == WakeStatus.OFF) {
                runCatching { WakeWordService.start(this@MainActivity) }
            }
        }
    }
}
