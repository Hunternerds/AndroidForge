package com.sago.app.domain.memory

import com.sago.app.data.db.MemoryDao
import com.sago.app.data.db.MemoryEntity
import kotlinx.coroutines.flow.Flow

/**
 * Lightweight, local-first, per-profile long-term memory. Independent of conversation history:
 * it stores short facts only, de-duplicates, updates outdated values, and retrieves a small relevant subset.
 */
class MemoryEngine(private val dao: MemoryDao) {

    fun observe(profileId: String): Flow<List<MemoryEntity>> = dao.observe(profileId)

    /** "Sago remember …": always saved (the user explicitly asked), still normalised and de-duplicated. */
    suspend fun saveExplicit(profileId: String, raw: String): String? = save(profileId, raw, "explicit", allowSensitive = true)

    /** Model-suggested memory: filtered hard for sensitivity, length and value. */
    suspend fun saveAuto(profileId: String, raw: String): Boolean = save(profileId, raw, "auto", allowSensitive = false) != null

    suspend fun addManual(profileId: String, raw: String): String? = save(profileId, raw, "manual", allowSensitive = true)

    private suspend fun save(profileId: String, raw: String, source: String, allowSensitive: Boolean): String? {
        val text = normalise(raw)
        if (text.length < 4 || text.length > MAX_LEN) return null
        if (!allowSensitive && (SensitiveFilter.isSensitive(text) || isTemporary(text))) return null
        val now = System.currentTimeMillis()
        val existing = dao.all(profileId)
        val newTokens = tokens(text)
        val newKey = subjectKey(text)

        // 1) Near-duplicate → refresh instead of adding.
        existing.firstOrNull { jaccard(tokens(it.text), newTokens) >= 0.75 }?.let {
            dao.update(it.copy(text = if (source == "auto" && it.source == "explicit") it.text else text, updatedAt = now))
            return text
        }
        // 2) Same subject, different value ("my favourite language is X" → "…is Y") → update the outdated entry.
        if (newKey != null) existing.firstOrNull { subjectKey(it.text) == newKey }?.let {
            dao.update(it.copy(text = text, source = if (source == "auto") it.source else source, updatedAt = now))
            return text
        }
        dao.insert(MemoryEntity(profileId = profileId, text = text, source = source, createdAt = now, updatedAt = now, lastUsedAt = now))
        prune(profileId)
        return text
    }

    /** At most a handful of short memories, ranked by relevance to the current message. Cheap, no embeddings. */
    suspend fun relevant(profileId: String, query: String, limit: Int = 6, charBudget: Int = 700): List<String> {
        val all = runCatching { dao.all(profileId) }.getOrDefault(emptyList())
        if (all.isEmpty()) return emptyList()
        val q = tokens(query)
        val now = System.currentTimeMillis()
        val scored = all.map { m ->
            val overlap = tokens(m.text).count { it in q }
            val pref = if (PREFERENCE_HINT.containsMatchIn(m.text)) 1.5 else 0.0
            val explicit = if (m.source != "auto") 0.4 else 0.0
            val recency = 1.0 / (1.0 + (now - m.updatedAt) / (30.0 * 86_400_000))
            m to (overlap * 2.0 + pref + explicit + recency * 0.3)
        }.sortedByDescending { it.second }
        val picked = mutableListOf<MemoryEntity>(); var chars = 0
        for ((m, score) in scored) {
            if (picked.size >= limit || chars + m.text.length > charBudget) break
            // Skip unrelated, non-preference notes entirely so tokens aren't wasted.
            if (score < 1.0) continue
            picked += m; chars += m.text.length
        }
        if (picked.isNotEmpty()) runCatching { dao.markUsed(picked.map { it.id }, now) }
        return picked.map { it.text }
    }

    suspend fun edit(entity: MemoryEntity, newText: String) {
        val t = normalise(newText)
        if (t.length >= 2) dao.update(entity.copy(text = t.take(MAX_LEN), updatedAt = System.currentTimeMillis()))
    }
    suspend fun delete(id: Long) = dao.delete(id)
    suspend fun clear(profileId: String) = dao.clear(profileId)

    private suspend fun prune(profileId: String) {
        val all = dao.all(profileId)
        if (all.size <= MAX_ENTRIES) return
        all.filter { it.source == "auto" }.sortedBy { it.lastUsedAt }.take(all.size - MAX_ENTRIES).forEach { dao.delete(it.id) }
    }

    /** "my project is StudyOS" → "User's project is StudyOS". Keeps the stored note third-person and compact. */
    fun normalise(raw: String): String {
        var s = raw.trim().replace(Regex("\\s+"), " ").trim('"', '“', '”', ' ', '.')
        s = s.replace(Regex("^that\\s+", RegexOption.IGNORE_CASE), "")
        s = when {
            s.matches(Regex("(?i)^my\\s+.*")) -> "User's " + s.drop(3)
            s.matches(Regex("(?i)^i\\s*(am|'m)\\s+.*")) -> "User is " + s.replace(Regex("(?i)^i\\s*(am|'m)\\s+"), "")
            s.matches(Regex("(?i)^i\\s+(prefer|like|love|hate|use|want|need|work|live)\\b.*")) ->
                s.replace(Regex("(?i)^i\\s+(prefer|like|love|hate|use|want|need|work|live)\\b")) { "User " + it.groupValues[1].lowercase() + "s" }
            s.matches(Regex("(?i)^i\\s+have\\b.*")) -> s.replace(Regex("(?i)^i\\s+have\\b"), "User has")
            else -> s
        }
        return s.replaceFirstChar { it.uppercase() }.take(MAX_LEN + 20)
    }

    private fun tokens(s: String): Set<String> =
        s.lowercase().split(Regex("[^a-z0-9]+")).filter { it.length >= 3 && it !in STOP }.toSet()

    private fun jaccard(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        return a.intersect(b).size.toDouble() / a.union(b).size
    }

    private fun subjectKey(s: String): String? =
        Regex("^(?:user's|my)\\s+(.{3,40}?)\\s+(?:is|are|was)\\s+", RegexOption.IGNORE_CASE).find(s)?.groupValues?.get(1)?.lowercase()

    private fun isTemporary(s: String) =
        Regex("\\b(today|tonight|tomorrow|right now|this (morning|afternoon|evening)|currently feeling|at the moment)\\b", RegexOption.IGNORE_CASE).containsMatchIn(s)

    companion object {
        const val MAX_LEN = 160
        const val MAX_ENTRIES = 200
        private val PREFERENCE_HINT = Regex("\\b(prefer|short answers|call me|my name|tone|language|answer)", RegexOption.IGNORE_CASE)
        private val STOP = setOf("the", "and", "for", "that", "with", "this", "from", "are", "was", "has", "have", "user", "users", "his", "her", "their", "about", "you", "your", "what", "when", "how", "can", "not")
    }
}

/** Blocks automatic saving of sensitive data. Only an explicit "Sago remember…" can store such things. */
object SensitiveFilter {
    private val patterns = listOf(
        "password", "passcode", "passphrase", "\\bpin\\b", "\\botp\\b", "api key", "secret", "token", "credit card", "card number", "cvv",
        "\\bssn\\b", "social security", "passport", "bank account", "\\biban\\b", "routing number", "salary", "diagnos", "medication",
        "prescription", "disease", "illness", "therapy", "religio", "political", "sexual", "home address", "phone number", "e-?mail",
        "\\d{9,}", "@[a-z0-9.-]+\\.[a-z]{2,}",
    ).map { Regex(it, RegexOption.IGNORE_CASE) }

    fun isSensitive(text: String) = patterns.any { it.containsMatchIn(text) }
}
