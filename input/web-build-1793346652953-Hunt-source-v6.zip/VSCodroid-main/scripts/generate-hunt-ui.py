#!/usr/bin/env python3
"""Builds HUNT's editor look from the two source images in hunt/.

    python3 scripts/generate-hunt-ui.py           # regenerate everything
    python3 scripts/generate-hunt-ui.py --check   # fail if the committed result is stale

Inputs
  hunt/logo-white.png  the white logo on a transparent background
  hunt/avatar.png      the cat avatar

Outputs
  hunt/hunt-logo.svg   the logo traced to a vector, so it stays sharp at any density
  hunt/hunt-mark.png   a round mark cut from the avatar, for the title bar
  the block between `<hunt-ui>` markers in android/app/src/main/assets/server.js,
      the stylesheet the workbench page gets (editor watermark, title-bar icon)
  contributes.configurationDefaults of the bundled welcome extension,
      the graded dark palette for the Dark Modern theme and the editor defaults

Why this shape. The editor's own logo files sit inside the prebuilt server download,
which build-time gates compare with the repository, so they are not edited. The page
is extended at start instead, the way the theme and the trusted domains already are.
The palette is a customisation scoped to the `Dark Modern` theme, not a theme of its
own: the pre-paint script in server.js knows the colours of the themes in the server
tree, and an unknown default theme would flash the light web default on every launch.
"""
import base64, io, json, re, sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
SERVER_JS = ROOT / "android/app/src/main/assets/server.js"
WELCOME = next((ROOT / "android/app/src/main/assets/extensions").glob("vscodroid.vscodroid-welcome-*/package.json"))

# --- palette: graded dark, darkest at the edges, lightest where the code is ----------
EDGE, ACTIVITY, SIDE, EDITOR, WIDGET, INPUT = "#0a0a0d", "#0d0d11", "#111116", "#16161c", "#1b1b22", "#1d1d25"
LINE, TEXT, MUTED, SILVER, STEEL = "#23232b", "#d4d7de", "#9298a8", "#e4e7ee", "#8d9bb8"

THEME = "Dark Modern"
COLORS = {
    "foreground": TEXT, "descriptionForeground": MUTED, "focusBorder": STEEL,
    "titleBar.activeBackground": EDGE, "titleBar.inactiveBackground": EDGE,
    "titleBar.activeForeground": TEXT, "titleBar.border": EDGE,
    "activityBar.background": ACTIVITY, "activityBar.foreground": SILVER,
    "activityBar.inactiveForeground": "#767c8e", "activityBar.border": ACTIVITY,
    "activityBar.activeBorder": SILVER, "activityBarBadge.background": SILVER,
    "activityBarBadge.foreground": EDGE,
    "sideBar.background": SIDE, "sideBar.border": SIDE, "sideBar.foreground": TEXT,
    "sideBarTitle.foreground": MUTED, "sideBarSectionHeader.background": SIDE,
    "sideBarSectionHeader.border": LINE,
    "editor.background": EDITOR, "editor.foreground": TEXT,
    "editor.lineHighlightBackground": "#1c1c24", "editor.lineHighlightBorder": "#00000000",
    "editor.selectionBackground": "#3a4254", "editor.inactiveSelectionBackground": "#2a303d",
    "editor.selectionHighlightBackground": "#2f3646", "editor.wordHighlightBackground": "#2f364680",
    "editor.findMatchBackground": "#59502c", "editor.findMatchHighlightBackground": "#3a3a2866",
    "editorCursor.foreground": SILVER, "editorLineNumber.foreground": "#5d6376",
    "editorLineNumber.activeForeground": SILVER, "editorIndentGuide.background1": "#242430",
    "editorIndentGuide.activeBackground1": "#4a5164", "editorWhitespace.foreground": "#2c2c38",
    "editorGutter.background": EDITOR, "editorBracketMatch.background": "#3a425466",
    "editorBracketMatch.border": STEEL,
    "editorGroup.border": EDGE, "editorGroupHeader.tabsBackground": SIDE,
    "editorGroupHeader.tabsBorder": SIDE,
    "tab.activeBackground": EDITOR, "tab.inactiveBackground": SIDE, "tab.border": WIDGET,
    "tab.activeForeground": SILVER, "tab.inactiveForeground": "#8a90a2",
    "tab.activeBorderTop": SILVER, "tab.hoverBackground": WIDGET,
    "breadcrumb.foreground": MUTED, "breadcrumb.focusForeground": SILVER,
    "panel.background": SIDE, "panel.border": LINE, "panelTitle.activeForeground": SILVER,
    "panelTitle.inactiveForeground": MUTED, "panelTitle.activeBorder": SILVER,
    "terminal.background": "#0f0f13", "terminal.foreground": TEXT,
    "statusBar.background": EDGE, "statusBar.foreground": "#aeb3c0", "statusBar.border": EDGE,
    "statusBar.noFolderBackground": EDGE, "statusBar.noFolderForeground": "#aeb3c0",
    "statusBarItem.hoverBackground": WIDGET, "statusBarItem.remoteBackground": SILVER,
    "statusBarItem.remoteForeground": EDGE,
    "list.activeSelectionBackground": "#262b38", "list.activeSelectionForeground": "#ffffff",
    "list.inactiveSelectionBackground": "#20242e", "list.hoverBackground": WIDGET,
    "list.focusOutline": STEEL,
    "input.background": INPUT, "input.border": LINE, "input.foreground": TEXT,
    "inputOption.activeBorder": STEEL, "dropdown.background": INPUT, "dropdown.border": LINE,
    "button.background": SILVER, "button.foreground": EDGE, "button.hoverBackground": "#ffffff",
    "button.secondaryBackground": LINE, "button.secondaryForeground": TEXT,
    "badge.background": SILVER, "badge.foreground": EDGE,
    "editorWidget.background": WIDGET, "editorWidget.border": LINE,
    "editorSuggestWidget.background": WIDGET, "editorSuggestWidget.selectedBackground": "#262b38",
    "editorHoverWidget.background": WIDGET, "menu.background": WIDGET, "menu.selectionBackground": "#262b38",
    "quickInput.background": WIDGET, "quickInputList.focusBackground": "#262b38",
    "notifications.background": WIDGET, "notificationCenterHeader.background": INPUT,
    "scrollbarSlider.background": "#8d9bb833", "scrollbarSlider.hoverBackground": "#8d9bb855",
    "scrollbarSlider.activeBackground": "#8d9bb877", "widget.shadow": "#00000066",
    "progressBar.background": SILVER, "textLink.foreground": "#9fb5ff",
}

def rule(scope, fg, style=None):
    s = {"foreground": fg}
    if style:
        s["fontStyle"] = style
    return {"scope": scope, "settings": s}

TOKEN_RULES = [
    rule(["comment", "punctuation.definition.comment"], "#7f869a", "italic"),
    rule(["keyword", "storage", "storage.type", "keyword.control", "keyword.operator.new",
          "keyword.operator.expression", "keyword.operator.logical.python"], "#9fb5ff"),
    rule(["entity.name.function", "support.function", "meta.function-call entity.name.function"], SILVER),
    rule(["entity.name.type", "entity.name.class", "support.class", "support.type",
          "entity.other.inherited-class", "storage.type.cs"], "#7fd0d0"),
    rule(["string", "string.quoted", "punctuation.definition.string"], "#b4d69e"),
    rule(["constant.numeric", "constant.language", "constant.character", "support.constant"], "#e6b980"),
    rule(["variable", "variable.other", "meta.definition.variable.name", "support.variable"], "#c9cedb"),
    rule(["variable.language", "variable.parameter"], "#d9c9f5"),
    rule(["keyword.operator", "punctuation", "meta.brace", "punctuation.separator"], "#98a0b4"),
    rule(["entity.name.tag", "meta.tag", "punctuation.definition.tag"], "#9fb5ff"),
    rule(["entity.other.attribute-name", "support.type.property-name"], "#7fd0d0"),
    rule(["markup.heading", "entity.name.section"], SILVER, "bold"),
    rule(["markup.inline.raw", "markup.fenced_code"], "#b4d69e"),
    rule(["invalid", "invalid.illegal"], "#ff8a8a"),
]

EDITOR_DEFAULTS = {
    # the stack walks Android's own monospace faces and ends on the generic family
    "editor.fontFamily": "'Roboto Mono', 'Droid Sans Mono', 'Noto Sans Mono', 'Cutive Mono', monospace",
    "editor.lineHeight": 1.55,
    "editor.lineNumbersMinChars": 3,
    "editor.glyphMargin": False,
    "editor.renderLineHighlight": "all",
    "editor.cursorBlinking": "smooth",
    "editor.cursorWidth": 2,
    "editor.guides.bracketPairs": "active",
    "editor.padding.top": 8,
    "editor.padding.bottom": 8,
    "editor.scrollBeyondLastLine": False,
}

# --- images ---------------------------------------------------------------------
def trace_logo(src: Path) -> str:
    a = np.array(Image.open(src).convert("RGBA"))[:, :, 3].astype(np.float32) / 255
    ys, xs = np.where(a > 0.02)
    m = 8
    crop = a[ys.min() - m: ys.max() + m + 1, xs.min() - m: xs.max() + m + 1]
    target, s = float(crop.sum()), 8
    big = cv2.GaussianBlur(cv2.resize(crop, None, fx=s, fy=s, interpolation=cv2.INTER_CUBIC).clip(0, 1), (0, 0), s * 0.22)
    lo, hi = 0.05, 0.95
    for _ in range(30):  # pick the threshold at which the vector covers what the source covers
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if (big > mid).sum() / (s * s) > target else (lo, mid)
    mask = ((big > (lo + hi) / 2) * 255).astype(np.uint8)
    cnts, _ = cv2.findContours(mask, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE)
    parts = []
    for c in cnts:
        if cv2.contourArea(c) < 0.35 * s * s:
            continue
        pts = cv2.approxPolyDP(c, 0.7, True)[:, 0, :]
        if len(pts) >= 3:
            parts.append("M" + "L".join(f"{x / s:.1f} {y / s:.1f}" for x, y in pts) + "Z")
    h, w = mask.shape
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w / s:.1f} {h / s:.1f}">'
            f'<path fill="#fff" fill-rule="evenodd" d="{"".join(parts)}"/></svg>')

def cut_mark(src: Path, size: int = 80) -> bytes:
    im = Image.open(src).convert("RGB").crop((98, 60, 246, 208)).resize((size, size), Image.LANCZOS)
    mask = Image.new("L", (size * 4, size * 4), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, size * 4 - 1, size * 4 - 1), fill=255)
    im.putalpha(mask.resize((size, size), Image.LANCZOS))
    out = io.BytesIO()
    im.save(out, "PNG", optimize=True)
    return out.getvalue()

def data_uri(mime: str, raw: bytes) -> str:
    return f"data:{mime};base64,{base64.b64encode(raw).decode()}"

def build_css(logo_uri: str, mark_uri: str) -> str:
    ed = ".monaco-workbench .part.editor>.content .editor-group-container"
    wm = f"{ed} .editor-group-watermark .letterpress"
    return "\n".join([
        "/* HUNT: the title bar mark, the empty editor's logo and its graded backdrop */",
        f".monaco-workbench .part.titlebar>.titlebar-container>.titlebar-left>.window-appicon:not(.codicon){{"
        f"background-image:url({mark_uri})!important;background-size:20px!important}}",
        f"{wm}{{background-image:url({logo_uri})!important;background-size:contain!important;"
        f"background-position:center!important;filter:drop-shadow(0 0 10px rgba(255,255,255,.16))}}",
        # the workbench fades a whole empty group to half; that would grey the logo out,
        # so the group stays at full strength and the logo is dimmed on its own
        f"{ed}.empty{{opacity:1!important}}",
        f"{ed}>.editor-group-watermark-wrapper>.editor-group-watermark{{opacity:.85}}",
        # the logo is white; on a light theme it would vanish, so it is inverted there
        f".monaco-workbench.vs {wm},.monaco-workbench.hc-light {wm}{{filter:invert(1)}}",
        f".monaco-workbench.vs-dark {ed}>.editor-group-watermark-wrapper,"
        f".monaco-workbench.hc-black {ed}>.editor-group-watermark-wrapper{{"
        "background:radial-gradient(ellipse 70% 55% at 50% 44%,rgba(214,222,240,.07),"
        "rgba(214,222,240,.025) 45%,transparent 75%)}",
    ])

# --- writers --------------------------------------------------------------------
def render():
    logo = trace_logo(ROOT / "hunt/logo-white.png")
    mark = cut_mark(ROOT / "hunt/avatar.png")
    css = build_css(data_uri("image/svg+xml", logo.encode()), data_uri("image/png", mark))
    block = ("// <hunt-ui> generated by scripts/generate-hunt-ui.py; edit that, not this block\n"
             "const HUNT_UI_MARKER = 'hunt-ui-1';\n"
             f"const HUNT_UI_CSS = {json.dumps(css)};\n"
             "// </hunt-ui>")
    js = SERVER_JS.read_text(encoding="utf8")
    pat = re.compile(r"// <hunt-ui>.*?// </hunt-ui>", re.S)
    if not pat.search(js):
        raise SystemExit("server.js has no <hunt-ui> block to fill")
    js = pat.sub(lambda _m: block, js)

    pkg = json.loads(WELCOME.read_text(encoding="utf8"))
    defaults = pkg["contributes"]["configurationDefaults"]
    defaults.update(EDITOR_DEFAULTS)
    defaults["workbench.colorCustomizations"] = {f"[{THEME}]": COLORS}
    defaults["editor.tokenColorCustomizations"] = {f"[{THEME}]": {"textMateRules": TOKEN_RULES}}
    return logo, mark, js, json.dumps(pkg, indent=2, ensure_ascii=False) + "\n"

def contrast_report():
    def lum(h):
        h = h.lstrip("#")[:6]
        r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
        f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
        return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)
    def cr(a, b):
        x, y = sorted((lum(a), lum(b)), reverse=True)
        return (x + 0.05) / (y + 0.05)
    worst = min((cr(r["settings"]["foreground"], EDITOR), r["scope"][0]) for r in TOKEN_RULES)
    return f"lowest token contrast on the editor: {worst[0]:.2f} ({worst[1]}); WCAG AA asks 4.5"

def main():
    logo, mark, js, pkg = render()
    if "--check" in sys.argv:
        stale = [n for n, cur, new in (
            ("hunt/hunt-logo.svg", (ROOT / "hunt/hunt-logo.svg").read_text(encoding="utf8") if (ROOT / "hunt/hunt-logo.svg").exists() else "", logo),
            ("server.js", SERVER_JS.read_text(encoding="utf8"), js),
            ("welcome package.json", WELCOME.read_text(encoding="utf8"), pkg)) if cur != new]
        if stale:
            raise SystemExit("stale, rerun scripts/generate-hunt-ui.py: " + ", ".join(stale))
        print("hunt ui is up to date")
        return
    (ROOT / "hunt/hunt-logo.svg").write_text(logo, encoding="utf8")
    (ROOT / "hunt/hunt-mark.png").write_bytes(mark)
    SERVER_JS.write_text(js, encoding="utf8")
    WELCOME.write_text(pkg, encoding="utf8")
    print(f"logo {len(logo)} bytes, mark {len(mark)} bytes; {contrast_report()}")

if __name__ == "__main__":
    main()
