# HUNT

HUNT is an Android code editor built from the open-source VSCodroid project, which
embeds a Code - OSS (VS Code compatible) server and a Node.js runtime in the app.
This file describes what the HUNT fork changes, how to build it, and what has and
has not been tested. Upstream attribution, `LICENSE`, `NOTICE.md` and `licenses/`
are kept as they were.

## What changed in v6: the HUNT look

- Logo. The empty editor shows your HUNT logo, traced to a vector (`hunt/hunt-logo.svg`)
  so it stays sharp on any screen, with a soft glow. The title bar shows a round mark
  cut from the cat avatar (`hunt/hunt-mark.png`). Light themes get the logo inverted
  so it does not vanish.
- Graded dark. A palette for the default theme (Dark Modern): each surface is a step
  lighter than the one outside it, from the status bar and title bar (darkest) through
  the activity bar and side bar to the editor, with a silver accent taken from the
  logo and a cool-grey syntax set. The empty editor also gets a faint radial glow.
  VS Code theme colours are solid, so this is stepped tone, not a screen-wide gradient.
  The lowest syntax contrast is 4.96:1 (comments); every other token is above 6:1.
- Type and code line. The editor font is a stack of Android's own monospace faces that
  ends on the generic family, line height is 1.55 times the font size, the gutter is
  tighter (no glyph margin, 3 digits), the current line is highlighted, the cursor is
  2 px and smooth, bracket-pair guides follow the cursor, and there is 8 px of padding
  above and below. No font file is bundled: the page policy refuses a font from a
  data URI, and a bundled font needs its own licence handling.
- How it is applied. Both live in the app, not in the prebuilt server download, which
  the build verifies against the repository. The logo and mark are a stylesheet
  `server.js` adds to the workbench page before its first paint (the way the theme and
  trusted domains already are). The palette and editor settings are
  `configurationDefaults` of the bundled welcome extension, so anything you set in
  Settings wins. The palette is scoped to Dark Modern rather than being a theme of its
  own, because the pre-paint colour script only knows the themes in the server tree and
  an unknown default would flash the light web default on every launch.
- Regenerate with `python3 scripts/generate-hunt-ui.py` (needs numpy, opencv-python and
  Pillow); change the palette or settings at the top of that script.
- Extension versions. The repository requires a changed bundled extension to ship as a
  new version directory (`check-extension-updates.py`). The v5 rebrand edited five
  extensions in place, which broke that rule and would not have reached an installed
  copy. They are now `editor-menus` 1.0.1, `process-monitor` 1.4.1, `saf-bridge`
  1.12.4, `serve-network` 1.3.1 and `welcome` 1.9.2.
- App version 1.6.1 (code 18). Setup re-extracts only when the version code changes,
  so an install over an older build would otherwise keep the old `server.js` and
  extensions. The first launch after upgrading re-extracts everything, which takes
  minutes, as any upgrade does.
- `scripts/test-hunt-ui.js` (run by lint and release) checks the page gets the
  stylesheet once, that the logo and mark are real images, that the palette is scoped
  to the default theme, every colour is valid and readable, and the surfaces are
  graded. `test-server-bootstrap.js` now expects four injected page scripts.

Checked here: 101 of 101 colour keys exist in the bundled VS Code, the editor option
names exist, the `[Dark Modern]` scope is matched by the theme code in the bundle,
and the stylesheet was rendered in headless Chrome against the real `workbench.css`
(`Hunt-ui-preview.png`, a mock of the page structure, not a device screenshot).
Not checked: the look on a device. The two selectors target the 1.139.1 workbench; a
different server build that renames them would leave the stock logo, not break
anything.

## What changed in v5 (on top of v4)

Branding, user-visible text only. Identifiers are deliberately untouched (see below).

- Android strings: every "VSCodroid" in `res/values/strings.xml` and the 13 translated
  `values-*/strings.xml` files now reads "Hunt" (the launcher label, notifications and
  About title already did). Korean particles are correct for "Hunt"; the Turkish
  suffix is `Hunt'ı`.
- Bundled extensions (5): display names, command titles ("Hunt: Open Welcome",
  "Hunt: Manage Device Folder Storage" and so on), the settings group titles, the
  welcome walkthrough text and the notices in `extension.js`, in all 14 languages
  (70 `package.nls*.json` files, 2 `package.json`, 2 `extension.js`), moved to new
  version directories in v6.
- Editor product name: `assets/server.js` sets `nameShort` and `nameLong` to "Hunt"
  on every server start, so the window title and About show HUNT. It is done here
  and not in `branding/product.json` because the downloaded server tree is checked
  against that file at build time.
- Kotlin (user-visible strings only): the error and loading page heading, the
  WebView-update message, the unknown-command message, the bug report header and
  clipboard label, the copy-to-clipboard label, and the `README.md` the first run writes
  into the projects folder.
- Tests updated to match: `scripts/test-server-bootstrap.js`,
  `LoginShellFilesAtomicityTest.kt`.
- `.github/workflows/hunt-apk.yml`: every action is pinned to a full commit SHA
  (the repository's own `check-workflow-steps.py` failed on six unpinned actions
  before). A new step opens the APK before upload: signature, package ID, the label
  "Hunt", the arm64-v8a native code, the Node runtime, the server entry point and
  the notices must all be present or the run fails. The artifact is named
  `HUNT-<version>-debug.apk`, with the signature and badging reports beside it.

From v4 (previous revision, not re-reviewed line by line here): the launcher icon,
monochrome icon and background, `hunt-prepare-assets.sh`, the root Gradle shim that
runs it, and the manifest declaring a touchscreen as optional and `navigation` in
`configChanges`.

## What is deliberately not renamed

- Application ID `com.vscodroid` (`.debug` suffix on debug), the Kotlin package, the
  `vscodroid.*` setting keys and command IDs, the `vscodroid://` sign-in scheme,
  `.vscodroid` data folders and the `vscodroid.*` extension IDs. Native scripts,
  patches and installed data depend on them, and a new application ID installs as a
  separate app with none of the old data. Renaming them needs a full rebuild and
  test on a device, and is not worth the risk for a name nobody reads.
- Links to the upstream project (privacy policy, issue tracker, toolchain
  downloads, `reportIssueUrl`). HUNT has no site of its own to point them at.

## Known limits (not fixed)

1. Strings baked into the prebuilt server tree. About ten editor strings still say
   VSCodroid: "Welcome to VSCodroid" (onboarding), "Get Started with VSCodroid",
   "Setup VSCodroid", the reload prompts after installing or removing an extension
   or switching profile, and the title of the sign-in callback page. They come from
   `patches/0006` and `patches/0011`, compiled into the server download. Gradle
   re-runs `verifyServerTree` and the patch fingerprint check on that tree, so
   editing the files after download fails the build. Fixing it properly means
   re-branding those two patches, running the "Build Code - OSS server" workflow
   and pointing `VSCODE_OSS_URL` at the result.
2. OTG keyboard and mouse: reviewed, not changed, not tested on hardware. See below.
3. Layout redesign, flicker and rendering: no changes beyond the v6 look (logo, palette,
   editor defaults). Restructuring toolbars or panels, and any flicker fix, need a
   device or a log to find the cause, and guessing at rendering settings is how
   regressions start.
4. Release signing: only the debug build is covered.

## OTG keyboard and mouse: what the code already does

Read, not run:

- `MainActivity.dispatchKeyEvent` hands every key to the view tree first and only
  then observes it; a source-scan test (`HardwareKeyboardTest`) pins that order. It
  also reports Escape as handled so a keyboard map cannot turn it into Back.
- `HardwareTyping` takes the extra key row away only after printing keys from a real,
  non-virtual alphabetic keyboard, and gives it back on a finger touch or when the
  keyboard goes away. Mouse clicks and touchpads do not count as touch.
- The manifest declares `keyboard|keyboardHidden|navigation` in `configChanges`, so
  plugging a device in does not rebuild the activity and WebView.
- The caret-drag code only acts for `pointerType === 'touch'`, so a mouse is left to
  the editor.

Suspected gap, not verified and not changed: a mouse side button (Back or Forward)
reaches the app as a Back key, and `setupBackNavigation` answers it with
`moveTaskToBack`, which sends HUNT to the background. If that happens on your
mouse, the fix belongs in `MainActivity` (ignore Back or Forward from a mouse source
after the view tree has had the key), and needs a real mouse and the existing
`HardwareKeyboardTest` kept green. It was left alone because a wrong guess at key
routing is worse than the symptom.

## Build

Needs network. The first run downloads and compiles a lot (the editor server, Node,
Termux tools, Python, native add-ons).

- GitHub: Actions tab, "Hunt APK", Run workflow. Download the `hunt-debug-apk`
  artifact.
- AndroidForge or any runner starting Gradle from the repository root:
  `./gradlew assembleDebug`. The root `settings.gradle.kts` runs
  `scripts/hunt-prepare-assets.sh` first (skip with `HUNT_SKIP_ASSETS=1`).
- Local Linux: JDK 17, Android SDK with NDK `27.2.12479018` and CMake 3.22.1,
  Node 20 or newer, python3, curl, unzip, bsdtar, gpg, xz, make. Then
  `bash scripts/build-all.sh`.

Output: `android/app/build/outputs/apk/debug/app-debug.apk` (arm64-v8a only).

## Install

`adb install -r app-debug.apk`, or open the file on the phone. If Android reports a
signature conflict with an earlier build, uninstall the old one first; that deletes
its app data.

## Tests run for this revision (v6)

Run in a sandbox with Node 22 and Python 3.12, no Android toolchain, no network:

- `scripts/test-*.js`: 26 of 26 pass. `scripts/test-*.py`: 10 of 10 pass.
- `check-translatable-strings`, `check-welcome-claims`, `check-permission-claims`,
  `check-bundled-extensions`, `check-checklist-totals`, `check-lint-baseline`,
  `check-bridge-api-spec`, `check-build-steps`, `check-library-attribution`: pass. `verify-server-tree.py --self-test`: pass.
- `check-workflow-steps`: failed with six errors before (the old `hunt-apk.yml`),
  passes now.
- All 14 `strings.xml` files parse as XML; all extension JSON parses; `server.js`
  passes `node --check`.

Not run: Gradle, Kotlin compilation, Kotlin unit tests, lint, any install or launch,
server startup on a device, OTG keyboard and mouse, rotation, backgrounding,
repeated launches. A passing Gradle run is not proof the app works, and none was
done here.

The APK in your earlier build log (not rebuilt here): Gradle reported success, the APK is
arm64-v8a, carries the Node runtime and the server tree, has a debug v2 signature
block and the launcher label "Hunt". It was not installed or launched.
