package org.levimc.launcher.slimpy;

import android.os.SystemClock;
import android.view.MotionEvent;

/**
 * Real clicks-per-second tracking from actual input events.
 * Fixed-size ring buffers of primitive timestamps: no boxing, no allocation per click or per read.
 */
public final class CpsTracker {
    public static final int LEFT = 0;
    public static final int RIGHT = 1;

    private static final int CAPACITY = 256; // far above any physically possible CPS in a 3s window

    private final long[][] times = new long[2][CAPACITY];
    private final int[] head = new int[2];   // next write index
    private final int[] size = new int[2];

    private int lastMouseButtons = 0;

    /** Fraction of screen width to the left of which touches are treated as movement (joystick), not clicks. */
    private static final float JOYSTICK_ZONE = 0.35f;

    public synchronized void record(int button) {
        long now = SystemClock.elapsedRealtimeNanos();
        int h = head[button];
        times[button][h] = now;
        head[button] = (h + 1) % CAPACITY;
        if (size[button] < CAPACITY) size[button]++;
    }

    /** Clicks within the last windowMs, normalised to a per-second rate. */
    public synchronized int cps(int button, int windowMs) {
        long now = SystemClock.elapsedRealtimeNanos();
        long windowNs = windowMs * 1_000_000L;
        int n = size[button];
        int h = head[button];
        long[] t = times[button];
        int count = 0;
        for (int i = 1; i <= n; i++) {
            int idx = h - i;
            if (idx < 0) idx += CAPACITY;
            if (now - t[idx] > windowNs) break;
            count++;
        }
        if (windowMs == 1000) return count;
        return (int) ((count * 1000L + windowMs / 2) / windowMs);
    }

    public synchronized void clear() {
        size[0] = size[1] = 0;
        head[0] = head[1] = 0;
        lastMouseButtons = 0;
    }

    /**
     * Touch input. A finger-down on the look/attack side of the screen counts as a left click;
     * touches in the joystick zone are ignored so walking does not inflate CPS.
     * Touch has no distinct right-click, so right CPS stays 0 on touch.
     */
    public void onTouch(MotionEvent e, int screenWidthPx) {
        int action = e.getActionMasked();
        if (action != MotionEvent.ACTION_DOWN && action != MotionEvent.ACTION_POINTER_DOWN) return;
        if (e.getButtonState() != 0) return; // mouse/stylus buttons are handled by onMouse
        int idx = e.getActionIndex();
        if (e.getX(idx) >= screenWidthPx * JOYSTICK_ZONE) {
            record(LEFT);
        }
    }

    /** Mouse/gamepad-pointer input: edge-detect primary/secondary button presses. */
    public void onMouse(MotionEvent e) {
        int buttons = e.getButtonState();
        int pressed = buttons & ~lastMouseButtons;
        if ((pressed & MotionEvent.BUTTON_PRIMARY) != 0) record(LEFT);
        if ((pressed & MotionEvent.BUTTON_SECONDARY) != 0) record(RIGHT);
        lastMouseButtons = buttons;
    }
}
