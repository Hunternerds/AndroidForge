package org.levimc.launcher.slimpy;

/**
 * Bridge between Slimpy's settings and the native render layer (libslimpy.so).
 *
 * The native layer owns everything that has to touch Minecraft's renderer: the hard FPS cap
 * (swap interval), motion blur, block overlay, first-person view model and nametags. Java pushes ONE
 * float[] config snapshot per settings change (no per-frame JNI calls, no allocation after init).
 *
 * If libslimpy.so is not present or does not export nativeApplyConfig, every call is a safe no-op and
 * {@link #isAvailable()} returns false. The UI uses that to say honestly that render features are inactive.
 */
public final class SlimpyNative {

    // ---- float[] config layout (shared contract with the C++ side) ----
    public static final int CFG_VERSION = 0;
    public static final int CFG_FPS_LIMIT = 1;            // 0 = unlimited
    public static final int CFG_MOTION_BLUR_ON = 2;       // 0/1
    public static final int CFG_MOTION_BLUR_STRENGTH = 3; // 0..1
    public static final int CFG_BLOCK_OVERLAY_ON = 4;
    public static final int CFG_BLOCK_OVERLAY_R = 5;      // 0..1
    public static final int CFG_BLOCK_OVERLAY_G = 6;
    public static final int CFG_BLOCK_OVERLAY_B = 7;
    public static final int CFG_BLOCK_OVERLAY_A = 8;
    public static final int CFG_BLOCK_OVERLAY_THICKNESS = 9; // pixels
    public static final int CFG_VIEWMODEL_ON = 10;
    public static final int CFG_VIEWMODEL_X = 11;         // blocks (units/100)
    public static final int CFG_VIEWMODEL_Y = 12;
    public static final int CFG_VIEWMODEL_Z = 13;
    public static final int CFG_VIEWMODEL_SCALE = 14;     // 1.0 = default
    public static final int CFG_VIEWMODEL_ROT_X = 15;     // degrees
    public static final int CFG_VIEWMODEL_ROT_Y = 16;
    public static final int CFG_VIEWMODEL_ROT_Z = 17;
    public static final int CFG_NAMETAG_ON = 18;
    public static final int CFG_NAMETAG_DISTANCE = 19;    // blocks
    public static final int CFG_NAMETAG_SCALE = 20;       // 1.0 = default
    public static final int CFG_SIZE = 21;
    public static final float CONFIG_VERSION = 1f;

    private static final float[] CONFIG = new float[CFG_SIZE];
    private static boolean loadTried;
    private static boolean loaded;

    private SlimpyNative() {}

    private static synchronized boolean ensureLoaded() {
        if (!loadTried) {
            loadTried = true;
            try {
                System.loadLibrary("slimpy");
                loaded = true;
            } catch (UnsatisfiedLinkError | SecurityException e) {
                loaded = false;
            }
        }
        return loaded;
    }

    public static boolean isAvailable() {
        return ensureLoaded();
    }

    /** Pushes the current settings snapshot to native. Safe to call from any thread. */
    public static synchronized void push(SlimpySettings s) {
        if (!ensureLoaded()) return;
        float[] c = CONFIG;
        c[CFG_VERSION] = CONFIG_VERSION;
        c[CFG_FPS_LIMIT] = s.effectiveFpsLimit();
        c[CFG_MOTION_BLUR_ON] = s.motionBlurEnabled ? 1f : 0f;
        c[CFG_MOTION_BLUR_STRENGTH] = s.motionBlurStrength / 100f;
        c[CFG_BLOCK_OVERLAY_ON] = s.blockOverlayEnabled ? 1f : 0f;
        int col = s.blockOverlayColor;
        c[CFG_BLOCK_OVERLAY_R] = ((col >> 16) & 0xFF) / 255f;
        c[CFG_BLOCK_OVERLAY_G] = ((col >> 8) & 0xFF) / 255f;
        c[CFG_BLOCK_OVERLAY_B] = (col & 0xFF) / 255f;
        c[CFG_BLOCK_OVERLAY_A] = s.blockOverlayOpacity / 100f;
        c[CFG_BLOCK_OVERLAY_THICKNESS] = s.blockOverlayThickness;
        c[CFG_VIEWMODEL_ON] = s.viewModelEnabled ? 1f : 0f;
        c[CFG_VIEWMODEL_X] = s.viewModelX / 100f;
        c[CFG_VIEWMODEL_Y] = s.viewModelY / 100f;
        c[CFG_VIEWMODEL_Z] = s.viewModelZ / 100f;
        c[CFG_VIEWMODEL_SCALE] = s.viewModelScale / 100f;
        c[CFG_VIEWMODEL_ROT_X] = s.viewModelRotX;
        c[CFG_VIEWMODEL_ROT_Y] = s.viewModelRotY;
        c[CFG_VIEWMODEL_ROT_Z] = s.viewModelRotZ;
        c[CFG_NAMETAG_ON] = s.nametagEnabled ? 1f : 0f;
        c[CFG_NAMETAG_DISTANCE] = s.nametagDistance;
        c[CFG_NAMETAG_SCALE] = s.nametagScale / 100f;
        try {
            nativeApplyConfig(c);
        } catch (UnsatisfiedLinkError e) {
            loaded = false; // library present but without our entry point
        }
    }

    private static native void nativeApplyConfig(float[] config);
}
