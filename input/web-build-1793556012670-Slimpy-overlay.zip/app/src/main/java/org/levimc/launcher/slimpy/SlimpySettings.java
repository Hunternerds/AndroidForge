package org.levimc.launcher.slimpy;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Slimpy's single source of truth for user settings.
 *
 * - Plain volatile fields: readers (HUD, native bridge) never allocate or hit disk.
 * - Loaded defensively: missing/corrupt/out-of-range values fall back to defaults or are clamped.
 * - Writes are debounced onto SharedPreferences so dragging a slider does not thrash storage.
 */
public final class SlimpySettings {

    public interface Listener {
        void onSlimpySettingsChanged();
    }

    /** Allowed FPS-limit presets. 0 means unlimited. */
    public static final int[] FPS_PRESETS = {30, 60, 90, 120, 144, 165, 0};

    private static final String PREFS = "slimpy_settings";
    private static final String KEY_JSON = "json";
    private static final int SCHEMA_VERSION = 1;
    private static final long SAVE_DELAY_MS = 400;

    private static volatile SlimpySettings instance;

    // ---- Performance ----
    public volatile boolean unlockFps = false;
    /** Target FPS cap. 0 = unlimited. Ignored for display selection when unlockFps is true. */
    public volatile int fpsLimit = 0;

    // ---- HUD: FPS ----
    public volatile boolean fpsEnabled = true;
    public volatile int fpsX = 20;          // permille of screen width (0..1000)
    public volatile int fpsY = 20;          // permille of screen height (0..1000)
    public volatile int fpsScale = 100;     // percent (50..300)
    public volatile int fpsColor = 0xFFFFFFFF;
    public volatile boolean fpsBackground = true;
    public volatile int fpsBgOpacity = 45;  // percent
    public volatile int fpsUpdateMs = 500;  // 100..2000

    // ---- HUD: CPS ----
    public volatile boolean cpsEnabled = true;
    public volatile int cpsX = 20;
    public volatile int cpsY = 90;
    public volatile int cpsScale = 100;
    public volatile int cpsColor = 0xFFFFFFFF;
    public volatile boolean cpsBackground = true;
    public volatile int cpsBgOpacity = 45;
    public volatile int cpsUpdateMs = 100;  // 50..1000
    public volatile int cpsWindowMs = 1000; // 250..3000
    public volatile boolean cpsShowRight = true;

    // ---- Visual (consumed by the native render layer) ----
    public volatile boolean motionBlurEnabled = false;
    public volatile int motionBlurStrength = 40;   // 0..100

    public volatile boolean blockOverlayEnabled = false;
    public volatile int blockOverlayColor = 0xFF39E6A8;
    public volatile int blockOverlayOpacity = 80;  // percent
    public volatile int blockOverlayThickness = 2; // 1..8

    public volatile boolean viewModelEnabled = false;
    public volatile int viewModelX = 0;      // -100..100 (units of 1/100 block)
    public volatile int viewModelY = 0;
    public volatile int viewModelZ = 0;
    public volatile int viewModelScale = 100; // percent 40..200
    public volatile int viewModelRotX = 0;    // degrees -90..90
    public volatile int viewModelRotY = 0;
    public volatile int viewModelRotZ = 0;

    public volatile boolean nametagEnabled = false;
    public volatile int nametagDistance = 24; // blocks 4..64
    public volatile int nametagScale = 100;   // percent 50..200

    private final Context appContext;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final CopyOnWriteArrayList<Listener> listeners = new CopyOnWriteArrayList<>();
    private final Runnable saveRunnable = this::saveNow;

    private SlimpySettings(Context context) {
        this.appContext = context.getApplicationContext();
    }

    public static SlimpySettings get(Context context) {
        SlimpySettings local = instance;
        if (local == null) {
            synchronized (SlimpySettings.class) {
                local = instance;
                if (local == null) {
                    local = new SlimpySettings(context);
                    local.load();
                    instance = local;
                }
            }
        }
        return local;
    }

    public void addListener(Listener l) { if (l != null) listeners.addIfAbsent(l); }
    public void removeListener(Listener l) { listeners.remove(l); }

    /** Call after mutating any field. Notifies listeners and schedules a debounced save. */
    public void commit() {
        for (Listener l : listeners) {
            try { l.onSlimpySettingsChanged(); } catch (RuntimeException ignored) { }
        }
        mainHandler.removeCallbacks(saveRunnable);
        mainHandler.postDelayed(saveRunnable, SAVE_DELAY_MS);
    }

    public void resetToDefaults() {
        applyDefaults();
        commit();
    }

    /** The FPS cap that should actually be applied right now (0 = uncapped). */
    public int effectiveFpsLimit() {
        return unlockFps ? 0 : fpsLimit;
    }

    // ------------------------------------------------------------------ persistence

    private void load() {
        applyDefaults();
        try {
            SharedPreferences sp = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String raw = sp.getString(KEY_JSON, null);
            if (raw == null || raw.isEmpty()) return;
            JSONObject o = new JSONObject(raw);

            unlockFps = o.optBoolean("unlockFps", unlockFps);
            fpsLimit = sanitizeFpsLimit(o.optInt("fpsLimit", fpsLimit));

            fpsEnabled = o.optBoolean("fpsEnabled", fpsEnabled);
            fpsX = clamp(o.optInt("fpsX", fpsX), 0, 1000);
            fpsY = clamp(o.optInt("fpsY", fpsY), 0, 1000);
            fpsScale = clamp(o.optInt("fpsScale", fpsScale), 50, 300);
            fpsColor = o.optInt("fpsColor", fpsColor) | 0xFF000000;
            fpsBackground = o.optBoolean("fpsBackground", fpsBackground);
            fpsBgOpacity = clamp(o.optInt("fpsBgOpacity", fpsBgOpacity), 0, 100);
            fpsUpdateMs = clamp(o.optInt("fpsUpdateMs", fpsUpdateMs), 100, 2000);

            cpsEnabled = o.optBoolean("cpsEnabled", cpsEnabled);
            cpsX = clamp(o.optInt("cpsX", cpsX), 0, 1000);
            cpsY = clamp(o.optInt("cpsY", cpsY), 0, 1000);
            cpsScale = clamp(o.optInt("cpsScale", cpsScale), 50, 300);
            cpsColor = o.optInt("cpsColor", cpsColor) | 0xFF000000;
            cpsBackground = o.optBoolean("cpsBackground", cpsBackground);
            cpsBgOpacity = clamp(o.optInt("cpsBgOpacity", cpsBgOpacity), 0, 100);
            cpsUpdateMs = clamp(o.optInt("cpsUpdateMs", cpsUpdateMs), 50, 1000);
            cpsWindowMs = clamp(o.optInt("cpsWindowMs", cpsWindowMs), 250, 3000);
            cpsShowRight = o.optBoolean("cpsShowRight", cpsShowRight);

            motionBlurEnabled = o.optBoolean("motionBlurEnabled", motionBlurEnabled);
            motionBlurStrength = clamp(o.optInt("motionBlurStrength", motionBlurStrength), 0, 100);

            blockOverlayEnabled = o.optBoolean("blockOverlayEnabled", blockOverlayEnabled);
            blockOverlayColor = o.optInt("blockOverlayColor", blockOverlayColor) | 0xFF000000;
            blockOverlayOpacity = clamp(o.optInt("blockOverlayOpacity", blockOverlayOpacity), 0, 100);
            blockOverlayThickness = clamp(o.optInt("blockOverlayThickness", blockOverlayThickness), 1, 8);

            viewModelEnabled = o.optBoolean("viewModelEnabled", viewModelEnabled);
            viewModelX = clamp(o.optInt("viewModelX", viewModelX), -100, 100);
            viewModelY = clamp(o.optInt("viewModelY", viewModelY), -100, 100);
            viewModelZ = clamp(o.optInt("viewModelZ", viewModelZ), -100, 100);
            viewModelScale = clamp(o.optInt("viewModelScale", viewModelScale), 40, 200);
            viewModelRotX = clamp(o.optInt("viewModelRotX", viewModelRotX), -90, 90);
            viewModelRotY = clamp(o.optInt("viewModelRotY", viewModelRotY), -90, 90);
            viewModelRotZ = clamp(o.optInt("viewModelRotZ", viewModelRotZ), -90, 90);

            nametagEnabled = o.optBoolean("nametagEnabled", nametagEnabled);
            nametagDistance = clamp(o.optInt("nametagDistance", nametagDistance), 4, 64);
            nametagScale = clamp(o.optInt("nametagScale", nametagScale), 50, 200);
        } catch (JSONException | RuntimeException e) {
            // Corrupt store: fall back to defaults rather than crash on launch.
            applyDefaults();
        }
    }

    private void saveNow() {
        try {
            JSONObject o = new JSONObject();
            o.put("v", SCHEMA_VERSION);
            o.put("unlockFps", unlockFps);
            o.put("fpsLimit", fpsLimit);

            o.put("fpsEnabled", fpsEnabled);
            o.put("fpsX", fpsX);
            o.put("fpsY", fpsY);
            o.put("fpsScale", fpsScale);
            o.put("fpsColor", fpsColor);
            o.put("fpsBackground", fpsBackground);
            o.put("fpsBgOpacity", fpsBgOpacity);
            o.put("fpsUpdateMs", fpsUpdateMs);

            o.put("cpsEnabled", cpsEnabled);
            o.put("cpsX", cpsX);
            o.put("cpsY", cpsY);
            o.put("cpsScale", cpsScale);
            o.put("cpsColor", cpsColor);
            o.put("cpsBackground", cpsBackground);
            o.put("cpsBgOpacity", cpsBgOpacity);
            o.put("cpsUpdateMs", cpsUpdateMs);
            o.put("cpsWindowMs", cpsWindowMs);
            o.put("cpsShowRight", cpsShowRight);

            o.put("motionBlurEnabled", motionBlurEnabled);
            o.put("motionBlurStrength", motionBlurStrength);

            o.put("blockOverlayEnabled", blockOverlayEnabled);
            o.put("blockOverlayColor", blockOverlayColor);
            o.put("blockOverlayOpacity", blockOverlayOpacity);
            o.put("blockOverlayThickness", blockOverlayThickness);

            o.put("viewModelEnabled", viewModelEnabled);
            o.put("viewModelX", viewModelX);
            o.put("viewModelY", viewModelY);
            o.put("viewModelZ", viewModelZ);
            o.put("viewModelScale", viewModelScale);
            o.put("viewModelRotX", viewModelRotX);
            o.put("viewModelRotY", viewModelRotY);
            o.put("viewModelRotZ", viewModelRotZ);

            o.put("nametagEnabled", nametagEnabled);
            o.put("nametagDistance", nametagDistance);
            o.put("nametagScale", nametagScale);

            appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putString(KEY_JSON, o.toString()).apply();
        } catch (JSONException ignored) {
        }
    }

    /** Flush immediately (call from onPause/onStop so nothing is lost if the process dies). */
    public void flush() {
        mainHandler.removeCallbacks(saveRunnable);
        saveNow();
    }

    private void applyDefaults() {
        unlockFps = false; fpsLimit = 0;
        fpsEnabled = true; fpsX = 20; fpsY = 20; fpsScale = 100; fpsColor = 0xFFFFFFFF;
        fpsBackground = true; fpsBgOpacity = 45; fpsUpdateMs = 500;
        cpsEnabled = true; cpsX = 20; cpsY = 90; cpsScale = 100; cpsColor = 0xFFFFFFFF;
        cpsBackground = true; cpsBgOpacity = 45; cpsUpdateMs = 100; cpsWindowMs = 1000; cpsShowRight = true;
        motionBlurEnabled = false; motionBlurStrength = 40;
        blockOverlayEnabled = false; blockOverlayColor = 0xFF39E6A8; blockOverlayOpacity = 80; blockOverlayThickness = 2;
        viewModelEnabled = false; viewModelX = 0; viewModelY = 0; viewModelZ = 0; viewModelScale = 100;
        viewModelRotX = 0; viewModelRotY = 0; viewModelRotZ = 0;
        nametagEnabled = false; nametagDistance = 24; nametagScale = 100;
    }

    private static int sanitizeFpsLimit(int v) {
        for (int p : FPS_PRESETS) if (p == v) return v;
        return 0;
    }

    private static int clamp(int v, int lo, int hi) {
        return v < lo ? lo : Math.min(v, hi);
    }
}
