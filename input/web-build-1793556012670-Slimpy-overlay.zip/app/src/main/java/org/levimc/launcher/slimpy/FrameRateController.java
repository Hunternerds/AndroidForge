package org.levimc.launcher.slimpy;

import android.app.Activity;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;

/**
 * Real frame-pacing control through the Android display pipeline.
 *
 * Picks a supported display mode (same resolution, so no mode-switch flicker) whose refresh rate
 * matches the requested cap, and asks the window to use it (preferredDisplayModeId /
 * preferredRefreshRate). SurfaceFlinger then paces presentation to that rate.
 *
 * - Unlimited / unlock: highest refresh rate the panel supports.
 * - Cap N: highest supported rate that does not exceed N; if the panel has none (e.g. cap 30 on a
 *   60/120 panel) the lowest supported rate is used.
 *
 * Limitation (intentional honesty): this paces to the panel's vsync. A game that renders without
 * vsync is only hard-capped by the native swap-interval hook, which {@link SlimpyNative} drives.
 */
public final class FrameRateController {

    private static final float TOLERANCE_HZ = 1.5f;

    public static final class Result {
        public final float requestedFps;   // 0 = unlimited
        public final float appliedHz;      // refresh rate asked of the display, 0 if nothing applied
        public final float maxHz;          // highest refresh rate the panel supports at this resolution
        public final boolean applied;

        Result(float requestedFps, float appliedHz, float maxHz, boolean applied) {
            this.requestedFps = requestedFps;
            this.appliedHz = appliedHz;
            this.maxHz = maxHz;
            this.applied = applied;
        }
    }

    private FrameRateController() {}

    /** Must be called on the UI thread. */
    @SuppressWarnings("deprecation")
    public static Result apply(Activity activity, SlimpySettings settings) {
        int limit = settings.effectiveFpsLimit();
        try {
            Display display = activity.getWindowManager().getDefaultDisplay();
            Display.Mode current = display.getMode();
            Display.Mode[] modes = display.getSupportedModes();

            Display.Mode highest = null;
            Display.Mode lowest = null;
            Display.Mode bestUnderCap = null;

            for (Display.Mode m : modes) {
                if (m.getPhysicalWidth() != current.getPhysicalWidth()
                        || m.getPhysicalHeight() != current.getPhysicalHeight()) continue;
                float hz = m.getRefreshRate();
                if (highest == null || hz > highest.getRefreshRate()) highest = m;
                if (lowest == null || hz < lowest.getRefreshRate()) lowest = m;
                if (limit > 0 && hz <= limit + TOLERANCE_HZ
                        && (bestUnderCap == null || hz > bestUnderCap.getRefreshRate())) {
                    bestUnderCap = m;
                }
            }
            if (highest == null) return new Result(limit, 0f, 0f, false);

            Display.Mode target;
            if (limit <= 0) target = highest;
            else target = bestUnderCap != null ? bestUnderCap : lowest;

            Window window = activity.getWindow();
            WindowManager.LayoutParams lp = window.getAttributes();
            if (lp.preferredDisplayModeId != target.getModeId()
                    || lp.preferredRefreshRate != target.getRefreshRate()) {
                lp.preferredDisplayModeId = target.getModeId();
                lp.preferredRefreshRate = target.getRefreshRate();
                window.setAttributes(lp);
            }
            return new Result(limit, target.getRefreshRate(), highest.getRefreshRate(), true);
        } catch (RuntimeException e) {
            return new Result(limit, 0f, 0f, false);
        }
    }
}
