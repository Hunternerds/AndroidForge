package org.levimc.launcher.slimpy;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/**
 * One lightweight view that draws every Slimpy HUD element (FPS, CPS) in a single pass.
 * No per-element windows or views, no allocation in onDraw or in the update path:
 * text lives in reusable char[] buffers, geometry in reused Rect/RectF objects.
 */
final class SlimpyHudView extends View {

    private static final float BASE_TEXT_DP = 14f;
    private static final float PAD_H_DP = 8f;
    private static final float PAD_V_DP = 4f;
    private static final float RADIUS_DP = 6f;

    private static final class Element {
        final char[] buf;
        int len;
        boolean enabled;
        boolean background;
        int xPermille, yPermille, scale, color, bgOpacity;
        final RectF bounds = new RectF();
        final Rect dirty = new Rect();
        float textX, textBaseline;
        boolean laidOut;

        Element(int capacity) { buf = new char[capacity]; }
    }

    private final Element fps = new Element(16);
    private final Element cps = new Element(24);

    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Rect tmpUnion = new Rect();
    private final float density;

    private int lastFps = Integer.MIN_VALUE;
    private int lastCpsL = -1, lastCpsR = -1;
    private boolean lastShowRight;

    SlimpyHudView(Context context) {
        super(context);
        density = context.getResources().getDisplayMetrics().density;
        setWillNotDraw(false);
        setClickable(false);
        setFocusable(false);
        textPaint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        textPaint.setShadowLayer(2f * density, 0f, 1f * density, 0xAA000000);
        bgPaint.setStyle(Paint.Style.FILL);
    }

    /** Re-read configuration. Cheap; call only when settings changed. */
    void applySettings(SlimpySettings s) {
        configure(fps, s.fpsEnabled, s.fpsBackground, s.fpsX, s.fpsY, s.fpsScale, s.fpsColor, s.fpsBgOpacity);
        configure(cps, s.cpsEnabled, s.cpsBackground, s.cpsX, s.cpsY, s.cpsScale, s.cpsColor, s.cpsBgOpacity);
        // Force text to be rebuilt in the new layout on next value push.
        lastFps = Integer.MIN_VALUE;
        lastCpsL = lastCpsR = -1;
        rebuildFpsText(lastFps);
        layoutElement(fps);
        layoutElement(cps);
        invalidate();
    }

    private static void configure(Element e, boolean enabled, boolean bg, int x, int y, int scale, int color, int bgOpacity) {
        e.enabled = enabled;
        e.background = bg;
        e.xPermille = x;
        e.yPermille = y;
        e.scale = scale;
        e.color = color;
        e.bgOpacity = bgOpacity;
    }

    /** value < 0 means "no reading available". Returns true if the visible text changed. */
    boolean setFps(int value) {
        if (value == lastFps) return false;
        lastFps = value;
        rebuildFpsText(value);
        relayoutAndInvalidate(fps);
        return true;
    }

    boolean setCps(int left, int right, boolean showRight) {
        if (left == lastCpsL && right == lastCpsR && showRight == lastShowRight) return false;
        lastCpsL = left;
        lastCpsR = right;
        lastShowRight = showRight;
        int n = 0;
        char[] b = cps.buf;
        b[n++] = 'C'; b[n++] = 'P'; b[n++] = 'S'; b[n++] = ' ';
        n = writeInt(b, n, left);
        if (showRight) {
            b[n++] = ' '; b[n++] = '|'; b[n++] = ' ';
            n = writeInt(b, n, right);
        }
        cps.len = n;
        relayoutAndInvalidate(cps);
        return true;
    }

    private void rebuildFpsText(int value) {
        char[] b = fps.buf;
        int n = 0;
        b[n++] = 'F'; b[n++] = 'P'; b[n++] = 'S'; b[n++] = ' ';
        if (value < 0) {
            b[n++] = '-'; b[n++] = '-';
        } else {
            n = writeInt(b, n, Math.min(value, 99999));
        }
        fps.len = n;
    }

    private static int writeInt(char[] buf, int pos, int v) {
        if (v < 0) v = 0;
        if (v == 0) { buf[pos++] = '0'; return pos; }
        int digits = 0;
        for (int t = v; t > 0; t /= 10) digits++;
        int end = pos + digits;
        for (int i = end - 1; i >= pos; i--) { buf[i] = (char) ('0' + v % 10); v /= 10; }
        return end;
    }

    // ------------------------------------------------------------------ layout / draw

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        layoutElement(fps);
        layoutElement(cps);
    }

    private void relayoutAndInvalidate(Element e) {
        if (!e.enabled) return;
        tmpUnion.set(e.dirty);
        layoutElement(e);
        tmpUnion.union(e.dirty);
        invalidate(tmpUnion);
    }

    private void layoutElement(Element e) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0 || e.len == 0) { e.laidOut = false; e.dirty.setEmpty(); return; }
        float scale = e.scale / 100f;
        textPaint.setTextSize(BASE_TEXT_DP * density * scale);
        float padH = PAD_H_DP * density * scale;
        float padV = PAD_V_DP * density * scale;
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        float textW = textPaint.measureText(e.buf, 0, e.len);
        float boxW = textW + padH * 2f;
        float boxH = (fm.descent - fm.ascent) + padV * 2f;
        float left = Math.max(0f, (w - boxW) * (e.xPermille / 1000f));
        float top = Math.max(0f, (h - boxH) * (e.yPermille / 1000f));
        e.bounds.set(left, top, left + boxW, top + boxH);
        e.textX = left + padH;
        e.textBaseline = top + padV - fm.ascent;
        float pad = 4f * density; // shadow margin
        e.dirty.set((int) (left - pad), (int) (top - pad), (int) (left + boxW + pad) + 1, (int) (top + boxH + pad) + 1);
        e.laidOut = true;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        drawElement(canvas, fps);
        drawElement(canvas, cps);
    }

    private void drawElement(Canvas canvas, Element e) {
        if (!e.enabled || !e.laidOut || e.len == 0) return;
        float scale = e.scale / 100f;
        textPaint.setTextSize(BASE_TEXT_DP * density * scale);
        if (e.background && e.bgOpacity > 0) {
            bgPaint.setColor(((e.bgOpacity * 255 / 100) << 24) | 0x000000);
            float r = RADIUS_DP * density * scale;
            canvas.drawRoundRect(e.bounds, r, r, bgPaint);
        }
        textPaint.setColor(e.color);
        canvas.drawText(e.buf, 0, e.len, e.textX, e.textBaseline, textPaint);
    }
}
