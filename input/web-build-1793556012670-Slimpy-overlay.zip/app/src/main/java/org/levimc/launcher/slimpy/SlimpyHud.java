package org.levimc.launcher.slimpy;

import android.app.Activity;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;

import org.levimc.launcher.core.mods.inbuilt.nativemod.FpsMod;

/**
 * Owns the Slimpy HUD: one non-touchable overlay window, one update loop.
 * The window is FLAG_NOT_TOUCHABLE so it can never interfere with game controls.
 * The loop only runs while at least one HUD element is enabled, and wakes only when a value is due.
 */
public final class SlimpyHud implements SlimpySettings.Listener {

    private static final int ATTACH_RETRY_MS = 100;
    private static final int ATTACH_MAX_TRIES = 30;

    private final Activity activity;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final SlimpySettings settings;
    private final CpsTracker cps = new CpsTracker();

    private SlimpyHudView view;
    private WindowManager windowManager;
    private boolean attachedToWindowManager;
    private boolean showing;
    private int attachTries;

    private boolean fpsSourceTried;
    private boolean fpsSourceReady;

    private long fpsDue;
    private long cpsDue;
    private int screenWidthPx;

    private final Runnable attachRunnable = this::tryAttach;
    private final Runnable applyRunnable = this::applyOnMain;
    private final Runnable tickRunnable = this::tick;

    public SlimpyHud(Activity activity) {
        this.activity = activity;
        this.settings = SlimpySettings.get(activity);
    }

    public CpsTracker cpsTracker() { return cps; }

    // ------------------------------------------------------------------ lifecycle

    public void show() {
        if (showing) return;
        showing = true;
        attachTries = 0;
        settings.addListener(this);
        handler.post(attachRunnable);
    }

    public void hide() {
        if (!showing) return;
        showing = false;
        settings.removeListener(this);
        handler.removeCallbacks(attachRunnable);
        handler.removeCallbacks(applyRunnable);
        handler.removeCallbacks(tickRunnable);
        if (view != null) {
            try {
                if (attachedToWindowManager && windowManager != null) {
                    windowManager.removeViewImmediate(view);
                } else if (view.getParent() instanceof ViewGroup) {
                    ((ViewGroup) view.getParent()).removeView(view);
                }
            } catch (RuntimeException ignored) { }
        }
        view = null;
        attachedToWindowManager = false;
        cps.clear();
    }

    @Override
    public void onSlimpySettingsChanged() {
        handler.removeCallbacks(applyRunnable);
        handler.post(applyRunnable);
    }

    // ------------------------------------------------------------------ input (never consumes events)

    public void onTouch(MotionEvent event) {
        if (!showing || !settings.cpsEnabled || screenWidthPx <= 0) return;
        cps.onTouch(event, screenWidthPx);
    }

    public void onMouse(MotionEvent event) {
        if (!showing || !settings.cpsEnabled) return;
        cps.onMouse(event);
    }

    // ------------------------------------------------------------------ attach

    private void tryAttach() {
        if (!showing || view != null) return;
        if (activity.isFinishing() || activity.isDestroyed()) return;

        android.os.IBinder token = activity.getWindow().getDecorView().getWindowToken();
        if (token == null) {
            if (++attachTries <= ATTACH_MAX_TRIES) {
                handler.postDelayed(attachRunnable, ATTACH_RETRY_MS);
            } else {
                attachFallback();
            }
            return;
        }

        SlimpyHudView v = new SlimpyHudView(activity);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_PANEL,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.token = token;
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        try {
            windowManager = (WindowManager) activity.getSystemService(Activity.WINDOW_SERVICE);
            windowManager.addView(v, lp);
            attachedToWindowManager = true;
            view = v;
        } catch (RuntimeException e) {
            attachFallback();
            return;
        }
        onAttached();
    }

    private void attachFallback() {
        if (view != null || !showing) return;
        ViewGroup root = activity.findViewById(android.R.id.content);
        if (root == null) return;
        SlimpyHudView v = new SlimpyHudView(activity);
        v.setClickable(false);
        root.addView(v, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        view = v;
        attachedToWindowManager = false;
        onAttached();
    }

    private void onAttached() {
        DisplayMetrics dm = activity.getResources().getDisplayMetrics();
        screenWidthPx = dm.widthPixels;
        applyOnMain();
    }

    // ------------------------------------------------------------------ update loop

    private void applyOnMain() {
        if (!showing || view == null) return;
        screenWidthPx = activity.getResources().getDisplayMetrics().widthPixels;
        view.applySettings(settings);
        if (settings.fpsEnabled) ensureFpsSource();
        long now = SystemClock.uptimeMillis();
        fpsDue = now;
        cpsDue = now;
        handler.removeCallbacks(tickRunnable);
        if (settings.fpsEnabled || settings.cpsEnabled) {
            handler.post(tickRunnable);
        }
    }

    private void ensureFpsSource() {
        if (fpsSourceTried) return;
        fpsSourceTried = true;
        try {
            fpsSourceReady = FpsMod.init();
        } catch (UnsatisfiedLinkError | RuntimeException e) {
            fpsSourceReady = false;
        }
    }

    private void tick() {
        if (!showing || view == null) return;
        long now = SystemClock.uptimeMillis();
        long next = Long.MAX_VALUE;

        if (settings.fpsEnabled) {
            if (now >= fpsDue) {
                int value = -1;
                if (fpsSourceReady) {
                    try {
                        if (FpsMod.nativeIsInitialized()) value = FpsMod.nativeGetFps();
                    } catch (UnsatisfiedLinkError e) {
                        fpsSourceReady = false;
                    }
                }
                view.setFps(value);
                fpsDue = now + settings.fpsUpdateMs;
            }
            next = Math.min(next, fpsDue);
        }
        if (settings.cpsEnabled) {
            if (now >= cpsDue) {
                int window = settings.cpsWindowMs;
                boolean right = settings.cpsShowRight;
                view.setCps(cps.cps(CpsTracker.LEFT, window), right ? cps.cps(CpsTracker.RIGHT, window) : 0, right);
                cpsDue = now + settings.cpsUpdateMs;
            }
            next = Math.min(next, cpsDue);
        }
        if (next != Long.MAX_VALUE) {
            handler.postDelayed(tickRunnable, Math.max(1L, next - SystemClock.uptimeMillis()));
        }
    }
}
