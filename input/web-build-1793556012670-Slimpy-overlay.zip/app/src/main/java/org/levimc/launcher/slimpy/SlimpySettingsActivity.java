package org.levimc.launcher.slimpy;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import org.levimc.launcher.ui.activities.SettingsActivity;

/**
 * Slimpy's own settings UI. Built in code (no XML) so it carries no Levi layouts or styles and adds
 * no resource-merge risk. Every control writes straight into {@link SlimpySettings}; nothing is a
 * placeholder.
 */
public class SlimpySettingsActivity extends Activity {

    private interface IntGet { int get(); }
    private interface IntSet { void set(int v); }
    private interface BoolGet { boolean get(); }
    private interface BoolSet { void set(boolean v); }

    private static final int BG = 0xFF0A0C11;
    private static final int CARD = 0xFF141821;
    private static final int CARD_HI = 0xFF1D2333;
    private static final int ACCENT = 0xFF39E6A8;
    private static final int TEXT = 0xFFE8ECF4;
    private static final int MUTED = 0xFF8A93A6;

    private static final int[] SWATCHES = {
            0xFFFFFFFF, 0xFF39E6A8, 0xFF4FC3F7, 0xFFFFD54F, 0xFFFF5252, 0xFFFF80AB
    };
    private static final String[] TABS = {"Performance", "HUD", "Visual", "Launcher"};

    private SlimpySettings s;
    private LinearLayout content;
    private TextView[] tabViews;
    private float density;
    private int tab = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        s = SlimpySettings.get(this);
        density = getResources().getDisplayMetrics().density;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setFitsSystemWindows(true);

        // Header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(20), dp(16), dp(20), dp(8));
        TextView title = text("SLIMPY", 26, ACCENT, true);
        title.setLetterSpacing(0.18f);
        header.addView(title);
        header.addView(text("Lightweight performance client", 13, MUTED, false));
        root.addView(header);

        // Tabs
        HorizontalScrollView tabScroll = new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setPadding(dp(14), dp(4), dp(14), dp(8));
        tabViews = new TextView[TABS.length];
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            TextView t = text(TABS[i], 14, MUTED, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(16), dp(8), dp(16), dp(8));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(dp(4), 0, dp(4), 0);
            t.setLayoutParams(lp);
            t.setOnClickListener(v -> selectTab(idx));
            tabViews[i] = t;
            tabRow.addView(t);
        }
        tabScroll.addView(tabRow);
        root.addView(tabScroll);

        // Content
        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(4), dp(14), dp(24));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        selectTab(0);
    }

    @Override
    protected void onPause() {
        super.onPause();
        s.flush();
    }

    // ------------------------------------------------------------------ tabs

    private void selectTab(int idx) {
        tab = idx;
        for (int i = 0; i < tabViews.length; i++) {
            boolean on = i == idx;
            tabViews[i].setTextColor(on ? BG : MUTED);
            tabViews[i].setBackground(round(on ? ACCENT : CARD, 20));
        }
        content.removeAllViews();
        switch (tab) {
            case 0: buildPerformance(); break;
            case 1: buildHud(); break;
            case 2: buildVisual(); break;
            default: buildLauncher(); break;
        }
    }

    private void buildPerformance() {
        LinearLayout c = card("Frame rate");
        switchRow(c, "Unlock FPS", "Run at the panel's highest refresh rate with no cap.",
                () -> s.unlockFps, v -> { s.unlockFps = v; s.commit(); });
        String[] labels = {"30", "60", "90", "120", "144", "165", "Unlimited"};
        chipRow(c, "FPS limit", labels, presetIndex(), i -> {
            s.fpsLimit = SlimpySettings.FPS_PRESETS[i];
            s.commit();
        });
        float max = panelMaxHz();
        c.addView(note(max > 0
                ? "This panel supports up to " + Math.round(max) + " Hz. Limits above that are capped by the display."
                : "Could not read the panel's refresh rates."));

        LinearLayout n = card("How the limit is applied");
        n.addView(note("Slimpy asks Android to run the game window at the matching display refresh mode, "
                + "so frame pacing follows the panel. A hard in-engine cap is applied by the native layer when it is installed."));
        n.addView(note("Native layer: " + (SlimpyNative.isAvailable() ? "active" : "not installed")));
    }

    private void buildHud() {
        LinearLayout f = card("FPS counter");
        switchRow(f, "Show FPS", "Measured from the game's real frame presentation.",
                () -> s.fpsEnabled, v -> { s.fpsEnabled = v; s.commit(); });
        sliderRow(f, "Position X", 0, 100, "%", () -> s.fpsX / 10, v -> { s.fpsX = v * 10; s.commit(); });
        sliderRow(f, "Position Y", 0, 100, "%", () -> s.fpsY / 10, v -> { s.fpsY = v * 10; s.commit(); });
        sliderRow(f, "Size", 50, 300, "%", () -> s.fpsScale, v -> { s.fpsScale = v; s.commit(); });
        sliderRow(f, "Update interval", 100, 2000, " ms", () -> s.fpsUpdateMs, v -> { s.fpsUpdateMs = v; s.commit(); });
        colorRow(f, "Text color", () -> s.fpsColor, v -> { s.fpsColor = v; s.commit(); });
        switchRow(f, "Background", null, () -> s.fpsBackground, v -> { s.fpsBackground = v; s.commit(); });
        sliderRow(f, "Background opacity", 0, 100, "%", () -> s.fpsBgOpacity, v -> { s.fpsBgOpacity = v; s.commit(); });

        LinearLayout c = card("CPS counter");
        switchRow(c, "Show CPS", "Counted from real touch and mouse input.",
                () -> s.cpsEnabled, v -> { s.cpsEnabled = v; s.commit(); });
        switchRow(c, "Show right-click CPS", "Mouse only. Touch has no separate right click.",
                () -> s.cpsShowRight, v -> { s.cpsShowRight = v; s.commit(); });
        sliderRow(c, "Position X", 0, 100, "%", () -> s.cpsX / 10, v -> { s.cpsX = v * 10; s.commit(); });
        sliderRow(c, "Position Y", 0, 100, "%", () -> s.cpsY / 10, v -> { s.cpsY = v * 10; s.commit(); });
        sliderRow(c, "Size", 50, 300, "%", () -> s.cpsScale, v -> { s.cpsScale = v; s.commit(); });
        sliderRow(c, "Averaging window", 250, 3000, " ms", () -> s.cpsWindowMs, v -> { s.cpsWindowMs = v; s.commit(); });
        sliderRow(c, "Update interval", 50, 1000, " ms", () -> s.cpsUpdateMs, v -> { s.cpsUpdateMs = v; s.commit(); });
        colorRow(c, "Text color", () -> s.cpsColor, v -> { s.cpsColor = v; s.commit(); });
        switchRow(c, "Background", null, () -> s.cpsBackground, v -> { s.cpsBackground = v; s.commit(); });
        sliderRow(c, "Background opacity", 0, 100, "%", () -> s.cpsBgOpacity, v -> { s.cpsBgOpacity = v; s.commit(); });

        LinearLayout t = card("Third-person nametags");
        switchRow(t, "Show nametags", "Needs the native render layer.",
                () -> s.nametagEnabled, v -> { s.nametagEnabled = v; s.commit(); });
        sliderRow(t, "Max distance", 4, 64, " blocks", () -> s.nametagDistance, v -> { s.nametagDistance = v; s.commit(); });
        sliderRow(t, "Size", 50, 200, "%", () -> s.nametagScale, v -> { s.nametagScale = v; s.commit(); });
    }

    private void buildVisual() {
        LinearLayout status = card("Render layer");
        status.addView(note(SlimpyNative.isAvailable()
                ? "Native render layer is installed. These settings are sent to it live."
                : "Native render layer (libslimpy) is not installed in this build, so these settings are saved "
                + "but have no visible effect yet."));

        LinearLayout m = card("Motion blur");
        switchRow(m, "Enable motion blur", null, () -> s.motionBlurEnabled, v -> { s.motionBlurEnabled = v; s.commit(); });
        sliderRow(m, "Strength", 0, 100, "%", () -> s.motionBlurStrength, v -> { s.motionBlurStrength = v; s.commit(); });

        LinearLayout b = card("Block overlay");
        switchRow(b, "Enable block overlay", "Outlines the block you are looking at.",
                () -> s.blockOverlayEnabled, v -> { s.blockOverlayEnabled = v; s.commit(); });
        colorRow(b, "Color", () -> s.blockOverlayColor, v -> { s.blockOverlayColor = v; s.commit(); });
        sliderRow(b, "Opacity", 0, 100, "%", () -> s.blockOverlayOpacity, v -> { s.blockOverlayOpacity = v; s.commit(); });
        sliderRow(b, "Thickness", 1, 8, " px", () -> s.blockOverlayThickness, v -> { s.blockOverlayThickness = v; s.commit(); });

        LinearLayout vm = card("View model");
        switchRow(vm, "Enable view model", "Moves and scales your first-person hand and item.",
                () -> s.viewModelEnabled, v -> { s.viewModelEnabled = v; s.commit(); });
        sliderRow(vm, "Position X", -100, 100, "", () -> s.viewModelX, v -> { s.viewModelX = v; s.commit(); });
        sliderRow(vm, "Position Y", -100, 100, "", () -> s.viewModelY, v -> { s.viewModelY = v; s.commit(); });
        sliderRow(vm, "Position Z", -100, 100, "", () -> s.viewModelZ, v -> { s.viewModelZ = v; s.commit(); });
        sliderRow(vm, "Scale", 40, 200, "%", () -> s.viewModelScale, v -> { s.viewModelScale = v; s.commit(); });
        sliderRow(vm, "Rotation X", -90, 90, "\u00B0", () -> s.viewModelRotX, v -> { s.viewModelRotX = v; s.commit(); });
        sliderRow(vm, "Rotation Y", -90, 90, "\u00B0", () -> s.viewModelRotY, v -> { s.viewModelRotY = v; s.commit(); });
        sliderRow(vm, "Rotation Z", -90, 90, "\u00B0", () -> s.viewModelRotZ, v -> { s.viewModelRotZ = v; s.commit(); });
    }

    private void buildLauncher() {
        LinearLayout c = card("Launcher");
        c.addView(button("Open launcher settings", v ->
                startActivity(new Intent(this, SettingsActivity.class))));
        c.addView(button("Reset Slimpy settings", v -> {
            s.resetToDefaults();
            selectTab(tab);
        }));
        LinearLayout a = card("About");
        a.addView(note("Slimpy is built on open-source launcher code under the Apache-2.0 licence. "
                + "See LICENSE and NOTICE for credits."));
    }

    // ------------------------------------------------------------------ row builders

    private LinearLayout card(String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(round(CARD, 16));
        c.setPadding(dp(16), dp(14), dp(16), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(6), 0, dp(6));
        c.setLayoutParams(lp);
        TextView h = text(title.toUpperCase(), 12, ACCENT, true);
        h.setLetterSpacing(0.12f);
        h.setPadding(0, 0, 0, dp(6));
        c.addView(h);
        content.addView(c);
        return c;
    }

    private void switchRow(LinearLayout parent, String label, String desc, BoolGet get, BoolSet set) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.addView(text(label, 15, TEXT, false));
        if (desc != null) labels.addView(text(desc, 12, MUTED, false));
        row.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(get.get());
        sw.setThumbTintList(ColorStateList.valueOf(ACCENT));
        sw.setTrackTintList(ColorStateList.valueOf(CARD_HI));
        sw.setOnCheckedChangeListener((CompoundButton b, boolean on) -> set.set(on));
        row.addView(sw);
        parent.addView(row);
    }

    private void sliderRow(LinearLayout parent, String label, int min, int max, String unit, IntGet get, IntSet set) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, dp(6), 0, dp(6));
        LinearLayout top = new LinearLayout(this);
        TextView name = text(label, 14, TEXT, false);
        final TextView value = text(get.get() + unit, 14, ACCENT, true);
        top.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(value);
        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(Math.max(0, Math.min(max - min, get.get() - min)));
        bar.setProgressTintList(ColorStateList.valueOf(ACCENT));
        bar.setThumbTintList(ColorStateList.valueOf(ACCENT));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                int v = p + min;
                value.setText(v + unit);
                if (fromUser) set.set(v);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        row.addView(top);
        row.addView(bar);
        parent.addView(row);
    }

    private void chipRow(LinearLayout parent, String label, String[] options, int selected, IntSet onSelect) {
        parent.addView(text(label, 14, TEXT, false));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, dp(8), 0, dp(8));
        final TextView[] chips = new TextView[options.length];
        for (int i = 0; i < options.length; i++) {
            final int idx = i;
            TextView chip = text(options[i], 13, TEXT, true);
            chip.setPadding(dp(14), dp(8), dp(14), dp(8));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, dp(8), 0);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(v -> {
                for (int j = 0; j < chips.length; j++) styleChip(chips[j], j == idx);
                onSelect.set(idx);
            });
            styleChip(chip, i == selected);
            chips[i] = chip;
            row.addView(chip);
        }
        hs.addView(row);
        parent.addView(hs);
    }

    private void styleChip(TextView chip, boolean on) {
        chip.setTextColor(on ? BG : TEXT);
        chip.setBackground(round(on ? ACCENT : CARD_HI, 14));
    }

    private void colorRow(LinearLayout parent, String label, IntGet get, IntSet set) {
        parent.addView(text(label, 14, TEXT, false));
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, dp(8), 0, dp(8));
        final View[] swatches = new View[SWATCHES.length];
        for (int i = 0; i < SWATCHES.length; i++) {
            final int color = SWATCHES[i];
            View sw = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
            lp.setMargins(0, 0, dp(10), 0);
            sw.setLayoutParams(lp);
            sw.setOnClickListener(v -> {
                for (int j = 0; j < swatches.length; j++) styleSwatch(swatches[j], SWATCHES[j], SWATCHES[j] == color);
                set.set(color);
            });
            styleSwatch(sw, color, (get.get() | 0xFF000000) == color);
            swatches[i] = sw;
            row.addView(sw);
        }
        parent.addView(row);
    }

    private void styleSwatch(View v, int color, boolean selected) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        d.setStroke(dp(selected ? 3 : 1), selected ? TEXT : CARD_HI);
        v.setBackground(d);
    }

    private TextView button(String label, View.OnClickListener l) {
        TextView b = text(label, 15, BG, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(16), dp(12), dp(16), dp(12));
        b.setBackground(round(ACCENT, 14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(6), 0, dp(6));
        b.setLayoutParams(lp);
        b.setOnClickListener(l);
        return b;
    }

    private TextView note(String msg) {
        TextView t = text(msg, 12, MUTED, false);
        t.setPadding(0, dp(4), 0, dp(6));
        return t;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(int v) { return Math.round(v * density); }

    private int presetIndex() {
        for (int i = 0; i < SlimpySettings.FPS_PRESETS.length; i++) {
            if (SlimpySettings.FPS_PRESETS[i] == s.fpsLimit) return i;
        }
        return SlimpySettings.FPS_PRESETS.length - 1;
    }

    @SuppressWarnings("deprecation")
    private float panelMaxHz() {
        try {
            Display d = getWindowManager().getDefaultDisplay();
            Display.Mode cur = d.getMode();
            float max = 0f;
            for (Display.Mode m : d.getSupportedModes()) {
                if (m.getPhysicalWidth() == cur.getPhysicalWidth()
                        && m.getPhysicalHeight() == cur.getPhysicalHeight()) {
                    max = Math.max(max, m.getRefreshRate());
                }
            }
            return max;
        } catch (RuntimeException e) {
            return 0f;
        }
    }
}
