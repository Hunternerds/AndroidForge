# Slimpy overlay (changed/new files only)

Copy this folder's contents over a FULL project checkout (same relative paths). Do not unzip it as a standalone project.

## New (app/src/main/java/org/levimc/launcher/slimpy/)
- SlimpySettings         persistent, validated, debounced settings (corrupt-safe, clamped)
- CpsTracker             real left/right CPS from touch/mouse events (primitive ring buffers)
- SlimpyHudView          ONE view draws FPS + CPS, allocation-free in the update/draw path
- SlimpyHud              single non-touchable overlay window + one adaptive update loop
- FrameRateController    real frame pacing: selects the display mode matching the FPS cap / unlock
- SlimpyNative           one float[] config push to libslimpy (native render layer)
- SlimpySettingsActivity Slimpy-only settings UI (code-built, no Levi layouts)

## Edited
- InbuiltOverlayManager  starts/stops Slimpy HUD, applies frame rate, pushes native config, forwards input for CPS
- BaseActivity           Settings nav tab now opens Slimpy settings (launcher settings reachable from it)
- AndroidManifest.xml    registers SlimpySettingsActivity

## NOT in this overlay (needs the native sources)
Motion blur, block overlay, view model, nametags and the hard in-engine FPS cap are drawn by the native
layer. Java side (settings, UI, persistence, JNI config contract in SlimpyNative.CFG_*) is done; the
native implementation is not, and the UI says so when libslimpy is absent.
