/**
 * Self-check for the process monitor's classification and its phantom count.
 *
 * Runs anywhere Node runs. The monitor reads /proc, which does not exist on a
 * macOS workstation and holds an uncontrolled process list on a CI runner, so
 * start() takes the directory to scan and this points it at a fixture.
 *
 * The assertions are made at the far end of the wire -- on the snapshot JSON
 * the status bar extension reads -- rather than on classify() directly. Both a
 * misclassification and a process the scan never reached present as a wrong
 * label in that file, and only one of those is a classify() defect.
 *
 *   node scripts/test-process-monitor.js
 */

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const MONITOR = require.resolve('../android/app/src/main/assets/process-monitor.js');
const monitor = require(MONITOR);

const UID = process.getuid();

/**
 * One fake /proc entry.
 *
 * The stat layout matters: readCpuTime() slices past the closing paren of comm
 * and then indexes 11 and 12 for utime and stime, so the filler between ppid
 * and those two has to be exactly nine fields wide.
 */
function writeProc(root, pid, argv, { uid = UID, ppid = 1, padding = 1 } = {}) {
    const dir = path.join(root, String(pid));
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(
        path.join(dir, 'status'),
        `Name:\tnode\nPPid:\t${ppid}\nUid:\t${uid}\t${uid}\t${uid}\t${uid}\n`,
    );
    fs.writeFileSync(path.join(dir, 'cmdline'), argv.join('\0') + '\0'.repeat(padding));
    fs.writeFileSync(
        path.join(dir, 'stat'),
        `${pid} (node) S ${ppid} ${'0 '.repeat(9)}7 3\n`,
    );
}

const NODE = '/data/data/com.vscodroid/lib/arm64/libnode.so';
// The interpreter FirstRunSetup writes into settings.json as
// python.defaultInterpreterPath, which is what ms-python launches its server
// with. Not every language server is a Node one, and the two rules differ there.
const PY = '/data/user/0/com.vscodroid/files/usr/bin/python3';
// Taken from the monitor, not written out here. The chat-backend rule is
// anchored to this directory, and the monitor derives it from where it sits, so
// a fixture spelling the device's path itself would answer for a monitor whose
// anchor had moved away from it. Which directory this is does not matter to any
// case below; that they are the SAME directory is the whole of it.
const REH = monitor.REH_ROOT;
// Where assets/server.js and assets/dns-proxy.js sit on device, taken from the
// monitor for the same reason REH is: the two are siblings, and the monitor
// derives its own anchor from where it was unpacked.
const SRV = path.dirname(REH);
// Marketplace and bundled-by-us extensions are extracted here, which is a
// different tree from the editor's own extensions under REH.
const EXT = '/data/user/0/com.vscodroid/files/home/.vscodroid/extensions';
// The ceiling ProcessManager derives from device RAM and puts on the command
// line. It is on the real processes and it belongs on the fixtures, because it
// is the argument that used to be the only thing the details view printed.
const HEAP = '--max-old-space-size=488';
const DATA = '/data/user/0/com.vscodroid/files/home/.vscodroid/data';
// The local copy of one folder opened through the SAF picker, named by the hash
// Environment.getSafMirrorDir builds. It is where the editor is pointed, so
// every path under it is a workspace path the user chose.
const MIRROR = '/data/user/0/com.vscodroid/files/saf-mirrors/a1b2c3';

// The status bar extension, loaded for its label table alone.
//
// It requires 'vscode', which exists only inside the workbench, so the name is
// resolved to a stub the way scripts/test-process-monitor-extension.js does.
// Nothing here activates it; only the exported table is read, and that is the
// point of taking the module rather than reading its source. A regex over the
// file would agree with anything once it stopped matching.
const Module = require('module');
const { newestExtensionDir } = require('./lib/bundled-extension');
const resolveFilename = Module._resolveFilename;
Module._resolveFilename = function (request, ...rest) {
    return request === 'vscode' ? 'vscode' : resolveFilename.call(this, request, ...rest);
};
require.cache.vscode = { id: 'vscode', filename: 'vscode', loaded: true, exports: {} };
const { TYPE_LABELS, STALE_AFTER_MS } = require(path.join(
    newestExtensionDir('vscodroid.vscodroid-process-monitor-'), 'extension.js',
));

/**
 * The reader's staleness bound still covers the writer's cadence.
 *
 * The extension decides a snapshot is no longer about now once it is
 * STALE_AFTER_MS old, and derives that from its own polling interval; this
 * module writes snapshots every SCAN_INTERVAL_MS. Two constants in two files
 * that are equal today by coincidence, with nothing between them: slow the scan
 * for battery and every snapshot the extension ever reads is already stale, so
 * the status item is '$(pulse) --' forever and the process tree opens with a
 * line saying there is no data. No count moves and nothing here would have gone
 * red.
 *
 * Two beats of slack rather than exact equality: the reader is on its own timer,
 * so it always looks a fraction of a beat after the write it wants, and one
 * missed scan must not blank a working session.
 *
 * NEGATIVE CONTROL: raise SCAN_INTERVAL_MS to 30_000, the plausible battery
 * change, and this fails at 30000 against a required 60000.
 */
function checkStalenessBoundCoversScanCadence() {
    assert.ok(
        Number.isFinite(STALE_AFTER_MS) && Number.isFinite(monitor.SCAN_INTERVAL_MS),
        'one of the two constants is no longer exported, so this check is comparing nothing: ' +
        `STALE_AFTER_MS=${STALE_AFTER_MS}, SCAN_INTERVAL_MS=${monitor.SCAN_INTERVAL_MS}`,
    );
    assert.ok(
        STALE_AFTER_MS >= 2 * monitor.SCAN_INTERVAL_MS,
        `the monitor writes a snapshot every ${monitor.SCAN_INTERVAL_MS} ms and the status bar ` +
        `extension calls one stale after ${STALE_AFTER_MS} ms, which is under two writes. Every ` +
        'snapshot it reads is stale on arrival: the count blanks and the process tree says ' +
        'there is no data, all with the monitor running normally.',
    );
    return monitor.SCAN_INTERVAL_MS;
}

/**
 * Every type the monitor really emitted has a word a person can read.
 *
 * The two vocabularies are declared in different files with no compiler and,
 * until this, nothing else between them. classify() gained 'bootstrap' so the
 * monitor would count the process it runs inside, the extension's table was not
 * told, and the tooltip rendered the internal word beside human ones: '1
 * bootstrap, 3 system'. The extension now falls back to the word 'unknown'
 * maps to rather than to the type itself, so a future gap is no longer visible
 * to a user, and this is what makes it visible to whoever opens the gap.
 *
 * Asked of the snapshot rather than of classify()'s source, so it covers the
 * type scan() assigns without going through the classifier at all, which is
 * exactly the one that was missing. What it cannot see is a classification no
 * fixture above produces; the count below is printed so a shrinking one is
 * readable from a run.
 */
function checkLabelCoverage(snapshot) {
    assert.ok(
        Object.keys(TYPE_LABELS).length > 0,
        'the extension exported no label table, so this check would agree with anything',
    );
    const types = [...new Set(snapshot.tree.map((entry) => entry.type))].sort();
    assert.ok(types.length > 1, `only ${types.length} type(s) reached the snapshot`);

    const unlabelled = types.filter((type) => !(type in TYPE_LABELS));
    assert.deepStrictEqual(
        unlabelled, [],
        'the monitor emits these types and the status bar extension has no word for ' +
        `them, so the tooltip would offer the reader an internal identifier: ${unlabelled.join(', ')}`,
    );
    return types;
}

/**
 * Every row says which program it is.
 *
 * The details view and the counter's tooltip are the only places a person can
 * find out what is holding a slot, and both print this string. It used to be
 * argv[0] plus argv[1], which on this device is the bundled Node binary plus the
 * heap ceiling for nearly every process the app owns: on an idle API 33 emulator
 * five of six rows read `libnode.so --max-old-space-size=488` and the view named
 * nothing.
 *
 * The pairs matter as much as the strings. `bootstrap-fork` is launched twice
 * with different `--type=`, so a rule that keeps only the program name leaves two
 * rows sharing one identity, and a rule that keeps only the first argument leaves
 * every row sharing the heap flag. Both failures are asserted for, and the
 * expectations are compared as a set so that a pid dropping out of the snapshot
 * cannot quietly empty the check.
 */
function checkCommandNames(snapshot, byPid) {
    const expected = new Map([
        [process.pid, 'libnode.so server.js'],
        [1001, 'libnode.so server-main.js'],
        [1007, 'libnode.so bootstrap-fork --type=fileWatcher'],
        [1029, 'libnode.so bootstrap-fork --type=agentHost'],
        [1030, 'libnode.so copilot-android-arm64/index.js'],
        [1004, 'libbash.so'],
    ]);
    for (const [pid, want] of expected) {
        const got = byPid.get(pid);
        assert.ok(got, `pid ${pid} never reached the snapshot, so its name was never compared`);
        assert.strictEqual(
            got.cmd, want,
            `pid ${pid} is printed as ${JSON.stringify(got.cmd)}; a reader cannot tell it ` +
            `from the other rows built on the same runtime`,
        );
    }

    const names = snapshot.tree.map((entry) => entry.cmd);
    assert.ok(
        !names.includes(`libnode.so ${HEAP}`),
        'a row is named after the runtime and its heap ceiling, which every process here ' +
        'shares, so the details view says nothing about it',
    );
    return expected.size;
}

/**
 * The chat backend is found wherever the editor tree is, not where it once was.
 *
 * That rule is the only one in classify() anchored to a directory rather than to
 * a program name, and the directory belongs to the Kotlin side, which names it
 * in five places. Renaming the leaf is loud -- server.js builds the same leaf
 * from __dirname and drops the app into its minimal health-check server -- but
 * moving the PARENT, files/server to files/editor or under a versioned
 * directory, leaves every __dirname-relative path in server.js working and would
 * silently stop this rule matching. The chat backend then returns to
 * 'unknown', outside lsCpuTracker and so never marked idle.
 *
 * Measured by moving it: a copy of the monitor is loaded from a directory of its
 * own and asked about two processes, one under the copy's tree and one under the
 * path the rule used to name. Both are the same command line otherwise, so what
 * separates the answers is the anchor alone.
 *
 * NEGATIVE CONTROL: put the literal back -- `script.includes('/server/vscode-reh/')`
 * in place of `script.startsWith(REH_PREFIX)` -- and the two assertions below
 * swap answers, the moved tree going 'unknown' and the abandoned path
 * 'langserver'.
 */
function checkRehAnchorFollowsTheTree(baseTmp) {
    // A capital in the directory on purpose. classify() lower-cases the command
    // line before comparing, so an anchor taken from a path and not lower-cased
    // matches nothing on any checkout carrying one, which is every CI runner
    // this repository builds on.
    const moved = fs.mkdtempSync(path.join(baseTmp, 'Editor-Moved-'));
    const copy = path.join(moved, 'process-monitor.js');
    fs.copyFileSync(MONITOR, copy);
    const relocated = require(copy);

    // Resolved, because Node's loader hands a module a real path and macOS puts
    // its temporary directories behind a symlink: comparing the two spellings
    // would fail here for a reason that has nothing to do with the anchor.
    assert.strictEqual(
        relocated.REH_ROOT, path.join(fs.realpathSync(moved), 'vscode-reh'),
        'the monitor does not take the editor tree from its own directory, so a copy of it ' +
            'somewhere else still answers for wherever the original was unpacked',
    );
    assert.notStrictEqual(
        relocated.REH_ROOT, monitor.REH_ROOT,
        'the copy resolved the same tree as the original, so nothing below can tell an anchor ' +
            'that moved with the monitor from one that stayed where it was written',
    );

    const proc = path.join(moved, 'proc');
    const tail = 'node_modules/@github/copilot-android-arm64/index.js';
    writeProc(proc, 2001, [NODE, `${relocated.REH_ROOT}/${tail}`, '--stdio']);
    // The tree this rule used to name, now holding nothing this app unpacked.
    writeProc(proc, 2002, [NODE, `/data/user/0/com.vscodroid/files/server/vscode-reh/${tail}`, '--stdio']);

    const out = path.join(moved, 'tmp');
    fs.mkdirSync(out);
    process.env.TMPDIR = out;
    relocated.start({ procRoot: proc });
    relocated.stop();

    const snapshot = JSON.parse(fs.readFileSync(path.join(out, 'vscodroid-processes.json'), 'utf8'));
    const type = (pid) => (snapshot.tree.find((e) => e.pid === pid) || {}).type;
    assert.strictEqual(
        type(2001), 'langserver',
        "the chat agent's model backend under the tree the monitor was loaded from is " +
            `${type(2001)}: the rule names a directory this build no longer uses, so the ` +
            "largest process the app owns is counted as 'other' and never marked idle",
    );
    assert.strictEqual(
        type(2002), 'unknown',
        'a backend under the directory the editor was moved OUT of is still claimed as ours, ' +
            'so the anchor is a literal rather than the tree beside the monitor',
    );
    return relocated.REH_ROOT;
}

/**
 * The snapshot comes back after the directory it is written into is reclaimed.
 *
 * TMPDIR is cacheDir/tmp, and Android deletes an app's cache directory under
 * storage pressure while the app keeps running, so it can go mid-session. The
 * write was a bare writeFileSync into a path resolved once at start(), inside a
 * catch that only logs, and nothing here recreated the directory: one reclaim
 * froze the status bar counter, its tooltip and the process tree on their last
 * snapshot for the life of the server. The Kotlin writer into that same
 * directory recreates it on the way past; this one did not.
 *
 * NEGATIVE CONTROL: remove the `fs.mkdirSync(path.dirname(outputPath), ...)`
 * line from scan() and the last assertion goes red, because no later scan can
 * write the file again.
 */
function checkSnapshotSurvivesReclaim(baseTmp, proc) {
    const out = path.join(baseTmp, 'reclaimed');
    fs.mkdirSync(out);
    process.env.TMPDIR = out;
    const snapshotPath = path.join(out, 'vscodroid-processes.json');

    monitor.start({ procRoot: proc });
    monitor.stop();
    assert.ok(fs.existsSync(snapshotPath), 'the monitor wrote no snapshot at all, so this ' +
        'check cannot tell a recreated directory from one that was never used');

    fs.rmSync(out, { recursive: true, force: true });
    assert.ok(!fs.existsSync(snapshotPath), 'the fixture directory did not go, so the write ' +
        'below is not being asked the question this exists to ask');

    monitor.start({ procRoot: proc });
    monitor.stop();
    assert.ok(
        fs.existsSync(snapshotPath),
        'the snapshot was never written again after the directory holding it was reclaimed, ' +
            'so the status bar counter, its tooltip and the process tree render the last one ' +
            'for the life of the server',
    );
}

/**
 * The snapshot is replaced whole or not at all.
 *
 * The reader is a different process on a timer of the same period as the
 * writer's, so once the two phase-align a readFileSync lands inside the write.
 * A bare writeFileSync truncates the file first, so what the reader gets back is
 * JSON that does not parse -- which the extension answers by keeping its previous
 * state, exactly what it does when the monitor has stopped writing altogether,
 * leaving the two indistinguishable from the side that reads it.
 *
 * Driven by interrupting the write rather than by racing a reader, which would
 * only fail some of the time: fs.writeFileSync is replaced with one that writes
 * the first fragment of the payload and then throws, which is what a kill landing
 * mid-write leaves behind.
 *
 * NEGATIVE CONTROL: write straight to outputPath again and the file left behind
 * is the fragment, so both assertions below go red.
 */
function checkSnapshotIsReplacedWhole(baseTmp) {
    const out = fs.mkdtempSync(path.join(baseTmp, 'atomic-'));
    const proc = path.join(out, 'proc');
    writeProc(proc, 3001, [NODE, `${REH}/out/server-main.js`, '--host', '127.0.0.1']);
    writeProc(proc, 3002, ['/data/data/com.vscodroid/lib/arm64/libbash.so', '-l']);
    process.env.TMPDIR = out;
    const snapshotPath = path.join(out, 'vscodroid-processes.json');

    monitor.start({ procRoot: proc });
    monitor.stop();
    const whole = fs.readFileSync(snapshotPath, 'utf8');
    JSON.parse(whole);

    const realWrite = fs.writeFileSync;
    fs.writeFileSync = (file, data, options) => {
        realWrite(file, String(data).slice(0, 30), options);
        throw new Error('interrupted');
    };
    try {
        monitor.start({ procRoot: proc });
        monitor.stop();
    } finally {
        fs.writeFileSync = realWrite;
    }

    assert.strictEqual(
        fs.readFileSync(snapshotPath, 'utf8'), whole,
        'a write that could not finish left a truncated snapshot where the previous one was, so ' +
            'the next reader gets JSON that does not parse and cannot tell that from a monitor ' +
            'that has stopped writing',
    );
    assert.deepStrictEqual(
        fs.readdirSync(out).filter((name) => name !== 'proc'),
        ['vscodroid-processes.json'],
        `the failed write left files beside the snapshot: ${fs.readdirSync(out).join(', ')}`,
    );

    // A temporary file from a previous boot is reused, not joined.
    //
    // The failure the rename above cannot catch is a kill landing between the
    // write and the rename: the temporary file survives, and nothing sweeps
    // TMPDIR. This runs every ten seconds in a process the platform SIGKILLs as
    // a matter of routine, so a name carrying the pid makes each of those a new
    // file that stays for the life of the install. One fixed name means the next
    // scan writes over it.
    fs.writeFileSync(`${snapshotPath}.tmp`, 'left behind by a kill');
    monitor.start({ procRoot: proc });
    monitor.stop();
    assert.deepStrictEqual(
        fs.readdirSync(out).filter((name) => name !== 'proc'),
        ['vscodroid-processes.json'],
        'a temporary file left behind by an interrupted write is still there after a completed ' +
            `scan, so one accumulates per kill: ${fs.readdirSync(out).join(', ')}`,
    );
}

function main() {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'vscodroid-monitor-'));
    const proc = path.join(tmp, 'proc');
    process.env.TMPDIR = tmp;

    // Nothing on the machine running this is ever signalled, and the stub is
    // what proves the monitor does not try. The fixture below is larger than
    // the 24 processes at which idle servers used to be SIGTERMed, its pids are
    // small numbers that belong to whatever the host started at boot, and what
    // is asserted at the end of run() is that the monitor chose no pid at all.
    const signals = [];
    const realKill = process.kill;
    process.kill = (pid, signal) => { signals.push([pid, signal]); };
    try {
        run(tmp, proc, signals);
    } finally {
        process.kill = realKill;
    }
}

/**
 * The body of main(), split out only so the kill stub above wraps all of it.
 */
function run(tmp, proc, signals) {
    // The monitor runs inside this very process, so its own pid has to be one
    // of the fixture entries for the count to mean anything.
    writeProc(proc, process.pid, [NODE, '--max-old-space-size=512', '/data/user/0/com.vscodroid/files/server/server.js', '--host=127.0.0.1']);

    const cases = [
        // pid, argv, the type the snapshot must carry
        // The command line assets/server.js really forks, preload and heap
        // ceiling included. It used to be the entry point and its host alone,
        // which resembles nothing the app launches and let the preload's spelling
        // decide what this row is called: `--require` and the path as two tokens
        // makes the path the first non-option argument, so scriptArgument() picks
        // it up and checkCommandNames() below reads `libnode.so dns-proxy.js` for
        // the editor server. The type is unaffected either way, which is why only
        // a fixture carrying the option can hold the naming.
        [1001, [NODE, HEAP, `--require=${SRV}/dns-proxy.js`,
            `${REH}/out/server-main.js`, '--host', '127.0.0.1'], 'server'],
        [1002, [NODE, `${REH}/extensions/css-language-features/server/dist/node/cssServerMain.js`, '--node-ipc'], 'langserver'],
        [1003, [NODE, `${REH}/extensions/json-language-features/server/dist/node/jsonServerMain.js`, '--node-ipc'], 'langserver'],
        [1004, ['/data/data/com.vscodroid/lib/arm64/libbash.so', '-l'], 'terminal'],
        [1005, [NODE, '/data/user/0/com.vscodroid/files/home/projects/my-eslint-tool/index.js'], 'unknown'],
        [1006, [NODE, '/data/user/0/com.vscodroid/files/usr/share/reporter/index.js'], 'unknown'],
        [1007, [NODE, HEAP, `${REH}/out/bootstrap-fork`, '--type=fileWatcher'], 'fileWatcher'],
        // A folder opened from device storage is copied under saf-mirrors, so
        // everything below that path is the user's workspace. It used to be a
        // classification of its own, matched on the whole command line, and the
        // three fixtures here are the two directions of removing it. A script
        // inside a copied folder is no more the sync engine than any other
        // script the user runs; the engine is a thread inside the Android app
        // process and never appears in /proc at all.
        [1008, [NODE, `${MIRROR}/sync.js`], 'unknown'],
        // The half that cost something. A language server whose own program
        // path lies inside the copied folder returned 'safSync' before any
        // pattern was read: the interpreter of a venv the user made there and
        // selected, and the workspace TypeScript the built-in extension resolves
        // under node_modules. Neither entered lsCpuTracker, so neither could be
        // reported idle, while both held one of the 32 phantom slots and read as
        // 'storage' in the tooltip.
        [1034, [`${MIRROR}/.venv/bin/python`,
            `${EXT}/ms-python.python-2026.4.0/python_files/run-jedi-language-server.py`],
            'langserver'],
        [1035, [NODE, `${MIRROR}/node_modules/typescript/lib/tsserver.js`,
            '--useInferredProjectPerProjectRoot'], 'langserver'],
        // A marketplace language server, not one of the four bundled with the
        // editor, and the reason it is here: check-langserver-patterns.py globs
        // *ServerMain.js and *WorkerMain.js under vscode-reh/extensions and
        // cannot see this file at all. The pattern for it matched the extension's directory name until
        // classification moved to argument basenames, and nothing noticed.
        [1009, [NODE, `${EXT}/bradlc.vscode-tailwindcss-0.16.0/dist/tailwindServer.js`,
            '--node-ipc', '--clientProcessId=1'], 'langserver'],
        [1010, [NODE, `${EXT}/bradlc.vscode-tailwindcss-0.16.0/dist/tailwindModeServer.js`,
            '--node-ipc'], 'langserver'],
        // The other half of that pattern: a bare 'tailwind' would match all three of
        // these, and 'langserver' is what the details view tells the user, beside
        // advice that names an extension to disable. These are the user's own work.
        [1011, [NODE, '/data/user/0/com.vscodroid/files/home/projects/site/tailwind.config.js'],
            'unknown'],
        [1012, [NODE, '/data/user/0/com.vscodroid/files/home/projects/build-tailwind.js'],
            'unknown'],
        // The same specificity question for the patterns that are single words.
        // These four are one rule read in both directions, and either half alone
        // passes on the wrong one: a rule that only has to classify gopls is
        // satisfied by matching every basename containing it, and a rule that
        // only has to spare run-eslint.js is satisfied by matching nothing.
        [1013, [NODE, '/data/user/0/com.vscodroid/files/home/projects/site/run-eslint.js'],
            'unknown'],
        // The ESLint command-line tool, which is how ESLint is run from a
        // terminal or a task here: SELinux refuses to execve the .bin shim under
        // filesDir, so it is reached as a script path through the bundled Node.
        // A bare 'eslint' pattern accepted exactly this basename -- the whole
        // name plus a Node extension -- and classified the user's own lint run as
        // a language server, reported idle once it sat still. The server that
        // pattern looked like it covered has always had its own entry,
        // eslintServer, exercised at 1017.
        [1036, [NODE, '/data/user/0/com.vscodroid/files/home/projects/site/node_modules/eslint/bin/eslint.js',
            '.'], 'unknown'],
        // The pattern reaches this one through a flag's value, not through the
        // script being run: every argument is tested, and the basename of
        // --out=/tmp/tsserver-log.js is tsserver-log.js.
        [1014, [NODE, '/data/user/0/com.vscodroid/files/home/projects/site/build.js',
            '--out=/tmp/tsserver-log.js'], 'unknown'],
        // A server whose program name is the pattern with nothing around it, and
        // one that is the pattern plus the extension its entry point carries.
        [1015, ['/data/user/0/com.vscodroid/files/usr/bin/gopls', '-mode=stdio'], 'langserver'],
        [1016, [NODE, `${REH}/extensions/node_modules/typescript/lib/tsserver.js`,
            '--useInferredProjectPerProjectRoot'], 'langserver'],
        // The three servers whose program name carries a bare pattern on the
        // front rather than being one. They are here because the bare-word rule
        // above cannot reach them and nothing else would say so: a server that
        // stops being classified keeps running, keeps its slot against the
        // 32-process budget, and reads exactly like no server running.
        //
        // The first two ship in this APK. The ESLint extension's client forks
        // server/out/eslintServer.js, and ms-python runs
        // python_files/run-jedi-language-server.py through the interpreter --
        // that one on every stock install, because settings.json is written with
        // python.languageServer set to Jedi.
        [1017, [NODE, `${EXT}/dbaeumer.vscode-eslint-3.0.34/server/out/eslintServer.js`,
            '--node-ipc', '--clientProcessId=1'], 'langserver'],
        [1018, [PY, `${EXT}/ms-python.python-2026.4.0/python_files/run-jedi-language-server.py`],
            'langserver'],
        // Not bundled, and the reason the entry for it carries hyphens: pyright
        // arrives with an extension the user installs.
        [1019, [NODE, '/data/user/0/com.vscodroid/files/home/projects/node_modules/pyright/dist/pyright-langserver.js',
            '--stdio'], 'langserver'],
        // The other direction for two of those entries, so that neither is
        // satisfied by a rule that matches everything: a user's own script whose
        // name merely contains the server's, one of them under the very
        // interpreter that runs the real one.
        [1020, [PY, '/data/user/0/com.vscodroid/files/home/projects/tools/jedi-scraper.py'],
            'unknown'],
        [1021, [NODE, '/data/user/0/com.vscodroid/files/home/projects/site/eslintServer.config.js'],
            'unknown'],
        // The editor's own servers as they actually launch, which is the spelling
        // that was missing. Every one of these clients passes an extensionless
        // module path to `fork`, and Node puts it in argv[1] verbatim, so the
        // basename carries no `.js`. The fixtures above at 1002 and 1003 named
        // the file on disk instead, which is why they passed for years while the
        // real processes were classified 'unknown'. Both spellings are covered
        // now, since a client is free to change which it passes.
        [1022, [NODE, `${REH}/extensions/css-language-features/server/dist/node/cssServerMain`,
            '--node-ipc'], 'langserver'],
        [1023, [NODE, `${REH}/extensions/html-language-features/server/dist/node/htmlServerMain`,
            '--node-ipc'], 'langserver'],
        [1024, [NODE, `${REH}/extensions/json-language-features/server/dist/node/jsonServerMain`,
            '--node-ipc'], 'langserver'],
        // Markdown's, which no pattern reached at all before and which the gate
        // could not even see: it globbed *ServerMain.js and this is
        // serverWorkerMain.js. Its client builds `./dist/serverWorkerMain` and
        // forks it over IPC, so it is a real process holding a slot.
        [1025, [NODE, `${REH}/extensions/markdown-language-features/dist/serverWorkerMain`,
            '--node-ipc'], 'langserver'],
        // And the other direction, so none of the four is satisfied by a rule
        // that matches too much. A bare word has to be the whole basename, so a
        // user's own file merely starting with one of these names stays theirs.
        [1026, [NODE, '/data/user/0/com.vscodroid/files/home/projects/site/cssServerMain.helper.js'],
            'unknown'],
        [1027, [NODE, '/data/user/0/com.vscodroid/files/home/projects/serverWorkerMain-shim.js'],
            'unknown'],
        // 'vscode-eslint' used to be a pattern, and a hyphen put it on the
        // substring arm where the only names it could still reach were the
        // user's. It is gone, and this is what its absence has to keep true.
        [1028, [NODE, '/data/user/0/com.vscodroid/files/home/projects/vscode-eslint-shim.js'],
            'unknown'],
        // The two processes a signed-out, untouched editor left running on this
        // device beyond its own core before 1.139.1, measured on an API 33 and an
        // API 37 emulator: the agent host, and the model backend it forks. Patch
        // 0020 keeps both from starting from 1.139.1 on. The backend is the one
        // that was invisible. Its basename is `index.js`, so no pattern above can
        // name it, and as 'unknown' it was never marked idle.
        [1029, [NODE, HEAP, `${REH}/out/bootstrap-fork`, '--type=agentHost',
            '--logsPath', `${DATA}/logs`], 'system'],
        [1030, [NODE, `${REH}/node_modules/@github/copilot-android-arm64/index.js`,
            '--headless', '--no-auto-update', '--stdio', '--no-auto-login'], 'langserver'],
        // The other direction for that needle. It carries the node_modules and
        // scope segments precisely so a name merely containing 'copilot' stays
        // the user's, and being classified 'langserver' is what the details view
        // tells the user about a process.
        [1031, [NODE, '/data/user/0/com.vscodroid/files/home/projects/copilot-demo/index.js'],
            'unknown'],
        // The needle's own negative control, and the reason it is not a bare
        // package name: @github/copilot lists eight @github/copilot-<platform>
        // packages as optional dependencies, so this is what a user gets by
        // running the Copilot CLI's own install inside a project. It is theirs,
        // and 'langserver' would report it as an idle language server five
        // minutes later.
        [1032, [NODE, '/data/user/0/com.vscodroid/files/home/projects/site/node_modules/@github/copilot-linux-arm64/index.js',
            '--headless'], 'unknown'],
        // The other alias site, which the agent host does not use but the
        // session provider can: same tree, deeper path.
        [1033, [NODE, `${REH}/extensions/copilot/node_modules/@github/copilot-android-arm64/index.js`,
            '--stdio'], 'langserver'],
        // The two rules that were still matched against the whole command line
        // after everything else had moved to argument basenames, read in the
        // direction that costs something. A directory of the user's own was
        // enough to claim a process for one of them, and both return before
        // LANG_SERVER_PATTERNS: a language server run from inside either path was
        // outside lsCpuTracker, and so never marked idle, while it went on
        // holding one of the 32 phantom slots.
        [1037, [NODE, '/data/user/0/com.vscodroid/files/home/projects/server-main.js-notes/index.js'],
            'unknown'],
        [1038, [NODE, '/data/user/0/com.vscodroid/files/home/projects/bootstrap-forklift/build.js'],
            'unknown'],
        [1040, [NODE, '/projects/build.js', '--out=/tmp/tsserver.js'], 'unknown'],
        [1041, [NODE, '/projects/build.js', '/tmp/tsserver.js'], 'unknown'],
        [1042, [NODE, '/projects/build.js', '--out=/tmp/cssServerMain.js'], 'unknown'],
        [1043, [NODE, '/projects/build.js', 'server-main.js'], 'unknown'],
        [1044, [NODE, '/projects/build.js', 'bash'], 'unknown'],
        [1045, [NODE, HEAP, '/extensions/tsserver.js'], 'langserver'],
        [1046, [NODE, '--require', '/tmp/tsserver.js', '/projects/build.js'], 'unknown'],
        [1047, [NODE, '--require', '/hooks/a.js', '/extensions/tsserver.js'], 'langserver'],
        [1048, [NODE, '-e', 'tsserver.js'], 'unknown'],
        [1049, ['/data/app/pkg/lib/arm64/libldmusl.so', NODE, '/extensions/tsserver.js'], 'langserver'],
        [1050, ['/data/app/pkg/lib/arm64/libldmusl.so', PY, '/extensions/run-jedi-language-server.py'], 'langserver'],
        [1051, [PY, '-m', 'pylsp'], 'langserver'],
        [1052, [PY, '-c', 'pylsp'], 'unknown'],
        [1053, [NODE, '/projects/with space/build.js', '/tmp/tsserver.js'], 'unknown'],
        [1054, [NODE, '/extensions/with space/tsserver.js'], 'langserver'],
        [1055, [NODE, '--unknown-pair', '/tmp/tsserver.js', '/projects/build.js'], 'unknown'],
        [1056, ['/usr/bin/gopls', '--config=/tmp/file'], 'langserver'],
        [1057, ['/usr/bin/bash', '-c', 'node /tmp/tsserver.js'], 'terminal'],
    ];
    for (const [pid, argv] of cases) {
        writeProc(proc, pid, argv);
    }

    // The main Android process is not a phantom and must not reach the tree.
    writeProc(proc, 1100, ['com.vscodroid.debug']);
    // Zygote leaves the app's cmdline padded with NULs well past the one that ends the name.
    writeProc(proc, 1101, ['com.vscodroid'], { padding: 65 });
    // Another app's process, same device, different uid.
    writeProc(proc, 1200, [NODE, `${REH}/out/server-main.js`], { uid: UID + 1 });

    monitor.start({ procRoot: proc });
    monitor.stop();

    const snapshot = JSON.parse(fs.readFileSync(path.join(tmp, 'vscodroid-processes.json'), 'utf8'));
    const byPid = new Map(snapshot.tree.map((entry) => [entry.pid, entry]));

    for (const [pid, argv, want] of cases) {
        const got = byPid.get(pid);
        assert.ok(got, `pid ${pid} (${argv.join(' ')}) never reached the snapshot`);
        assert.strictEqual(got.type, want, `pid ${pid} (${argv.join(' ')}) was labelled ${got.type}`);
    }

    assert.ok(!byPid.has(1100), 'the main Android process was counted as a phantom');
    assert.ok(!byPid.has(1101), 'the main Android process, NUL padded as zygote leaves it, was counted as a phantom');
    assert.ok(!byPid.has(1200), "another uid's process was counted against our budget");

    // Well past the 24 processes at which idle servers used to be signalled,
    // which is what makes the no-signal assertions at the end of this function
    // mean something: a fixture under that count would have been left alone by
    // the old code too.
    const OLD_RECLAIM_COUNT = 24;
    assert.ok(
        snapshot.total >= OLD_RECLAIM_COUNT,
        `this fixture holds ${snapshot.total} processes, under the ${OLD_RECLAIM_COUNT} at ` +
            'which idle servers used to be signalled, so the no-signal assertions below ' +
            'would pass on the code they exist to refuse',
    );
    assert.deepStrictEqual(signals, [], `the first scan signalled ${JSON.stringify(signals)}`);

    // Android's phantom accounting is per-UID and counts the process this code
    // runs inside, which ProcessBuilder launched like any other. Skipping it
    // reported one fewer than the limit is measured against.
    assert.ok(byPid.has(process.pid), 'the bootstrap process the monitor runs in was not counted');

    assert.strictEqual(snapshot.total, snapshot.tree.length, 'total disagrees with the tree it summarises');
    assert.strictEqual(snapshot.budget.current, snapshot.total, 'budget.current disagrees with total');

    // The thresholds have to stand clear of what the app costs when nothing is
    // happening. They did not: the soft budget was chosen when the idle set was
    // smaller, the idle set grew to meet it, and a fresh install came up with
    // its own warning already lit and nothing open. An always-on warning is one
    // nobody reads, so this pins the relation rather than the numbers.
    const budget = snapshot.budget;
    for (const key of ['idle', 'soft', 'error', 'hard']) {
        assert.ok(
            Number.isInteger(budget[key]),
            `budget.${key} is missing, so the status bar has nothing to colour against ` +
            'and falls back to numbers of its own, which is the split this replaced',
        );
    }
    assert.ok(
        budget.soft > budget.idle,
        `the soft budget (${budget.soft}) is not above the idle baseline (${budget.idle}), ` +
        'so an untouched install shows a warning it can do nothing about',
    );
    assert.ok(
        budget.error > budget.soft && budget.hard > budget.error,
        `thresholds out of order: idle ${budget.idle}, soft ${budget.soft}, ` +
        `error ${budget.error}, hard ${budget.hard}`,
    );
    // Standing clear of the idle set is not enough, the ordinary session has to clear it
    // too. Opening ONE JavaScript file starts four processes (the ESLint server, two
    // tsserver processes and the typings installer; measured on API 37 with Code - OSS
    // 1.139.1), and Run adds a terminal, so the count of a session doing nothing unusual
    // is the idle set plus five. A soft budget under that lit the warning, and the amber
    // status item, for opening a file.
    const ONE_JAVASCRIPT_FILE = 4;
    const ONE_TERMINAL = 1;
    assert.ok(
        budget.soft > budget.idle + ONE_JAVASCRIPT_FILE + ONE_TERMINAL,
        `the soft budget (${budget.soft}) is at or under what one JavaScript file and a terminal ` +
        `cost on top of the idle ${budget.idle}: the warning would show for an ordinary session`,
    );
    // No threshold that promises an action. `reclaim` was the count at which
    // idle servers were signalled, and the details view rendered it as the one
    // number that made something happen on its own; a snapshot still naming it
    // would be describing a reclaim nothing performs.
    assert.ok(
        !('reclaim' in budget),
        `budget.reclaim is published as ${budget.reclaim}, naming a threshold at which nothing ` +
        'is reclaimed',
    );
    assert.strictEqual(snapshot.total, cases.length + 1, 'the count moved');

    // A language server seen once is not idle, and the field has to be there to
    // say so: the details view reads it off the row and treats a missing one as
    // 'not idle', so an absent field and a false one are the same to it and only
    // this can tell them apart.
    const servers = snapshot.tree.filter((e) => e.type === 'langserver');
    assert.ok(servers.length > 1, `only ${servers.length} language server(s) reached the snapshot`);
    assert.deepStrictEqual(
        servers.filter((e) => e.idle !== false).map((e) => e.pid), [],
        'a language server first seen in this very scan is reported idle, so the details view ' +
            'would call one idle that has never had a chance to run',
    );

    // The other direction, which needs time rather than another fixture: the
    // tracker holds the first scan's reading and the stat files never change, so
    // a scan five minutes later sees no CPU movement and every one of them is
    // idle. Date.now is moved rather than the fixtures, because what is being
    // measured is elapsed time and nothing else in the scan reads a clock.
    // One of them does not sit still, and it is what binds the ORDER of the two
    // calls the scan makes rather than only their result. trackLangServer is
    // what moves lastActive when the CPU time has changed, so a scan that asks
    // isIdle before it runs answers from the previous scan's reading: this
    // server used CPU between the two scans and would be called idle in the very
    // scan that saw the work. A first sighting cannot show that, because there
    // is no tracker entry yet and the answer is false whichever order they run
    // in.
    //
    // The mutation is asserted rather than assumed. A stat file that did not
    // change would leave this row indistinguishable from the ones that really
    // are idle, and the pair of assertions below would then both be satisfied by
    // a monitor that never reads CPU time at all.
    const BUSY = 1002;
    const busyStat = path.join(proc, String(BUSY), 'stat');
    const beforeStat = fs.readFileSync(busyStat, 'utf8');
    fs.writeFileSync(busyStat, beforeStat.replace('7 3', '9 5'));
    assert.notStrictEqual(
        fs.readFileSync(busyStat, 'utf8'), beforeStat,
        `pid ${BUSY}'s utime and stime did not move, so this fixture cannot tell a server that ` +
            'ran from one that sat idle',
    );
    assert.strictEqual(
        byPid.get(BUSY).type, 'langserver',
        `pid ${BUSY} is not classified as a language server, so its CPU time is never read and ` +
            'the reading above is not part of any comparison',
    );

    const realNow = Date.now;
    Date.now = () => realNow() + 6 * 60 * 1000;
    try {
        monitor.start({ procRoot: proc });
        monitor.stop();
    } finally {
        Date.now = realNow;
    }
    const later = JSON.parse(fs.readFileSync(path.join(tmp, 'vscodroid-processes.json'), 'utf8'));
    const stillBusy = later.tree
        .filter((e) => e.type === 'langserver' && e.pid !== BUSY && e.idle !== true)
        .map((e) => e.pid);
    assert.deepStrictEqual(
        stillBusy, [],
        'these language servers have not used a tick of CPU in six minutes and are still not ' +
            'reported idle, so the details view never marks one idle: ' +
            stillBusy.join(', '),
    );
    assert.strictEqual(
        later.tree.find((e) => e.pid === BUSY).idle, false,
        `pid ${BUSY} used CPU between the two scans and is still reported idle, so the row is ` +
            'answered from the reading taken before the one that saw the work, and the details ' +
            'view would mark a working server idle',
    );

    // Idle servers, a count past the old reclaim threshold, and no signal.
    //
    // The monitor used to SIGTERM every idle language server at this point,
    // and again under a critical memory-pressure file, and measured on device
    // the kill freed nothing: each server's extension restarted it under a new
    // pid within a second, the count never fell, and the restarted server was a
    // first sighting here that went idle and was killed again five minutes
    // later for the life of the session. So the idle rows are published for the
    // details view to name, and nothing is sent to them.
    //
    // NEGATIVE CONTROL: put the `process.kill(pid, 'SIGTERM')` loop back behind
    // `tree.length >= 24` and the first assertion goes red on every idle pid.
    const idleServers = later.tree
        .filter((e) => e.type === 'langserver' && e.idle === true)
        .map((e) => e.pid);
    assert.ok(idleServers.length > 1, `only ${idleServers.length} idle server(s) in the fixture`);
    assert.deepStrictEqual(
        signals, [],
        `a scan at ${later.total} processes with idle language servers ` +
            `${JSON.stringify(idleServers)} signalled ${JSON.stringify(signals)}. Their ` +
            'extensions restart them within a second, so the kill frees no slot and costs ' +
            'a re-index on a device already short of memory.',
    );

    // The other trigger the old code answered: the pressure file an older
    // Android side wrote into TMPDIR, which nothing writes now and a device
    // upgraded from that build may still hold. Written with the word that used
    // to mean "shed work", at the same instant as the scan above so the same
    // rows are idle and the busy one is still busy.
    fs.writeFileSync(path.join(tmp, 'vscodroid-memory-pressure'), 'critical\n');
    Date.now = () => realNow() + 6 * 60 * 1000;
    try {
        monitor.start({ procRoot: proc });
        monitor.stop();
    } finally {
        Date.now = realNow;
    }
    const pressured = JSON.parse(fs.readFileSync(path.join(tmp, 'vscodroid-processes.json'), 'utf8'));
    const stillIdle = pressured.tree
        .filter((e) => e.type === 'langserver' && e.idle === true)
        .map((e) => e.pid);
    assert.deepStrictEqual(
        stillIdle, idleServers,
        'the idle rows changed between two scans in which no CPU time moved, so the pressure ' +
            'scan is not measuring the same servers',
    );
    assert.deepStrictEqual(
        signals, [],
        `a scan under a critical memory-pressure file signalled ${JSON.stringify(signals)}; ` +
            'the servers come straight back, so the pressure is not relieved by it',
    );

    const cadence = checkStalenessBoundCoversScanCadence();
    const labelled = checkLabelCoverage(snapshot);
    const named = checkCommandNames(snapshot, byPid);

    // All three repoint TMPDIR, which start() resolves the snapshot from, so
    // they run after everything that reads it.
    checkSnapshotSurvivesReclaim(tmp, proc);
    checkSnapshotIsReplacedWhole(tmp);
    const moved = checkRehAnchorFollowsTheTree(tmp);

    assert.deepStrictEqual(
        signals, [],
        `something after the main fixture signalled ${JSON.stringify(signals)}`,
    );

    fs.rmSync(tmp, { recursive: true, force: true });
    console.log(
        `ok -- ${snapshot.total} processes counted, ${cases.length} classifications checked, ` +
        `${labelled.length} types all labelled by the status bar extension, ` +
        `a ${cadence} ms scan inside the extension's ${STALE_AFTER_MS} ms staleness bound, ` +
        `${named} rows named after the program they run, ` +
        `${idleServers.length} idle servers published and none signalled at ${later.total} ` +
        'processes or under memory pressure, ' +
        `snapshot rewritten after its directory was reclaimed and replaced whole or not at all, ` +
        `chat backend still found under a tree moved to ${path.basename(path.dirname(moved))}`,
    );
}

main();
