#!/usr/bin/env bash
# Hunt: fetch and build everything the APK needs that is not in the source tree,
# so that a plain `gradle assembleDebug` (all AndroidForge runs) produces an APK
# with the editor in it. Without this the app installs, shows "Starting server...",
# then "Failed to start development server", because libnode.so (the Node runtime)
# and the VS Code server were never packaged.
#
# This is scripts/build-all.sh steps 1-10, in the same order, plus provisioning of
# whatever the build machine lacks (Node, NDK, bsdtar, gnupg, cmake). It is run by
# the root settings.gradle.kts before the android/ build is configured, because that
# build measures assets/ at configuration time.
#
# Safe to re-run: it exits at once when the assets are already in place.
# Skip it entirely with HUNT_SKIP_ASSETS=1 or -PhuntSkipAssets.
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
ASSETS="$ROOT_DIR/android/app/src/main/assets"
JNI="$ROOT_DIR/android/app/src/main/jniLibs/arm64-v8a"
TOOLS="${HUNT_TOOLS_DIR:-${HOME:-/tmp}/.hunt-tools}"
NDK_VERSION="27.2.12479018"

STEP="starting"
log()  { printf '\n[hunt-assets %s] %s\n' "$(date +%T)" "$*"; }
step() { STEP="$*"; log "$*"; }
on_err() {
    local code=$?
    printf '\n[hunt-assets] FAILED during: %s (exit %s)\n' "$STEP" "$code" >&2
    exit "$code"
}
trap on_err ERR

already_prepared() {
    [ -f "$ASSETS/vscode-reh/out/server-main.js" ] \
        && [ -f "$JNI/libnode.so" ] \
        && [ "$(wc -c < "$JNI/libnode.so")" -gt 1000000 ]
}
if already_prepared; then
    log "assets already in place, nothing to do"
    exit 0
fi

have() { command -v "$1" >/dev/null 2>&1; }

SUDO=""
if [ "$(id -u)" != "0" ] && have sudo; then SUDO="sudo"; fi
apt_install() {
    have apt-get || { echo "apt-get not available; cannot install: $*" >&2; return 1; }
    $SUDO apt-get update -y >/dev/null 2>&1 || true
    $SUDO env DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "$@"
}

# ---------------------------------------------------------------- host tools
step "Checking host tools"
have curl    || apt_install curl ca-certificates
have unzip   || apt_install unzip
have python3 || apt_install python3
have git     || apt_install git
have bsdtar  || apt_install libarchive-tools
have gpg     || apt_install gnupg
have xz      || apt_install xz-utils
have make    || apt_install build-essential
have cmake   || apt_install cmake

node_major() { have node && node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0; }
if [ "$(node_major)" -lt 20 ]; then
    step "Installing a host Node.js 24"
    case "$(uname -m)" in aarch64|arm64) arch=arm64 ;; *) arch=x64 ;; esac
    base="https://nodejs.org/dist/latest-v24.x"
    file="$(curl -fsSL "$base/SHASUMS256.txt" | awk -v a="linux-$arch.tar.xz" '$2 ~ (a "$") {print $2; exit}')"
    [ -n "$file" ]
    mkdir -p "$TOOLS"
    curl -fsSL "$base/$file" | tar -xJ -C "$TOOLS"
    export PATH="$TOOLS/${file%.tar.xz}/bin:$PATH"
fi
log "node $(node --version), python3 $(python3 --version 2>&1 | cut -d' ' -f2), cmake $(cmake --version | head -1 | cut -d' ' -f3)"

# --------------------------------------------------------------------- NDK
step "Locating Android NDK $NDK_VERSION"
ndk_ok() { [ -n "${1:-}" ] && [ -f "$1/source.properties" ] && grep -q '^Pkg.Revision *= *27\.' "$1/source.properties"; }
NDK=""
for cand in "${ANDROID_NDK_HOME:-}" "${ANDROID_NDK_ROOT:-}" \
            "${ANDROID_HOME:-/nonexistent}/ndk/$NDK_VERSION" \
            "${ANDROID_SDK_ROOT:-/nonexistent}/ndk/$NDK_VERSION" \
            "$TOOLS/android-sdk/ndk/$NDK_VERSION"; do
    if ndk_ok "$cand"; then NDK="$cand"; break; fi
done

if [ -z "$NDK" ]; then
    step "Installing Android NDK $NDK_VERSION"
    HUNT_SDK="$TOOLS/android-sdk"
    SDKMANAGER="$(command -v sdkmanager || true)"
    if [ -z "$SDKMANAGER" ]; then
        for d in "${ANDROID_HOME:-}" "${ANDROID_SDK_ROOT:-}" /opt/android-sdk /usr/local/lib/android/sdk /usr/lib/android-sdk; do
            [ -n "$d" ] || continue
            c="$(ls -d "$d"/cmdline-tools/*/bin/sdkmanager 2>/dev/null | sort -V | tail -1 || true)"
            if [ -n "$c" ]; then SDKMANAGER="$c"; break; fi
        done
    fi
    if [ -z "$SDKMANAGER" ]; then
        log "no sdkmanager found, downloading Google's command-line tools"
        mkdir -p "$HUNT_SDK/cmdline-tools" "$TOOLS/dl"
        curl -fsSL -o "$TOOLS/dl/cmdline-tools.zip" \
            "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
        unzip -q -o "$TOOLS/dl/cmdline-tools.zip" -d "$HUNT_SDK/cmdline-tools"
        rm -rf "$HUNT_SDK/cmdline-tools/latest"
        mv "$HUNT_SDK/cmdline-tools/cmdline-tools" "$HUNT_SDK/cmdline-tools/latest"
        SDKMANAGER="$HUNT_SDK/cmdline-tools/latest/bin/sdkmanager"
    fi
    yes | "$SDKMANAGER" --sdk_root="$HUNT_SDK" --licenses >/dev/null 2>&1 || true
    "$SDKMANAGER" --sdk_root="$HUNT_SDK" "ndk;$NDK_VERSION"
    NDK="$HUNT_SDK/ndk/$NDK_VERSION"
fi
ndk_ok "$NDK" || { echo "NDK at $NDK is not r27" >&2; false; }
export ANDROID_NDK_HOME="$NDK" ANDROID_NDK_ROOT="$NDK"
log "NDK: $NDK"

# ------------------------------------------------------------ server source
# The project publishes the built Code - OSS server as a release asset. Fetch it by
# URL so no GitHub login is needed. Override with VSCODE_OSS_URL for a mirror.
VSCODE_VERSION="$(tr -d '[:space:]' < VSCODE_VERSION)"
export VSCODE_OSS_URL="${VSCODE_OSS_URL:-https://github.com/rmyndharis/VSCodroid/releases/download/server-$VSCODE_VERSION/vscode-reh-web-linux-arm64-$VSCODE_VERSION.tar.gz}"
log "server tree: $VSCODE_OSS_URL"

# -------------------------------------------------- the build-all.sh sequence
run() { step "$1"; shift; "$@"; }
run "1/14 Checking prerequisites"                       bash scripts/setup.sh
run "2/14 Fetching the Code - OSS server tree"          bash scripts/fetch-vscode-oss.sh
run "3/14 Installing the server tree into assets"       bash scripts/package-assets.sh
run "4/14 Building translated interface bundles"        python3 scripts/build-nls-bundles.py
run "5/14 Downloading Termux tools"                     bash scripts/download-termux-tools.sh
run "6/14 Downloading npm"                              bash scripts/download-npm.sh
run "7/14 Downloading Python"                           bash scripts/download-python.sh
run "8/14 Downloading extensions"                       bash scripts/download-extensions.sh
run "9/14 Downloading the musl loader"                  bash scripts/download-musl-loader.sh
run "10/14 Downloading the Node.js runtime (libnode)"   bash scripts/download-node.sh
run "11/14 Building native addons"                      bash scripts/build-native-addons.sh
run "12/14 Building the glibc compatibility shim"       bash scripts/build-glibc-shim.sh \
                                                            --scan "$ASSETS/vscode-reh" --scan "$ASSETS/extensions"
run "13/14 Building the exec interceptor"               bash scripts/build-termux-exec.sh
run "14/14 Building the execution trampoline and shim"  bash -c 'bash scripts/build-exec-trampoline.sh && bash scripts/build-claude-shim.sh'

step "Final check"
already_prepared || { echo "assets are still incomplete after the pipeline ran" >&2; false; }
log "done: the editor and native tools are in place; Gradle can package them now"
