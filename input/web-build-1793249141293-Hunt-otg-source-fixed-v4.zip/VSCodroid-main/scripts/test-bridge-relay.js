/**
 * Self-check for the BroadcastChannel bridge relay, end to end.
 *
 *   node scripts/test-bridge-relay.js
 *
 * The relay is JavaScript written inside a Kotlin raw string and handed to
 * `WebView.evaluateJavascript`. Nothing compiles it, nothing lints it, and no
 * unit test reads it -- Kotlin tests exercise the bridge methods it calls and
 * stop at the language boundary. So the half of a bridge change that is
 * actually user-visible had no cover at all: inverting a ternary here, or
 * going back to an unconditional `ok: true`, leaves every suite green and
 * restores the defect in full.
 *
 * This extracts the real relay from MainActivity.kt, runs it against a stub
 * AndroidBridge, and drives it through the real bundled extension, so the only
 * faked things are Android itself and the vscode API. What is asserted is what
 * the user would be shown.
 *
 * Extraction is deliberately strict. If the raw string moves or changes shape
 * this fails saying so, rather than quietly checking an empty string -- the
 * failure mode that makes a scan of nothing look like a pass.
 */
'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const Module = require('module');
const vm = require('vm');
const { EXTENSIONS_DIR, newestExtensionDir } = require('./lib/bundled-extension');

require('./test-auth-callback-provider');

const ROOT = path.join(__dirname, '..');
const MAIN_ACTIVITY = path.join(
    ROOT, 'android/app/src/main/kotlin/com/vscodroid/MainActivity.kt',
);
const ANDROID_BRIDGE = path.join(
    ROOT, 'android/app/src/main/kotlin/com/vscodroid/bridge/AndroidBridge.kt',
);
const STRINGS_XML = path.join(
    ROOT, 'android/app/src/main/res/values/strings.xml',
);
const ENVIRONMENT_KT = path.join(
    ROOT, 'android/app/src/main/kotlin/com/vscodroid/util/Environment.kt',
);
const PROCESS_MANAGER = path.join(
    ROOT, 'android/app/src/main/kotlin/com/vscodroid/service/ProcessManager.kt',
);
const SAF_STORAGE_MANAGER = path.join(
    ROOT, 'android/app/src/main/kotlin/com/vscodroid/storage/SafStorageManager.kt',
);

/**
 * One of the user-facing decline reasons, read from where it now lives.
 *
 * The relay used to hold this sentence as a literal and the checks below read it
 * from there. It moved to the bridge, which is the only side that knows which
 * failure happened, so the checks follow it rather than being dropped: the
 * question they ask is about the words a user is shown, and those words are the
 * same words wherever they are declared.
 */
function bridgeReason(name) {
    const src = fs.readFileSync(ANDROID_BRIDGE, 'utf8');
    // Two hops, because the words moved once already. The bridge now names a
    // resource rather than carrying the sentence, so that a translation can
    // reach it; the sentence itself lives in strings.xml. Following both hops
    // keeps this asking the question it has always asked, which is about the
    // words a user is shown, not about where they happen to be declared.
    const ref = src.match(new RegExp('val ' + name + '\\s*=\\s*R\\.string\\.(\\w+)'));
    assert.ok(
        ref,
        name + ' is gone from AndroidBridge.kt, so this check has nothing to read. If the ' +
        'reasons moved, point this at their new home rather than deleting the check.',
    );
    const strings = fs.readFileSync(STRINGS_XML, 'utf8');
    const text = strings.match(
        new RegExp('<string name="' + ref[1] + '"[^>]*>([\\s\\S]*?)</string>'),
    );
    assert.ok(
        text,
        name + ' points at R.string.' + ref[1] + ', which strings.xml does not declare. ' +
        'The bridge would then fail at getString rather than showing the reason.',
    );
    // What a user reads, not what the file stores: the resource compiler
    // unescapes these, and a format argument is filled before the sentence is
    // shown, so the assertions below would otherwise compare against text that
    // never appears on screen.
    return text[1]
        .replace(/%\d+\$s/g, '')
        .replace(/\\'/g, "'")
        .replace(/\\"/g, '"')
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .trim();
}

/** How a literal dollar is written inside a Kotlin raw string. */
const DOLLAR_ESCAPE = "${'$'}";

/**
 * The bundled bridge extension, whatever version it is at.
 *
 * Not a hardcoded directory. Bumping the version of a bundled extension is
 * mandatory here whenever its contents change -- a device only re-extracts a
 * directory whose name it does not already have -- so a path pinned to one
 * version is a path that breaks on the next correct change, and the version in
 * it is stale the moment anyone edits the extension.
 *
 * Ordered by parsed version rather than by name, because 1.10.0 sorts below
 * 1.9.0 as text. check-welcome-claims.py sorts its directory by parsed version
 * for the same reason; the comparison here is not identical to that one -- it
 * zero-pads a shorter tail where Python's tuple compare would sort it first --
 * which only shows up between 1.2 and 1.2.0 and does not arise in this tree.
 */
function bridgeExtension() {
    return path.join(
        newestExtensionDir('vscodroid.vscodroid-saf-bridge-'), 'extension.js',
    );
}

/**
 * The body of the raw string in one of MainActivity's injectors, with the
 * indentation `trimIndent()` removes taken off, which is the text the WebView is
 * given.
 *
 * Takes the function name because there are two scripts worth running here, not
 * one. `injectWindowOpenOverride` calls the same bridge method as the relay and
 * reads its answer differently, so a change to that answer can be right in one
 * and inverted in the other.
 *
 * @param mustMention a token the extracted text has to contain, so that pulling
 *   the wrong block fails here instead of passing as a scan of something else.
 */
function extractInjected(fnName, mustMention) {
    const lines = fs.readFileSync(MAIN_ACTIVITY, 'utf8').split('\n');
    const fn = lines.findIndex((l) => l.includes('private fun ' + fnName + '()'));
    assert.notStrictEqual(
        fn, -1,
        fnName + '() is gone from MainActivity.kt, so this check has nothing to run. ' +
        'If it moved, point this at its new home rather than deleting the check.',
    );

    const open = lines.findIndex((l, i) => i > fn && l.trim() === '"""');
    const close = lines.findIndex((l, i) => i > open && l.trim().startsWith('"""'));
    assert.ok(open !== -1 && close !== -1 && close > open + 1,
        'could not find the raw string in ' + fnName + '(); its shape changed');

    const body = lines.slice(open + 1, close);
    const indent = Math.min(
        ...body.filter((l) => l.trim()).map((l) => l.length - l.trimStart().length),
    );
    const js = body.map((l) => (l.trim() ? l.slice(indent) : '')).join('\n');

    // A bare $ is interpolated by Kotlin before the WebView ever sees the string,
    // so the injected script would not be the one written here. The escape for a
    // literal dollar is itself spelled with one, so valid escapes are removed
    // before looking -- checking the raw text would reject exactly the form this
    // message tells the reader to use.
    const withoutEscapes = js.split(DOLLAR_ESCAPE).join('');
    assert.ok(
        !withoutEscapes.includes('$'),
        'the relay contains a bare $, which Kotlin interpolates into the raw string before the ' +
        'WebView sees it. Escape it, or the injected script is not what is written here.',
    );
    assert.ok(js.includes(mustMention),
        'the extracted text does not mention ' + mustMention + ', so the wrong block was extracted');

    // Resolve the escapes the way Kotlin does, so what runs below is what runs there.
    return js.split(DOLLAR_ESCAPE).join('$');
}

// ---- the Android side, stubbed -------------------------------------------
// The bridge answers with the reason it did not open, and the empty string when
// it did. A boolean here would let a relay that inverted the test stay green.
let bridgeAnswer = '';
const bridgeCalls = [];

// The four disk-walking commands answer by reply id: they hand back at once and
// the value follows through the relay's reply hook. So the stub's return value
// is not the answer, it is only the refusal channel, and every case below that
// wants an answer has to post one.
let listAnswer = '';
let reclaimAnswer = '';
let breakdownAnswer = '';
const listCalls = [];
const reclaimCalls = [];
const breakdownCalls = [];

// The key row toggle answers on the caller's thread with the state it has just
// saved, true meaning hidden.
let toggleAnswer = false;
const toggleCalls = [];

// The bug report is answered inline too, with the report, or with the empty
// string when the session token was refused.
let reportAnswer = '';
const reportCalls = [];

const AndroidBridge = {
    openExternalUrl(url, token) {
        bridgeCalls.push({ url, token });
        return bridgeAnswer;
    },
    listSafMirrors(token, replyId) {
        listCalls.push({ token, replyId });
        return listAnswer;
    },
    reclaimSafMirror(token, hash, force, replyId) {
        reclaimCalls.push({ token, hash, force, replyId });
        return reclaimAnswer;
    },
    getStorageBreakdown(token, replyId) {
        breakdownCalls.push({ token, replyId });
        return breakdownAnswer;
    },
    toggleExtraKeyRow(token) {
        toggleCalls.push({ token });
        return toggleAnswer;
    },
    generateBugReport(token) {
        reportCalls.push({ token });
        return reportAnswer;
    },
};

// ---- the vscode API, stubbed ---------------------------------------------
const shown = { info: [], error: [] };
// Every warning shown, with the options and the buttons it was shown with.
const warnings = [];
let inputBoxAnswer = null;
// The folders the extension activates into, the listeners it leaves for a folder
// added afterwards, and the commands it runs on its own.
let workspaceFolders = [];
const folderListeners = [];
const executed = [];
// The files the extension reads through the editor, and the one file there is:
// the editor server's note, by path, holding `serverNote`, or nothing when null.
const fileReads = [];
let serverNotePath = null;
let serverNote = null;
// What the user does at each prompt of the device-folder flow. Null is the
// dismissal, which is what every case that does not reach a removal wants.
let quickPickChoice = null;
let warningChoice = null;
// What the user picks from an information message's buttons, given them.
let infoChoice = null;
// The untitled documents the extension opens, the ones it shows in an editor,
// and what it puts on the clipboard. A document holds what the user sees, which
// they may edit before choosing anything.
const openedDocs = [];
const shownDocs = [];
const runLines = [];
const clipboard = [];
// The status bar items the extension makes, each marked while it shows, and who
// listens for a document closing.
const statusItems = [];
const closeListeners = [];
// Every command run, with its arguments, for the ones whose arguments matter.
const ranWith = [];
// What the editor shows besides folders: the workspace file, the documents, the
// tabs and the terminals, and the directories the extension lists, by path. A
// listing that is absent throws as the workbench does for a missing directory.
let workspaceFile;
let textDocuments = [];
let notebookDocuments = [];
let tabGroups = { all: [], activeTabGroup: undefined };
let terminals = [];
let directories = new Map();
let directoryRead;
let storageUpdate;
let documentShow;
let commandRun;
class TabInputText { constructor(uri) { this.uri = uri; } }
/** A Uri with the one method the extension calls on it. */
function uriOf(scheme, authority, p) {
    return { scheme, authority, path: p, with(change) { return uriOf(scheme, authority, change.path); } };
}
const commands = new Map();
const vscodeStub = {
    commands: {
        registerCommand: (id, fn) => { commands.set(id, fn); return { dispose() {} }; },
        executeCommand: async (id, ...args) => {
            executed.push(id); ranWith.push([id, ...args]);
            if (commandRun) return commandRun(id, ...args);
        },
    },
    window: {
        showInputBox: async () => inputBoxAnswer,
        showInformationMessage: async (m, ...items) => {
            shown.info.push(m);
            return infoChoice ? infoChoice(items) : undefined;
        },
        showTextDocument: async (doc) => { shownDocs.push(doc); if (documentShow) await documentShow(doc); return {}; },
        showErrorMessage: (m) => { shown.error.push(m); },
        // Answers only with a button the call offered, as the workbench does, so a
        // warning that loses its button loses the action behind it too. The
        // options come first when there are any, as in the API.
        showWarningMessage: async (message, ...rest) => {
            const options = rest.length && typeof rest[0] === 'object' ? rest.shift() : {};
            warnings.push({ message, options, items: rest });
            return rest.includes(warningChoice) ? warningChoice : undefined;
        },
        showQuickPick: async (items) => (quickPickChoice ? quickPickChoice(items) : undefined),
        createStatusBarItem: (...args) => {
            const item = { args, shown: false, show() { this.shown = true; }, hide() { this.shown = false; }, dispose() {} };
            statusItems.push(item);
            return item;
        },
        get tabGroups() { return tabGroups; },
        get terminals() { return terminals; },
        createTerminal(options) {
            const terminal = { name: options.name, show() {}, sendText(line) { runLines.push(line); },
                dispose() { terminals = terminals.filter(item => item !== this); } };
            terminals.push(terminal);
            return terminal;
        },
    },
    workspace: {
        get workspaceFolders() { return workspaceFolders; },
        get workspaceFile() { return workspaceFile; },
        get textDocuments() { return textDocuments; },
        getWorkspaceFolder() { return undefined; },
        get notebookDocuments() { return notebookDocuments; },
        openTextDocument: async (options) => {
            const doc = { options, text: options.content, getText() { return this.text; } };
            openedDocs.push(doc);
            return doc;
        },
        onDidChangeWorkspaceFolders: (fn) => { folderListeners.push(fn); return { dispose() {} }; },
        onDidCloseTextDocument: (fn) => { closeListeners.push(fn); return { dispose() {} }; },
        fs: {
            readFile: async (uri) => {
                fileReads.push(uri.path);
                if (serverNote === null || uri.path !== serverNotePath) {
                    throw new Error(`ENOENT: ${uri.path}`);
                }
                return new TextEncoder().encode(serverNote);
            },
            readDirectory: async (uri) => {
                if (directoryRead) await directoryRead(uri);
                const listing = directories.get(uri.path);
                if (listing instanceof Error) throw listing;
                if (!listing) throw Object.assign(new Error(`ENOENT: ${uri.path}`), { code: 'FileNotFound' });
                return listing;
            },
        },
    },
    env: { clipboard: { writeText: async (text) => { clipboard.push(text); } } },
    Uri: class {
        static parse(s) { return { toString: () => s }; }
        // Resolves `..` the way the API documents for joinPath.
        static joinPath(uri, ...parts) { return { ...uri, path: path.posix.join(uri.path, ...parts) }; }
    },
    StatusBarAlignment: { Left: 1, Right: 2 },
    FileType: { Unknown: 0, File: 1, Directory: 2, SymbolicLink: 64 },
    TabInputText,
};

const realLoad = Module._load;
Module._load = function (request) {
    if (request === 'vscode') return vscodeStub;
    return realLoad.apply(this, arguments);
};

/**
 * Every command a bundled extension sends must have a branch in the relay.
 *
 * The severity word is not the only string crossing this boundary. The relay
 * dispatches its command names, written once in a Kotlin raw string, and the
 * bundled extensions send most of them, written again in JavaScript. Nothing
 * compared the two sets. A name that matches no branch is not
 * an error anywhere -- the relay's `if/else if` chain simply ends, no reply is
 * posted, and the extension's promise rejects five seconds later with a timeout
 * that says the app might not be running. The cause and the symptom share no
 * words.
 *
 * Only this direction is asserted. Branches with no sender are dead code, not a
 * user-visible failure, and there are some; they are reported rather than
 * refused so removing one stays a deliberate decision.
 *
 * The limit worth knowing, because a reader would assume otherwise: both sides
 * are read as LITERALS. A command name built from a variable is absent from the
 * sent set and therefore unchecked -- silently, and in the one direction this
 * exists for. `sent.size > 0` catches total blindness, not a partial miss. Every
 * name on both sides is a literal today, which is what makes the check worth
 * having and also what would make the first non-literal invisible.
 */
function checkCommandCoverage(relay) {
    const dispatched = new Set(
        [...relay.matchAll(/d\.cmd === ['"]([A-Za-z0-9_.-]+)['"]/g)].map((m) => m[1]),
    );
    const extensionsDir = path.join(ROOT, 'android/app/src/main/assets/extensions');
    const sent = new Set();
    for (const dir of fs.readdirSync(extensionsDir)) {
        // The entry point the manifest names, not a guess at it. Reading
        // <dir>/extension.js was a guess that happens to be right for every
        // bundled extension today, and it fails silently: an extension whose
        // manifest points elsewhere contributes nothing to `sent`, `sent.size > 0`
        // is already satisfied by its neighbours, and the summary line then claims
        // every command an extension sends has a branch.
        const manifestPath = path.join(extensionsDir, dir, 'package.json');
        if (!fs.existsSync(manifestPath)) continue;
        const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
        const entry = manifest.browser || manifest.main;
        if (!entry) continue;
        // Resolved the way the extension host resolves it, which is require():
        // vscode-eslint names "./client/out/extension" and ships extension.js,
        // and treating the manifest string as a path finds nothing there.
        const base = path.join(extensionsDir, dir, entry);
        const file = [base, `${base}.js`, path.join(base, 'index.js')].find(fs.existsSync);
        assert.ok(
            file,
            `${dir}'s manifest names an entry point that resolves to nothing: ${entry}. The ` +
            'extension cannot load, and this sweep would have skipped it silently.',
        );
        for (const m of fs.readFileSync(file, 'utf8').matchAll(/sendBridgeCommand\(['"]([A-Za-z0-9_.-]+)['"]/g)) {
            sent.add(m[1]);
        }
    }

    // Both sides report success by finding nothing, so both are asserted to
    // have found something before anything is concluded from the comparison.
    assert.ok(dispatched.size > 0, 'no dispatch branches were read from the relay');
    assert.ok(sent.size > 0, 'no bridge commands were read from any bundled extension');

    const unhandled = [...sent].filter((c) => !dispatched.has(c)).sort();
    assert.deepStrictEqual(
        unhandled, [],
        `these commands are sent by a bundled extension and have no branch in the relay, so ` +
        `they post no reply and fail five seconds later as "Bridge timeout: is the app ` +
        `running on Android?", which names neither the command nor the real cause: ` +
        `${unhandled.join(', ')}`,
    );

    return {
        dispatched: dispatched.size,
        sent: sent.size,
        unused: [...dispatched].filter((c) => !sent.has(c)).sort(),
    };
}

async function main() {
    const relay = extractInjected('injectBridgeRelay', 'openExternalUrl');
    const NO_HANDLER = bridgeReason('OPEN_URL_NO_HANDLER');
    const STALE_SESSION = bridgeReason('STORAGE_STALE_SESSION');
    const coverage = checkCommandCoverage(relay);
    // Held rather than written inline, because the relay installs the reply hook
    // ON this object. That hook is the road a late answer takes back into the
    // page, so a test that cannot reach it cannot drive any command that answers
    // by id, which is four of the seventeen.
    const relayWindow = { __vscodroid: { authToken: 'test-token' } };
    vm.runInNewContext(relay, {
        AndroidBridge,
        BroadcastChannel,
        window: relayWindow,
        console,
    });
    assert.strictEqual(
        typeof relayWindow.__vscodroidBridgeReply, 'function',
        'the relay installed no reply hook, so nothing can answer the four commands that ' +
        'hand back before their work is done. Every one of them would then sit until the ' +
        'extension\'s two-minute deadline and report that the app may not be on Android.',
    );

    // ---- shared storage opened by path -------------------------------------
    //
    // Android lists the directories on shared storage for this app and hides
    // every file another app saved there, so a folder opened there through the
    // workbench's own dialog shows its subfolders and nothing else. The
    // extension has to say so once per folder each time the editor server
    // starts, in a dialog, and its button has to reach the route that shows the
    // files. Folders the app can see in full must stay quiet: its own directory
    // under Android/data on any volume and in any case, a device folder's copy,
    // and anything in its home.
    //
    // A folder is named the way the workbench names one, by the last segment of
    // its path, which a trailing slash does not empty.
    const folder = (p) => ({ uri: { path: p }, name: path.posix.basename(p) });

    // Where the extension finds the editor server's note. Its own directory is
    // the server's --extensions-dir, and the note sits in the server directory,
    // both under the app's files directory, so the path it asks for is built
    // here from the sources that decide each part. Moving either directory then
    // fails here, where it would otherwise bring the warning back on every page
    // load with nothing to show for it.
    const FILES = '/data/user/0/com.vscodroid/files';
    const environment = fs.readFileSync(ENVIRONMENT_KT, 'utf8');
    const filesSubdir = (fn) => {
        const found = new RegExp(
            'fun ' + fn + '\\(context: Context\\): String =\\s*"\\$\\{context\\.filesDir\\}([^"]+)"',
        ).exec(environment);
        assert.ok(found, `Environment.${fn} is gone or changed shape, so this check cannot ` +
            'say where the extension and the editor server note live');
        return found[1];
    };
    const noteName = /const val EDITOR_PID_FILE = "([^"]+)"/.exec(fs.readFileSync(PROCESS_MANAGER, 'utf8'));
    assert.ok(noteName, 'EDITOR_PID_FILE is gone from ProcessManager.kt; point this at the note\'s name');
    const extensionUri = {
        scheme: 'vscode-remote',
        authority: '127.0.0.1:13337',
        path: `${FILES}${filesSubdir('getExtensionsDir')}/${path.basename(path.dirname(bridgeExtension()))}`,
    };
    serverNotePath = `${FILES}${filesSubdir('getServerDir')}/${noteName[1]}`;

    // Extension state as the workbench keeps it, which outlives a page load,
    // holding one folder an earlier session silenced with Don't Show Again. It
    // is kept by its key, the volume and the path below it in lower case.
    const state = new Map([['sharedStorageWarning.silenced', ['primary:documents/silenced']]]);

    /** A page load: a new extension host activates the extension over the same state. */
    async function pageLoad(folders) {
        workspaceFolders = folders;
        folderListeners.length = 0;
        warnings.length = 0;
        executed.length = 0;
        fileReads.length = 0;
        require(bridgeExtension()).activate({
            subscriptions: [],
            extensionUri,
            globalState: {
                get: (key, fallback) => (state.has(key) ? state.get(key) : fallback),
                update: async (key, value) => {
                    state.set(key, value !== null && typeof value === 'object' ? JSON.parse(JSON.stringify(value)) : value);
                    if (storageUpdate) await storageUpdate(key, value);
                },
            },
        });
        await settle();
    }
    const warnedNames = () => warnings.map((w) => (/saved (?:in|on) (.+)\.$/.exec(w.message) || [, w.message])[1]);

    const OPEN = 'Open Folder from Device';
    const QUIET = 'Don\'t Show Again';
    const notes = folder('/storage/emulated/0/Documents/notes');
    const openedFolders = [
        notes,
        folder('/storage/emulated/0/Android/data/com.vscodroid/files/projects/app'),
        folder('/storage/1A2B-3C4D/Android/data/com.vscodroid/files/card'),
        folder('/storage/self/primary/Android/data/com.vscodroid/files/self'),
        folder('/storage/emulated/0/android/data/com.vscodroid/files/lower'),
        folder('/data/user/0/com.vscodroid/files/saf-mirrors/8e440ff38c8e'),
        folder('/data/user/0/com.vscodroid/files/home/projects/site'),
        folder('/storagebox/drafts'),
        // Not volumes: the parents of the primary storage's own spellings.
        folder('/storage/emulated'),
        folder('/storage/self'),
        // The silenced folder, spelled another way: another volume path, another
        // case and a trailing slash.
        folder('/sdcard/documents/Silenced/'),
    ];
    serverNote = '{"pid":4242,"port":13337}';

    // A page with no folder on shared storage, the usual case, reads nothing.
    await pageLoad([folder('/data/user/0/com.vscodroid/files/home/projects/site')]);
    assert.deepStrictEqual(
        [fileReads, warnings], [[], []],
        'a page load with no shared-storage folder read a file or warned: ' +
        JSON.stringify({ fileReads, warnings }),
    );

    warningChoice = OPEN;
    await pageLoad(openedFolders);

    assert.deepStrictEqual(
        fileReads, [serverNotePath],
        'the extension did not read the editor server note where server.js writes it: ' +
        JSON.stringify(fileReads),
    );
    assert.ok(
        warnings.length === 1 && warnedNames()[0] === 'notes',
        'a folder opened by path on shared storage must raise exactly one warning naming it, ' +
        'and no folder the app can see in full may raise one: ' + JSON.stringify(warnings),
    );
    assert.ok(
        warnings[0].options.modal === true && /cannot be opened/.test(warnings[0].options.detail || ''),
        'the warning must be a dialog that says why, since a notification hides itself after ' +
        '12 seconds: ' + JSON.stringify(warnings[0]),
    );
    assert.deepStrictEqual(
        warnings[0].items, [OPEN, QUIET],
        'the warning must offer Open Folder from Device and Don\'t Show Again: ' +
        JSON.stringify(warnings[0].items),
    );
    assert.deepStrictEqual(
        executed, ['vscodroid.openFolderFromDevice'],
        'the warning\'s button did not run Open Folder from Device: ' + JSON.stringify(executed),
    );

    // A reload, or a switch to another folder and back, loads a new page on the
    // same server: the folder was warned about while that server runs, and
    // stays quiet.
    warningChoice = null;
    await pageLoad(openedFolders);
    assert.deepStrictEqual(
        warnings, [],
        'a page load on the same editor server warned about the same folder again, which is ' +
        'every reload and every folder switch: ' + JSON.stringify(warnings),
    );

    // A folder added to the open workspace in place, which reloads nothing, so
    // only the listener can see it. Every spelling of shared storage counts, an
    // SD card included, as does an Android/data that is not at the top of a
    // volume, and the folder already warned about stays quiet, however its
    // path is spelled this time.
    //
    // What the warning says follows what Android's folder picker does with the
    // folder. On the device's storage it will not grant the top, Download or
    // Android, a trailing slash included, so those are sent to a folder inside,
    // and the top is not named by its last segment. On an SD card the same
    // holds, while a USB drive is granted whole, and a path cannot tell the two
    // apart, so a removable volume's top and its Download say both. The picker
    // does not even list Android/data, Android/obb and Android/sandbox, so for
    // those there is no button to offer and the files left out are beside the
    // point. Android/data itself is no app's own folder: only a package
    // directory below it is, so it is warned about.
    warnings.length = 0; executed.length = 0; warningChoice = null;
    workspaceFolders = [
        ...openedFolders,
        folder('/sdcard/Download/proj'),
        folder('/mnt/sdcard/Music/beats'),
        folder('/storage/self/primary/Projects/web'),
        folder('/storage/1A2B-3C4D/Code/game'),
        folder('/storage/emulated/0/Documents/backup/Android/data/old'),
        folder('/storage/emulated/0'),
        folder('/sdcard/Download'),
        folder('/storage/emulated/0/Android/'),
        folder('/storage/1A2B-3C4D'),
        folder('/storage/1A2B-3C4D/download/'),
        folder('/sdcard/Android/data'),
        folder('/storage/emulated/0/Android/obb/com.example.game'),
        folder('/sdcard/android/Sandbox'),
        folder('/sdcard/Documents/notes/'),
        folder('/storage/self/primary/documents/NOTES'),
    ];
    assert.strictEqual(folderListeners.length, 1, 'the extension does not listen for added folders');
    folderListeners[0]();
    await settle();
    assert.deepStrictEqual(
        warnedNames(),
        [
            'proj', 'beats', 'web', 'game', 'old', 'your device storage', 'Download', 'Android',
            'this SD card or USB drive', 'download', 'data', 'com.example.game', 'Sandbox',
        ],
        'an added shared-storage folder must be warned about once, and an earlier one not ' +
        'again: ' + JSON.stringify(warnings),
    );
    const kindOf = (w) => {
        const d = w.options.detail || '';
        if (w.options.modal !== true) return 'not a dialog';
        if (w.items.join() === QUIET) {
            return /Android\/obb/.test(d) && /cannot open them either/.test(d) && !/50 MB/.test(d)
                ? 'not in the picker' : 'no button, no reason';
        }
        if (w.items.join() !== [OPEN, QUIET].join() || !d.includes('50 MB') || !d.includes('.git')) {
            return 'button or the files left out missing';
        }
        if (d.includes('pick a folder inside it')) {
            return d.includes('USB drive') ? 'inside, unless a USB drive' : 'inside';
        }
        return d.includes('Open Folder from Device shows them') ? 'open' : 'no route';
    };
    assert.deepStrictEqual(
        warnings.map(kindOf),
        [
            'open', 'open', 'open', 'open', 'open', 'inside', 'inside', 'inside',
            'inside, unless a USB drive', 'inside, unless a USB drive',
            'not in the picker', 'not in the picker', 'not in the picker',
        ],
        'each warning must say what the folder picker does with that folder: ' +
        JSON.stringify(warnings),
    );
    assert.deepStrictEqual(executed, [], 'a dismissed warning ran a command: ' + JSON.stringify(executed));

    // Don't Show Again keeps the folder quiet in every later session, and adds
    // it to the ones silenced before rather than replacing them.
    warnings.length = 0; warningChoice = QUIET;
    workspaceFolders = [...workspaceFolders, folder('/sdcard/Documents/mine')];
    folderListeners[0]();
    await settle();
    assert.deepStrictEqual(
        [warnings.length, executed, state.get('sharedStorageWarning.silenced')],
        [1, [], ['primary:documents/silenced', 'primary:documents/mine']],
        'Don\'t Show Again did not silence the folder by its key for later sessions',
    );

    // A new editor server is a new start of the app: the folders it has not
    // warned about yet include the one the last server did, and a silenced
    // folder stays silenced under any spelling.
    warningChoice = null;
    serverNote = '{"pid":5151,"port":13337}';
    await pageLoad([notes, folder('/storage/emulated/0/documents/Mine')]);
    assert.deepStrictEqual(
        warnedNames(), ['notes'],
        'a restarted editor server must warn about a folder the previous one had, so that ' +
        'the warning is once per start rather than once per install, and must leave a ' +
        'silenced folder alone however it is spelled: ' + JSON.stringify(warnings),
    );

    // With no note to tie them to, the warnings last as long as the page, as
    // they did before there was one, rather than going quiet for good.
    serverNote = null;
    await pageLoad([notes]);
    const firstWithoutNote = warnedNames();
    await pageLoad([notes]);
    assert.deepStrictEqual(
        [firstWithoutNote, warnedNames()], [['notes'], ['notes']],
        'without the editor server note the warning must still be shown on each page load: ' +
        JSON.stringify(warnings),
    );
    warnings.length = 0; warningChoice = null; serverNote = null;

    const openInBrowser = commands.get('vscodroid.openInBrowser');
    assert.ok(openInBrowser, 'the bundled extension no longer registers vscodroid.openInBrowser');

    async function run(url, answer) {
        shown.info.length = 0; shown.error.length = 0; bridgeCalls.length = 0;
        bridgeAnswer = answer;
        inputBoxAnswer = url;
        // No wait after this. The handler is async and awaits sendBridgeCommand,
        // whose promise settles only from the channel's onmessage or its own 5s
        // timeout, and the catch calls showErrorMessage synchronously -- so by the
        // time this returns, anything the user would see has already been pushed.
        // A sleep here would add nothing except a way for a contended runner to
        // fail two required workflows with a message about the relay.
        await openInBrowser();
        return { info: [...shown.info], error: [...shown.error], calls: [...bridgeCalls] };
    }

    // A URL the bridge declines has to reach the user. This is the whole point:
    // the relay used to post ok:true here, which resolved the extension's promise
    // and left its error handler unreachable.
    const LAN = 'http://192.168.1.5:3000';
    const refused = await run(LAN, NO_HANDLER);
    assert.strictEqual(refused.calls.length, 1, 'the relay never reached the bridge');

    // What it passed, not just that it passed something. The relay calls
    // openExternalUrl(d.url, token) and the bridge validates the SECOND argument
    // as the session token; swapping them -- which reads like a tidy-up, since
    // every sibling branch takes the token first -- hands the URL to the token
    // check and refuses every open on device, while a length assertion stays green.
    assert.deepStrictEqual(
        refused.calls[0], { url: LAN, token: 'test-token' },
        'the relay passed the wrong arguments to the bridge: ' + JSON.stringify(refused.calls[0]),
    );
    assert.strictEqual(
        refused.error.length, 1,
        refused.error.length === 0
            ? 'the bridge was called but nothing reached the user. Either the relay stopped ' +
              'answering a declined URL -- the defect this check exists for -- or the await in ' +
              'run() no longer covers the channel round trip, which would be a fault in this ' +
              'check rather than in the relay. Rule the second out before reading the first.'
            : 'a declined URL must surface exactly one message; got ' + JSON.stringify(refused.error),
    );
    assert.ok(!refused.error[0].includes('undefined'),
        'the surfaced message leaked an undefined: ' + refused.error[0]);

    // The relay's own text has to be the text that arrives. Asserting only that
    // SOME message appeared accepts the failure this check exists to catch: a
    // relay that answers nothing leaves the extension to reject on its own
    // five-second timeout, which is also exactly one message, and says the app
    // may not be running.
    assert.ok(
        refused.error[0].includes(NO_HANDLER),
        'the message the user saw is not the reason the bridge gave. Saw: ' + refused.error[0],
    );

    // Forwarded, not re-stated. The relay posted one fixed sentence for every
    // refusal and the check above would accept that again, since the sentence it
    // posted is the one the bridge now returns for this case. A reason no source
    // file contains can only arrive by being passed through.
    const ONLY_HERE = 'a reason that exists only inside this check';
    const passedThrough = await run('http://192.168.1.5:3000', ONLY_HERE);
    assert.ok(
        passedThrough.error.length === 1 && passedThrough.error[0].includes(ONLY_HERE),
        'the relay did not forward the reason the bridge gave, so it is stating a cause it ' +
        'cannot know. Saw: ' + JSON.stringify(passedThrough.error),
    );

    // The message must not describe a URL policy. This asked for the opposite
    // until the allow-list was removed: while the bridge refused http on any host
    // but localhost, a boolean could not say WHICH of the two causes fired, so the
    // message had to name both. With the filter gone there is one cause left --
    // nothing on the device claimed the link -- and a message still listing
    // permitted schemes would send a user hunting for a rule that no longer
    // exists. Pinned as an absence rather than left to prose, because the wording
    // and the policy are in different files and only one of them fails a build.
    for (const stale of ['https, mailto', 'allow', 'localhost', 'scheme']) {
        assert.ok(
            !NO_HANDLER.toLowerCase().includes(stale),
            `the decline message mentions "${stale}", which reads as a URL restriction. There ` +
            'is none: any URL is handed to the platform, and the only way to get here is that ' +
            `no installed app took the intent. Message: ${NO_HANDLER}`,
        );
    }
    assert.ok(
        /no app|handles that link/i.test(NO_HANDLER),
        'the decline message no longer names the one cause that can produce it -- that nothing ' +
        'on the device handles the link: ' + NO_HANDLER,
    );

    // A different scheme, same handling. The bridge is stubbed here and ignores
    // the URL, so this cannot fail independently of the run above; what it pins is
    // that the relay does not branch on the scheme before deciding what to say.
    // Which failure produced the reason is decided in Kotlin and is covered there.
    const allowedButUnopened = await run('mailto:someone@example.com', NO_HANDLER);
    assert.strictEqual(allowedButUnopened.error.length, 1,
        'an allowed URL that failed to open must still reach the user');
    assert.ok(
        allowedButUnopened.error[0].includes(NO_HANDLER),
        'the mailto case surfaced a different message: ' + allowedButUnopened.error[0],
    );

    // The control. Without it, a relay that reported failure unconditionally
    // would satisfy the assertion above and put an error in front of every
    // successful open.
    const opened = await run('http://localhost:3000', '');
    assert.strictEqual(opened.calls.length, 1, 'the relay never reached the bridge');
    assert.strictEqual(
        opened.error.length, 0,
        'a URL the bridge opened must not surface an error; got ' + JSON.stringify(opened.error),
    );

    // Cancelling the input box must not reach Android at all.
    for (const [label, value] of [['cancelled', undefined], ['whitespace', '   ']]) {
        const inert = await run(value, '');
        assert.strictEqual(inert.calls.length, 0, `${label} input still called the bridge`);
        assert.strictEqual(inert.error.length, 0, `${label} input surfaced an error`);
    }

    // The other reader of the same answer. `injectWindowOpenOverride` calls the
    // same bridge method and decides from its answer whether the click was
    // handled, it is injected JavaScript that nothing compiles, and it reads the
    // answer the opposite way round from the relay: success is the empty string,
    // so a bare truthiness test claims every click it FAILED to open and lets the
    // one it did open fall through to the WebView as well. Both directions are
    // asserted, because that inversion satisfies either one on its own.
    const override = extractInjected('injectWindowOpenOverride', 'openExternalUrl');

    // The window carries a `location`, because the override reads one before it
    // reaches the bridge at all: a second window is this window on a device, and
    // the workbench builds that URL from its own origin with no connection
    // token, so handing it to the system browser is answered "Forbidden."
    const ORIGIN = 'http://127.0.0.1:13337';

    function windowOpen(answer, url) {
        const seen = { bridge: 0, orig: 0, navigated: null };
        const win = {
            __vscodroid: { authToken: 'test-token' },
            open() { seen.orig++; return 'fell through to the WebView'; },
            location: {
                origin: ORIGIN,
                set href(value) { seen.navigated = value; },
                get href() { return seen.navigated; },
            },
        };
        vm.runInNewContext(override, {
            window: win,
            AndroidBridge: {
                openExternalUrl() { seen.bridge++; return answer; },
            },
        });
        return { ...seen, result: win.open(url), calls: seen };
    }

    const claimed = windowOpen('', 'https://example.com/docs');
    assert.strictEqual(claimed.calls.bridge, 1, 'window.open never reached the bridge');
    assert.strictEqual(
        claimed.calls.orig, 0,
        'the bridge opened the URL and window.open fell through as well, so the page opens ' +
        'twice: once in a browser and once inside the WebView',
    );
    assert.strictEqual(claimed.result, null, 'a click that was handled must report that it was');

    const fellThrough = windowOpen(NO_HANDLER, 'https://example.com/docs');
    assert.strictEqual(fellThrough.calls.bridge, 1, 'window.open never reached the bridge');
    assert.strictEqual(
        fellThrough.calls.orig, 1,
        'the bridge did not open the URL and window.open swallowed the click anyway, so it ' +
        'did nothing and said nothing',
    );

    // The editor asking for a second window. A device has one, so this one is
    // it: the URL must be navigated in place and must never reach the bridge,
    // whose localhost branch hands it to the system browser, where the server
    // answers a request with no connection token "Forbidden." and the editor is
    // left under VS Code's own popup-blocked message.
    const ownWindow = windowOpen('', ORIGIN + '/?ew=true');
    assert.strictEqual(
        ownWindow.calls.bridge, 0,
        "the editor's own address was handed to the device browser, which is answered " +
        'Forbidden because the workbench builds that URL without a connection token',
    );
    assert.strictEqual(ownWindow.calls.orig, 0, 'the platform opened a second window as well');
    assert.strictEqual(
        ownWindow.calls.navigated, ORIGIN + '/?ew=true',
        'nothing navigated, so New Window does nothing at all',
    );
    assert.ok(
        ownWindow.result,
        'the override answered falsy for a window it did handle, and the caller reads ' +
        '`!!window.open(...)`, so the editor draws a blocked-popup message over a ' +
        'navigation that is working',
    );

    // A first argument the platform accepts that is not a string: an object that
    // stringifies to a URL, which `new URL(...)` is. It has no indexOf, so the
    // prefix test threw on every such call instead of reaching either branch.
    const asObject = text => ({ toString() { return text; } });
    const objectExternal = windowOpen('', asObject('https://example.com/docs'));
    assert.strictEqual(objectExternal.calls.bridge, 1, 'an object naming an external URL never reached the bridge');
    const objectOwn = windowOpen('', asObject(ORIGIN + '/?ew=true'));
    assert.strictEqual(objectOwn.calls.navigated, ORIGIN + '/?ew=true', 'an object naming the editor itself was not navigated to');
    assert.strictEqual(objectOwn.calls.bridge, 0, "an object naming the editor's own address reached the device browser");

    // And the other direction, which is what the prefix test protects: a dev
    // server on another port is a different origin and still belongs to the
    // browser. Written as a URL that CONTAINS our origin later on, the shape a
    // substring search would get wrong, blanking the editor mid sign-in.
    const looksLikeOurs = windowOpen(
        '', 'https://auth.example.com/authorize?redirect_uri=' + ORIGIN + '/callback',
    );
    assert.strictEqual(
        looksLikeOurs.calls.bridge, 1,
        'a remote URL naming our origin in its query was navigated in place, so the editor ' +
        'was replaced by whatever that address serves',
    );
    assert.strictEqual(looksLikeOurs.calls.navigated, null, 'the page navigated to a remote URL');

    // ---- the commands that answer by reply id ----------------------------
    //
    // These four hand back the empty string and deliver the value afterwards,
    // because a bridge call holds the calling JavaScript thread until it returns
    // and the caller here is the workbench page's own thread. Nothing else runs
    // this shape: the Kotlin tests stop at the language boundary, and the
    // extension is only ever driven against a relay that answered inline.
    //
    // The pending promise is what makes the case meaningful, so the handler is
    // started rather than awaited, and it is only awaited once an answer has been
    // posted. If a branch ever went back to answering inline, `started` below
    // settles with the stub's empty return and every assertion about the posted
    // answer fails.
    const manageDeviceFolders = commands.get('vscodroid.manageDeviceFolders');
    assert.ok(manageDeviceFolders,
        'the bundled extension no longer registers vscodroid.manageDeviceFolders');

    /** Lets queued channel messages and the awaits behind them run. */
    async function settle() {
        for (let i = 0; i < 5; i += 1) await new Promise((r) => setTimeout(r, 0));
    }

    /** Starts the command and reports whether it has finished. */
    function start() {
        shown.info.length = 0; shown.error.length = 0;
        warnings.length = 0;
        listCalls.length = 0; reclaimCalls.length = 0;
        const state = { done: false };
        state.running = manageDeviceFolders().then(() => { state.done = true; });
        return state;
    }

    listAnswer = '';
    reclaimAnswer = '';
    quickPickChoice = null;
    warningChoice = null;

    // The listing is asked for with the session token and a reply id, and NOTHING
    // has happened by the time the call returns.
    const listing = start();
    await settle();
    assert.strictEqual(listCalls.length, 1, 'the relay never reached listSafMirrors');
    assert.strictEqual(
        listCalls[0].token, 'test-token',
        'the relay passed the wrong first argument to listSafMirrors: ' +
        JSON.stringify(listCalls[0]),
    );
    assert.ok(
        typeof listCalls[0].replyId === 'string' && listCalls[0].replyId.length > 0,
        'the relay called listSafMirrors without a reply id, so the answer has no way ' +
        'back and the caller waits for its own deadline: ' + JSON.stringify(listCalls[0]),
    );
    assert.strictEqual(
        listing.done, false,
        'the listing settled before Android posted anything back, so the relay is not ' +
        'waiting for the answer -- it took the empty acceptance for the list itself',
    );
    assert.deepStrictEqual(
        { info: shown.info, error: shown.error }, { info: [], error: [] },
        'something was shown to the user while the walk was still running: ' +
        JSON.stringify(shown),
    );

    // The answer arrives by id and the flow carries on. showQuickPick is dismissed,
    // so what is asserted is that nothing went wrong on the way there.
    relayWindow.__vscodroidBridgeReply(
        listCalls[0].replyId, true,
        JSON.stringify([{ hash: 'abc123', name: 'Notes', bytes: 12, reclaimable: true }]),
    );
    await listing.running;
    assert.deepStrictEqual(
        { info: shown.info, error: shown.error }, { info: [], error: [] },
        'a listing that arrived by reply id was not understood: ' + JSON.stringify(shown),
    );

    // A refusal posted by id reaches the user in the words Android chose. This is
    // openExternalUrl's pass-through property, on the other road back.
    const POSTED_ONLY_HERE = 'a refusal that exists only inside this check';
    const rejected = start();
    await settle();
    relayWindow.__vscodroidBridgeReply(listCalls[0].replyId, false, POSTED_ONLY_HERE);
    await rejected.running;
    assert.ok(
        shown.error.length === 1 && shown.error[0].includes(POSTED_ONLY_HERE),
        'a refusal posted by reply id did not reach the user unchanged. Saw: ' +
        JSON.stringify(shown.error),
    );

    // A refusal decided before any work started travels back as the RETURN value,
    // and the relay has to post it rather than dropping it: the caller is waiting
    // for an answer that will never come otherwise.
    listAnswer = STALE_SESSION;
    const refusedAtOnce = start();
    await refusedAtOnce.running;
    assert.ok(
        shown.error.length === 1 && shown.error[0].includes(STALE_SESSION),
        'a command refused before it started did not reach the user, so the caller waits ' +
        'two minutes and is then told the app may not be running on Android. Saw: ' +
        JSON.stringify(shown.error),
    );
    listAnswer = '';

    // Legacy reclaimable=true rows need the same warning and consent as current rows.
    for (const reclaimable of [false, true]) {
        let offeredCopy;
        quickPickChoice = (items) => { [offeredCopy] = items; return offeredCopy; };
        warningChoice = 'Remove';
        const removal = start();
        await settle();
        relayWindow.__vscodroidBridgeReply(
            listCalls[0].replyId, true,
            JSON.stringify([{ hash: 'abc123', name: 'Notes', bytes: 12, reclaimable, granted: false }]),
        );
        await settle();
        assert.ok(
            /may hold files/i.test(offeredCopy.detail) && !/unchanged copy/i.test(offeredCopy.detail),
            'the listed copy was described as safe to remove: ' + JSON.stringify(offeredCopy),
        );
        assert.ok(
            warnings.length === 1 && warnings[0].options.modal === true &&
                /THIS DELETES FILES/.test(warnings[0].message) &&
                /may hold files that have not reached the device folder/.test(warnings[0].message) &&
                /Stop terminals/.test(warnings[0].message),
            'a removal did not warn about unique files and active work: ' + JSON.stringify(warnings),
        );
        assert.strictEqual(reclaimCalls.length, 1, 'the confirmed removal never reached the bridge');
        assert.deepStrictEqual(
            { token: reclaimCalls[0].token, hash: reclaimCalls[0].hash, force: reclaimCalls[0].force },
            { token: 'test-token', hash: 'abc123', force: true },
            'the relay passed the wrong arguments to reclaimSafMirror. The reply id is LAST ' +
            'here and first nowhere, so an argument out of place hands the hash to the token ' +
            'check or deletes with the wrong force flag: ' + JSON.stringify(reclaimCalls[0]),
        );
        assert.ok(
            typeof reclaimCalls[0].replyId === 'string' && reclaimCalls[0].replyId.length > 0,
            'the removal was sent without a reply id: ' + JSON.stringify(reclaimCalls[0]),
        );
        assert.strictEqual(
            removal.done, false,
            'the removal settled before its outcome was posted, so a refusal could not have ' +
            'been reported and the user is told nothing about a copy that is still there',
        );

        const IN_USE = 'That folder is open in the editor.';
        relayWindow.__vscodroidBridgeReply(reclaimCalls[0].replyId, false, IN_USE);
        await removal.running;
        assert.ok(
            shown.error.length === 1 && shown.error[0].includes(IN_USE),
            'a refused removal did not reach the user in the words Android chose, so the ' +
            'thing that has to change first is never named. Saw: ' + JSON.stringify(shown.error),
        );
    }
    quickPickChoice = null;
    warningChoice = null;

    quickPickChoice = (items) => items[0];
    const cancelledRemoval = start();
    await settle();
    relayWindow.__vscodroidBridgeReply(listCalls[0].replyId, true,
        JSON.stringify([{ hash: 'abc123', name: 'Notes', bytes: 12, reclaimable: true, granted: true }]));
    await cancelledRemoval.running;
    assert.strictEqual(warnings.length, 1, 'the selected legacy row was never confirmed');
    assert.strictEqual(reclaimCalls.length, 0, 'a dismissed confirmation still sent a removal');
    quickPickChoice = null;

    // Expire the actual extension timer without waiting two minutes. Posted replies
    // still pass through the real relay and BroadcastChannel in this harness.
    const realSetTimeout = global.setTimeout;
    const diskTimers = [];
    global.setTimeout = (callback, delay, ...args) => {
        if (delay === 120000) {
            const timer = { callback, args };
            diskTimers.push(timer);
            return timer;
        }
        return realSetTimeout(callback, delay, ...args);
    };
    try {
        const missingList = start();
        await settle();
        assert.strictEqual(diskTimers.length, 1, 'the listing did not use the bounded storage timer');
        diskTimers[0].callback(...diskTimers[0].args);
        await missingList.running;
        assert.ok(
            shown.error.length === 1 && /Could not read the list/.test(shown.error[0]) && warnings.length === 0,
            'a listing timeout was described as a removal outcome: ' + JSON.stringify({ shown, warnings }),
        );

        quickPickChoice = (items) => items[0];
        warningChoice = 'Remove';
        const unknownRemoval = start();
        await settle();
        relayWindow.__vscodroidBridgeReply(listCalls[0].replyId, true,
            JSON.stringify([{ hash: 'abc123', name: 'Notes', bytes: 12, reclaimable: true, granted: true }]));
        await settle();
        assert.strictEqual(reclaimCalls.length, 1, 'the removal never reached its actual relay branch');
        assert.strictEqual(diskTimers.length, 3, 'the removal did not keep a bounded result wait');
        const removalTimer = diskTimers[2];
        removalTimer.callback(...removalTimer.args);
        await unknownRemoval.running;
        assert.ok(
            shown.error.length === 0 && shown.info.length === 0 && warnings.length === 2 &&
                /not reported the removal result/.test(warnings[1].message) &&
                /may still finish/.test(warnings[1].message) && /before trying again/.test(warnings[1].message),
            'an expired result wait claimed that removal failed or completed: ' + JSON.stringify({ shown, warnings }),
        );
        const commandCount = executed.length;
        relayWindow.__vscodroidBridgeReply(reclaimCalls[0].replyId, true, '');
        await settle();
        assert.strictEqual(executed.length, commandCount, 'a late result reopened the command after its outcome warning');
        assert.strictEqual(shown.error.length, 0, 'a late result produced a second outcome');
    } finally {
        global.setTimeout = realSetTimeout;
        quickPickChoice = null;
        warningChoice = null;
    }

    // The storage screen's Total row, which is the first and largest thing a
    // person sees on the screen they open because they are out of disk.
    //
    // It is the one item built without a key, so it reaches the picker's final
    // arm. That arm used to close the picker in silence, which reads as a screen
    // that does not work; the sentence put there instead said Total was the sum
    // of the rows below it, and it is not. Total is every byte under the app's
    // data and cache directories, and the rows name the subtrees that can be
    // identified: the cache row alone was narrowed to the four directories the
    // clear action reaches, while the whole cache directory stays in Total.
    //
    // So this drives the real command with a breakdown whose rows deliberately
    // do NOT add up, and asserts the two figures are BOTH named. Numbers rather
    // than wording, because a check on the phrasing is one a synonym walks past.
    //
    // NEGATIVE CONTROL, measured: restore 'That is the sum of the rows below it.
    // Pick one of those to see what can be freed.' and the second assertion goes
    // red -- the sentence names neither figure.
    const showStorageUsage = commands.get('vscodroid.showStorageUsage');
    assert.ok(showStorageUsage, 'the bundled extension no longer registers vscodroid.showStorageUsage');

    // Decimal, because that is what formatBytes divides by and what the phone's
    // own storage screen counts in. A binary fixture here renders 3 GiB as
    // "3.2 GB" and the sentences below stop matching, which is a test of the
    // fixture rather than of the screen.
    const MB = 1000 * 1000;
    // Two rows of 512 MB inside a 3 GB total: the rows add to 1.0 GB, a figure
    // that is neither the total nor any single row, so naming it cannot be
    // satisfied by echoing something already on the screen.
    const breakdown = {
        vscode_server: 512 * MB,
        extensions: 512 * MB,
        total: 3000 * MB,
        clearable: ['cache', 'logs'],
    };
    let offered = null;
    quickPickChoice = (items) => { offered = items; return items[0]; };
    shown.info.length = 0; shown.error.length = 0; breakdownCalls.length = 0;
    const usage = showStorageUsage();
    await settle();
    assert.strictEqual(breakdownCalls.length, 1, 'the relay never reached getStorageBreakdown');
    relayWindow.__vscodroidBridgeReply(
        breakdownCalls[0].replyId, true, JSON.stringify(breakdown),
    );
    await usage;
    quickPickChoice = null;

    assert.ok(
        offered && offered[0] && offered[0].key === undefined,
        'the first item is no longer the keyless Total row, so this drove some other arm: ' +
        JSON.stringify(offered),
    );
    assert.strictEqual(
        shown.info.length, 1,
        'the Total row said nothing at all, so the screen reads as one that does not work: ' +
        JSON.stringify(shown),
    );
    const totalSaid = shown.info[0];
    assert.ok(
        totalSaid.includes('3.0 GB'),
        'the Total row does not name the figure it is showing: ' + totalSaid,
    );
    assert.ok(
        totalSaid.includes('1.0 GB'),
        'the Total row does not say how much of itself the rows below account for. They add ' +
        'to 1.0 GB of a 3.0 GB total, and a person out of disk adds them up: any claim that ' +
        'the rows come to the total is one this breakdown does not support. Saw: ' + totalSaid,
    );

    // The extension picks its sentence from the toggle's answer alone. A relay
    // branch that posts no data, or an inverted test in the extension, still
    // flips the row on the Kotlin side while telling the user the opposite.
    const toggleKeyRow = commands.get('vscodroid.toggleExtraKeyRow');
    assert.ok(toggleKeyRow, 'the bundled extension no longer registers vscodroid.toggleExtraKeyRow');

    async function toggleTo(answer) {
        shown.info.length = 0; shown.error.length = 0; toggleCalls.length = 0;
        toggleAnswer = answer;
        await toggleKeyRow();
        return { info: [...shown.info], error: [...shown.error], calls: [...toggleCalls] };
    }

    const hid = await toggleTo(true);
    assert.deepStrictEqual(
        hid.calls, [{ token: 'test-token' }],
        'the relay did not hand the session token to toggleExtraKeyRow: ' + JSON.stringify(hid.calls),
    );
    assert.ok(
        hid.error.length === 0 && hid.info.length === 1 && hid.info[0].startsWith('Extra key row hidden'),
        'a toggle that hid the row did not say so: ' + JSON.stringify(hid),
    );
    const restored = await toggleTo(false);
    assert.ok(
        restored.error.length === 0 && restored.info.length === 1 &&
            restored.info[0].startsWith('Extra key row shown'),
        'a toggle that brought the row back did not say so: ' + JSON.stringify(restored),
    );

    // ---- the bug report -------------------------------------------------
    //
    // The relay answered generateBugReport from the start and no extension sent
    // it, so nothing in the editor could hand a user the report. The command
    // has to put the report in an editor before anything reaches the
    // clipboard, because it quotes server output that can name the user's files
    // and folders, and Copy has to take what the editor then holds, so a line
    // the user deleted stays out of what they paste.
    const copyBugReport = commands.get('vscodroid.copyBugReport');
    assert.ok(copyBugReport, 'the bundled extension no longer registers vscodroid.copyBugReport');

    async function bugReport(answer, choose) {
        shown.info.length = 0; shown.error.length = 0; reportCalls.length = 0;
        openedDocs.length = 0; shownDocs.length = 0; clipboard.length = 0;
        reportAnswer = answer;
        infoChoice = choose;
        await copyBugReport();
        infoChoice = null;
        return { info: [...shown.info], error: [...shown.error] };
    }

    const PRIVATE = '/storage/emulated/0/Documents/client-project\n';
    const REPORT = '=== VSCodroid Bug Report ===\n' + PRIVATE + '--- Server Log (last 200 lines) ---\n';
    let onScreenWhenAsked = 0;
    const copied = await bugReport(REPORT, (items) => {
        onScreenWhenAsked = shownDocs.length;
        // The user reads the report and deletes the line naming their folder.
        openedDocs[0].text = openedDocs[0].text.replace(PRIVATE, '');
        return items.includes('Copy') ? 'Copy' : undefined;
    });
    assert.deepStrictEqual(
        reportCalls, [{ token: 'test-token' }],
        'the relay did not ask the bridge for the report with the session token: ' +
        JSON.stringify(reportCalls),
    );
    assert.deepStrictEqual(
        openedDocs.map((d) => d.options), [{ content: REPORT, language: 'plaintext' }],
        'the report was not opened as a plain-text document holding exactly what the ' +
        'bridge answered: ' + JSON.stringify(openedDocs.map((d) => d.options)),
    );
    assert.strictEqual(
        onScreenWhenAsked, 1,
        'the user was offered Copy before the report was on screen to be read',
    );
    assert.ok(
        copied.error.length === 0 && /before you share it/.test(copied.info[0] || ''),
        'the user is not asked to read the report before sharing it: ' + JSON.stringify(copied),
    );
    assert.deepStrictEqual(
        clipboard, [REPORT.replace(PRIVATE, '')],
        'Copy did not take what the editor holds, so a line the user deleted is pasted ' +
        'anyway: ' + JSON.stringify(clipboard),
    );

    const dismissed = await bugReport(REPORT, () => undefined);
    assert.deepStrictEqual(
        [clipboard, dismissed.error], [[], []],
        'a report whose notice was dismissed still reached the clipboard: ' + JSON.stringify(clipboard),
    );

    // The notice hides itself after ten seconds, long before a report of a few
    // hundred lines has been read. Copy has to stay in the status bar while the
    // report is open, take what the editor holds by then, and go only when that
    // report is closed.
    // Every page load activates the extension again; the command run above is
    // the newest activation's, and so is its item.
    const copyItem = statusItems.filter((item) => item.shown).pop();
    const itemRuns = copyItem && copyItem.command;
    assert.ok(
        itemRuns && itemRuns.command === 'vscodroid.copyBugReport' && itemRuns.arguments[0] === openedDocs[0],
        'Copy is not in the status bar for the open report: ' + JSON.stringify(itemRuns),
    );
    // The workbench keeps the items of every extension host in one table, and
    // one made without an id is numbered per host: on a device this item took
    // the process monitor's slot and was gone at that item's next update.
    assert.ok(
        typeof copyItem.args[0] === 'string' && copyItem.args[0] !== '',
        'the status bar Copy is made without an id, so it shares a slot with another ' +
        'extension host\'s item: ' + JSON.stringify(copyItem.args),
    );
    openedDocs[0].text = 'what the user kept\n';
    closeListeners.forEach((fn) => fn({ getText: () => 'another document' }));
    // The extension host reports a language change as a close of a document
    // that it keeps open.
    textDocuments = [openedDocs[0]];
    closeListeners.forEach((fn) => fn(openedDocs[0]));
    textDocuments = [];
    await commands.get(itemRuns.command)(...itemRuns.arguments);
    assert.deepStrictEqual(
        [copyItem.shown, openedDocs.length, clipboard], [true, 1, ['what the user kept\n']],
        'Copy in the status bar did not take what the open report holds, made another ' +
        'report, or went when another document closed or the report changed language: ' +
        JSON.stringify(clipboard),
    );
    closeListeners.forEach((fn) => fn(openedDocs[0]));
    assert.ok(!copyItem.shown, 'Copy stayed in the status bar after its report was closed');

    // The bridge answers a refused session token with the empty string, which
    // is no report at all: an empty editor would read as a device with nothing
    // to report.
    const refusedReport = await bugReport('', () => 'Copy');
    assert.ok(
        openedDocs.length === 0 && clipboard.length === 0 && refusedReport.error.length === 1 &&
            /did not accept the request/.test(refusedReport.error[0]),
        'a refused report must say so and open nothing: ' +
        JSON.stringify({ openedDocs, clipboard, refusedReport }),
    );

    // ---- a device folder shown by its copy's hash ---------------------------
    //
    // A copy lives at saf-mirrors/<hash>, and the workbench names a folder after
    // the last segment of its path, so the app opens a copy through
    // saf-mirrors/by-name/<hash>/<name>, a link to it. A page still on a copy's
    // hash, as the folder reopened at launch after an update is, has to be
    // offered the move and moved only when nothing is left behind: the workbench
    // keeps unsaved changes and terminals under the path a folder was opened by,
    // so after a move they would be out of sight. The editors that were open come
    // back on the page the move lands on.
    const kotlinNamedDir = /const val NAMED_DIR = "([^"]+)"/.exec(fs.readFileSync(SAF_STORAGE_MANAGER, 'utf8'));
    const jsNamedDir = /const NAMED_DIR = '([^']+)'/.exec(fs.readFileSync(bridgeExtension(), 'utf8'));
    assert.ok(kotlinNamedDir && jsNamedDir, 'NAMED_DIR is gone from SafStorageManager.kt or the extension');
    assert.strictEqual(
        jsNamedDir[1], kotlinNamedDir[1],
        'the extension looks for named paths where the app does not make them, so a page on a ' +
        'copy\'s hash is never offered its name',
    );

    const remote = (p) => uriOf('vscode-remote', '127.0.0.1:13337', p);
    const COPY = `${FILES}/saf-mirrors/8e440ff38c8e`;
    const NAMES = `${FILES}/saf-mirrors/by-name/8e440ff38c8e`;
    const NAMED = `${NAMES}/recipes`;
    const LINK = vscodeStub.FileType.Directory | vscodeStub.FileType.SymbolicLink;
    // The extension's storage for the folder, which names the workbench's id for it,
    // and the backups the workbench keeps under that id.
    const STORAGE = uriOf('vscode-userdata', '', '/User/workspaceStorage/a1b2c3/vscodroid.vscodroid-saf-bridge');
    const BACKUPS = '/User/Backups/a1b2c3';
    const CARRIED = 'namedPath.carried';
    const DECLINED = 'namedPath.declined';
    const tab = (p, extra = {}) => ({ input: new TabInputText(remote(p)), isDirty: false, ...extra });

    /** A page on [folders] (and [file]), with what the editor shows set up first. */
    async function namedPageLoad({ folders, file, tabs = [], active, docs = [], books = [], terms = [] }) {
        workspaceFile = file;
        textDocuments = docs;
        notebookDocuments = books;
        terminals = terms;
        tabGroups = { all: [{ tabs }], activeTabGroup: { activeTab: active } };
        shown.info.length = 0; ranWith.length = 0; shownDocs.length = 0;
        workspaceFolders = folders;
        folderListeners.length = 0;
        warnings.length = 0;
        executed.length = 0;
        require(bridgeExtension()).activate({
            subscriptions: [],
            extensionUri,
            storageUri: STORAGE,
            globalState: {
                get: (key, fallback) => (state.has(key) ? state.get(key) : fallback),
                update: async (key, value) => {
                    state.set(key, value !== null && typeof value === 'object' ? JSON.parse(JSON.stringify(value)) : value);
                    if (storageUpdate) await storageUpdate(key, value);
                },
            },
        });
        await settle();
    }
    const onCopy = [{ uri: remote(COPY), name: '8e440ff38c8e' }];
    const moved = () => ranWith.filter(([id]) => id === 'vscode.openFolder');
    const reopen = (items) => (items.includes('Reopen') ? 'Reopen' : undefined);

    directories = new Map([[NAMES, [['recipes', LINK]]]]);
    infoChoice = reopen;
    const readme = tab(`${COPY}/README.md`);
    const app = tab(`${COPY}/src/app.js`);
    await namedPageLoad({
        folders: onCopy,
        tabs: [app, readme, tab('/data/user/0/com.vscodroid/files/home/projects/x.js'), { input: {}, isDirty: false }],
        active: app,
        docs: [{ isDirty: false }],
    });
    assert.ok(
        shown.info.length === 1 && shown.info[0].includes('8e440ff38c8e') && shown.info[0].includes('recipes'),
        'a page on a copy\'s hash was not offered the folder\'s name: ' + JSON.stringify(shown.info),
    );
    assert.deepStrictEqual(
        moved().map(([, target, options]) => [target.scheme, target.path, options]),
        [['vscode-remote', NAMED, { forceReuseWindow: true }]],
        'Reopen did not open the folder by its name in this window: ' + JSON.stringify(ranWith),
    );
    assert.deepStrictEqual(
        state.get(CARRIED) && [state.get(CARRIED).to, state.get(CARRIED).root, state.get(CARRIED).files],
        [NAMED, NAMED, ['README.md', 'src/app.js']],
        'the editors open under the copy were not carried, the active one last: ' +
        JSON.stringify(state.get(CARRIED)),
    );

    // The page the move lands on opens them, in that order, and forgets them.
    infoChoice = null;
    await namedPageLoad({ folders: [{ uri: remote(NAMED), name: 'recipes' }] });
    assert.deepStrictEqual(
        shownDocs.map((u) => u.path), [`${NAMED}/README.md`, `${NAMED}/src/app.js`],
        'the editors carried across the move were not opened again under the new path: ' +
        JSON.stringify(shownDocs),
    );
    assert.ok(
        state.get(CARRIED) === undefined && shown.info.length === 0 && moved().length === 0,
        'the page reached by name kept the carried editors or was offered a move again',
    );

    // Expired records retire; a live record for another page belongs to that page.
    for (const [why, carried] of [
        ['long ago', { to: NAMED, root: NAMED, files: ['README.md'], at: Date.now() - 600000 }],
        ['to another page', { to: `${NAMES}/other`, root: `${NAMES}/other`, files: ['README.md'], at: Date.now() }],
    ]) {
        state.set(CARRIED, carried);
        await namedPageLoad({ folders: [{ uri: remote(NAMED), name: 'recipes' }] });
        assert.ok(
            shownDocs.length === 0 && (why === 'long ago' ? state.get(CARRIED) === undefined : state.get(CARRIED) === carried),
            `editors carried ${why} were opened here, or kept: ` + JSON.stringify(shownDocs),
        );
    }

    // Nothing left behind, or no move. Each of these keeps the page where it is
    // and says what to do first, with nothing carried.
    infoChoice = reopen;
    const keeps = async (why, setup) => {
        state.delete(CARRIED);
        await namedPageLoad({ folders: onCopy, ...setup });
        assert.ok(
            moved().length === 0 && state.get(CARRIED) === undefined &&
                warnings.length === 1 && /unsaved changes/.test(warnings[0].message),
            `the page was moved, or not told why it was not, with ${why}: ` +
            JSON.stringify({ ranWith, warnings }),
        );
    };
    await keeps('an unsaved document', { docs: [{ isDirty: true }] });
    await keeps('an unsaved tab', { tabs: [tab(`${COPY}/a.txt`, { isDirty: true })] });
    await keeps('an unsaved notebook', { books: [{ isDirty: true }] });
    await keeps('a terminal', { terms: [{}] });
    // A backup of unsaved changes the workbench has not reopened yet.
    directories.set(BACKUPS, [['vscode-remote', vscodeStub.FileType.Directory]]);
    directories.set(`${BACKUPS}/vscode-remote`, [['1a2b3c', vscodeStub.FileType.File]]);
    await keeps('a backup of unsaved changes', {});
    directories.set(`${BACKUPS}/vscode-remote`, []);
    await namedPageLoad({ folders: onCopy });
    assert.strictEqual(moved().length, 1, 'an emptied backup directory still kept the page where it was');
    // Backups that cannot be read are not known to be absent.
    directories.set(BACKUPS, Object.assign(new Error('no access'), { code: 'NoPermissions' }));
    await keeps('backups that could not be read', {});
    directories.delete(BACKUPS);

    // No offer without exactly one named path to go to, nor for any other page.
    const offersMove = async (setup) => {
        await namedPageLoad({ folders: onCopy, ...setup });
        return shown.info.length > 0 || moved().length > 0;
    };
    directories.delete(NAMES);
    const noNames = await offersMove({});
    directories.set(NAMES, [['old', LINK], ['new', LINK]]);
    const twoNames = await offersMove({});
    directories.set(NAMES, [['recipes', vscodeStub.FileType.Directory]]);
    const notALink = await offersMove({});
    directories.set(NAMES, [['recipes', LINK]]);
    const severalFolders = await offersMove({
        folders: [...onCopy, { uri: remote(`${FILES}/home/projects/site`), name: 'site' }],
    });
    const ordinary = await offersMove({ folders: [{ uri: remote(`${FILES}/home/projects/site`), name: 'site' }] });
    assert.deepStrictEqual(
        [noNames, twoNames, notALink, severalFolders, ordinary], [false, false, false, false, false],
        'a move was offered with no single named path to go to, or for a page not on one copy',
    );

    // A workspace file at the top of a copy moves to the same file by name.
    state.delete(CARRIED);
    await namedPageLoad({ folders: onCopy, file: remote(`${COPY}/app.code-workspace`) });
    assert.deepStrictEqual(
        moved().map(([, target]) => target.path), [`${NAMED}/app.code-workspace`],
        'a workspace file in the copy was not reopened through the named path: ' + JSON.stringify(ranWith),
    );
    workspaceFile = undefined;

    // Don't Ask Again is kept, and that copy is not offered again.
    infoChoice = (items) => (items.includes('Don\'t Ask Again') ? 'Don\'t Ask Again' : undefined);
    await namedPageLoad({ folders: onCopy });
    const declinedNow = state.get(DECLINED);
    infoChoice = reopen;
    await namedPageLoad({ folders: onCopy });
    assert.ok(
        JSON.stringify(declinedNow) === '["8e440ff38c8e"]' && shown.info.length === 0 && moved().length === 0,
        'Don\'t Ask Again was not kept for the copy, or the move was offered again: ' +
        JSON.stringify({ declinedNow, info: shown.info }),
    );
    function deferred() {
        let resolve;
        const promise = new Promise(answer => { resolve = answer; });
        return { promise, resolve };
    }
    const clone = value => JSON.parse(JSON.stringify(value));
    const newerCarried = () => ({ id: 'new-window-record', to: '/other/page', root: '/other', files: ['new.txt'], at: Date.now() });
    let asyncNamedCases = 0;
    async function interruptedNamed(gate, mutate, answer = 'Reopen') {
        state.delete(DECLINED); state.delete(CARRIED);
        directories = new Map([[NAMES, [['recipes', LINK]]]]);
        const release = deferred();
        let entered = false;
        let backupReads = 0;
        const wait = async () => { entered = true; await release.promise; };
        directoryRead = async uri => {
            if (uri.path === BACKUPS) backupReads++;
            if (!entered && ((gate === 'lookup' && uri.path === NAMES) ||
                (gate === 'backups' && uri.path === BACKUPS) ||
                (gate === 'final-backups' && uri.path === BACKUPS && backupReads === 2))) await wait();
        };
        storageUpdate = async (key, value) => {
            if (!entered && gate === 'carry' && key === CARRIED && value) await wait();
        };
        infoChoice = items => items.includes('Reopen') ? (gate === 'dialog' ? wait().then(() => answer) : answer) : undefined;
        try {
            await namedPageLoad({ folders: onCopy });
            assert.ok(entered, 'named-path schedule did not reach ' + gate);
            await mutate();
            release.resolve(); await settle();
            assert.strictEqual(moved().length, 0, 'a stale named-path operation reopened after ' + gate);
            asyncNamedCases++;
        } finally {
            release.resolve(); directoryRead = undefined; storageUpdate = undefined; infoChoice = null;
        }
    }
    await interruptedNamed('lookup', () => { workspaceFolders = [{ uri: remote('/work/other'), name: 'other' }]; });
    assert.strictEqual(shown.info.length, 0, 'a stale directory lookup still offered its old workspace');
    await interruptedNamed('dialog', () => { workspaceFolders = [{ uri: remote('/work/other'), name: 'other' }]; }, "Don't Ask Again");
    assert.strictEqual(state.get(DECLINED), undefined, 'a stale dialog persisted its choice for an abandoned workspace');
    await interruptedNamed('backups', () => { textDocuments = [{ isDirty: true }]; });
    for (const [why, mutate] of [
        ['dirty document', () => { textDocuments = [{ isDirty: true }]; }],
        ['terminal', () => { terminals = [{}]; }],
        ['workspace path', () => { workspaceFolders = [{ uri: remote('/work/other'), name: 'other' }]; }],
        ['remote authority', () => { workspaceFolders = [{ uri: uriOf('vscode-remote', 'other', COPY), name: 'other' }]; }],
        ['query', () => { workspaceFolders = [{ uri: { ...remote(COPY), query: 'other' }, name: 'other' }]; }],
        ['fragment', () => { workspaceFolders = [{ uri: { ...remote(COPY), fragment: 'other' }, name: 'other' }]; }],
        ['deactivation', () => { require(bridgeExtension()).deactivate(); }],
    ]) {
        await interruptedNamed('carry', () => {
            assert.ok(state.get(CARRIED).id, 'published carry record has no ownership token');
            mutate();
        });
        assert.strictEqual(state.get(CARRIED), undefined, 'abandoned cloned record was retained after ' + why);
    }
    await interruptedNamed('final-backups', () => { directories.set(BACKUPS, [['pending', vscodeStub.FileType.File]]); });
    assert.strictEqual(state.get(CARRIED), undefined, 'a newly appearing backup left a stale carried record');
    const newer = newerCarried();
    await interruptedNamed('carry', () => { state.set(CARRIED, clone(newer)); });
    assert.deepStrictEqual(state.get(CARRIED), newer, 'old publication cleanup erased the observed newer window record');
    {
        const saving = deferred();
        let running;
        await interruptedNamed('carry', () => {
            const document = { uri: remote('/work/new.js'), languageId: 'javascript', isUntitled: false, isDirty: false,
                async save() { await saving.promise; return true; } };
            vscodeStub.window.activeTextEditor = { document };
            running = commands.get('vscodroid.runFile')();
        });
        assert.strictEqual(state.get(CARRIED), undefined, 'a newer run intent left the old carried record');
        saving.resolve(); await running;
        assert.strictEqual(runLines.at(-1), "node '/work/new.js'", 'the accepted newer run was canceled with the old offer');
        vscodeStub.window.activeTextEditor = undefined;
    }
    for (const replacement of [undefined, newerCarried()]) {
        state.delete(CARRIED); state.delete(DECLINED);
        directories = new Map([[NAMES, [['recipes', LINK]]]]);
        infoChoice = reopen;
        commandRun = async id => {
            if (id !== 'vscode.openFolder') return;
            if (replacement) state.set(CARRIED, clone(replacement));
            throw new Error('folder command declined');
        };
        try {
            await namedPageLoad({ folders: onCopy });
            assert.strictEqual(moved().length, 1, 'the clean control did not dispatch its folder command');
            assert.deepStrictEqual(state.get(CARRIED), replacement, 'failed folder command cleanup removed a newer record or retained its own');
            asyncNamedCases++;
        } finally { commandRun = undefined; infoChoice = null; }
    }
    for (const replacement of [false, true]) {
        const carried = { id: 'arriving-record', to: NAMED, root: NAMED, files: ['one.txt'], at: Date.now() };
        state.set(CARRIED, clone(carried));
        const release = deferred();
        let entered = false;
        storageUpdate = async (key, value) => { if (key === CARRIED && value === undefined) { entered = true; await release.promise; } };
        try {
            await namedPageLoad({ folders: [{ uri: remote(NAMED), name: 'recipes' }] });
            assert.ok(entered, 'arrival did not reach record consumption');
            if (replacement) state.set(CARRIED, clone(newer));
            else workspaceFolders = onCopy;
            release.resolve(); await settle();
            if (replacement) assert.deepStrictEqual(state.get(CARRIED), newer, 'old arrival cleanup erased a newer observed record');
            else {
                assert.strictEqual(shownDocs.length, 0, 'arrival reopened files after leaving its workspace');
                assert.strictEqual(moved().length, 0, 'old arrival completion offered a different workspace');
            }
            asyncNamedCases++;
        } finally { release.resolve(); storageUpdate = undefined; }
    }
    for (const deactivate of [false, true]) {
        state.set(CARRIED, { id: 'arriving-files', to: NAMED, root: NAMED, files: ['one.txt', 'two.txt'], at: Date.now() });
        const release = deferred();
        let entered = false;
        documentShow = async () => { if (!entered) { entered = true; await release.promise; } };
        try {
            await namedPageLoad({ folders: [{ uri: remote(NAMED), name: 'recipes' }] });
            assert.ok(entered, 'arrival did not reach its first editor');
            if (deactivate) require(bridgeExtension()).deactivate();
            else workspaceFolders = [{ uri: remote('/work/other'), name: 'other' }];
            release.resolve(); await settle();
            assert.deepStrictEqual(shownDocs.map(uri => uri.path), [NAMED + '/one.txt'], 'late restoration opened another editor after its page was retired');
            asyncNamedCases++;
        } finally { release.resolve(); documentShow = undefined; }
    }
    assert.strictEqual(asyncNamedCases, 19, 'an asynchronous named-path schedule was skipped');
    {
        state.delete(DECLINED); state.delete(CARRIED);
        directories = new Map([[NAMES, [['recipes', LINK]]]]);
        infoChoice = items => items.includes("Don't Ask Again") ? "Don't Ask Again" : undefined;
        const unhandled = [];
        const recordRejection = error => unhandled.push(error);
        process.on('unhandledRejection', recordRejection);
        storageUpdate = async key => { if (key === DECLINED) throw new Error('storage unavailable'); };
        try {
            await namedPageLoad({ folders: onCopy });
            await settle();
            assert.deepStrictEqual(unhandled, [], 'a failed preference update escaped the named-path handler');
            assert.strictEqual(moved().length, 0);
        } finally {
            process.off('unhandledRejection', recordRejection);
            storageUpdate = undefined; infoChoice = null;
        }
    }


    state.delete(DECLINED); state.delete(CARRIED);
    infoChoice = null; directories = new Map(); tabGroups = { all: [], activeTabGroup: undefined };

    const unused = coverage.unused.length
        ? `; ${coverage.unused.length} relay branches have no sender (${coverage.unused.join(', ')})`
        : '';
    say(
        `ok -- a declined URL surfaces "${refused.error[0]}", an opened one stays silent, ` +
        'and window.open claims only the clicks the bridge opened; a device-folder listing ' +
        'and a removal each hand back before their work is done and are answered by reply ' +
        'id, and a refusal on either road reaches the user in the bridge\'s own words; ' +
        'a shared-storage folder opened by path is warned about in a dialog once per editor ' +
        'server, with a button to Open Folder from Device and one that silences it for ' +
        'later sessions; the bug report opens in an editor before Copy takes what it holds; ' +
        'a page on a device folder copy\'s hash is offered the folder\'s name and moved there ' +
        'only with nothing unsaved and no terminal, its editors following; ' +
        `${asyncNamedCases} delayed named-path schedules preserve newer intent and carried records; ` +
        `all ${coverage.sent} commands sent by an extension have a relay branch${unused}\n`,
    );
}

/**
 * Writes synchronously, because the exit below cannot wait for it otherwise.
 *
 * `process.exit()` is documented to leave pending writes to stdout unflushed,
 * and stdout is only synchronous when it is a TTY. Under CI it is a pipe, so a
 * console.log immediately before the exit is exactly the line that goes
 * missing -- and a check that exits 0 having printed nothing reads as a check
 * that did not run.
 */
function say(text) {
    fs.writeSync(1, text);
}

// Exit explicitly. The relay opens a BroadcastChannel inside the VM context and
// nothing here holds a reference to unref it, so the event loop stays alive and
// the process hangs forever after the last assertion -- green, and never
// finishing, which in CI is a stall rather than a pass.
main().then(
    () => process.exit(0),
    (e) => { fs.writeSync(2, `${e.message}\n`); process.exit(1); },
);
