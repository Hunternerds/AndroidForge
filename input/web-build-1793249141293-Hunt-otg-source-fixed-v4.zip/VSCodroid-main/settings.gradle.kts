// Root shim. The real Gradle build lives in android/, but some build runners
// (AndroidForge among them) start Gradle from the repository root, where it
// finds no settings file and stops with "does not contain a Gradle build".
//
// This makes the root a thin composite build that includes android/ as-is.
// android/ keeps its own settings, wrapper, version catalog and gradle.properties,
// and android/app/build.gradle.kts still sees the repository root as
// rootProject.projectDir.parentFile, which it relies on for patches/, scripts/,
// branding/ and the notice documents.
rootProject.name = "hunt-root"

// A bare `assembleDebug` packages only the Android shell. The editor itself (the Node
// runtime, the VS Code server, the Termux tools and the native add-ons) is produced
// by scripts, and without it the app opens to "Failed to start development server".
// So before android/ is configured, which is when it measures assets/, run the
// preparation script once. It returns at once when the assets are already there.
// Only for tasks that build an APK or bundle; skip with HUNT_SKIP_ASSETS=1 or
// -PhuntSkipAssets.
val huntBuildsPackage = gradle.startParameter.taskNames.any {
    it.contains("assemble", ignoreCase = true) || it.contains("bundle", ignoreCase = true)
}
val huntSkipAssets = System.getenv("HUNT_SKIP_ASSETS") == "1" ||
    providers.gradleProperty("huntSkipAssets").isPresent
val huntPrepareScript = File(settingsDir, "scripts/hunt-prepare-assets.sh")

if (huntBuildsPackage && !huntSkipAssets && huntPrepareScript.isFile) {
    println("Hunt: preparing the editor assets (first run takes a while)...")
    val process = ProcessBuilder("bash", huntPrepareScript.path)
        .directory(settingsDir)
        .redirectErrorStream(true)
        .start()
    process.inputStream.bufferedReader().forEachLine { println(it) }
    val exitCode = process.waitFor()
    if (exitCode != 0) {
        throw GradleException(
            "Hunt asset preparation failed (exit $exitCode). The last [hunt-assets] " +
                "line above says which step. Without these assets the APK would open " +
                "to \"Failed to start development server\"."
        )
    }
}

includeBuild("android")
