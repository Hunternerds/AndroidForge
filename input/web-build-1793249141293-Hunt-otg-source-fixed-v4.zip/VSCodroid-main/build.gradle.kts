// The wrapper in this directory (gradlew, gradlew.bat, gradle/wrapper/) is a copy of
// android/'s. It exists so runners that start in the repository root find a wrapper
// here and use Gradle 9.x, instead of falling back to whatever `gradle` is installed
// (AGP 9 refuses anything older than 9.5). When android/'s wrapper is bumped, copy
// it here too.
//
// Forwards the usual tasks to the :app module of the included android/ build, so
// `android/gradlew assembleDebug` works from the repository root as well as from
// android/. Outputs stay where they always were: android/app/build/outputs/.
//
// To forward another task, add its name to the list.
val appBuild = gradle.includedBuilds.single()

listOf(
    "assembleDebug",
    "assembleRelease",
    "bundleDebug",
    "bundleRelease",
    "testDebugUnitTest",
    "lintDebug",
).forEach { taskName ->
    tasks.register(taskName) {
        group = "android"
        description = "Runs :app:$taskName in the android/ build."
        dependsOn(appBuild.task(":app:$taskName"))
    }
}
