package com.vscodroid

import android.net.Uri
import io.mockk.every
import io.mockk.mockkStatic
import io.mockk.unmockkAll
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Assumptions.assumeTrue
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir
import java.io.File as JavaFile

/**
 * That a multi-root workspace survives the round trip through the URL.
 *
 * The workbench opens a `.code-workspace` by navigating its own WebView to
 * `?workspace=<file>`, which is a client-side contract the shipped bundle
 * already implements in full. The Kotlin shell only ever spoke `?folder=`, in
 * both directions, and the cost of that was not cosmetic:
 *
 *  - `folderFromUrl` answered null for a workspace URL, so the page-loaded
 *    callback ran neither of its consumers. `adoptWorkbenchFolder` is one of
 *    them, and it is what starts the write-back watcher for a device folder the
 *    workbench reached on its own. A workspace opened out of a mirror was
 *    therefore served read-write with nothing syncing it, and every edit stayed
 *    in the mirror and never reached the user's own files. Measured on an
 *    emulator: the same edit reaches the device folder when it is opened as a
 *    folder and does not when it is opened as a workspace.
 *  - The same null fell through to the remembered folder and then to the default
 *    projects directory, so the workspace was not reopened on the next launch.
 *
 * The two are one defect: nothing could name a workspace, so nothing could
 * remember one or recognise one. These pin the naming, which is what the rest
 * hangs off. `File` and `Uri` are unavailable in a plain JVM test, which is why
 * the decision is a function over strings the way [rememberedFolderToReopen] is.
 */
class WorkspaceUrlRoundTripTest {

    private val token = "0123456789abcdef"
    private val workspace = "/data/user/0/com.vscodroid/files/saf-mirrors/92f67f007ab2/proj.code-workspace"
    private val folder = "/data/user/0/com.vscodroid/files/projects/site"

    @BeforeEach
    fun setUp() {
        // Uri is a stub under the unit-test android.jar and throws otherwise.
        // Identity encoding is faithful enough for these paths, which carry no
        // character the encoder would touch.
        mockkStatic(Uri::class)
        every { Uri.encode(any()) } answers { firstArg<String>() }
    }

    @AfterEach
    fun tearDown() = unmockkAll()

    @Test
    fun `a workspace file is named by the workspace parameter`() {
        assertTrue(
            workbenchUrl(13337, workspace, token, isFile = { true }).contains("?workspace="),
            "the shipped workbench reads `workspace` and `folder` as different things: " +
                "`folder` builds a folderUri from whatever path it is handed with no " +
                "file test, so a .code-workspace sent as `folder` opens as a single-root " +
                "folder whose root is a file, not as the workspace it is",
        )
    }

    @Test
    fun `an ordinary folder is still named by the folder parameter`() {
        assertTrue(
            workbenchUrl(13337, folder, token).contains("?folder="),
            "every navigation that is not a workspace has to be untouched by this, and " +
                "it is the overwhelmingly common one",
        )
    }

    @Test
    fun `a directory named like a workspace is navigated to as a folder`() {
        assertTrue(
            workbenchUrl(13337, "$mirror/odd.code-workspace", token, isFile = { false })
                .contains("?folder="),
            "the workbench answers a workspace it cannot read with an empty window and " +
                "no message, and a directory is one of those. `folderOpenTarget` already " +
                "excludes it where the picker chooses a target; the URL builder is where " +
                "the choice is actually made, and it decided on the name alone. Nothing " +
                "corrected it afterwards either: `folderFromUrl` answers null for a " +
                "`workspace` URL naming a directory, so the folder was neither reopened " +
                "nor forgotten",
        )
    }

    @Test
    fun `the connection token still rides along on a workspace URL`() {
        assertTrue(
            workbenchUrl(13337, workspace, token, isFile = { true }).contains("&tkn=$token"),
            "the server answers a bare Forbidden without it, and a workspace URL is " +
                "reached by the same navigation as a folder one",
        )
    }

    @Test
    fun `a folder parameter naming something that is not a directory is refused`() {
        assertNull(
            workbenchTarget(
                query = "folder=$workspace",
                isDirectory = { false },
                isFile = { true },
            ),
            "the directory test on `folder` is what keeps a dead path from pinning the " +
                "WebView, and it predates this change. A workspace file arriving as " +
                "`folder` is a URL nothing here builds any more, so it stays refused",
        )
    }

    @Test
    fun `a workspace parameter naming an existing file is taken`() {
        assertEquals(
            workspace,
            workbenchTarget(
                query = "workspace=$workspace",
                isDirectory = { false },
                isFile = { true },
            ),
            "this is the answer the page-loaded callback needs in order to run at all: " +
                "without it adoptWorkbenchFolder never sees the mirror the workspace " +
                "lives in and no watcher is started for it",
        )
    }

    @Test
    fun `a workspace file that is gone is not taken`() {
        assertNull(
            workbenchTarget(
                query = "workspace=$workspace",
                isDirectory = { false },
                isFile = { false },
            ),
            "the same reason the folder branch stats what it reads: a workspace deleted " +
                "while the app was away would otherwise be remembered and reopened onto " +
                "a path that is not there",
        )
    }

    @Test
    fun `the final recognized selector wins in either order and across duplicates`() {
        val cases = listOf(
            "folder=$folder&workspace=$workspace" to workspace,
            "workspace=$workspace&folder=$folder" to folder,
            "folder=/old&folder=$folder" to folder,
            "workspace=/old.code-workspace&workspace=$workspace" to workspace,
            "folder=/old&workspace=$workspace&folder=$folder&token=ignored" to folder,
            "folder=$folder&ew=false" to null,
            "workspace=$workspace&ew" to null,
            "ew=true&folder=$folder" to folder,
            "ew=true&workspace=$workspace" to workspace,
        )
        for ((query, expected) in cases) {
            assertEquals(
                expected,
                workbenchTarget(query, { it == folder }, { it == workspace }),
                query,
            )
        }
    }

    @Test
    fun `an unusable final target never falls back to an earlier selector`() {
        for (query in listOf(
            "folder=$folder&workspace=/missing.code-workspace",
            "workspace=$workspace&folder=/missing",
            "folder=$folder&workspace=$folder",
            "workspace=$workspace&folder=$workspace",
            "folder=$folder&folder=/missing",
            "workspace=$workspace&workspace=",
            "ew=true&folder=/missing",
            "folder=$folder&folder=relative",
            "workspace=$workspace&workspace=relative.code-workspace",
        )) {
            assertNull(workbenchTarget(query, { it == folder }, { it == workspace }), query)
            assertNull(emptyWindowUrl("http://127.0.0.1:13337/?$query", 13337), query)
        }
    }

    @Test
    fun `relative and empty selected paths are refused before filesystem checks`() {
        for (query in listOf("folder=relative", "workspace=relative.code-workspace", "folder=", "workspace=")) {
            assertNull(workbenchTarget(query, { error("must not stat a relative path") }, {
                error("must not stat a relative path")
            }), query)
        }
    }

    @Test
    fun `selector names and values use form decoding once after splitting`() {
        val cases = listOf(
            "folder=$folder&work%73pace=$workspace" to workspace,
            "workspace=$workspace&%66older=$folder" to folder,
            "folder=/a+b" to "/a b",
            "folder=/a%2Bb" to "/a+b",
            "folder=/a%26workspace%3Dother" to "/a&workspace=other",
            "folder=/a%252Fb" to "/a%2Fb",
            "folder=%2Fa%" to "/a%",
            "folder=%2Fa%2" to "/a%2",
        )
        for ((query, expected) in cases) {
            assertEquals(expected, workbenchTarget(query, { true }, { true }), query)
        }
    }

    @Test
    fun `only the final empty selector closes the window regardless of its value`() {
        for (query in listOf("ew", "ew=", "ew=false", "folder=$folder&%65w=0", "ew=true&ew=false")) {
            val url = "http://127.0.0.1:13337/?$query#folder=/ignored"
            assertEquals(url, emptyWindowUrl(url, 13337), query)
        }
        assertNull(emptyWindowUrl("http://127.0.0.1:13337/?ew=true&folder=$folder", 13337))
        assertNull(emptyWindowUrl("http://127.0.0.1:13337/#?ew=true", 13337))
        assertNull(emptyWindowUrl("http://127.0.0.1:13337/?folder=$folder#&ew=true", 13337))
    }

    @Test
    fun `the directory in force for a workspace is the one holding it`() {
        assertEquals(
            "/data/user/0/com.vscodroid/files/saf-mirrors/92f67f007ab2",
            workspaceDirectoryInForce(workspace, isFile = { true }),
            "the resource interceptor publishes this as a root, and a root that is a " +
                "single file matches only itself: every resource in the workspace would " +
                "be refused for a workspace held outside the statically published trees",
        )
    }

    /**
     * The one case that exercises the DEFAULT predicates against a real filesystem.
     *
     * Every other case here passes its own `isFile`, which is what makes them
     * readable, and is also a hole: the defaults on `workbenchUrl` and
     * `workspaceDirectoryInForce` are what production actually runs, and nothing
     * else reaches them. Weakening one to `{ true }` restores the defect this file
     * exists to refuse, with every other case in the suite still green.
     *
     * A temporary directory rather than a fixture path, because the whole point is
     * that the real `File.isFile` answers, and it answers false for every
     * `/data/user/0/...` path on a JVM host.
     */
    @Test
    fun `the default file test reads the real filesystem`(@TempDir dir: JavaFile) {
        val workspaceFile = JavaFile(dir, "real.code-workspace").apply { writeText("{}") }
        val lookalikeDirectory = JavaFile(dir, "odd.code-workspace").apply { mkdir() }

        assertTrue(
            workbenchUrl(13337, workspaceFile.path, token).contains("?workspace="),
            "a real workspace file must still be named by the workspace parameter when " +
                "nobody passes a predicate, which is how production calls it",
        )
        assertTrue(
            workbenchUrl(13337, lookalikeDirectory.path, token).contains("?folder="),
            "and a real directory spelled the same way must not be, which is the whole " +
                "defect: the editor answers a workspace it cannot read with an empty " +
                "window and no message",
        )
        assertEquals(
            dir.path,
            workspaceDirectoryInForce(workspaceFile.path),
            "the published root for a real workspace file is the directory holding it",
        )
        assertEquals(
            lookalikeDirectory.path,
            workspaceDirectoryInForce(lookalikeDirectory.path),
            "and for a real directory it is the directory itself, not its parent, which " +
                "is what kept every sibling of the opened folder readable",
        )
    }

    /**
     * Where the reduction happens, which no pure function can pin.
     *
     * `workspaceDirectoryInForce` needs a `stat`, and the resource interceptor
     * runs once per request, so the reduction was moved to the one navigation-time
     * writer and both suppliers hand the result. Nothing else notices if that
     * moves back: the interceptor would still be handed a path, the roots would
     * still be a list, and every case above would stay green while a workspace
     * session paid a `stat` per request and a momentarily absent file silently
     * unpublished the root.
     *
     * Read from the source because the writer is an Activity method and the
     * suppliers are lambdas closing over its fields, neither of which a plain JVM
     * test can drive. See [SourceScan] for the ceiling that reading carries.
     */
    @Test
    fun `the workspace root is reduced once at navigation, not per request`() {
        val source = SourceScan.read("src/main/kotlin/com/vscodroid/MainActivity.kt")
        val writer = SourceScan.withoutComments(
            SourceScan.body(source, "private fun rememberWorkspaceFolder("),
        )

        // Read as one line rather than as one contiguous string: the writer also
        // has to answer the closed-folder case, where the field is null and there
        // is nothing to reduce, so the assignment is guarded. What matters is
        // that the assignment and the reduction are the same statement, which a
        // per-line test says and a substring search cannot.
        assertTrue(
            writer.lines().any {
                it.contains("openWorkspaceRoot =") && it.contains("workspaceDirectoryInForce(")
            },
        ) {
            "rememberWorkspaceFolder no longer derives the published root, so either " +
                "nothing does and a workspace file publishes only itself, or the " +
                "interceptor went back to reducing per request"
        }

        val body = SourceScan.withoutComments(source)
        assertTrue(body.contains("openFolder = { openWorkspaceRoot }")) {
            "the webview client is handed the unreduced folder again"
        }
        assertTrue(body.contains("{ self.get()?.openWorkspaceRoot }")) {
            "the service worker is handed the unreduced folder again, and it is the " +
                "entry point that does not go through the client"
        }
    }

    /**
     * That closing the folder is recorded, and recorded from the right URL.
     *
     * The workbench closes a folder by navigating its own WebView, so this
     * callback is the only place Kotlin can learn it happened. Without the
     * clearing branch the record went on naming the folder the user had closed:
     * the next launch reopened it, and [MainActivity.openWorkspaceRoot] went on
     * publishing it as a served resource root for the rest of the session.
     *
     * The predicate matters as much as its presence. `isWorkbenchUrl` is host
     * and port only, so writing the branch against it would forget a live folder
     * on a bare `/` load, and the symptom (the next launch lands in the projects
     * directory) looks nothing like the cause.
     */
    @Test
    fun `a closed folder is recorded as closed, from the URL that says so`() {
        val bridge = SourceScan.withoutComments(
            SourceScan.body(
                SourceScan.read("src/main/kotlin/com/vscodroid/MainActivity.kt"),
                "private fun initBridge(",
            ),
        )

        assertTrue(bridge.contains("emptyWindowUrl(url, port)")) {
            "the page-loaded callback no longer asks whether the workbench closed the " +
                "folder, so the closed state is remembered for as long as the WebView " +
                "lives and no longer"
        }
        assertTrue(bridge.contains("rememberWorkspaceFolder(null)")) {
            "nothing clears the remembered folder, so closing it and relaunching puts " +
                "the user back into the folder they closed"
        }
    }

    @Test
    fun `a failed selected path clears only the live workspace after the page loads`() {
        val bridge = SourceScan.withoutComments(
            SourceScan.body(
                SourceScan.read("src/main/kotlin/com/vscodroid/MainActivity.kt"),
                "private fun initBridge(",
            ),
        )
        val invalid = SourceScan.body(bridge, "else if (isWorkbenchUrl(url, port) &&")
        assertTrue(invalid.contains("openWorkspaceFolder = null"))
        assertTrue(invalid.contains("openWorkspaceRoot = null"))
        assertFalse(invalid.contains("rememberWorkspaceFolder("))
        assertFalse(invalid.contains("workspacePrefs"))
        assertTrue(bridge.contains("workbenchSelection(workspaceQueryFromUrl(url))?.kind"))
    }

    @Test
    fun `recovery follows a close or folder switch after the lookup`() {
        assertEquals(folder, workspaceTargetAfterLookup("data:text/html,placeholder", 13337, null, folder))
        assertEquals(workspace, workspaceTargetAfterLookup(workbenchUrl(13337, workspace, null), 13337, workspace, folder))
        for (query in listOf("ew=true", "ew=false", "folder=$folder&ew=0")) {
            assertNull(workspaceTargetAfterLookup("http://127.0.0.1:13337/?$query", 13337, null, folder))
        }
        assertNull(workspaceTargetAfterLookup(null, 13337, null, null))
    }

    @Test
    fun `empty windows accept both supported HTTP loopback hosts and root spellings`() {
        for (address in listOf(
            "http://127.0.0.1:13337", "http://127.0.0.1:13337/",
            "http://localhost:13337", "http://localhost:13337/",
        )) {
            for (query in listOf("ew", "ew=false", "folder=/missing&%65w=0", "ew=true&ew=false")) {
                val url = "$address?$query#ignored"
                assertEquals(url, emptyWindowUrl(url, 13337), url)
            }
        }
    }

    @Test
    fun `empty window aliases retain the HTTP root and selector guards`() {
        for (url in listOf(
            "http://localhost:9999/?ew=true", "http://example.com:13337/?ew=true",
            "http://localhost:13337/vscode-remote-resource?ew=true",
            "http://127.0.0.1:13337/static/workbench.html?ew=true",
            "https://localhost:13337/?ew=true", "ftp://127.0.0.1:13337/?ew=true",
            "http://localhost:13337/?ew=true&folder=/missing",
            "http://localhost:13337/?ew=true&workspace=/missing.code-workspace",
            "http://localhost:13337/#?ew=true",
        )) assertNull(emptyWindowUrl(url, 13337), url)
        val malformedQuery = "http://localhost:13337/?ignored=%&%65w=false"
        assertEquals(malformedQuery, emptyWindowUrl(malformedQuery, 13337))
        assertNull(emptyWindowUrl("http://localhost:13337/%?ew=true", 13337))
    }

    @Test
    fun `resource paths are not closed workbench windows`() {
        for (path in listOf("vscode-remote-resource", "static/workbench.html")) {
            val url = "http://127.0.0.1:13337/$path?ew=true"
            assertNull(emptyWindowUrl(url, 13337))
            assertEquals(folder, workspaceTargetAfterLookup(url, 13337, null, folder))
        }
    }

    /**
     * That the editor's own new window stays in the editor.
     *
     * The workbench builds a second window's URL from its own origin and
     * pathname and puts no connection token on it. Handed to the system browser,
     * which is where every other `window.open` goes, the server answers it
     * "Forbidden.", and the editor is left under VS Code's own popup-blocked
     * dialog. A device has one window, so the answer is to navigate in place.
     *
     * Read from the source because the override is a JavaScript string evaluated
     * in a page no JVM test has.
     */
    @Test
    fun `a second window is this window`() {
        val override = SourceScan.withoutComments(
            SourceScan.body(
                SourceScan.read("src/main/kotlin/com/vscodroid/MainActivity.kt"),
                "private fun injectWindowOpenOverride(",
            ),
        )

        val sameOrigin = override.indexOf("location.origin")
        val bridge = override.indexOf("AndroidBridge.openExternalUrl")
        assertTrue(sameOrigin >= 0) {
            "window.open no longer tests for our own origin, so the editor's own " +
                "address goes to the device browser, which is answered Forbidden"
        }
        assertTrue(bridge >= 0) {
            "the bridge call is gone, so an ordinary external link no longer opens"
        }
        assertTrue(sameOrigin < bridge) {
            "the same-origin test now runs after the bridge has already been handed " +
                "the URL, which is the defect with an extra branch above it"
        }
        assertTrue(override.contains("return window")) {
            "the override answers falsy for a window it did handle, and the caller " +
                "reads `!!window.open(...)`, so VS Code draws its popup-blocked " +
                "message over a navigation that is working"
        }
        val guard = override.indexOf("url.charAt(root.length)")
        assertTrue(guard >= 0 && guard < override.indexOf("window.location.href = url")) {
            "any address on our origin is navigated to in place, so a workspace HTML " +
                "file served through /vscode-remote-resource replaces the editor with " +
                "the editor's storage and bridge in reach"
        }
    }

    /**
     * That the workbench still spells the empty window the way this reads it.
     *
     * Both halves of the closed-folder work rest on one string the shipped
     * bundle chooses: `ew=true` on a URL built from `document.location.origin`.
     * A VS Code bump that renames the parameter, or builds the URL from
     * somewhere other than our origin, makes [emptyWindowUrl] match nothing and
     * the same-origin branch match nothing, silently and in both directions.
     *
     * Skipped rather than failed when the tree is absent: it is a gitignored
     * artifact and the unit-test job stubs it, and a silent skip there would read
     * as a green check of something nothing ran.
     */
    @Test
    fun `the shipped workbench still names the empty window this way`() {
        val workbench = JavaFile(
            "src/main/assets/vscode-reh/out/vs/code/browser/workbench/workbench.js",
        )
        assumeTrue(
            workbench.isFile,
            "no packaged workbench at ${workbench.path}; run scripts/fetch-vscode-oss.sh " +
                "and scripts/package-assets.sh to check these against the shipped bundle",
        )
        val source = workbench.readText()

        assertTrue(source.contains("QUERY_PARAM_EMPTY_WINDOW=\"ew\"")) {
            "the workbench no longer calls the empty window `ew`, so emptyWindowUrl " +
                "recognises nothing and a closed folder is forgotten again"
        }
        assertTrue(source.contains("document.location.origin}\${document.location.pathname}")) {
            "the workbench no longer builds a new window's URL from its own origin, so " +
                "the same-origin branch in injectWindowOpenOverride matches nothing and " +
                "the address goes back to the device browser"
        }
    }

    @Test
    fun `the directory in force for a directory named like a workspace is itself`() {
        assertEquals(
            "$mirror/odd.code-workspace",
            workspaceDirectoryInForce("$mirror/odd.code-workspace", isFile = { false }),
            "reducing to the parent is right for a workspace FILE, whose siblings are " +
                "the workspace's own content. For a directory it published a root one " +
                "level too high, covering every sibling of the folder the user opened",
        )
    }

    @Test
    fun `the directory in force for an ordinary folder is itself`() {
        assertEquals(
            folder,
            workspaceDirectoryInForce(folder),
            "the common path has to pass through unchanged",
        )
    }

    /**
     * A closed folder is the third thing the workbench can be showing, and the
     * folder chain cannot name it: `folderFromUrl` answers a path or nothing, and
     * "no folder, deliberately" is not a path. So a renderer crash over a closed
     * folder fell through to the remembered folder and put the user back in the
     * workspace they had just closed.
     *
     * Recognising the state from the URL is what makes this expressible at all;
     * `loadVSCode` then rebuilds it through [workbenchUrl], with the live token.
     */
    @Test
    fun `a closed folder is restored as a closed folder`() {
        assertEquals(
            "http://127.0.0.1:13337/?ew=true",
            emptyWindowUrl("http://127.0.0.1:13337/?ew=true", 13337),
        )
    }

    /**
     * And that the restore is rebuilt rather than reloaded.
     *
     * Every spawned server has a token of its own, so the `vscode-tkn` cookie the
     * page holds names a server a restart may have replaced, and a closed-folder
     * URL loaded verbatim is then answered "Forbidden.". [workbenchUrl] spells the
     * closed state with the token, and `navigateToFolder` is the route to it.
     *
     * `reload()` is that verbatim load too, and the tempting one: it is how the
     * resume path keeps `?ew=true`. `onServerReady` puts the editor back through
     * this method after a spawn, and every spawn replaced the token, so a reload
     * is refused anywhere in it: a guard clause in front of the closed-folder
     * branch is the same reload as a path inside it. The builder is looked for in
     * that branch itself, because kept beside a reload for one caller or the
     * other it would still be in the method.
     */
    @Test
    fun `a closed folder is reloaded with the live token, not the cookie`() {
        val load = SourceScan.withoutComments(
            SourceScan.body(
                SourceScan.read("src/main/kotlin/com/vscodroid/MainActivity.kt"),
                "private fun loadVSCode(",
            ),
        )
        val closed = SourceScan.body(load, "if (emptyWindowUrl(")

        assertTrue(closed.contains("navigateToFolder(port, null)")) {
            "loadVSCode no longer restores the closed folder through the one builder " +
                "that carries the token"
        }
        assertFalse(load.contains("reload(")) {
            "loadVSCode reloads the page verbatim again, on at least one path, so a " +
                "closed folder restored after a server restart is sent with the previous " +
                "server's cookie and answered Forbidden"
        }
        assertFalse(load.contains(".loadUrl(")) {
            "loadVSCode loads a URL itself again, so a closed folder restored after a " +
                "server restart is sent with a dead token and answered Forbidden"
        }
    }

    /**
     * The other half of that: a cold start has no URL to restore, so it has to
     * build one.
     *
     * Restoring is only available while the page is still there, which covers a
     * renderer crash and nothing else. A launch after the process died has to
     * spell the empty window itself, and it has to spell it in the one builder,
     * with the token: a fresh process holds no `vscode-tkn` cookie, and a
     * request without one is answered "Forbidden." Building `?folder=` for the
     * closed state, or dropping the token, both put a page in front of the user
     * that the server refuses.
     */
    @Test
    fun `the closed state has a URL of its own, with the token`() {
        assertEquals(
            "http://127.0.0.1:13337/?ew=true&tkn=$token",
            workbenchUrl(13337, null, token),
        )
    }

    /**
     * And that the two halves still recognise each other.
     *
     * The builder writes the empty window and [emptyWindowUrl] reads it back.
     * Renaming the parameter on one side alone leaves the crash path unable to
     * recognise a window this code itself opened, with every other case here
     * green.
     */
    @Test
    fun `the empty window this builds is the one the crash path restores`() {
        val built = workbenchUrl(13337, null, "tok")

        assertEquals(built, emptyWindowUrl(built, 13337))
    }

    @Test
    fun `an ordinary workbench URL is not treated as a closed folder`() {
        assertNull(
            emptyWindowUrl("http://127.0.0.1:13337/?folder=/x/y", 13337),
            "the folder chain owns this one, and it rebuilds the URL with a fresh " +
                "token rather than reloading a stripped one",
        )
    }

    @Test
    fun `a workspace URL is not treated as a closed folder`() {
        assertNull(
            emptyWindowUrl("http://127.0.0.1:13337/?workspace=/x/y.code-workspace", 13337),
        )
    }

    @Test
    fun `a page on another port is refused`() {
        assertNull(
            emptyWindowUrl("http://127.0.0.1:9999/?ew=true", 13337),
            "the port is the whole of what makes a URL ours, and the placeholder and " +
                "error pages this is asked about are neither",
        )
    }

    @Test
    fun `the data placeholder is refused`() {
        assertNull(
            emptyWindowUrl("data:text/html,<html></html>", 13337),
            "the WebView holds this before the first navigation and after a crash, " +
                "which is exactly when this is asked",
        )
    }

    private val mirror = "/data/user/0/com.vscodroid/files/saf-mirrors/92f67f007ab2"

    /**
     * The picker grants a directory, because `ACTION_OPEN_DOCUMENT_TREE` returns
     * nothing else, so a workspace can only ever be reached through the folder
     * holding it. Nothing connected the two: the folder opened as a folder, and
     * the workspace inside it was reachable only by knowing to find the file in
     * the explorer and press a button on it. Desktop VS Code offers this itself,
     * and the browser workbench does not carry that code, so the shell is the
     * only side that can.
     */
    @Test
    fun `a granted folder holding one workspace opens as that workspace`() {
        assertEquals(
            "$mirror/proj.code-workspace",
            folderOpenTarget(
                mirror,
                names = listOf("src", "proj.code-workspace", "README.md"),
                isFile = { true },
            ),
            "this is the whole of what the issue asks for: a workspace opened from " +
                "the Android picker, which can only grant the folder around it",
        )
    }

    @Test
    fun `a granted folder with no workspace opens as a folder`() {
        assertEquals(
            mirror,
            folderOpenTarget(mirror, names = listOf("src", "README.md"), isFile = { true }),
            "the overwhelmingly common case, and it must not change",
        )
    }

    @Test
    fun `a granted folder holding two workspaces opens as a folder`() {
        assertEquals(
            mirror,
            folderOpenTarget(
                mirror,
                names = listOf("a.code-workspace", "b.code-workspace"),
                isFile = { true },
            ),
            "picking one of them would be a guess, and the wrong guess is worse than " +
                "the folder the user actually chose: the explorer still shows both, so " +
                "opening either is one tap away",
        )
    }

    @Test
    fun `a directory named like a workspace is not opened as one`() {
        assertEquals(
            mirror,
            folderOpenTarget(
                mirror,
                names = listOf("odd.code-workspace"),
                isFile = { false },
            ),
            "a `.code-workspace` that is a directory would navigate the workbench to a " +
                "workspace URL it cannot resolve, and the workbench answers an " +
                "unreadable workspace with an empty window and no message",
        )
    }
}
