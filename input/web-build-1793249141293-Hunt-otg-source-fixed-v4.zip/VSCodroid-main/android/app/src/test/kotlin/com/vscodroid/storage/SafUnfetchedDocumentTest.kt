package com.vscodroid.storage

import android.content.ContentResolver
import android.content.Context
import android.database.Cursor
import android.os.FileObserver
import android.os.SystemClock
import android.net.Uri
import android.provider.DocumentsContract
import com.vscodroid.util.Logger
import io.mockk.Runs
import io.mockk.every
import io.mockk.just
import io.mockk.mockk
import io.mockk.mockkObject
import io.mockk.mockkStatic
import io.mockk.unmockkAll
import io.mockk.verify
import kotlinx.coroutines.runBlocking
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * What happens to a device document the sync could not read, when a local file
 * of that name appears afterwards.
 *
 * The sync leaves no trace of a document it skipped, so "absent from the mirror"
 * carries two meanings at once: not on the device, and on the device holding
 * content this app has never seen. Every write-back path used to resolve that
 * the destructive way, and by design rather than by accident: `createOneInSaf`
 * exists precisely to write into an existing document rather than fork it, so
 * the write opens the device's file with truncation. A 60 MB archive skipped for
 * size became whatever the user typed into a new file of that name, and nothing
 * on screen or in a release logcat said so, because the skip was logged at debug.
 *
 * A running watcher is required for any of this, so it does its damage in the
 * sessions the picker opened, which is the opposite population from the folders
 * the workbench opens for itself.
 */
class SafUnfetchedDocumentTest {

    @TempDir
    lateinit var mirror: File

    @TempDir
    lateinit var filesDir: File

    private lateinit var resolver: ContentResolver
    private lateinit var context: Context
    private lateinit var engine: SafSyncEngine
    private lateinit var treeUri: Uri
    private val uris = mutableMapOf<String, Uri>()
    private val renamedDirectoryNames = mutableMapOf<String, String>()

    @BeforeEach
    fun setUp() {
        mockkObject(Logger)
        every { Logger.i(any(), any()) } just Runs
        every { Logger.d(any(), any()) } just Runs
        every { Logger.w(any(), any()) } just Runs
        every { Logger.w(any(), any(), any()) } just Runs
        every { Logger.e(any(), any()) } just Runs
        every { Logger.e(any(), any(), any()) } just Runs

        mockkStatic(DocumentsContract::class)
        every { DocumentsContract.getTreeDocumentId(any()) } returns "root"
        every { DocumentsContract.buildChildDocumentsUriUsingTree(any(), any()) } returns
            mockk(relaxed = true)
        every { DocumentsContract.buildDocumentUriUsingTree(any(), any()) } answers {
            uris.getOrPut(secondArg()) { mockk(relaxed = true) }
        }
        every { DocumentsContract.getDocumentId(any()) } answers {
            uris.entries.first { it.value === firstArg<Uri>() }.key
        }
        // Needed by the control that uploads a genuinely new file: without it the
        // static answers null, no document exists to write into, and the case
        // would pass by doing nothing, which is the failure it is here to exclude.
        every { DocumentsContract.createDocument(any(), any(), any(), any()) } answers {
            uris.getOrPut("doc:" + lastArg<String>()) { mockk(relaxed = true) }
        }
        // Needed by the directory cases: a mocked static with no answer throws, and
        // `deleteFromSaf` swallows the throw, so a control asserting the delete went
        // through would be asserting on a call that never completed.
        every { DocumentsContract.deleteDocument(any(), any()) } returns true
        every { DocumentsContract.renameDocument(any(), any(), any()) } answers {
            val name = thirdArg<String>()
            val id = "doc:$name"
            renamedDirectoryNames[id] = name
            uris.getOrPut(id) { mockk(relaxed = true) }
        }

        resolver = mockk(relaxed = true)
        context = mockk<Context>(relaxed = true)
        every { context.contentResolver } returns resolver
        every { context.filesDir } returns filesDir
        engine = SafSyncEngine(context)
        treeUri = mockk(relaxed = true)
    }

    @AfterEach
    fun tearDown() {
        File(mirror.path + SafSyncEngine.SYNCED_RECORD_SUFFIX).delete()
        unmockkAll()
    }

    /**
     * One file in the device folder, described through a fake cursor. [size]
     * decides whether the sync fetches it; [readable] decides whether the fetch
     * succeeds.
     */
    private fun deviceHolding(name: String, size: Long, readable: Boolean = true) {
        val cursor = mockk<Cursor>(relaxed = true)
        var row = -1
        every { cursor.moveToNext() } answers { ++row == 0 }
        every { cursor.getColumnIndexOrThrow(any()) } answers {
            when (firstArg<String>()) {
                DocumentsContract.Document.COLUMN_DOCUMENT_ID -> 0
                DocumentsContract.Document.COLUMN_DISPLAY_NAME -> 1
                DocumentsContract.Document.COLUMN_MIME_TYPE -> 2
                else -> 3
            }
        }
        every { cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED) } returns 4
        every { cursor.isNull(any()) } returns false
        every { cursor.getString(0) } returns "doc:$name"
        every { cursor.getString(1) } returns name
        every { cursor.getString(2) } returns "text/plain"
        every { cursor.getLong(3) } returns size
        every { cursor.getLong(4) } returns 1_700_000_000_000
        every { resolver.query(any(), any(), any(), any(), any()) } answers {
            row = -1
            cursor
        }
        every { resolver.openInputStream(any()) } answers {
            if (readable) ByteArrayInputStream("device contents".toByteArray())
            else throw IOException("the provider refused the read")
        }
    }

    /** One event, and the write-back thread's pass over what it queued. */
    private fun deliver(event: Int, entry: String) {
        engine.handleMirrorEvent(event, File(mirror, entry), mirror, treeUri)
        engine.runWriteBackLoop { false }
    }

    /** inotify's "the entry this event is about is a directory", as the kernel sends it. */
    private val isDirFlag = 0x40000000

    /** One entry as the provider lists it. */
    private data class Entry(
        val name: String,
        val size: Long = 15,
        val isDirectory: Boolean = false,
    )

    /**
     * A device folder with structure, for the cases that turn on where a document is.
     *
     * [deviceHolding] answers the same one row under every parent, which cannot
     * describe a directory holding a file: the walk would find the file again inside
     * itself, for ever. [tree] maps a parent's document id to the entries directly
     * under it, with `root` as the tree's own. Every file reads as the same short
     * contents, and only ones under [SafSyncEngine.MAX_FILE_SIZE] are ever read.
     */
    private fun deviceTree(tree: Map<String, List<Entry>>, unenumerable: Set<String> = emptySet()) {
        every { DocumentsContract.buildChildDocumentsUriUsingTree(any(), any()) } answers {
            val parent = secondArg<String>()
            mockk<Uri>(relaxed = true).also { every { it.toString() } returns "children:$parent" }
        }
        every { resolver.query(any(), any(), any(), any(), any()) } answers {
            val queried = firstArg<Uri>()
            val documentId = uris.entries.firstOrNull { it.value === queried }?.key
            if (documentId != null) {
                val entry = renamedDirectoryNames[documentId]?.let { Entry(it, isDirectory = true) }
                    ?: tree.values.flatten().firstOrNull { "doc:${it.name}" == documentId }
                return@answers cursorOver(listOfNotNull(entry))
            }
            val parent = queried.toString().removePrefix("children:")
            // A parent the provider answers for and then will not list: a cloud or SMB
            // provider momentarily offline, or an MTP bridge hiccup. The walk carries
            // on from it, which is what leaves the directory in the mirror empty.
            if (parent in unenumerable) throw IllegalStateException("cannot list $parent")
            cursorOver(tree[parent].orEmpty())
        }
        every { resolver.openInputStream(any()) } answers {
            ByteArrayInputStream("device contents".toByteArray())
        }
    }

    private fun cursorOver(entries: List<Entry>): Cursor {
        var row = -1
        return mockk<Cursor>(relaxed = true) {
            every { moveToNext() } answers { ++row < entries.size }
            every { moveToFirst() } answers { row = 0; entries.isNotEmpty() }
            every { getColumnIndex(any()) } answers {
                when (firstArg<String>()) {
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID -> 0
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME -> 1
                    DocumentsContract.Document.COLUMN_MIME_TYPE -> 2
                    DocumentsContract.Document.COLUMN_SIZE -> 3
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED -> 4
                    else -> -1
                }
            }
            every { getColumnIndexOrThrow(any()) } answers {
                when (firstArg<String>()) {
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID -> 0
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME -> 1
                    DocumentsContract.Document.COLUMN_MIME_TYPE -> 2
                    else -> 3
                }
            }
            every { getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED) } returns 4
            every { isNull(any<Int>()) } returns false
            every { getString(0) } answers { "doc:${entries[row].name}" }
            every { getString(1) } answers { entries[row].name }
            every { getString(2) } answers {
                if (entries[row].isDirectory) DocumentsContract.Document.MIME_TYPE_DIR
                else "text/plain"
            }
            every { getLong(3) } answers { entries[row].size }
            every { getLong(4) } returns 1_700_000_000_000
        }
    }

    /** A `docs` directory whose only document is one the sync will not read. */
    private val docsHoldingUnread = mapOf(
        "root" to listOf(Entry("docs", isDirectory = true)),
        "doc:docs" to listOf(Entry("big.zip", size = SafSyncEngine.MAX_FILE_SIZE + 1)),
    )

    /**
     * Deleting a directory in the editor, as inotify reports it: the mirror entry is
     * already gone when the event arrives, and the flag is the only thing left that
     * says it was a directory.
     */
    private fun deleteDirectory(relativePath: String) {
        File(mirror, relativePath).deleteRecursively()
        deliver(FileObserver.DELETE or isDirFlag, relativePath)
    }

    @Test
    fun `a save checking an old device stamp cannot cross a reopen that could not read the document`() {
        reopenAroundOutboundAdmission(FileObserver.MODIFY)
    }

    @Test
    fun `a queued delete cannot cross a reopen that could not read the document`() {
        reopenAroundOutboundAdmission(FileObserver.DELETE)
    }

    @Test
    fun `a reopen refuses while a create checks the existing document and succeeds afterwards`() {
        reopenAroundOutboundAdmission(FileObserver.CREATE)
    }

    @Test
    fun `a replacement engine reopening the mirror invalidates an older engine save`() {
        reopenAroundOutboundAdmission(FileObserver.MODIFY, replacementEngine = true)
    }

    @Test
    fun `a replacement engine reopening the mirror invalidates an older engine delete`() {
        reopenAroundOutboundAdmission(FileObserver.DELETE, replacementEngine = true)
    }

    @Test
    fun `opening another mirror leaves a valid save able to finish`() {
        reopenAroundOutboundAdmission(FileObserver.MODIFY, anotherMirror = true)
    }

    @Test
    fun `opening another mirror leaves a valid delete able to finish`() {
        reopenAroundOutboundAdmission(FileObserver.DELETE, anotherMirror = true)
    }

    private fun reopenAroundOutboundAdmission(
        event: Int,
        replacementEngine: Boolean = false,
        anotherMirror: Boolean = false,
    ) {
        val contents = AtomicReference("device contents")
        val modified = AtomicLong(1_700_000_000_000)
        val readable = AtomicBoolean(true)
        val exists = AtomicBoolean(true)
        val writes = AtomicInteger()
        val deletes = AtomicInteger()
        val failedReads = AtomicInteger()
        val reads = AtomicInteger()
        val outboundPaused = CountDownLatch(1)
        val releaseOutbound = CountDownLatch(1)
        val pauseNextStamp = AtomicBoolean(true)
        val failure = AtomicReference<Throwable?>()
        var outbound: Thread? = null
        deviceTree(mapOf("root" to listOf(Entry("notes.md"))))
        every { resolver.query(any(), any(), any(), any(), any()) } answers {
            val document = firstArg<Uri>() === uris["doc:notes.md"]
            val stamp = modified.get()
            val size = contents.get().toByteArray().size.toLong()
            if (document) {
                // A provider cursor is a snapshot, even if its binder call returns later.
                if (Thread.currentThread() === outbound && pauseNextStamp.compareAndSet(true, false)) {
                    outboundPaused.countDown()
                    check(releaseOutbound.await(10, TimeUnit.SECONDS)) { "the outbound checkpoint was not released" }
                }
                mockk<Cursor>(relaxed = true) {
                    every { moveToFirst() } returns true
                    every { getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED) } returns 0
                    every { getColumnIndex(DocumentsContract.Document.COLUMN_SIZE) } returns 1
                    every { isNull(any<Int>()) } returns false
                    every { getLong(0) } returns stamp
                    every { getLong(1) } returns size
                }
            } else {
                cursorOver(if (exists.get()) listOf(Entry("notes.md", size)) else emptyList()).also {
                    every { it.getLong(4) } returns stamp
                }
            }
        }
        every { resolver.openInputStream(any()) } answers {
            reads.incrementAndGet()
            if (!readable.get()) {
                failedReads.incrementAndGet()
                throw IOException("the provider refused the read")
            }
            ByteArrayInputStream(contents.get().toByteArray())
        }
        every { resolver.openOutputStream(any(), "wt") } answers {
            writes.incrementAndGet()
            contents.set("")
            object : ByteArrayOutputStream() {
                override fun close() {
                    contents.set(toString("UTF-8"))
                    super.close()
                }
            }
        }
        every { DocumentsContract.deleteDocument(any(), any()) } answers {
            deletes.incrementAndGet()
            exists.set(false)
            true
        }
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        val local = File(mirror, "notes.md")
        assertEquals("device contents", local.readText())
        if (event == FileObserver.DELETE) assertTrue(local.delete())
        else local.writeText("saved in the editor")
        engine.handleMirrorEvent(event, local, mirror, treeUri)
        val drain = Thread {
            try {
                if (event == FileObserver.DELETE) {
                    // DELETE proves bytes inside admission, so reopen before the queued job starts.
                    outboundPaused.countDown()
                    check(releaseOutbound.await(10, TimeUnit.SECONDS)) { "the queued delete was not released" }
                }
                engine.runWriteBackLoop { false }
            } catch (error: Throwable) {
                failure.set(error)
            }
        }
        outbound = drain
        val openingEngine = if (replacementEngine) SafSyncEngine(context) else engine
        val openingMirror = if (anotherMirror) File(filesDir, "other-mirror").apply { mkdirs() } else mirror
        val admittedCreate = event == FileObserver.CREATE && !anotherMirror
        var readsBeforeRelease = 0
        drain.start()
        try {
            assertTrue(outboundPaused.await(5, TimeUnit.SECONDS), "the outbound job never reached its checkpoint")
            if (admittedCreate) {
                val error = runCatching {
                    runBlocking { openingEngine.initialSync(treeUri, openingMirror) { _, _ -> } }
                }.exceptionOrNull()
                assertTrue(error is FolderBusyException, "the admitted create did not keep the mirror busy: $error")
                assertEquals("saved in the editor", local.readText(), "the busy open changed the mirror")
                assertEquals("device contents", contents.get())
                assertEquals(0, writes.get())
                assertEquals(0, deletes.get())
            } else {
                if (!anotherMirror) {
                    contents.set("changed by another app")
                    modified.set(System.currentTimeMillis() + 60_000)
                    readable.set(false)
                }
                runBlocking { openingEngine.initialSync(treeUri, openingMirror) { _, _ -> } }
                if (anotherMirror) assertEquals("device contents", File(openingMirror, "notes.md").readText())
                else assertTrue(failedReads.get() > 0, "the reopen did not try to read the changed document")
            }
            readsBeforeRelease = reads.get()
        } finally {
            releaseOutbound.countDown()
            drain.join(5_000)
        }
        assertFalse(drain.isAlive, "the outbound job did not finish after its provider call returned")
        failure.get()?.let { throw AssertionError("the outbound job failed", it) }
        if (admittedCreate) {
            assertTrue(exists.get())
            assertEquals("saved in the editor", contents.get())
            assertEquals(1, writes.get())
            assertEquals(0, deletes.get())
            verify(exactly = 0) { DocumentsContract.createDocument(any(), any(), any(), any()) }

            contents.set("changed by another app")
            modified.set(System.currentTimeMillis() + 60_000)
            readable.set(false)
            runBlocking { openingEngine.initialSync(treeUri, openingMirror) { _, _ -> } }

            assertTrue(failedReads.get() > 0, "the later reopen did not try to read the changed document")
            assertTrue(exists.get())
            assertEquals("changed by another app", contents.get())
            assertEquals(1, writes.get(), "the later unreadable reopen replaced the device copy")
            assertEquals(0, deletes.get())
            return
        }
        if (event == FileObserver.DELETE) {
            assertEquals(
                readsBeforeRelease + if (anotherMirror) 1 else 0, reads.get(),
                "the delete did not respect generation admission and fresh byte proof",
            )
        }
        if (anotherMirror) {
            assertEquals(event != FileObserver.DELETE, exists.get(), "opening another mirror cancelled the valid delete")
            assertEquals(if (event == FileObserver.DELETE) "device contents" else "saved in the editor", contents.get())
            assertEquals(if (event == FileObserver.DELETE) 0 else 1, writes.get())
            assertEquals(if (event == FileObserver.DELETE) 1 else 0, deletes.get())
            return
        }
        assertTrue(exists.get(), "the queued delete removed a document the reopen could not read")
        assertEquals("changed by another app", contents.get(), "the queued save replaced unread device bytes")
        assertEquals(0, writes.get(), "the stale save opened the device document with truncation")
        assertEquals(0, deletes.get(), "the stale delete reached the provider")
    }

    @Test
    fun `a reopen refuses promptly while a provider write is admitted and succeeds after it finishes`() {
        reopenDuringOutboundMutation(FileObserver.MODIFY)
    }

    @Test
    fun `a reopen refuses promptly while a provider delete is admitted and succeeds after it finishes`() {
        reopenDuringOutboundMutation(FileObserver.DELETE)
    }

    private fun reopenDuringOutboundMutation(event: Int) {
        val contents = AtomicReference("device contents")
        val exists = AtomicBoolean(true)
        val writes = AtomicInteger()
        val deletes = AtomicInteger()
        val insideMutation = CountDownLatch(1)
        val releaseMutation = CountDownLatch(1)
        val reopenFinished = CountDownLatch(1)
        val drainFailure = AtomicReference<Throwable?>()
        val reopenFailure = AtomicReference<Throwable?>()
        deviceTree(mapOf("root" to listOf(Entry("notes.md"))))
        every { resolver.query(any(), any(), any(), any(), any()) } answers {
            cursorOver(if (exists.get()) listOf(Entry("notes.md", contents.get().toByteArray().size.toLong())) else emptyList())
        }
        every { resolver.openInputStream(any()) } answers { ByteArrayInputStream(contents.get().toByteArray()) }
        every { resolver.openOutputStream(any(), "wt") } answers {
            insideMutation.countDown()
            check(releaseMutation.await(10, TimeUnit.SECONDS)) { "the provider write was not released" }
            writes.incrementAndGet()
            contents.set("")
            object : ByteArrayOutputStream() {
                override fun close() {
                    contents.set(toString("UTF-8"))
                    super.close()
                }
            }
        }
        every { DocumentsContract.deleteDocument(any(), any()) } answers {
            insideMutation.countDown()
            check(releaseMutation.await(10, TimeUnit.SECONDS)) { "the provider delete was not released" }
            deletes.incrementAndGet()
            exists.set(false)
            true
        }
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        val local = File(mirror, "notes.md")
        assertEquals("device contents", local.readText())
        if (event == FileObserver.DELETE) assertTrue(local.delete())
        else local.writeText("saved in the editor")
        engine.handleMirrorEvent(event, local, mirror, treeUri)
        val drain = Thread {
            try {
                engine.runWriteBackLoop { false }
            } catch (error: Throwable) {
                drainFailure.set(error)
            }
        }
        val reopening = Thread {
            try {
                runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
            } catch (error: Throwable) {
                reopenFailure.set(error)
            } finally {
                reopenFinished.countDown()
            }
        }
        drain.start()
        try {
            assertTrue(insideMutation.await(5, TimeUnit.SECONDS), "the outbound job never entered its provider mutation")
            reopening.start()

            assertTrue(reopenFinished.await(5, TimeUnit.SECONDS), "the reopen waited for the blocked provider mutation")

            assertTrue(reopenFailure.get() is IOException, "the busy reopen did not report an IOException: ${reopenFailure.get()}")
            assertTrue(exists.get())
            assertEquals("device contents", contents.get())
        } finally {
            releaseMutation.countDown()
            drain.join(5_000)
            reopening.join(5_000)
        }
        assertFalse(drain.isAlive, "the provider mutation did not finish after being released")
        assertFalse(reopening.isAlive, "the reopen did not return")
        drainFailure.get()?.let { throw AssertionError("the outbound job failed", it) }
        assertEquals(event != FileObserver.DELETE, exists.get())
        assertEquals(if (event == FileObserver.DELETE) "device contents" else "saved in the editor", contents.get())
        assertEquals(if (event == FileObserver.DELETE) 0 else 1, writes.get())
        assertEquals(if (event == FileObserver.DELETE) 1 else 0, deletes.get())

        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        assertEquals(event != FileObserver.DELETE, exists.get(), "the completed mutation was not retained after reopening")
        assertEquals(if (event == FileObserver.DELETE) "device contents" else "saved in the editor", contents.get())
    }

    /**
     * The same skip, one level up. The document is never in the mirror, so the editor
     * shows its directory as empty; the user deletes the directory; and the delete
     * that reaches the device is `deleteDocument` on a directory document, which takes
     * the archive with it. The file guard tests the directory's own path, which no
     * skip ever records, so nothing stood in the way.
     */
    @Test
    fun `a null root listing protects a stale mirror file after the provider recovers`() {
        deviceHolding("notes.txt", 15)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        every { resolver.query(any(), any(), any(), any(), any()) } returns null
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        deviceHolding("notes.txt", 18)
        var device = "UNREAD DEVICE EDIT"
        every { resolver.openOutputStream(any(), "wt") } answers {
            object : ByteArrayOutputStream() {
                override fun close() { device = toString("UTF-8") }
            }
        }
        File(mirror, "notes.txt").writeText("NEW LOCAL EDIT")

        deliver(FileObserver.MODIFY, "notes.txt")

        assertEquals("UNREAD DEVICE EDIT", device)
    }

    @Test
    fun `a failed child listing protects saves below that directory`() {
        val tree = mapOf(
            "root" to listOf(Entry("docs", isDirectory = true)),
            "doc:docs" to listOf(Entry("notes.md")),
        )
        deviceTree(tree, unenumerable = setOf("doc:docs"))
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        deviceTree(tree)
        var device = "UNREAD DEVICE EDIT"
        every { resolver.openOutputStream(any(), "wt") } answers {
            object : ByteArrayOutputStream() {
                override fun close() { device = toString("UTF-8") }
            }
        }
        File(mirror, "docs/notes.md").writeText("NEW LOCAL EDIT")

        deliver(FileObserver.MODIFY, "docs/notes.md")

        assertEquals("UNREAD DEVICE EDIT", device)
    }

    @Test
    fun `a directory holding a document the sync never read is kept on the device`() {
        val kept = mutableListOf<String>()
        val asDirectory = mutableListOf<Boolean>()
        engine.onKeptOnDevice = { file, isDirectory, _ ->
            kept.add(file.name)
            asDirectory.add(isDirectory)
        }
        deviceTree(docsHoldingUnread)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        deleteDirectory("docs")

        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
        assertEquals(
            listOf("docs"),
            kept,
            "the directory was kept, or deleted, without the user being told which",
        )
        // The flag picks the sentence, and nothing downstream can recover it: the
        // entry is unlinked before the event arrives, so it cannot be stat'd.
        assertEquals(
            listOf(true),
            asDirectory,
            "the directory was announced with the wording for a single document, which " +
                "says the editor never had a copy of a folder",
        )
    }

    /**
     * The control that keeps the case above honest: a directory the sync read whole
     * is deleted on the device when it is deleted in the editor, and nothing is said.
     * A guard matching on anything other than a child of this directory fails here.
     */
    @Test
    fun `a directory the sync read whole is deleted from the device`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        deviceTree(
            mapOf(
                "root" to listOf(Entry("docs", isDirectory = true)),
                "doc:docs" to listOf(Entry("notes.md")),
            )
        )
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        deleteDirectory("docs")

        verify(exactly = 1) { DocumentsContract.deleteDocument(any(), uris.getValue("doc:docs")) }
        assertTrue(kept.isEmpty(), "a delete that went through was announced as kept: $kept")
    }

    /**
     * The same tree as the control above, opened with free space under the floor, so
     * `notes.md` is held back rather than copied. Held back has to mean guarded: the
     * editor shows `docs` empty, and deleting it must not take the document with it.
     */
    @Test
    fun `a directory whose documents were held back for space is kept on the device`() {
        engine.usableSpaceOf = { SafSyncEngine.OPEN_SPACE_FLOOR_BYTES - 1 }
        deviceTree(
            mapOf(
                "root" to listOf(Entry("docs", isDirectory = true)),
                "doc:docs" to listOf(Entry("notes.md")),
            )
        )
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        deleteDirectory("docs")

        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
    }

    /**
     * The same loss as a skipped directory, with no name to recognise it by. The
     * provider answered for `docs` itself and then refused to list what is under it,
     * so the walk carried on and the mirror holds an empty `docs` while the device
     * holds its documents. A skipped name is filtered out by [SafSyncEngine.shouldWriteBack]
     * before the guard ever runs; this one has an ordinary name and reaches it, so the
     * guard is the only thing standing between `rm -r docs` and the device's subtree.
     */
    @Test
    fun `a directory whose enumeration failed is kept on the device`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        deviceTree(
            mapOf(
                "root" to listOf(Entry("docs", isDirectory = true)),
                "doc:docs" to listOf(Entry("notes.md")),
            ),
            unenumerable = setOf("doc:docs"),
        )
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        deleteDirectory("docs")

        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
        assertEquals(
            listOf("docs"),
            kept,
            "a directory the sync could not read was deleted from the device, taking " +
                "documents the mirror never held",
        )
    }

    /** The unread document sits two levels down; the ancestor is still what holds it. */
    @Test
    fun `a directory is kept for a document the sync never read at any depth`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        deviceTree(
            mapOf(
                "root" to listOf(Entry("docs", isDirectory = true)),
                "doc:docs" to listOf(Entry("sub", isDirectory = true)),
                "doc:sub" to listOf(Entry("big.zip", size = SafSyncEngine.MAX_FILE_SIZE + 1)),
            )
        )
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        deleteDirectory("docs")

        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
        assertEquals(listOf("docs"), kept, "a nested unread document did not keep its ancestor")
    }

    /**
     * `docs` is a prefix of `docs2` as a string and not as a path. A guard comparing
     * without the separator would keep `docs` for a document that lives under `docs2`,
     * and the user would be told their empty directory holds files.
     */
    @Test
    fun `a sibling whose name merely starts the same does not keep the directory`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        deviceTree(
            mapOf(
                "root" to listOf(
                    Entry("docs", isDirectory = true),
                    Entry("docs2", isDirectory = true),
                ),
                "doc:docs" to listOf(Entry("notes.md")),
                "doc:docs2" to listOf(Entry("big.zip", size = SafSyncEngine.MAX_FILE_SIZE + 1)),
            )
        )
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        deleteDirectory("docs")

        verify(exactly = 1) { DocumentsContract.deleteDocument(any(), uris.getValue("doc:docs")) }
        assertTrue(kept.isEmpty(), "docs was kept for a document under docs2: $kept")
    }

    /**
     * The set is a memory of what this sync could not read, not a fact about the
     * device. When the directory is no longer there, there is nothing to keep, and the
     * no provider delete or kept-content notice is needed.
     */
    @Test
    fun `a directory the device no longer holds is not kept`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        deviceTree(docsHoldingUnread)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        // The directory, archive and all, was deleted on the device between the sync
        // and the event.
        deviceTree(mapOf("root" to emptyList()))
        deleteDirectory("docs")

        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
        assertTrue(
            kept.isEmpty(),
            "a directory the device had already lost was announced as kept: $kept",
        )
    }

    /**
     * A rename arrives as a MOVED_FROM and a MOVED_TO, and the first half is a delete
     * to everything but the pairing. A directory with an unread document in it has to
     * keep renaming as one provider move, because that move is the one path that
     * carries the document to the new name; a guard that refused the MOVED_FROM would
     * leave the pair unclaimed, the new name built from a mirror that never held the
     * document, and the old name standing on the device with it.
     */
    @Test
    fun `renaming a directory that holds a document the sync never read still renames it`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        deviceTree(docsHoldingUnread)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        engine.handleMirrorEvent(
            FileObserver.MOVED_FROM or isDirFlag, File(mirror, "docs"), mirror, treeUri
        )
        deliver(FileObserver.MOVED_TO or isDirFlag, "archive")

        verify(exactly = 1) {
            DocumentsContract.renameDocument(any(), uris.getValue("doc:docs"), "archive")
        }
        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
        assertTrue(kept.isEmpty(), "half of a rename was announced as a kept directory: $kept")
    }

    /**
     * A claimed rename moves the unread document to the new name on the device, so the
     * memory of it has to move too: kept at the old path, the guard stopped answering
     * for the directory the moment it was renamed, and `rm -r` on the new name sent the
     * archive to `deleteDocument`.
     */
    @Test
    fun `a renamed directory still keeps the document the sync never read`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        deviceTree(docsHoldingUnread)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        engine.handleMirrorEvent(
            FileObserver.MOVED_FROM or isDirFlag, File(mirror, "docs"), mirror, treeUri
        )
        deliver(FileObserver.MOVED_TO or isDirFlag, "archive")
        // The device now lists the archive under its new name.
        deviceTree(
            mapOf(
                "root" to listOf(Entry("archive", isDirectory = true)),
                "doc:archive" to listOf(Entry("big.zip", size = SafSyncEngine.MAX_FILE_SIZE + 1)),
            )
        )

        deleteDirectory("archive")

        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
        assertEquals(listOf("archive"), kept, "the rename left the unread memory at the old name")
    }

    /** `docs` holding one file the sync reads whole. */
    private val docsHoldingNotes = mapOf(
        "root" to listOf(Entry("docs", isDirectory = true)),
        "doc:docs" to listOf(Entry("notes.md")),
    )

    /**
     * Another app's edit of the document [id] since the sync read it: asked about alone, it
     * reports a later time, and a read gives other bytes than the sync fetched.
     */
    private fun changedByAnotherApp(id: String) {
        val document = uris.getValue(id)
        every { resolver.query(document, any(), any(), any(), any()) } answers {
            mockk<Cursor>(relaxed = true) {
                every { moveToFirst() } returns true
                every { getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED) } returns 0
                every { getColumnIndex(DocumentsContract.Document.COLUMN_SIZE) } returns 1
                every { isNull(any<Int>()) } returns false
                every { getLong(0) } returns 1_700_000_060_000
                every { getLong(1) } returns 22
            }
        }
        every { resolver.openInputStream(document) } answers {
            ByteArrayInputStream("changed by another app".toByteArray())
        }
    }

    /**
     * A directory delete the closing folder's drain sends after a reopen, its queue having
     * outlived the stop behind a slow provider. The reopen could not read what the directory
     * holds. The queued delete belongs to the earlier generation, so it is declined before
     * consulting the reopened folder's memory and announced as a changed device copy.
     */
    @Test
    fun `a directory delete sent after a reopen that could not read what it holds is declined`() {
        val kept = mutableListOf<Triple<String, Boolean, Boolean>>()
        engine.onKeptOnDevice = { file, isDirectory, changed -> kept.add(Triple(file.name, isDirectory, changed)) }
        deviceTree(docsHoldingNotes)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        File(mirror, "docs").deleteRecursively()
        engine.handleMirrorEvent(FileObserver.DELETE or isDirFlag, File(mirror, "docs"), mirror, treeUri)
        every { resolver.openInputStream(any()) } throws IOException("the provider refused the read")
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        engine.runWriteBackLoop { false }

        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
        assertEquals(
            listOf(Triple("docs", true, true)), kept,
            "the stale delete must not describe the reopened generation's unread state as its own",
        )
    }

    /**
     * `rm -r docs` after another app changed `docs/notes.md` while the folder was open. The
     * file's delete is declined, and the directory's, sent right after it, took the file
     * anyway: `deleteDocument` on a directory takes whatever it still holds.
     */
    @Test
    fun `a directory holding a file whose delete was declined is kept on the device`() {
        val kept = mutableListOf<Triple<String, Boolean, Boolean>>()
        engine.onKeptOnDevice = { file, isDirectory, changed -> kept.add(Triple(file.name, isDirectory, changed)) }
        deviceTree(docsHoldingNotes)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        changedByAnotherApp("doc:notes.md")
        File(mirror, "docs").deleteRecursively()

        // In the order `rm -r` reports them, both queued before either is sent.
        engine.handleMirrorEvent(FileObserver.DELETE, File(mirror, "docs/notes.md"), mirror, treeUri)
        engine.handleMirrorEvent(FileObserver.DELETE or isDirFlag, File(mirror, "docs"), mirror, treeUri)
        engine.runWriteBackLoop { false }

        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
        // Both said as a change on the device: the editor had the file, so "the editor never
        // had a copy of it" and "files that were never copied into the editor" are false here.
        assertEquals(listOf(Triple("notes.md", false, true), Triple("docs", true, true)), kept)
    }

    /** What a declined delete left follows its directory's rename, as the unread memory does. */
    @Test
    fun `a renamed directory still keeps a file whose delete was declined`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        deviceTree(docsHoldingNotes)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        changedByAnotherApp("doc:notes.md")
        File(mirror, "docs/notes.md").delete()
        deliver(FileObserver.DELETE, "docs/notes.md")
        assertEquals(listOf("notes.md"), kept, "setup: the file's delete went through")
        engine.handleMirrorEvent(
            FileObserver.MOVED_FROM or isDirFlag, File(mirror, "docs"), mirror, treeUri
        )
        deliver(FileObserver.MOVED_TO or isDirFlag, "archive")
        deviceTree(
            mapOf(
                "root" to listOf(Entry("archive", isDirectory = true)),
                "doc:archive" to listOf(Entry("notes.md")),
            )
        )
        kept.clear()

        deleteDirectory("archive")

        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
        assertEquals(listOf("archive"), kept, "the rename left the declined file's memory at the old name")
    }

    /**
     * `mv [from] [to]` in the editor, as the observer reports it: the old name leaves, the
     * new one arrives, and the write-back that renames the device's own document runs.
     *
     * The new name is not on disk while its event is delivered, because a directory that
     * exists is watched through a `FileObserver`, which a JVM test cannot build; the move
     * on disk follows, for the cases that go on to save into the directory.
     */
    private fun renameDirectory(from: String, to: String) {
        engine.handleMirrorEvent(FileObserver.MOVED_FROM or isDirFlag, File(mirror, from), mirror, treeUri)
        engine.handleMirrorEvent(FileObserver.MOVED_TO or isDirFlag, File(mirror, to), mirror, treeUri)
        assertTrue(File(mirror, from).renameTo(File(mirror, to)))
        engine.runWriteBackLoop { false }
    }

    /**
     * `docs`, which the rename cases move, beside `docs2`, whose name starts the same as
     * text and is not below it as a path. Each holds one file by a name of its own, because
     * a document id here is its name.
     */
    private val docsBesideDocs2 = mapOf(
        "root" to listOf(Entry("docs", isDirectory = true), Entry("docs2", isDirectory = true)),
        "doc:docs" to listOf(Entry("notes.md")),
        "doc:docs2" to listOf(Entry("other.md")),
    )

    /** The same device folder once `docs` has been renamed to `archive` on it. */
    private val archiveBesideDocs2 = mapOf(
        "root" to listOf(Entry("archive", isDirectory = true), Entry("docs2", isDirectory = true)),
        "doc:archive" to listOf(Entry("notes.md")),
        "doc:docs2" to listOf(Entry("other.md")),
    )

    /** The `.device-` copies in [directory] of the mirror, by name, with what each holds. */
    private fun deviceCopiesIn(directory: String): List<String> =
        File(mirror, directory).listFiles()!!
            .filter { it.name.contains(SafSyncEngine.DEVICE_COPY_SUFFIX) }
            .map { it.readText() }

    /**
     * What the device last reported for each document is what the guard on a save asks
     * about another app's edit, and it is kept by mirror path. A path with no entry fails
     * open, so a file below a renamed directory was saved over a newer device copy with no
     * copy of it kept, until the next open filled the entry in again.
     *
     * The sibling beside it is the other half: its name begins with the renamed one's, and
     * an entry moved because of that would leave its own file unguarded instead.
     */
    @Test
    fun `a file below a renamed directory still keeps another app's edit when it is saved`() {
        deviceTree(docsBesideDocs2)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        renameDirectory("docs", "archive")
        deviceTree(archiveBesideDocs2)
        changedByAnotherApp("doc:notes.md")
        changedByAnotherApp("doc:other.md")

        File(mirror, "archive/notes.md").writeText("typed in the editor")
        deliver(FileObserver.MODIFY, "archive/notes.md")
        File(mirror, "docs2/other.md").writeText("typed in the editor too")
        deliver(FileObserver.MODIFY, "docs2/other.md")

        assertEquals(
            listOf("changed by another app"), deviceCopiesIn("archive"),
            "a save below the renamed directory went over another app's edit unguarded",
        )
        assertEquals(
            listOf("changed by another app"), deviceCopiesIn("docs2"),
            "a directory whose name only starts like the renamed one lost its guard",
        )
    }

    /** The same entry for a delete, which declines rather than keeps a copy. */
    @Test
    fun `a file below a renamed directory is still kept on the device when another app changed it`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        deviceTree(docsBesideDocs2)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        renameDirectory("docs", "archive")
        deviceTree(archiveBesideDocs2)
        changedByAnotherApp("doc:notes.md")
        changedByAnotherApp("doc:other.md")

        File(mirror, "archive/notes.md").delete()
        deliver(FileObserver.DELETE, "archive/notes.md")
        File(mirror, "docs2/other.md").delete()
        deliver(FileObserver.DELETE, "docs2/other.md")

        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
        assertEquals(
            listOf("notes.md", "other.md"), kept,
            "a delete went over another app's edit of a file below a renamed directory, or " +
                "of one below a directory whose name only starts like it",
        )
    }

    /**
     * The unread documents of a directory, and of a sibling whose name starts the same:
     * both are kept on the device when deleted after the rename, which fails for the
     * sibling if the match is by text rather than by path.
     */
    @Test
    fun `a renamed directory keeps its unread documents and not a sibling's by name alone`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        val unread = SafSyncEngine.MAX_FILE_SIZE + 1
        deviceTree(
            mapOf(
                "root" to listOf(Entry("docs", isDirectory = true), Entry("docs2", isDirectory = true)),
                "doc:docs" to listOf(Entry("big.zip", size = unread)),
                "doc:docs2" to listOf(Entry("big2.zip", size = unread)),
            )
        )
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        renameDirectory("docs", "archive")
        deviceTree(
            mapOf(
                "root" to listOf(Entry("archive", isDirectory = true), Entry("docs2", isDirectory = true)),
                "doc:archive" to listOf(Entry("big.zip", size = unread)),
                "doc:docs2" to listOf(Entry("big2.zip", size = unread)),
            )
        )

        deleteDirectory("archive")
        deleteDirectory("docs2")

        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
        assertEquals(listOf("archive", "docs2"), kept)
    }

    /**
     * The files whose delete was declined, below a renamed directory and below a sibling
     * whose name starts the same: `rm -r` of either is kept on the device after the
     * rename, which fails for the sibling if the match is by text rather than by path.
     */
    @Test
    fun `a renamed directory keeps its declined deletes and not a sibling's by name alone`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        deviceTree(docsBesideDocs2)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        changedByAnotherApp("doc:notes.md")
        changedByAnotherApp("doc:other.md")
        File(mirror, "docs/notes.md").delete()
        deliver(FileObserver.DELETE, "docs/notes.md")
        File(mirror, "docs2/other.md").delete()
        deliver(FileObserver.DELETE, "docs2/other.md")
        assertEquals(listOf("notes.md", "other.md"), kept, "setup: the deletes went through")
        renameDirectory("docs", "archive")
        deviceTree(archiveBesideDocs2)
        kept.clear()

        deleteDirectory("archive")
        deleteDirectory("docs2")

        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
        assertEquals(listOf("archive", "docs2"), kept)
    }

    /**
     * A directory the open could not enumerate is recorded by its own path, since nothing
     * below it was read to be recorded. The memory followed only what lay below the
     * renamed path, so the directory's own entry stayed at the old name and `rm -r` of the
     * new one sent `deleteDocument` for documents the editor never had.
     */
    @Test
    fun `a renamed directory whose enumeration failed is still kept on the device`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        deviceTree(docsHoldingNotes, unenumerable = setOf("doc:docs"))
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        renameDirectory("docs", "archive")
        deviceTree(
            mapOf(
                "root" to listOf(Entry("archive", isDirectory = true)),
                "doc:archive" to listOf(Entry("notes.md")),
            )
        )

        deleteDirectory("archive")

        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
        assertEquals(listOf("archive"), kept, "the rename left the directory's own entry at the old name")
    }

    /**
     * A save held back names its document by the URI it had, which on a provider whose ids
     * are paths is dead once the directory is renamed, or is whatever is made at the old
     * path next. It ends with the rename, so no try is made at the old path or at the new,
     * and the file waits for its next save, which its entry now guards.
     *
     * The old path is made again, because that is where a hold left behind would be tried:
     * one left at a path nothing is at is dropped by the next try anyway. The sibling's
     * hold is the control, and it is tried.
     */
    @Test
    fun `a save held back below a renamed directory ends there and a sibling's does not`() {
        var clock = 0L
        mockkStatic(SystemClock::class)
        every { SystemClock.elapsedRealtime() } answers { clock }
        val lost = mutableListOf<String>()
        engine.onWriteBackFailed = { lost.add(it.name) }
        deviceTree(docsBesideDocs2)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        // A set-aside needs a fetch, which the floor refuses: another app's edit that cannot
        // be kept holds the save back.
        engine.usableSpaceOf = { SafSyncEngine.OPEN_SPACE_FLOOR_BYTES - 1 }
        changedByAnotherApp("doc:notes.md")
        changedByAnotherApp("doc:other.md")
        File(mirror, "docs/notes.md").writeText("typed in the editor")
        deliver(FileObserver.MODIFY, "docs/notes.md")
        File(mirror, "docs2/other.md").writeText("typed in the editor too")
        deliver(FileObserver.MODIFY, "docs2/other.md")
        assertEquals(listOf("notes.md", "other.md"), lost, "setup: the saves were not held back")
        renameDirectory("docs", "archive")
        File(mirror, "docs").mkdirs()
        File(mirror, "docs/notes.md").writeText("made again at the old name")
        clock += SafSyncEngine.HELD_BACK_RETRY_FIRST_MS
        val watching = WatchSession(mirror)

        // One try per call, and one that is made puts its hold back with a longer wait.
        var tried = 0
        while (tried < 5 && engine.retryHeldBack(watching)) tried++

        assertEquals(
            1, tried,
            "a save held back below the renamed directory was tried, at the old name or the new",
        )
    }

    /**
     * What the user guide says of a held save whose directory is renamed: the trying ends,
     * and the file's next save keeps the other app's version beside it, which the entry
     * that moved with the rename still asks about. The floor is lifted by then, so the
     * other app's version can be copied.
     */
    @Test
    fun `the next save of a file whose held save ended with a rename keeps the other app's version`() {
        var clock = 0L
        mockkStatic(SystemClock::class)
        every { SystemClock.elapsedRealtime() } answers { clock }
        deviceTree(docsBesideDocs2)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        engine.usableSpaceOf = { SafSyncEngine.OPEN_SPACE_FLOOR_BYTES - 1 }
        changedByAnotherApp("doc:notes.md")
        File(mirror, "docs/notes.md").writeText("typed in the editor")
        deliver(FileObserver.MODIFY, "docs/notes.md")
        renameDirectory("docs", "archive")
        deviceTree(archiveBesideDocs2)
        changedByAnotherApp("doc:notes.md")
        engine.usableSpaceOf = { Long.MAX_VALUE }
        clock += SafSyncEngine.HELD_BACK_RETRY_FIRST_MS
        assertFalse(engine.retryHeldBack(WatchSession(mirror)), "setup: a held save was tried")

        File(mirror, "archive/notes.md").writeText("typed again in the editor")
        deliver(FileObserver.MODIFY, "archive/notes.md")

        assertEquals(
            listOf("changed by another app"), deviceCopiesIn("archive"),
            "the save after the rename went over another app's version with no copy kept",
        )
    }

    /**
     * What a declined delete left belongs to the open it was declined in, as the unread
     * memory does: the next open reads the file again, and `rm -r` of its directory then
     * goes through.
     */
    @Test
    fun `a reopen forgets a file whose delete was declined`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        deviceTree(docsHoldingNotes)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        changedByAnotherApp("doc:notes.md")
        File(mirror, "docs/notes.md").delete()
        deliver(FileObserver.DELETE, "docs/notes.md")
        assertEquals(listOf("notes.md"), kept, "setup: the file's delete went through")
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        kept.clear()

        deleteDirectory("docs")

        verify(exactly = 1) { DocumentsContract.deleteDocument(any(), uris.getValue("doc:docs")) }
        assertEquals(emptyList<String>(), kept, "a delete declined before the reopen kept the directory")
    }

    /**
     * The file made again under the name of one whose delete was declined: its save keeps the
     * other app's version as a `.device-` copy and then lands, so nothing in the directory is
     * left that this app has not read, and `rm -r` of it goes through.
     */
    @Test
    fun `a directory is deleted once a file made again over a declined delete has landed`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        val remaining = docsHoldingNotes.toMutableMap()
        deviceTree(remaining)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        val notesUri = uris.getValue("doc:notes.md")
        var deviceContents = "changed by another app"
        remaining["doc:docs"] = listOf(Entry("notes.md", deviceContents.toByteArray().size.toLong()))
        every { resolver.openInputStream(notesUri) } answers {
            ByteArrayInputStream(deviceContents.toByteArray())
        }
        every { resolver.openOutputStream(notesUri, "wt") } answers {
            deviceContents = ""
            remaining["doc:docs"] = listOf(Entry("notes.md", 0))
            object : ByteArrayOutputStream() {
                override fun close() {
                    deviceContents = toString("UTF-8")
                    remaining["doc:docs"] = listOf(Entry("notes.md", size().toLong()))
                    super.close()
                }
            }
        }
        val notes = File(mirror, "docs/notes.md").apply { delete() }
        deliver(FileObserver.DELETE, "docs/notes.md")
        assertEquals(listOf("notes.md"), kept, "setup: the file's delete went through")
        notes.writeText("made again in the editor")
        deliver(FileObserver.CREATE, "docs/notes.md")
        assertEquals("made again in the editor", deviceContents, "setup: the recreated file did not land")
        assertEquals(listOf("changed by another app"), deviceCopiesIn("docs"))
        val gone = File(mirror, "docs").listFiles()!!.map { it.name }
        assertTrue(
            gone.any { it.startsWith("notes.md" + SafSyncEngine.DEVICE_COPY_SUFFIX) },
            "setup: the save kept no copy of the other app's version: $gone",
        )
        File(mirror, "docs").deleteRecursively()

        every { DocumentsContract.deleteDocument(any(), any()) } answers {
            val id = DocumentsContract.getDocumentId(secondArg())
            remaining.replaceAll { _, entries -> entries.filterNot { "doc:${it.name}" == id } }
            true
        }

        for (name in gone) {
            engine.handleMirrorEvent(FileObserver.DELETE, File(mirror, "docs/$name"), mirror, treeUri)
        }
        engine.handleMirrorEvent(FileObserver.DELETE or isDirFlag, File(mirror, "docs"), mirror, treeUri)
        engine.runWriteBackLoop { false }

        verify(exactly = 1) { DocumentsContract.deleteDocument(any(), uris.getValue("doc:notes.md")) }
        verify(exactly = 1) { DocumentsContract.deleteDocument(any(), uris.getValue("doc:docs")) }
        assertEquals(listOf("notes.md"), kept, "the directory was kept after its file had landed")
    }

    /**
     * A provider that cannot be asked is not a provider that said "gone". The delete is
     * `deleteDocument` on a subtree the set says holds an unread document, so an
     * unanswered lookup keeps; the cost of keeping wrongly is one stale directory.
     */
    @Test
    fun `a directory is kept when the provider cannot say whether it still holds it`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        deviceTree(docsHoldingUnread)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        every { resolver.query(any(), any(), any(), any(), any()) } throws
            IllegalStateException("the provider is gone")

        deleteDirectory("docs")

        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
        assertEquals(listOf("docs"), kept, "an unanswerable provider was read as \"gone\"")
    }

    /**
     * The same question one level down, where the answer used to be the opposite of
     * the truth. A document the sync could not read leaves the mirror without it and
     * its path in the set; the user deletes the name they can see in the editor; and
     * the delete has to be declined for the reason the directory above is declined,
     * because `deleteDocument` here takes the only copy of the document.
     *
     * What was wrong was not the refusal but the sentence. The guard that refuses
     * writes sat above the event type and answered for the delete as well, so the
     * user was told the only copy was inside VSCodroid at the moment the app held
     * none of it.
     */
    @Test
    fun `a document the sync never read is kept on the device when the editor deletes it`() {
        val kept = mutableListOf<String>()
        val asDirectory = mutableListOf<Boolean>()
        val asChanged = mutableListOf<Boolean>()
        val lost = mutableListOf<String>()
        engine.onKeptOnDevice = { file, isDirectory, changed ->
            kept.add(file.name)
            asDirectory.add(isDirectory)
            asChanged.add(changed)
        }
        engine.onWriteBackFailed = { lost.add(it.name) }
        deviceHolding("notes.md", size = 64, readable = false)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        deliver(FileObserver.DELETE, "notes.md")

        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
        assertEquals(
            listOf("notes.md"),
            kept,
            "the device document was kept without the user being told where their file is",
        )
        assertEquals(
            listOf(false),
            asDirectory,
            "a single document was announced in the wording for a directory, which tells " +
                "the user their file holds files",
        )
        assertEquals(
            listOf(false), asChanged,
            "a document the editor never had was announced as one another app changed",
        )
        assertTrue(
            lost.isEmpty(),
            "a document that is only on the device was announced as one only the app " +
                "holds, which sends the user looking in the wrong place: $lost",
        )
    }

    /**
     * The same rule the directory arm follows, and the reason this walk is the
     * three-state one: a provider that cannot be asked has not said "gone". Answering
     * "not held" for a failed lookup is right where the cost of being wrong is a
     * duplicate name, and wrong here, where it is `deleteDocument` on the one copy of
     * a document the editor never had.
     */
    @Test
    fun `a document is kept when the provider cannot say whether it still holds it`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        deviceHolding("notes.md", size = 64, readable = false)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        every { resolver.query(any(), any(), any(), any(), any()) } throws
            IllegalStateException("the provider is gone")

        deliver(FileObserver.DELETE, "notes.md")

        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
        assertEquals(listOf("notes.md"), kept, "an unanswerable provider was read as \"gone\"")
    }

    /**
     * The control that keeps the two cases above honest. A document the sync did read
     * is mirrored, so deleting it in the editor is a deletion of something the device
     * and the app both have, and it goes through as it always did. A guard widened past
     * the set fails here.
     */
    @Test
    fun `a document the sync did read is deleted from the device`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        deviceHolding("notes.md", size = 15)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        File(mirror, "notes.md").delete()
        deliver(FileObserver.DELETE, "notes.md")

        verify(exactly = 1) {
            DocumentsContract.deleteDocument(any(), uris.getValue("doc:notes.md"))
        }
        assertTrue(kept.isEmpty(), "a delete that went through was announced as kept: $kept")
    }

    /**
     * The other half of a delete, and the one the workbench is measured to send for a
     * directory: the entry is renamed away rather than unlinked. Both arrive as one
     * type here, so a guard reading the raw event instead of the type would let this
     * one through and take the document with it.
     */
    @Test
    fun `a document the sync never read is kept when it is moved away instead`() {
        val kept = mutableListOf<String>()
        val lost = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        engine.onWriteBackFailed = { lost.add(it.name) }
        deviceHolding("notes.md", size = 64, readable = false)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        deliver(FileObserver.MOVED_FROM, "notes.md")

        verify(exactly = 0) { DocumentsContract.deleteDocument(any(), any()) }
        assertEquals(
            listOf("notes.md"),
            kept,
            "a move away deleted the document the sync never read",
        )
        assertTrue(lost.isEmpty(), "the notice said the app holds the only copy: $lost")
    }

    /**
     * `notes.md` is a prefix of `notes.md.bak` as a string and not as a path. The
     * directory arm above matches by prefix because a directory holds what is under
     * it; a file has to match its own path exactly, or deleting a document the sync
     * read whole is refused because an unrelated backup beside it was skipped.
     */
    @Test
    fun `a neighbour whose name merely starts the same does not keep the document`() {
        val kept = mutableListOf<String>()
        engine.onKeptOnDevice = { file, _, _ -> kept.add(file.name) }
        deviceTree(
            mapOf(
                "root" to listOf(
                    Entry("notes.md"),
                    Entry("notes.md.bak", size = SafSyncEngine.MAX_FILE_SIZE + 1),
                ),
            )
        )
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        File(mirror, "notes.md").delete()
        deliver(FileObserver.DELETE, "notes.md")

        verify(exactly = 1) {
            DocumentsContract.deleteDocument(any(), uris.getValue("doc:notes.md"))
        }
        assertTrue(kept.isEmpty(), "notes.md was kept for a document named notes.md.bak: $kept")
    }

    /**
     * The device folder was emptied from another app, so the enumeration comes back
     * with nothing and [SafSyncEngine.reconcileDeletions] leaves the mirror standing.
     * Deleting one of those entries in the editor resolves to no document, which is not
     * a refusal: nothing on the device declined anything, and the notice's two clauses
     * are both false. It would tell the user the file comes back on the next open, when
     * the next enumeration is still empty, and send them to a file manager to delete a
     * file that is not there.
     */
    @Test
    fun `deleting a mirror entry the device never held is not announced as a refusal`() {
        val refused = mutableListOf<String>()
        engine.onDeleteRefused = { refused.add(it.name) }
        deviceTree(mapOf("root" to emptyList()))
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        File(mirror, "notes.md").writeText("only ever in the mirror")
        deliver(FileObserver.DELETE, "notes.md")

        assertTrue(
            refused.isEmpty(),
            "a deletion the device had nothing to refuse was reported as refused, with " +
                "instructions to go and delete a file that is not there: $refused",
        )
    }

    /**
     * The control for the case above, and the guarantee it must not cost. A provider
     * that cannot answer at all is not a provider that answered "gone": the document
     * may well still be there, so the warning still has to be said.
     */
    @Test
    fun `a delete is still announced when the device cannot say whether it holds the file`() {
        val refused = mutableListOf<String>()
        engine.onDeleteRefused = { refused.add(it.name) }
        // Nothing is walked, so nothing is cached and the delete has to resolve the
        // path live. The folder then stops answering, so the resolution comes back
        // empty for a reason that is not absence.
        deviceTree(mapOf("root" to emptyList()))
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        File(mirror, "notes.md").writeText("saved in the editor")
        every { resolver.query(any(), any(), any(), any(), any()) } throws
            IllegalStateException("the provider stopped answering")
        deliver(FileObserver.DELETE, "notes.md")

        assertEquals(
            listOf("notes.md"),
            refused,
            "a delete the device may still be holding went unannounced, so the file " +
                "stays on the device with nothing on screen saying so",
        )
    }

    /**
     * The refusal notice is a budget of one per path per folder open, and it belongs to
     * the write refusal, whose sentence is only ever said once for a file the editor
     * keeps saving. A delete spending it costs the save that comes after: the user
     * recreates the name, saves it, the write is refused because the device still holds
     * the document under it, and this time "the only copy is inside VSCodroid" is true
     * and urgent. Nothing said it, until the folder was closed and opened again.
     */
    @Test
    fun `a refused delete leaves the notice the next refused save needs`() {
        val lost = mutableListOf<String>()
        engine.onWriteBackFailed = { lost.add(it.name) }
        deviceHolding("notes.md", size = 64, readable = false)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        deliver(FileObserver.DELETE, "notes.md")
        assertTrue(lost.isEmpty(), "the delete announced a refusal of its own: $lost")

        File(mirror, "notes.md").writeText("typed again, in the editor")
        deliver(FileObserver.CREATE, "notes.md")

        assertEquals(
            listOf("notes.md"),
            lost,
            "the save that really did stay inside the app was silent, because the " +
                "delete before it had already spent the one notice for that path",
        )
    }

    /**
     * The case the guard exists for. The document is past [SafSyncEngine.MAX_FILE_SIZE],
     * so the sync never reads it and the mirror never holds it. A local file of
     * that name then arrives, and the write opens the device's document with
     * truncation.
     */
    @Test
    fun `a document too large to mirror is not replaced by a local file of that name`() {
        deviceHolding("big.zip", size = SafSyncEngine.MAX_FILE_SIZE + 1)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        File(mirror, "big.zip").writeText("stub")
        deliver(FileObserver.CREATE, "big.zip")

        verify(exactly = 0) { resolver.openOutputStream(any(), "wt") }
    }

    /** The same shape when the copy was attempted and failed rather than skipped. */
    @Test
    fun `a document whose copy failed is not replaced either`() {
        deviceHolding("notes.md", size = 64, readable = false)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        File(mirror, "notes.md").writeText("stub")
        deliver(FileObserver.CREATE, "notes.md")

        verify(exactly = 0) { resolver.openOutputStream(any(), "wt") }
    }

    /**
     * The control, and it is the one that keeps the two above from passing for
     * the wrong reason. A document the sync did read is mirrored, so a later edit
     * to the mirror is an edit to something this app has a copy of, and writing
     * it back is the whole point of the feature.
     */
    @Test
    fun `a document the sync did read is still written back`() {
        deviceHolding("notes.md", size = 15)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        File(mirror, "notes.md").writeText("edited in the editor")
        deliver(FileObserver.MODIFY, "notes.md")

        verify(atLeast = 1) { resolver.openOutputStream(any(), "wt") }
    }

    /**
     * The set is a memory of what this sync could not read, not a permanent
     * refusal. If the device no longer holds a document at that name, the local
     * file is an ordinary new file and belongs on the device.
     */
    @Test
    fun `a name the device no longer holds is uploaded normally`() {
        deviceHolding("big.zip", size = SafSyncEngine.MAX_FILE_SIZE + 1)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        // The device folder is now empty: the oversized document was deleted
        // there between the sync and the event.
        val empty = mockk<Cursor>(relaxed = true)
        every { empty.moveToNext() } returns false
        every { resolver.query(any(), any(), any(), any(), any()) } returns empty

        File(mirror, "big.zip").writeText("a new file that happens to share the name")
        deliver(FileObserver.CREATE, "big.zip")

        // A name the device does not hold is created and then written, so the
        // write happening at all is what separates this from the guarded cases.
        verify(atLeast = 1) { resolver.openOutputStream(any(), "wt") }
    }

    /**
     * The skip has to name the document at a severity a release build keeps.
     *
     * `Logger.d` is gated on a debuggable build, so on a release build the only trace of
     * a document the editor does not have was a count in the summary line. The file is
     * intact on the device and the folder opened successfully, so nothing else says
     * anything at all, and a user asking why they cannot find it needs the name.
     */
    @Test
    fun `a document skipped for size is named at a severity a release build keeps`() {
        deviceHolding("big.zip", size = SafSyncEngine.MAX_FILE_SIZE + 1)

        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        verify(atLeast = 1) { Logger.i(any(), match { it.contains("big.zip") }) }
    }

    /**
     * The four cases above pin that the device document survives. These pin the other
     * half, which was missing: that the user is told their edit did not travel.
     *
     * Refusing the write is correct and it is also invisible. The mirror holds the
     * edit, the editor reports the save, the tab goes clean, and the device folder
     * still holds a different document. That is the shape the project's own rule
     * forbids, a save that looks identical to one that worked, and the engine's KDoc
     * names this group as "the user's only copy" while announcing nothing about it.
     *
     * Asserted on the seam rather than on a Toast: the engine has no screen, and
     * `WriteBackNoticeWiringTest` covers the Activity end of the same channel.
     */
    @Test
    fun `a refused write-back tells the user their edit stayed in the app`() {
        val announced = mutableListOf<String>()
        engine.onWriteBackFailed = { announced.add(it.name) }

        deviceHolding("big.zip", size = SafSyncEngine.MAX_FILE_SIZE + 1)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        File(mirror, "big.zip").writeText("stub")
        deliver(FileObserver.CREATE, "big.zip")

        assertEquals(
            listOf("big.zip"),
            announced,
            "the write was refused and nothing said so, which is the silence this " +
                "guard was supposed to end rather than create",
        )
    }

    /**
     * A replacement engine refused admission while the departing engine reads must
     * still guard device documents it never read. The nested open reaches the busy
     * refusal before per-file copy admission, and the outer provider read then fails.
     */
    @Test
    fun `a sync refused while another engine reads still guards the document`() {
        deviceHolding("notes.md", size = 15)
        val loser = SafSyncEngine(context)
        val announced = mutableListOf<String>()
        loser.onWriteBackFailed = { announced.add(it.name) }

        var writes = 0
        every { resolver.openOutputStream(any(), "wt") } answers {
            writes++
            java.io.ByteArrayOutputStream()
        }

        var reentered = false
        every { resolver.openInputStream(any()) } answers {
            if (!reentered) {
                reentered = true
                // Inside the winner's read, so mirror admission refuses the nested open.
                runBlocking { loser.initialSync(treeUri, mirror) { _, _ -> } }
            }
            // And then the winner's own copy fails, which is what leaves the
            // mirror without the document and the device holding the only one.
            throw IOException("the provider refused the read")
        }

        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        assertTrue(reentered, "the second sync never ran, so no claim was ever contested")

        // Counted from here, because the reentrant sync above is a whole sync of
        // its own and a bare `exactly = 0` would be answering for both.
        val before = writes

        File(mirror, "notes.md").writeText("stub")
        loser.handleMirrorEvent(FileObserver.CREATE, File(mirror, "notes.md"), mirror, treeUri)
        loser.runWriteBackLoop { false }

        assertEquals(
            before, writes,
            "the engine that lost the copy wrote a local file over a device document it " +
                "never read, opening it with \"wt\": the device copy is truncated to " +
                "whatever the mirror happened to hold",
        )
        assertEquals(
            listOf("notes.md"), announced,
            "the write was refused and nothing said so, which is the silence the guard " +
                "exists to end rather than create",
        )
    }

    /** The same, for a document the sync tried to read and could not. */
    @Test
    fun `a copy that failed is announced too`() {
        val announced = mutableListOf<String>()
        engine.onWriteBackFailed = { announced.add(it.name) }

        deviceHolding("notes.md", size = 64, readable = false)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        File(mirror, "notes.md").writeText("stub")
        deliver(FileObserver.MODIFY, "notes.md")

        assertEquals(listOf("notes.md"), announced, "a failed copy refused the write silently")
    }

    /**
     * The negative control, and the one that stops the two above from passing for the
     * wrong reason. A write that actually lands must announce nothing: an app that
     * warns on every successful save teaches the user to ignore the warning, which
     * costs more than the silence did.
     */
    @Test
    fun `a write-back that lands announces nothing`() {
        val announced = mutableListOf<String>()
        engine.onWriteBackFailed = { announced.add(it.name) }

        deviceHolding("notes.md", size = 15)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }

        File(mirror, "notes.md").writeText("edited in the editor")
        deliver(FileObserver.MODIFY, "notes.md")

        verify(atLeast = 1) { resolver.openOutputStream(any(), "wt") }
        assertTrue(
            announced.isEmpty(),
            "a save that reached the device folder still warned the user: $announced",
        )
    }

    /**
     * Once per file, not once per save. The refusal fires on every inotify MODIFY, so an
     * editor autosaving reaches it every few seconds, and the notice is throttled by one
     * timer for the whole folder: a wall of the same message would also swallow an
     * unrelated write-back failure for as long as it lasted.
     */
    @Test
    fun `an editor saving the same file again is not announced again`() {
        val announced = mutableListOf<String>()
        engine.onWriteBackFailed = { announced.add(it.name) }

        deviceHolding("big.zip", size = SafSyncEngine.MAX_FILE_SIZE + 1)
        runBlocking { engine.initialSync(treeUri, mirror) { _, _ -> } }
        File(mirror, "big.zip").writeText("stub")

        repeat(3) { deliver(FileObserver.MODIFY, "big.zip") }

        assertEquals(listOf("big.zip"), announced, "one notice per file, not one per save")
    }

    /**
     * The other refusal site cannot be driven from here at all: reaching it means walking
     * into a directory, and delivering a directory event builds a `FileObserver`, whose
     * static initializer needs native code. What holds it to the behaviour above is that
     * there is one refusal in the file, so this reads the source and pins that.
     *
     * Two claims, and they fail differently. The message having one home says that a
     * second refusal cannot have been written that forgets to announce. The call count
     * says every refusal is still there: the sentence can sit in the file, spelt exactly
     * once, while the site that reaches it has been commented out. That site is the
     * destructive one (with the call gone, `createOneInSaf` falls through to the write
     * and truncates a device document this sync never read), and no behavioural test in
     * this class can reach it.
     *
     * The call count counts only what the compiler sees. A plain search over raw text
     * finds the call inside a line a `//` has disabled exactly as readily as inside a
     * live one, which is how a guard of this shape reports wiring that is already dead
     * as present. Excluded for the same reason: the declaration, which wears the same
     * spelling, and a doc comment naming the helper.
     */
    @Test
    fun `the refusal message has one home, so every site announces`() {
        val engineSource =
            File("../../android/app/src/main/kotlin/com/vscodroid/storage/SafSyncEngine.kt")
        assertTrue(engineSource.isFile, "SafSyncEngine.kt is not where this test expects it")
        val text = engineSource.readText()

        assertEquals(
            1,
            Regex("sync never read, and writing would replace it").findAll(text).count(),
            "a second copy of the refusal means a site that refuses without saying so",
        )
        val callSites = text.lines().count { line ->
            val at = line.indexOf("refuseUnreadDocument(")
            val before = if (at < 0) "" else line.substring(0, at)
            at >= 0 && "//" !in before && !before.trimStart().startsWith("*") &&
                "private fun " !in before
        }
        assertEquals(
            3,
            callSites,
            "the three write paths that can find a document this sync never read are the " +
                "event path, the write-back of a queued save and the directory walk, and " +
                "each has to refuse through the announcing helper. If another path " +
                "legitimately grew one, raise this number; if one went away, the write it " +
                "used to refuse now replaces a document the user has no other copy of",
        )
    }
}
