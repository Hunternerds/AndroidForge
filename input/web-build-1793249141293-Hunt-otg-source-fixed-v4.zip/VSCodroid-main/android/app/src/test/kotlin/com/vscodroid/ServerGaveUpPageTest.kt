package com.vscodroid

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

/**
 * The page shown when the server will not come back, and the escaping it rests on.
 *
 * The page itself needs a device: it replaces a WebView's content and its button
 * is a navigation the bootstrap client answers, neither of which a JVM can build.
 * What can be checked here is the part that would fail silently rather than
 * visibly, which is the interpolation. The page is assembled with string
 * templates, so a message carrying a quote or an angle bracket would not throw,
 * it would change the markup around it, and the retry button is inside that
 * markup.
 *
 * Nothing hostile reaches it today: both strings come from this app's resources.
 * It is covered because the next person to interpolate something here may be
 * carrying a filename, a path, or an exception message.
 */
class ServerGaveUpPageTest {

    @Test
    fun `the five characters that change surrounding markup are escaped`() {
        assertEquals("&amp;", escapeHtml("&"))
        assertEquals("&lt;", escapeHtml("<"))
        assertEquals("&gt;", escapeHtml(">"))
        assertEquals("&quot;", escapeHtml("\""))
        assertEquals("&#39;", escapeHtml("'"))
    }

    @Test
    fun `the ampersand is escaped first, so an escape is not escaped twice`() {
        // Kills the ordering bug this is most likely to acquire: replacing "<"
        // before "&" turns a plain "<" into "&amp;lt;", which renders as the
        // text "&lt;" instead of a bracket. Ordering is invisible in the output
        // of every single-character case above.
        assertEquals("&amp;lt;", escapeHtml("&lt;"))
        assertEquals("&lt;a&gt;", escapeHtml("<a>"))
    }

    @Test
    fun `text with nothing to escape is returned unchanged`() {
        val plain = "The development server stopped and could not be restarted."
        assertEquals(plain, escapeHtml(plain))
    }

    @Test
    fun `a message cannot close the anchor the retry button lives in`() {
        // The concrete harm, stated as the assertion. The button is an <a> tag
        // in the same document as the message, so a message able to emit a tag
        // could take the only way out off the page.
        val hostile = """</p><a href="#">not the retry button</a><p>"""

        val escaped = escapeHtml(hostile)

        assertFalse(escaped.contains("<a"), "an anchor survived escaping: $escaped")
        assertFalse(escaped.contains("</p>"), "a closing tag survived escaping: $escaped")
        assertTrue(escaped.contains("&lt;a"), "the text should still be readable as text")
    }

    /**
     * The log block shows the newest lines, with a repeated failure said once.
     *
     * This page is reached only after the restart budget is spent, so a failure
     * that is the same every time has written its line six times by then.
     * Measured on an emulator with the Node binary removed: the block filled with
     * six identical copies of one sentence and showed nothing else.
     */
    @Test
    fun `a run of identical lines is shown once, and the newest lines are kept`() {
        val log = listOf("started", "boom", "boom", "boom", "boom", "boom", "boom")

        assertEquals(listOf("started", "boom"), collapseRuns(log, 20))
    }

    /**
     * Collapsing before cutting, which is the order that carries the value.
     *
     * Cut first and the six repeats ARE the whole window, so the attempt that
     * preceded them is dropped and the page shows one sentence with no context.
     */
    @Test
    fun `the collapse happens before the cut, so context survives a long run`() {
        val log = listOf("started") + List(6) { "boom" }

        // Two lines fit in a window of two only because the run collapsed first.
        assertEquals(listOf("started", "boom"), collapseRuns(log, 2))
    }

    /** Only consecutive runs merge: a line recurring later is a new event. */
    @Test
    fun `a line that comes back later is not merged with its earlier self`() {
        val log = listOf("boom", "boom", "restarted", "boom")

        assertEquals(listOf("boom", "restarted", "boom"), collapseRuns(log, 20))
    }

    /** An empty log is an empty block, not a crash and not a blank line. */
    @Test
    fun `an empty log collapses to nothing`() {
        assertEquals(emptyList<String>(), collapseRuns(emptyList(), 20))
    }

    /**
     * Which failures get the log, pinned at the call sites.
     *
     * The split is the load-bearing part and it is invisible: both variants draw
     * the same page, so swapping one call site shows a previous session's log as
     * the explanation for a foreground-service refusal, or drops the log from the
     * one failure it was written for. Neither shows up as a test failure anywhere
     * else, and neither is visible in a diff that only reads the page.
     */
    @Test
    fun `only the spent-restart-budget failures are given the server log`() {
        val src = SourceScan.withoutComments(
            SourceScan.read("src/main/kotlin/com/vscodroid/MainActivity.kt")
        )

        // A refused foreground service: nothing was launched, so the file holds
        // some earlier session and offering it would explain the wrong thing.
        for (site in listOf("private fun startAndBindService(", "private fun retryServerStart(")) {
            val body = SourceScan.body(src, site)
            assertTrue(body.contains("showServerGaveUp()")) {
                "$site no longer shows the gave-up page at all"
            }
            assertFalse(body.contains("showServerGaveUpWithLog(")) {
                "$site offers the server log for a foreground-service refusal, which " +
                    "happens before anything is launched: the log it shows belongs to " +
                    "an earlier session"
            }
        }

        // The restart budget running out, which is what the log describes.
        assertTrue(src.contains("if (afterRestarts) showServerGaveUpWithLog() else showServerGaveUp()")) {
            "the onServerGaveUp handler no longer chooses by the flag, so either a " +
                "STAND_DOWN shows a stale log or a real crash loop shows none"
        }
    }
    @Test
    fun `a delayed log page checks its request document and view after the read`() {
        val source = SourceScan.read("src/main/kotlin/com/vscodroid/MainActivity.kt")
        val body = SourceScan.body(source, "private fun showServerGaveUpWithLog(")
        val read = body.indexOf("withContext(Dispatchers.IO)")
        assertTrue(body.indexOf("val request = ++recoveryPageEpoch") in 0 until read)
        assertTrue(body.indexOf("val generation = AuthTabWindow.pageGeneration()") in 0 until read)
        val guard = body.substringAfter("val detail =").substringAfter(".let { collapseRuns")
        assertTrue(guard.contains("request != recoveryPageEpoch") && guard.contains("webView !== targetView"))
        assertTrue(guard.contains("generation != AuthTabWindow.pageGeneration()") && guard.contains("return@launch"))
        assertTrue(guard.indexOf("return@launch") < guard.indexOf("showErrorPage("))
    }

    @Test
    fun `each native page replacement invalidates a pending log page`() {
        val source = SourceScan.read("src/main/kotlin/com/vscodroid/MainActivity.kt")
        for ((name, load) in listOf(
            "setupWebView" to "wv.loadData(",
            "retryServerStart" to "webView?.loadData(",
            "showErrorPage" to "webView?.loadDataWithBaseURL(",
            "navigateToFolder" to "wv.loadUrl(",
        )) {
            val body = SourceScan.body(source, "private fun $name(")
            assertTrue(body.indexOf("recoveryPageEpoch++") in 0 until body.indexOf(load), name)
        }
    }

}
