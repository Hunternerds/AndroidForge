package com.sago.app.ui.screens

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sago.app.avatar.AvatarView
import com.sago.app.avatar.emotionColor
import com.sago.app.domain.model.ChatMessage
import com.sago.app.domain.model.Emotion
import com.sago.app.ui.components.Backdrop
import com.sago.app.ui.theme.LocalSagoUi
import com.sago.app.ui.theme.Palette
import com.sago.app.ui.viewmodel.ChatViewModel
import com.sago.app.voice.AssistantState
import com.sago.app.voice.UiError
import com.sago.app.wake.WakeStatus
import com.sago.app.wake.WakeWordService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: ChatViewModel, onHistory: () -> Unit, onSettings: () -> Unit, onAiSettings: () -> Unit, onVoiceSettings: () -> Unit) {
    val ctx = LocalContext.current
    val ui = LocalSagoUi.current
    val s by vm.settings.collectAsStateWithLifecycle()
    val avatar by vm.assistant.avatar.collectAsStateWithLifecycle()
    val state by vm.assistant.state.collectAsStateWithLifecycle()
    val mouth by vm.assistant.mouthOpen.collectAsStateWithLifecycle()
    val level by vm.assistant.micLevel.collectAsStateWithLifecycle()
    val partial by vm.assistant.partial.collectAsStateWithLifecycle()
    val error by vm.assistant.error.collectAsStateWithLifecycle()
    val messages by vm.messages.collectAsStateWithLifecycle()
    val draft by vm.draft.collectAsStateWithLifecycle()
    val attaching by vm.attaching.collectAsStateWithLifecycle()
    val wakeStatus by vm.wakeStatus.collectAsStateWithLifecycle()
    val wakeDetail by vm.wakeDetail.collectAsStateWithLifecycle()
    var input by rememberSaveable { mutableStateOf("") }
    val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    // Surface a failed background-listening start as a normal, dismissible error.
    LaunchedEffect(wakeStatus) {
        if (wakeStatus == WakeStatus.ERROR || wakeStatus == WakeStatus.MODEL_MISSING || wakeStatus == WakeStatus.NO_PERMISSION)
            vm.assistant.error.value = UiError(wakeDetail.ifBlank { "Background listening stopped." })
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.assistant.startVoice()
        else vm.assistant.error.value = UiError("Microphone permission was denied. You can allow it later in Settings → Privacy, or keep typing.")
    }
    fun onMic() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.assistant.startVoice()
        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    var capturePath by rememberSaveable { mutableStateOf<String?>(null) }
    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        capturePath?.let { p -> if (ok) vm.attachFile(File(p)) else File(p).delete() }
    }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> uri?.let(vm::attach) }
    fun onCamera() {
        try {
            val f = File(File(ctx.cacheDir, "captures").apply { mkdirs() }, "cap_${System.currentTimeMillis()}.jpg")
            capturePath = f.absolutePath
            takePicture.launch(FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f))
        } catch (e: ActivityNotFoundException) {
            vm.assistant.error.value = UiError("No camera app was found on this device. You can pick a photo instead.")
        } catch (e: Exception) {
            vm.assistant.error.value = UiError("Couldn't open the camera: ${e.message}")
        }
    }

    fun send() {
        if (input.isBlank() && draft == null) return
        vm.send(input); input = ""
    }

    Box(Modifier.fillMaxSize()) {
        Backdrop(s.showBackground)
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            TopRow(
                wakeActive = wakeStatus == WakeStatus.LISTENING || wakeStatus == WakeStatus.ENGAGED,
                onHistory = onHistory, onNew = { vm.assistant.newConversation(); input = "" }, onSettings = onSettings,
                onStopListening = { WakeWordService.stop(ctx) },
            )

            Column(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                AvatarView(
                    ui = avatar, mouthOpen = mouth, micLevel = level, avatarSize = if (imeOpen) 84.dp else s.avatarSizeDp.dp,
                    animations = s.avatarAnimations, emotionGlow = s.showEmotion,
                    modifier = Modifier.clickable(enabled = state != AssistantState.IDLE) { vm.assistant.stop() },
                )
                StatusLine(state, partial, avatar.emotion, s.showEmotion)
            }

            MessageList(Modifier.weight(1f).fillMaxWidth(), messages, thinking = state == AssistantState.THINKING)

            error?.let { e ->
                ErrorBanner(
                    e, onRetry = { vm.assistant.retry() }, onDismiss = { vm.assistant.dismissError() },
                    onSettings = { vm.assistant.dismissError(); if (e.openAiSettings) onAiSettings() else onVoiceSettings() },
                )
            }
            draft?.let { d -> DraftChip(d.savedPath) { vm.clearDraft() } }
            if (attaching) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp))

            InputBar(
                input = input, onInput = { input = it }, state = state, hasDraft = draft != null,
                onSend = ::send, onMic = ::onMic, onStop = { vm.assistant.stop() }, onCamera = ::onCamera,
                onGallery = { pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopRow(wakeActive: Boolean, onHistory: () -> Unit, onNew: () -> Unit, onSettings: () -> Unit, onStopListening: () -> Unit) {
    val ui = LocalSagoUi.current
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onHistory) { Icon(Icons.Default.History, "Conversation history", tint = ui.text) }
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("SAGO", style = MaterialTheme.typography.titleLarge, color = ui.text, letterSpacing = 3.sp)
            if (wakeActive) {
                Surface(
                    onClick = onStopListening, shape = CircleShape, color = Color(0xFF14532D).copy(0.85f),
                    modifier = Modifier.semantics { contentDescription = "Listening for the wake word. Tap to stop listening." },
                ) {
                    Row(Modifier.padding(horizontal = 10.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF4ADE80)))
                        Spacer(Modifier.width(6.dp))
                        Text("Listening for “Sago” · tap to stop", style = MaterialTheme.typography.labelSmall, color = Color.White)
                    }
                }
            }
        }
        IconButton(onNew) { Icon(Icons.Default.Add, "New conversation", tint = ui.text) }
        IconButton(onSettings) { Icon(Icons.Default.Settings, "Settings", tint = ui.text) }
    }
}

@Composable
private fun StatusLine(state: AssistantState, partial: String, emotion: Emotion, showEmotion: Boolean) {
    val ui = LocalSagoUi.current
    Box(Modifier.heightIn(min = 30.dp).padding(horizontal = 24.dp), contentAlignment = Alignment.Center) {
        when {
            state == AssistantState.LISTENING -> Text(partial.ifBlank { "Listening…" }, color = ui.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
            state == AssistantState.THINKING -> Text("Thinking…", color = ui.subtext)
            state == AssistantState.SPEAKING -> Text("Speaking · tap me to interrupt", color = ui.subtext, style = MaterialTheme.typography.bodyMedium)
            showEmotion && emotion != Emotion.NEUTRAL -> Surface(shape = CircleShape, color = ui.glass, border = BorderStroke(1.dp, emotionColor(emotion).copy(0.7f))) {
                Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(emotionColor(emotion)))
                    Spacer(Modifier.width(6.dp))
                    Text(emotion.label, style = MaterialTheme.typography.labelSmall, color = ui.text)
                }
            }
        }
    }
}

@Composable
private fun MessageList(modifier: Modifier, messages: List<ChatMessage>, thinking: Boolean) {
    val ui = LocalSagoUi.current
    val listState = rememberLazyListState()
    val count = messages.size + if (thinking) 1 else 0
    LaunchedEffect(count) { if (count > 0) listState.animateScrollToItem(count - 1) }
    if (count == 0) {
        Box(modifier.padding(32.dp), contentAlignment = Alignment.Center) {
            Text(
                "Say hi! Type below or tap the mic.\nTurn on the “Sago” wake word in Settings → Voice to talk hands-free.",
                color = ui.subtext, style = MaterialTheme.typography.bodyMedium, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
        return
    }
    LazyColumn(modifier, state = listState, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(messages, key = { it.id }) { Bubble(it) }
        if (thinking) item { ThinkingBubble() }
    }
}

@Composable
private fun Bubble(m: ChatMessage) {
    val ui = LocalSagoUi.current
    val user = m.role == ChatMessage.Role.USER
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        Surface(
            shape = RoundedCornerShape(18.dp, 18.dp, if (user) 18.dp else 4.dp, if (user) 4.dp else 18.dp),
            color = if (user) Palette.PinkDeep else ui.glass, contentColor = if (user) Color.White else ui.text,
            border = if (user) null else BorderStroke(1.dp, ui.glassBorder), modifier = Modifier.widthIn(max = 320.dp),
        ) {
            Column(Modifier.padding(horizontal = 13.dp, vertical = 9.dp)) {
                m.imagePath?.let { ChatImage(it) }
                if (m.text.isNotBlank()) SelectionContainer { Text(m.text, style = MaterialTheme.typography.bodyLarge) }
                Text(DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(m.createdAt)), style = MaterialTheme.typography.labelSmall, modifier = Modifier.alpha(0.65f).align(Alignment.End))
            }
        }
    }
}

@Composable
private fun ChatImage(path: String) {
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { runCatching { BitmapFactory.decodeFile(path)?.asImageBitmap() }.getOrNull() }
    }
    bmp?.let { Image(it, "Photo you shared", Modifier.padding(bottom = 6.dp).widthIn(max = 240.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.FillWidth) }
}

@Composable
private fun ThinkingBubble() {
    val ui = LocalSagoUi.current
    val t = rememberInfiniteTransition(label = "dots")
    Surface(shape = RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp), color = ui.glass, border = BorderStroke(1.dp, ui.glassBorder)) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            for (i in 0..2) {
                val a by t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(600, delayMillis = i * 160), RepeatMode.Reverse), label = "d$i")
                Box(Modifier.size(8.dp).alpha(a).clip(CircleShape).background(ui.text))
            }
        }
    }
}

@Composable
private fun ErrorBanner(e: UiError, onRetry: () -> Unit, onDismiss: () -> Unit, onSettings: () -> Unit) {
    Surface(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), shape = RoundedCornerShape(14.dp), color = Color(0xFF7F1D3A).copy(0.92f), contentColor = Color.White) {
        Column(Modifier.padding(12.dp)) {
            Text(e.message, style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                if (e.canRetry) TextButton(onRetry) { Text("Retry", color = Color.White) }
                if (e.openAiSettings) TextButton(onSettings) { Text("Open settings", color = Color.White) }
                TextButton(onDismiss) { Text("Dismiss", color = Color.White.copy(0.8f)) }
            }
        }
    }
}

@Composable
private fun DraftChip(path: String, onRemove: () -> Unit) {
    val ui = LocalSagoUi.current
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { runCatching { BitmapFactory.decodeFile(path)?.asImageBitmap() }.getOrNull() }
    }
    Row(Modifier.padding(horizontal = 14.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = RoundedCornerShape(12.dp), color = ui.glass, border = BorderStroke(1.dp, ui.glassBorder)) {
            Row(Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                bmp?.let { Image(it, "Attached photo", Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop) }
                Text("  Photo attached", color = ui.text, style = MaterialTheme.typography.bodyMedium)
                IconButton(onRemove, Modifier.size(32.dp)) { Icon(Icons.Default.Close, "Remove photo", tint = ui.text) }
            }
        }
    }
}

@Composable
private fun InputBar(
    input: String, onInput: (String) -> Unit, state: AssistantState, hasDraft: Boolean,
    onSend: () -> Unit, onMic: () -> Unit, onStop: () -> Unit, onCamera: () -> Unit, onGallery: () -> Unit,
) {
    val ui = LocalSagoUi.current
    var menu by remember { mutableStateOf(false) }
    val busy = state != AssistantState.IDLE
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box {
            IconButton({ menu = true }) { Icon(Icons.Default.AddPhotoAlternate, "Attach a photo", tint = ui.text) }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text("Take a photo") }, leadingIcon = { Icon(Icons.Default.PhotoCamera, null) }, onClick = { menu = false; onCamera() })
                DropdownMenuItem(text = { Text("Choose a photo") }, leadingIcon = { Icon(Icons.Default.PhotoLibrary, null) }, onClick = { menu = false; onGallery() })
            }
        }
        TextField(
            value = input, onValueChange = onInput, modifier = Modifier.weight(1f), maxLines = 5,
            placeholder = { Text(if (hasDraft) "Ask about this photo…" else "Message SAGO", color = ui.subtext) },
            shape = RoundedCornerShape(24.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = ui.glass, unfocusedContainerColor = ui.glass, focusedTextColor = ui.text, unfocusedTextColor = ui.text,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, cursorColor = Palette.Pink,
            ),
        )
        Spacer(Modifier.width(8.dp))
        val (icon, desc, action) = when {
            busy -> Triple(Icons.Default.Stop, "Stop", onStop)
            input.isNotBlank() || hasDraft -> Triple(Icons.AutoMirrored.Filled.Send, "Send message", onSend)
            else -> Triple(Icons.Default.Mic, "Talk to SAGO", onMic)
        }
        FilledIconButton(action, Modifier.size(50.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = Palette.PinkDeep, contentColor = Color.White)) {
            Icon(icon, desc)
        }
    }
}
