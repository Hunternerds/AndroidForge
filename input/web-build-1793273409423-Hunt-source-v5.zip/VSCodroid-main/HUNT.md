# HUNT

HUNT is an Android code editor built from the open-source VSCodroid project, which
embeds a Code - OSS (VS Code compatible) server and a Node.js runtime in the app.
This file describes what the HUNT fork changes, how to build it, and what has and
has not been tested. Upstream attribution, `LICENSE`, `NOTICE.md` and `licenses/`
are kept as they were.

## What changed in this revision (v5, on top of v4)

Branding, user-visible text only. Identifiers are deliberately untouched (see below).

- Android strings: every "VSCodroid" in `res/values/strings.xml` and the 13 translated
  `values-*/strings.xml` files now reads "Hunt" (the launcher label, notifications and
  About title already did). Korean particles are correct for "Hunt"; the Turkish
  suffix is `Hunt'ı`.
- Bundled extensions (5): display names, command titles ("Hunt: Open Welcome",
  "Hunt: Manage Device Folder Storage" and so on), the settings group titles, the
  welcome walkthrough text and the notices in `extension.js`, in all 14 languages
  (70 `package.nls*.json` files, 2 `package.json`, 2 `extension.js`).
- Editor product name: `assets/server.js` sets `nameShort` and `nameLong` to "Hunt"
  on every server start, so the window title and About show HUNT. It is done here
  and not in `branding/product.json` because the downloaded server tree is checked
  against that file at build time.
- Kotlin (user-visible strings only): the error and loading page heading, the
  WebView-update message, the unknown-command message, the bug report header and
  clipboard label, the copy-to-clipboard label, and the `README.md` the first run writes
  into the projects folder.
- Tests updated to match: `scripts/test-server-bootstrap.js`,
  `LoginShellFilesAtomicityTest.kt`.
- `.github/workflows/hunt-apk.yml`: every action is pinned to a full commit SHA
  (the repository's own `check-workflow-steps.py` failed on six unpinned actions
  before). A new step opens the APK before upload: signature, package ID, the label
  "Hunt", the arm64-v8a native code, the Node runtime, the server entry point and
  the notices must all be present or the run fails. The artifact is named
  `HUNT-<version>-debug.apk`, with the signature and badging reports beside it.

From v4 (previous revision, not re-reviewed line by line here): the launcher icon,
monochrome icon and background, `hunt-prepare-assets.sh`, the root Gradle shim that
runs it, and the manifest declaring a touchscreen as optional and `navigation` in
`configChanges`.

## What is deliberately not renamed

- Application ID `com.vscodroid` (`.debug` suffix on debug), the Kotlin package, the
  `vscodroid.*` setting keys and command IDs, the `vscodroid://` sign-in scheme,
  `.vscodroid` data folders and the `vscodroid.*` extension IDs. Native scripts,
  patches and installed data depend on them, and a new application ID installs as a
  separate app with none of the old data. Renaming them needs a full rebuild and
  test on a device, and is not worth the risk for a name nobody reads.
- Links to the upstream project (privacy policy, issue tracker, toolchain
  downloads, `reportIssueUrl`). HUNT has no site of its own to point them at.

## Known limits (not fixed)

1. Strings baked into the prebuilt server tree. About ten editor strings still say
   VSCodroid: "Welcome to VSCodroid" (onboarding), "Get Started with VSCodroid",
   "Setup VSCodroid", the reload prompts after installing or removing an extension
   or switching profile, and the title of the sign-in callback page. They come from
   `patches/0006` and `patches/0011`, compiled into the server download. Gradle
   re-runs `verifyServerTree` and the patch fingerprint check on that tree, so
   editing the files after download fails the build. Fixing it properly means
   re-branding those two patches, running the "Build Code - OSS server" workflow
   and pointing `VSCODE_OSS_URL` at the result.
2. OTG keyboard and mouse: reviewed, not changed, not tested on hardware. See below.
3. UI redesign, flicker and rendering: no changes. There is no log or device here to
   find a cause, and the instructions forbid guessing at rendering settings.
4. Release signing: only the debug build is covered.

## OTG keyboard and mouse: what the code already does

Read, not run:

- `MainActivity.dispatchKeyEvent` hands every key to the view tree first and only
  then observes it; a source-scan test (`HardwareKeyboardTest`) pins that order. It
  also reports Escape as handled so a keyboard map cannot turn it into Back.
- `HardwareTyping` takes the extra key row away only after printing keys from a real,
  non-virtual alphabetic keyboard, and gives it back on a finger touch or when the
  keyboard goes away. Mouse clicks and touchpads do not count as touch.
- The manifest declares `keyboard|keyboardHidden|navigation` in `configChanges`, so
  plugging a device in does not rebuild the activity and WebView.
- The caret-drag code only acts for `pointerType === 'touch'`, so a mouse is left to
  the editor.

Suspected gap, not verified and not changed: a mouse side button (Back or Forward)
reaches the app as a Back key, and `setupBackNavigation` answers it with
`moveTaskToBack`, which sends HUNT to the background. If that happens on your
mouse, the fix belongs in `MainActivity` (ignore Back or Forward from a mouse source
after the view tree has had the key), and needs a real mouse and the existing
`HardwareKeyboardTest` kept green. It was left alone because a wrong guess at key
routing is worse than the symptom.

## Build

Needs network. The first run downloads and compiles a lot (the editor server, Node,
Termux tools, Python, native add-ons).

- GitHub: Actions tab, "Hunt APK", Run workflow. Download the `hunt-debug-apk`
  artifact.
- AndroidForge or any runner starting Gradle from the repository root:
  `./gradlew assembleDebug`. The root `settings.gradle.kts` runs
  `scripts/hunt-prepare-assets.sh` first (skip with `HUNT_SKIP_ASSETS=1`).
- Local Linux: JDK 17, Android SDK with NDK `27.2.12479018` and CMake 3.22.1,
  Node 20 or newer, python3, curl, unzip, bsdtar, gpg, xz, make. Then
  `bash scripts/build-all.sh`.

Output: `android/app/build/outputs/apk/debug/app-debug.apk` (arm64-v8a only).

## Install

`adb install -r app-debug.apk`, or open the file on the phone. If Android reports a
signature conflict with an earlier build, uninstall the old one first; that deletes
its app data.

## Tests run for this revision

Run in a sandbox with Node 22 and Python 3.12, no Android toolchain, no network:

- `scripts/test-*.js`: 25 of 25 pass. `scripts/test-*.py`: 10 of 10 pass.
- `check-translatable-strings`, `check-welcome-claims`, `check-permission-claims`,
  `check-bundled-extensions`, `check-checklist-totals`, `check-lint-baseline`,
  `check-bridge-api-spec`, `check-build-steps`, `check-library-attribution`: pass.
- `check-workflow-steps`: failed with six errors before (the old `hunt-apk.yml`),
  passes now.
- All 14 `strings.xml` files parse as XML; all extension JSON parses; `server.js`
  passes `node --check`.

Not run: Gradle, Kotlin compilation, Kotlin unit tests, lint, any install or launch,
server startup on a device, OTG keyboard and mouse, rotation, backgrounding,
repeated launches. A passing Gradle run is not proof the app works, and none was
done here.

The APK in your earlier build log (not rebuilt here): Gradle reported success, the APK is
arm64-v8a, carries the Node runtime and the server tree, has a debug v2 signature
block and the launcher label "Hunt". It was not installed or launched.
