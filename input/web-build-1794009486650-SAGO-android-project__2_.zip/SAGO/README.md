# SAGO 2.0 — Android AI companion

Native Kotlin + Jetpack Compose. Groq for AI, an offline "Sago" wake word, your face artwork as the animated avatar.

> **Status: written, never compiled or run.** This project was authored in an environment with no Android SDK or Gradle.
> Version 1 compiled after one import fix (from a real build log); 2.0 adds about 3,000 lines that have *not* been through a compiler.
> Expect some compile errors on first sync, then test on a real phone. Unit tests are written but have not been run.

## Open and build
1. Android Studio Ladybug (2024.2)+, JDK 17. File → Open this folder; Studio fetches Gradle 8.9 (`gradle-wrapper.jar` could not be generated here; for the CLI run `gradle wrapper --gradle-version 8.9`).
2. Run on a device (minSdk 26 / targetSdk 35). Use a real phone for wake word, voice and notifications.
3. First launch: paste your Groq key. Updating from 1.0 keeps your data (database migration 1→2; if it ever fails the old file is kept as `sago.db.bak` and a fresh one is created).
4. Tests: `./gradlew test` (JUnit; parsing, emotion, tools, time, WAV/envelope, search helpers).

## What's new in 2.0
**Voice you asked for**
- **Natural girl voice:** Groq's Orpheus (`canopylabs/orpheus-v1-english`), female voices Autumn/Diana/Hannah, with a delivery cue from SAGO's mood. 200 characters per request, so replies are sent sentence by sentence; the next sentence is synthesised while the current one plays. Falls back to the device voice (with a visible reason) if Groq's voice fails, e.g. you haven't accepted the model terms at console.groq.com yet. "Brightness" (pitch) and speed are applied at playback for a lighter, more anime-like tone. A fully custom anime voice isn't available through Groq.
- **Mouth sync that works with any voice:** audio is played by SAGO itself (AudioTrack); the mouth follows the loudness of the audio actually playing. This replaces the word-callback approach that depends on the TTS engine.
- **Background listening:** wake lock while listening (optional), one-tap battery-optimisation request, the setting is no longer switched off by transient failures, and if Android stops the service a notification offers "Resume" (the one case Android 14+ allows restarting a microphone service from the background). Opening the app also restarts it.
- **Accurate recognition:** Groq Whisper for both the mic button and "Sago …" requests; adaptive voice-activity detection ends the recording when you stop talking.

**Intelligence**
- Memory 2.0: categories, importance, confidence, expiry; merge/update; daily consolidation; retrieval by relevance + SQLite FTS (a separate index DB that can always be rebuilt). Commands: "Sago remember …", "Sago forget …", "what do you remember (about …)?" plus natural variants. Remember/forget/recall work offline.
- Conversation summaries (stored separately from memories, restore context when reopening), AI titles (no extra call), natural-language conversation search (History screen).
- Reply modes (casual, quick, detailed, technical, tutor, brainstorm, planning, creative, translate), auto-detected or forced in Settings → AI.
- Multi-step engine: local planner → one structured Groq call → validated tools → optional follow-up call → local verifier. At most two chat calls per turn (+1 inside web research). SAGO never claims an action the app didn't perform.
- Tools (schema-validated, timeouts, permission checks): remember, forget (needs confirmation), search memory/notes/documents/conversations, notes, tasks, reminders, routines, calendar (READ_CALENDAR), web research (Groq browser search, gpt-oss models), safe settings. Results appear as cards written by app code; safe changes have **Undo**.
- Fallback model if the chat model is unavailable (configurable).

**Autonomy**
- Reminders and routines via WorkManager (survive restarts). Optional morning briefing/check-ins built only from saved data, quiet hours, easy to switch off. Timing is not exact while the phone is idle.
- Library screen: notes, tasks, reminders/routines, and a private **document vault** (text files, PDFs and photos; PDFs/photos are read with the vision model, so those pages are sent to Groq once). Answers from your files are labelled with their source.
- Multi-image questions (up to 4), screenshots/documents.
- Offline banner; notes, memory, history and the vault work without internet.

**Quality**
- Diagnostics screen (startup, API latency/failures, tokens, events) with plain-number suggestions; logs never contain messages or keys.
- Data export (JSON), retention (auto-delete old conversations), Android shortcuts and a home-screen widget, reduced-motion setting, screen-reader labels.

## Honest limits
- Not compiled/run (see top). Groq's Orpheus voice, browser search and Whisper were checked against Groq's docs but not called from this build.
- No LLM streaming (replies arrive whole); sentence-by-sentence speech keeps the delay low. Voice barge-in isn't implemented (no echo cancellation); tap the avatar or Stop to interrupt.
- No embeddings (full-text search + scoring instead), no weather tool (no authorised provider), no PDF text extraction library (vision is used).
- Android 14+ can't auto-start the microphone service at boot or from the background.
- "Battery saver" silence-skipping for the wake word was considered but not built.
