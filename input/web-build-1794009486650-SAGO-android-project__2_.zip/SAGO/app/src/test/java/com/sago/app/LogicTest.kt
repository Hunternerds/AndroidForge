package com.sago.app

import com.sago.app.avatar.Expression
import com.sago.app.data.db.SearchIndex
import com.sago.app.domain.ai.EmotionResolver
import com.sago.app.domain.ai.ReplyParser
import com.sago.app.domain.ai.ResponseMode
import com.sago.app.domain.ai.StudyMode
import com.sago.app.domain.memory.LocalCommand
import com.sago.app.domain.memory.MemoryCommandParser
import com.sago.app.domain.memory.MemoryEngine
import com.sago.app.domain.memory.SensitiveFilter
import com.sago.app.domain.model.AiReply
import com.sago.app.domain.model.ChatMessage
import com.sago.app.domain.model.Emotion
import com.sago.app.domain.tools.*
import com.sago.app.voice.SpeechOutput
import com.sago.app.voice.Wav
import com.sago.app.voice.WavDecoder
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneId

class MemoryCommandTest {
    @Test fun rememberVariants() {
        assertEquals(LocalCommand.Remember("my favourite language is Python"), MemoryCommandParser.parseCommand("Sago remember my favourite language is Python", false))
        assertEquals(LocalCommand.Remember("I prefer short answers"), MemoryCommandParser.parseCommand("Sago, please remember that I prefer short answers.", false))
        // right after the wake word, a bare "remember …" counts; the misheard wake word is stripped
        assertTrue(MemoryCommandParser.parseCommand("remember my project is StudyOS", true) is LocalCommand.Remember)
        assertTrue(MemoryCommandParser.parseCommand("say go remember my project is StudyOS", true) is LocalCommand.Remember)
    }
    @Test fun typedRememberNeedsTheWakeWord() { assertNull(MemoryCommandParser.parseCommand("remember to buy milk", false)) }
    @Test fun forgetAndRecall() {
        assertEquals(LocalCommand.Forget("my favourite language", false), MemoryCommandParser.parseCommand("Sago forget my favourite language", false))
        assertTrue((MemoryCommandParser.parseCommand("Sago forget everything", false) as LocalCommand.Forget).all)
        assertEquals(LocalCommand.Recall(null), MemoryCommandParser.parseCommand("What do you remember about me?", false))
        assertEquals(LocalCommand.Recall("my project"), MemoryCommandParser.parseCommand("what do you remember about my project", false))
        assertEquals(LocalCommand.Recall("my dog", soft = true), MemoryCommandParser.parseCommand("Do you remember my dog?", false))
    }
    @Test fun stripWakeAndLeadIn() {
        assertEquals("what's the weather", MemoryCommandParser.stripWake("Sago what's the weather", false))
        assertEquals("what's the weather", MemoryCommandParser.dropThroughWake("um so go what's the weather"))
        assertTrue(MemoryCommandParser.isOnlyWake("Sago."))
    }
    @Test fun memoryNormaliseAndCategory() {
        assertEquals("User's project is StudyOS", MemoryEngine.normalise("my project is StudyOS"))
        assertEquals("User prefers short answers", MemoryEngine.normalise("I prefer short answers"))
        assertEquals("project", MemoryEngine.categorise("User's app is called StudyOS"))
        assertEquals("preference", MemoryEngine.categorise("User prefers short answers"))
    }
    @Test fun sensitiveDataIsBlockedFromAutoMemory() {
        assertTrue(SensitiveFilter.isSensitive("My password is hunter2"))
        assertTrue(SensitiveFilter.isSensitive("call me on 5551234567"))
        assertFalse(SensitiveFilter.isSensitive("User's project is called StudyOS"))
    }
}

class ReplyParserTest {
    @Test fun parsesStructuredReply() {
        val r = ReplyParser.parse("""{"response":"Hey *you*!","emotion":"playful","avatar":"playful","memories":[{"text":"User is building StudyOS","category":"project","importance":4,"confidence":0.9}],"actions":[{"tool":"create_reminder","args":{"title":"call mum","time":"2026-11-05T09:00"}}],"title":"Planning","sources":["S1","bogus"]}""")
        assertEquals("Hey you!", r.text); assertEquals(Emotion.PLAYFUL, r.emotion); assertEquals(Expression.PLAYFUL, r.expression)
        assertEquals("project", r.memories.single().category); assertEquals("create_reminder", r.actions.single().tool)
        assertEquals(listOf("S1"), r.sourceIds); assertEquals("Planning", r.title)
    }
    @Test fun metadataNeverLeaksWhenFormatIsIgnored() {
        val r = ReplyParser.parse("just chatting\n{\"emotion\":\"happy\"}")
        assertFalse(r.text.contains("emotion")); assertTrue(r.text.contains("just chatting"))
    }
    @Test fun stripsThinkingBlocksAndFences() {
        assertEquals("hi", ReplyParser.parse("<think>hmm</think>```json\n{\"response\":\"hi\"}\n```").text)
    }
}

class EmotionTest {
    private fun reply(text: String, emotion: Emotion = Emotion.NEUTRAL, face: Expression = Expression.NORMAL) = AiReply(text, emotion, expression = face)
    @Test fun angryEmojiBeatsANormalFace() { assertEquals(Expression.ANGRY, EmotionResolver.resolve(reply("Fine. I'm so mad 😤 but just teasing", Emotion.PLAYFUL, Expression.NORMAL), false).expression) }
    @Test fun playfulEmojiFixesAMislabelledFace() { assertEquals(Expression.PLAYFUL, EmotionResolver.resolve(reply("That's cute 😏", Emotion.NEUTRAL), false).expression) }
    @Test fun negatedMoodWordIsIgnored() { assertNotEquals(Expression.ANGRY, EmotionResolver.resolve(reply("I'm not angry at all", Emotion.NEUTRAL), false).expression) }
    @Test fun studyModeSticks() { assertEquals(Expression.STUDY, EmotionResolver.resolve(reply("Sure, let's keep going"), true).expression) }
    @Test fun studyModeIsDerivedFromTheChat() {
        fun m(id: Long, t: String) = ChatMessage(id, 1, ChatMessage.Role.USER, t, null, null, 0)
        assertTrue(StudyMode.isActive(listOf(m(1, "study mode please")), "go on"))
        assertFalse(StudyMode.isActive(listOf(m(1, "study mode please"), m(2, "stop studying")), "hi"))
    }
    @Test fun userReactionIsEmpathetic() { assertEquals(Expression.SLEEPY, EmotionResolver.reactionTo("I'm sad today")); assertNull(EmotionResolver.reactionTo("what time is it")) }
}

class ToolValidatorTest {
    private val spec = listOf(ToolArg("title", ArgType.TEXT, max = 10), ToolArg("time", ArgType.ISO_TIME), ToolArg("repeat", ArgType.TEXT, false, allowed = setOf("daily", "weekly")))
    @Test fun acceptsValidArguments() {
        val r = ToolValidator.validate(spec, JSONObject("""{"title":"call","time":"2026-11-05T09:00","repeat":"Daily"}"""))
        assertTrue(r.isSuccess); assertEquals("daily", r.getOrThrow().getString("repeat")); assertTrue(r.getOrThrow().getLong("time") > 0)
    }
    @Test fun rejectsBadArguments() {
        assertTrue(ToolValidator.validate(spec, JSONObject("""{"time":"2026-11-05T09:00"}""")).isFailure)            // missing title
        assertTrue(ToolValidator.validate(spec, JSONObject("""{"title":"far too long title","time":"2026-11-05T09:00"}""")).isFailure)
        assertTrue(ToolValidator.validate(spec, JSONObject("""{"title":"x","time":"tomorrow-ish"}""")).isFailure)
        assertTrue(ToolValidator.validate(spec, JSONObject("""{"title":"x","time":"2026-11-05T09:00","repeat":"hourly"}""")).isFailure)
    }
    @Test fun intRangeIsEnforced() {
        val s = listOf(ToolArg("days", ArgType.INT, max = 14, min = 1))
        assertTrue(ToolValidator.validate(s, JSONObject("""{"days":3}""")).isSuccess); assertTrue(ToolValidator.validate(s, JSONObject("""{"days":99}""")).isFailure)
    }
}

class TimeAndModeTest {
    private fun at(h: Int, m: Int) = LocalDateTime.of(2026, 11, 5, h, m).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    @Test fun parsesTimes() { assertNotNull(TimeUtil.parseIso("2026-11-05T09:00")); assertNull(TimeUtil.parseIso("soon")); assertEquals(510, TimeUtil.parseClock("8:30")); assertNull(TimeUtil.parseClock("25:00")) }
    @Test fun nextOccurrenceIsStrictlyInTheFuture() { val n = TimeUtil.nextOccurrence("daily", 9 * 60, at(9, 0)); assertTrue(n > at(9, 0)); assertTrue(n - at(9, 0) <= 25 * 3_600_000L) }
    @Test fun quietHoursWrapPastMidnight() {
        assertTrue(TimeUtil.inQuietHours(at(23, 0), 22 * 60, 7 * 60)); assertTrue(TimeUtil.inQuietHours(at(6, 0), 22 * 60, 7 * 60)); assertFalse(TimeUtil.inQuietHours(at(12, 0), 22 * 60, 7 * 60))
    }
    @Test fun classifiesResponseModes() {
        assertEquals(ResponseMode.TECHNICAL, ResponseMode.classify("my kotlin code crashes with an error"))
        assertEquals(ResponseMode.PLANNING, ResponseMode.classify("help me plan my week"))
        assertEquals(ResponseMode.TRANSLATE, ResponseMode.classify("translate good morning to french"))
        assertEquals(ResponseMode.TUTOR, ResponseMode.classify("hey", studyMode = true))
        assertEquals(ResponseMode.CASUAL, ResponseMode.classify("hey you"))
    }
}

class SearchAndVoiceTest {
    @Test fun searchTokensAndChunks() {
        assertEquals("project* OR studyos*", SearchIndex.matchExpression("what about the project StudyOS?"))
        assertNull(SearchIndex.matchExpression("what is it"))
        val chunks = SearchIndex.chunk("Sentence one. ".repeat(200)); assertTrue(chunks.size > 1); assertTrue(chunks.all { it.length <= 800 })
    }
    @Test fun speechTextIsSanitisedAndSplit() {
        assertEquals("Hey link", SpeechOutput.sanitize("**Hey** 😊 https://example.com"))
        val pieces = SpeechOutput.split("One short one. Two is short too. " + "word ".repeat(80), 100)
        assertTrue(pieces.all { it.length <= 100 }); assertTrue(pieces.first().startsWith("One short one."))
    }
    @Test fun wavRoundTripAndEnvelope() {
        val pcm = ShortArray(16000) { i -> if (i < 8000) (Math.sin(i / 8.0) * 12000).toInt().toShort() else 0 } // 0.5 s tone, 0.5 s silence
        val clip = WavDecoder.decode(Wav.encode(pcm, 16000))!!
        assertEquals(16000, clip.sampleRate); assertEquals(1, clip.channels); assertEquals(pcm.size, clip.pcm.size)
        assertTrue(clip.envelope.first() > 0.5f); assertEquals(0f, clip.envelope.last(), 0.001f)
        assertNull(WavDecoder.decode(ByteArray(10)))
    }
}
