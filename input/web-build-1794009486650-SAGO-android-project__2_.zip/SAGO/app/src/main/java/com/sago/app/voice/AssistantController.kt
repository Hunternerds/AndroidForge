package com.sago.app.voice

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.sago.app.avatar.AvatarMode
import com.sago.app.avatar.AvatarUi
import com.sago.app.avatar.Expression
import com.sago.app.data.groq.GroqError
import com.sago.app.data.prefs.Keys
import com.sago.app.data.prefs.SettingsStore
import com.sago.app.domain.ai.ConversationEngine
import com.sago.app.domain.ai.EmotionResolver
import com.sago.app.domain.ai.Turn
import com.sago.app.domain.model.AiReply
import com.sago.app.domain.model.PickedImage
import com.sago.app.wake.MicStream
import com.sago.app.wake.WakeCoordinator
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.io.IOException

enum class AssistantState { IDLE, LISTENING, THINKING, SPEAKING }

data class UiError(val message: String, val canRetry: Boolean = false, val openAiSettings: Boolean = false)

/**
 * App-wide orchestrator for the pipeline  mic → recogniser → conversation engine → Groq → reply → TTS → avatar.
 * Text and voice (push-to-talk and wake-word) all run through [runTurn], so they share one engine and one history.
 * It lives at application scope so a wake-word session can complete even when the UI isn't visible.
 */
class AssistantController(
    private val context: Context,
    private val scope: CoroutineScope,
    private val settings: SettingsStore,
    private val engine: ConversationEngine,
    val voice: SpeechOutput,
    private val stt: SpeechRecognizerController,
    private val speech: SpeechToText,
    private val recorder: UtteranceRecorder,
    private val wake: WakeCoordinator,
) {
    val state = MutableStateFlow(AssistantState.IDLE)
    val avatar = MutableStateFlow(AvatarUi())
    val partial = MutableStateFlow("")
    val micLevel = MutableStateFlow(0f)
    val error = MutableStateFlow<UiError?>(null)
    /** True while a finished recording is being turned into text. */
    val transcribing = MutableStateFlow(false)
    val activeConversation = MutableStateFlow(0L)
    val mouthOpen get() = voice.mouthOpen
    val mouthLevel get() = voice.mouthLevel

    private var job: Job? = null
    private var decayJob: Job? = null
    private var lastTurn: Turn? = null

    init {
        scope.launch { activeConversation.value = settings.snapshot().activeConversation }
        scope.launch { stt.level.collect { micLevel.value = it } }
        scope.launch { stt.partial.collect { if (state.value == AssistantState.LISTENING) partial.value = it } }
        scheduleDecay()
    }

    // ───────── public actions ─────────

    fun sendText(text: String, images: List<PickedImage>) {
        if (text.isBlank() && images.isEmpty()) return
        launchTurn {
            react(text)
            setState(AssistantState.THINKING)
            val turn = engine.begin(activeConversation.value, text, images, viaWake = false)
            setActive(turn.conversationId)
            runTurn(turn)
        }
    }

    /** Push-to-talk. Requires RECORD_AUDIO (checked by the UI). */
    fun startVoice() {
        launchTurn {
            wake.manualMic.value = true
            try {
                setState(AssistantState.LISTENING)
                val s = settings.snapshot()
                val transcript = if (s.sttEngine == "device") stt.listen(s.preferOfflineStt) else listenAccurately()
                if (transcript.isNullOrBlank()) {
                    error.value = UiError("I didn't catch anything. Tap the mic and try again.")
                    return@launchTurn
                }
                processTranscript(transcript, viaWake = false)
            } finally {
                wake.manualMic.value = false
                transcribing.value = false
            }
        }
    }

    /** Records with voice-activity detection, then transcribes with Groq Whisper (offline fallback isn't available here). */
    private suspend fun listenAccurately(): String? {
        delay(250) // give the wake-word loop a moment to release the microphone
        val pcm: ShortArray? = try {
            withContext(Dispatchers.IO) {
                MicStream().use { mic ->
                    recorder.record(mic, null, 7_000, 30_000, onLevel = { micLevel.value = it }, cancelled = { !isActive })
                }
            }
        } catch (e: IOException) {
            throw SpeechError("Couldn't use the microphone. Check the permission in Settings → Privacy, or close other apps that are recording.")
        }
        if (pcm == null) return null
        transcribing.value = true
        try { return speech.transcribe(pcm, null) } finally { transcribing.value = false }
    }

    fun retry() {
        val t = lastTurn ?: return
        launchTurn { setState(AssistantState.THINKING); runTurn(t) }
    }

    /** Interrupts listening, thinking or speaking immediately. */
    fun stop() {
        job?.cancel(); job = null
        voice.stop(); stt.cancel()
        wake.manualMic.value = false
        resetIdle()
    }

    fun newConversation() { stop(); setActive(0L); error.value = null }

    fun openConversation(id: Long) { stop(); setActive(id); error.value = null }

    fun dismissError() { error.value = null }

    // ───────── wake-word session hooks (called by WakeWordService) ─────────

    fun onWakeDetected() {
        job?.cancel(); voice.stop(); error.value = null; partial.value = ""
        setState(AssistantState.LISTENING)
        buzz()
    }

    fun setTranscribing(on: Boolean) { transcribing.value = on }
    fun onWakeError(e: Throwable) { reportError(e); transcribing.value = false; partial.value = ""; micLevel.value = 0f; setState(AssistantState.IDLE); scheduleDecay() }
    fun onFollowUpListening() { partial.value = ""; setState(AssistantState.LISTENING) }
    fun onWakePartial(text: String) { partial.value = text }
    fun onWakeLevel(level: Float) { micLevel.value = level }
    fun onWakeEnded() { transcribing.value = false; if (state.value == AssistantState.LISTENING) { partial.value = ""; micLevel.value = 0f; setState(AssistantState.IDLE); scheduleDecay() } }

    /** Processes text captured by the offline engine and suspends until SAGO has finished answering. */
    suspend fun handleWakeTranscript(text: String) {
        launchTurn { processTranscript(text, viaWake = true) }.join()
    }

    // ───────── internals ─────────

    private suspend fun processTranscript(text: String, viaWake: Boolean) {
        partial.value = ""
        react(text)
        setState(AssistantState.THINKING)
        val turn = engine.begin(activeConversation.value, text, emptyList(), viaWake)
        setActive(turn.conversationId)
        runTurn(turn)
    }

    private suspend fun runTurn(turn: Turn) {
        lastTurn = turn
        val reply = engine.complete(turn)
        present(reply)
    }

    private suspend fun present(reply: AiReply) {
        val s = settings.snapshot()
        avatar.update { it.copy(expression = reply.expression, emotion = reply.emotion) }
        if (s.speakReplies && reply.text.isNotBlank()) {
            var noticed = false
            try {
                // Stays in "thinking" while the voice is being prepared; flips to "speaking" when sound really starts.
                voice.speak(reply.text, reply.emotion, reply.voice,
                    onNotice = { msg -> if (!noticed) { noticed = true; error.value = UiError(msg) } },
                    onFirstAudio = { setState(AssistantState.SPEAKING) })
            } catch (e: SpeechError) {
                error.value = UiError(e.message ?: "Couldn't speak the reply.")
            }
        }
        setState(AssistantState.IDLE)
        scheduleDecay()
    }

    /** Context-aware reaction: the avatar softens, smiles or blushes in response to what the user just said, before SAGO replies. */
    private fun react(userText: String) {
        EmotionResolver.reactionTo(userText)?.let { e -> avatar.update { it.copy(expression = e) } }
    }

    private fun launchTurn(block: suspend () -> Unit): Job {
        job?.cancel(); voice.stop(); stt.cancel()
        error.value = null
        val j = scope.launch {
            try { block() }
            catch (e: CancellationException) { throw e }
            catch (e: Throwable) { reportError(e) }
        }
        job = j
        j.invokeOnCompletion { if (job === j) { wake.manualMic.value = false; scope.launch { resetIdle() } } }
        return j
    }

    private fun reportError(e: Throwable) {
        error.value = when (e) {
            is GroqError.InvalidKey, is GroqError.MissingKey -> UiError(e.message.orEmpty(), canRetry = false, openAiSettings = true)
            is GroqError.ModelUnavailable -> UiError(e.message.orEmpty(), canRetry = false, openAiSettings = true)
            is GroqError -> UiError(e.userMessage, canRetry = true)
            is SpeechError -> UiError(e.message.orEmpty())
            else -> UiError("Something went wrong: ${e.message ?: e::class.simpleName}", canRetry = lastTurn != null)
        }
    }

    private fun resetIdle() {
        partial.value = ""; micLevel.value = 0f
        if (state.value != AssistantState.IDLE) setState(AssistantState.IDLE)
        scheduleDecay()
    }

    private fun setActive(id: Long) {
        activeConversation.value = id
        scope.launch { settings.set(Keys.ACTIVE_CONVERSATION, id) }
    }

    private fun setState(s: AssistantState) {
        state.value = s
        avatar.update {
            val mode = when (s) {
                AssistantState.IDLE -> AvatarMode.IDLE; AssistantState.LISTENING -> AvatarMode.LISTENING
                AssistantState.THINKING -> AvatarMode.THINKING; AssistantState.SPEAKING -> AvatarMode.SPEAKING
            }
            // Keep the current mood visible while listening/thinking; only a neutral face switches to the "thinking" face.
            val expr = if (s == AssistantState.THINKING && it.expression == Expression.NORMAL) Expression.THINKING else it.expression
            it.copy(mode = mode, expression = expr)
        }
        if (s != AssistantState.IDLE) decayJob?.cancel()
    }

    /**
     * Mood persists through the conversation: SAGO keeps her last expression and only relaxes to neutral after a
     * few quiet minutes, and looks sleepy after a long one. A new reply always sets a fresh expression.
     */
    private fun scheduleDecay() {
        decayJob?.cancel()
        decayJob = scope.launch {
            delay(3 * 60_000L)
            if (state.value == AssistantState.IDLE) avatar.update { it.copy(expression = Expression.NORMAL, emotion = com.sago.app.domain.model.Emotion.NEUTRAL) }
            delay(7 * 60_000L)
            if (state.value == AssistantState.IDLE) avatar.update { it.copy(expression = Expression.SLEEPY) }
        }
    }

    @Suppress("DEPRECATION")
    private fun buzz() = runCatching {
        val v = if (Build.VERSION.SDK_INT >= 31)
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        else context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        v.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
    }
}
