package com.sago.app.domain.ai

import android.util.Base64
import com.sago.app.avatar.Expression
import com.sago.app.core.Connectivity
import com.sago.app.core.Diagnostics
import com.sago.app.data.ChatRepository
import com.sago.app.data.DocumentRepository
import com.sago.app.data.groq.*
import com.sago.app.data.prefs.AppSettings
import com.sago.app.data.prefs.SettingsStore
import com.sago.app.domain.memory.LocalCommand
import com.sago.app.domain.memory.MemoryCommandParser
import com.sago.app.domain.memory.MemoryEngine
import com.sago.app.domain.model.AiReply
import com.sago.app.domain.model.ChatMessage
import com.sago.app.domain.model.Emotion
import com.sago.app.domain.model.PickedImage
import com.sago.app.domain.tools.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import org.json.JSONObject

/** A user message that has been stored and is waiting for (or retrying) a reply. */
data class Turn(
    val conversationId: Long,
    val profileId: String,
    val userMessageId: Long,
    val text: String,
    val images: List<PickedImage>,
    val viaWake: Boolean,
)

/**
 * The single AI engine shared by typed chat and voice. One coherent SAGO, with a small internal workflow:
 *  Planner (local: command parsing, reply mode, retrieval) → Responder (one structured Groq call, which also proposes
 *  memories and tool actions) → Executor (validated tools, real results) → optional follow-up call when a tool returned
 *  data → Verifier (local: no claiming actions that didn't happen, no phantom sources) → persist.
 * At most two chat calls per turn (plus one inside the web-research tool); on any problem it degrades to a plain reply.
 */
class ConversationEngine(
    private val settings: SettingsStore,
    private val groq: GroqClient,
    private val repo: ChatRepository,
    private val memory: MemoryEngine,
    private val docs: DocumentRepository,
    private val tools: ToolRegistry,
    private val summarizer: ConversationSummarizer,
    private val connectivity: Connectivity,
    private val diag: Diagnostics,
    private val scope: CoroutineScope,
) {
    suspend fun begin(conversationId: Long, text: String, images: List<PickedImage>, viaWake: Boolean): Turn {
        val s = settings.snapshot()
        val shown = MemoryCommandParser.stripWake(text, viaWake)
        val cid = conversationId.takeIf { it != 0L && repo.conversation(it, s.activeProfile) != null }
            ?: repo.createConversation(s.activeProfile, shown.ifBlank { "Photo" })
        val mid = repo.addMessage(cid, ChatMessage.Role.USER, shown, imagePath = images.joinToString("|") { it.savedPath }.ifBlank { null })
        return Turn(cid, s.activeProfile, mid, text, images, viaWake)
    }

    suspend fun complete(turn: Turn): AiReply {
        val s = settings.snapshot()
        val cleanText = MemoryCommandParser.stripWake(turn.text, turn.viaWake)

        // ── Planner: local commands never need the network ──
        val cmd = MemoryCommandParser.parseCommand(turn.text, turn.viaWake)
        if (cmd is LocalCommand.Forget) return localForget(turn, cmd)
        if (cmd is LocalCommand.Recall) localRecall(turn, cmd)?.let { return it }
        val saved = (cmd as? LocalCommand.Remember)?.let { runCatching { memory.saveExplicit(turn.profileId, it.info) }.getOrNull() }

        // ── Planner: gather only what's relevant (compact context) ──
        val convo = repo.conversationById(turn.conversationId)
        val summarizedUpTo = convo?.summarizedUpTo ?: 0L
        val recentAll = runCatching { repo.recent(turn.conversationId, maxOf(s.historyLimit + 1, 40)) }.getOrDefault(emptyList()).filter { it.id != turn.userMessageId }
        val history = recentAll.filter { it.id > summarizedUpTo }.takeLast(s.historyLimit)
        val studyMode = StudyMode.isActive(recentAll, cleanText)
        val mood = recentAll.lastOrNull { it.role == ChatMessage.Role.ASSISTANT }?.emotion
        val memories = runCatching { memory.relevant(turn.profileId, cleanText) }.getOrDefault(emptyList())
        val snippets = runCatching { docs.retrieve(turn.profileId, cleanText, 3) }.getOrDefault(emptyList())
        val mode = ResponseMode.fromKey(s.replyStyle) ?: ResponseMode.classify(cleanText, studyMode)
        val wantTitle = convo != null && !convo.titleByAi && recentAll.none { it.role == ChatMessage.Role.ASSISTANT }

        val system = PromptBuilder.system(PromptContext(
            personality = PersonalityDefaults.resolve(s.systemPrompt), memories = memories, autoMemory = s.autoMemory && cmd !is LocalCommand.Remember,
            justSaved = saved?.text, imageCount = turn.images.size, mood = mood, mode = mode, summary = convo?.summary, snippets = snippets,
            toolsHelp = if (s.toolsEnabled) tools.help(s.allowWeb) else "", wantTitle = wantTitle, offline = !connectivity.online.value,
        ))
        val urls = turn.images.map { "data:image/jpeg;base64," + Base64.encodeToString(it.jpeg, Base64.NO_WRAP) }
        val turns = buildList {
            add(ChatTurn("system", system))
            var budget = HISTORY_CHAR_BUDGET
            history.asReversed().takeWhile { budget -= it.text.length; budget > 0 }.asReversed().forEach {
                add(ChatTurn(if (it.role == ChatMessage.Role.USER) "user" else "assistant", if (it.imagePaths.isNotEmpty()) "[shared ${it.imagePaths.size} image(s)] ${it.text}" else it.text))
            }
            add(ChatTurn("user", cleanText.ifBlank { if (urls.size > 1) "Compare these images." else "What do you see in this image?" }, urls))
        }
        val model = if (turn.images.isNotEmpty()) s.visionModel else s.textModel

        // ── Responder ──
        val first = try { callModel(s, model, turns, allowFallback = turn.images.isEmpty()) }
        catch (e: GroqError) {
            if (saved != null) return finish(turn, AiReply("Got it — I've saved that to memory. I couldn't reach Groq for a proper reply though.", Emotion.CALM, "memory", Expression.HAPPY), emptyList(), emptyList(), false)
            if (turn.images.isNotEmpty() && e is GroqError.ModelUnavailable) throw GroqError.Unknown("image analysis isn't available because the vision model “$model” can't be used. Choose another vision model in Settings → AI.")
            throw e
        }
        var reply = ReplyParser.parse(first.text)

        // ── Executor (+ optional follow-up when a read tool returned data) ──
        var outcomes: List<ToolOutcome> = emptyList()
        if (s.toolsEnabled && reply.actions.isNotEmpty()) {
            val tctx = ToolContext(turn.profileId, turn.conversationId, s.textModel, s.allowWeb)
            outcomes = tools.run(reply.actions, tctx)
            if (outcomes.any { it.readOnly }) {
                val followTurns = turns + ChatTurn("assistant", first.text) + ChatTurn("user", toolResultsMessage(outcomes))
                runCatching { callModel(s, model, followTurns, allowFallback = turn.images.isEmpty()) }.getOrNull()?.let { second ->
                    val r2 = ReplyParser.parse(second.text)
                    val extraWrites = r2.actions.filter { !tools.isReadOnly(it.tool) }
                    val outcomes2 = if (extraWrites.isNotEmpty()) tools.run(extraWrites, tctx) else emptyList()
                    outcomes = outcomes.filter { !it.readOnly } + outcomes.filter { it.readOnly && !it.ok } + outcomes2
                    reply = r2.copy(title = r2.title ?: reply.title, memories = r2.memories.ifEmpty { reply.memories })
                }
            }
        }

        // ── Verifier + emotion reconciliation (local) ──
        val look = EmotionResolver.resolve(reply, studyMode)
        val text = ReplyVerifier.check(reply.text.ifBlank { outcomes.firstOrNull { !it.readOnly || !it.ok }?.message ?: "…" }, outcomes)
        reply = reply.copy(text = text, emotion = look.emotion, expression = look.expression)
        val usedSources = reply.sourceIds.mapNotNull { id -> snippets.firstOrNull { it.id == id }?.title }.distinct()

        if (s.autoMemory && cmd !is LocalCommand.Remember) reply.memories.forEach { runCatching { memory.saveAuto(turn.profileId, it) } }
        if (wantTitle) reply.title?.let { runCatching { repo.setAiTitle(turn.conversationId, it) } }
        return finish(turn, reply, outcomes, usedSources, true)
    }

    // ── Local, offline answers ──

    private suspend fun localForget(turn: Turn, cmd: LocalCommand.Forget): AiReply {
        if (cmd.all) {
            return finishLocal(turn, "That's everything I know about you. Are you sure? Tap Confirm below and I'll erase it all.",
                card = CardMeta.confirm(ConfirmSpec("clear_memories", JSONObject(), "Erase all memories for this profile?")), cardText = "Erase all memories for this profile?")
        }
        val match = memory.findToForget(turn.profileId, cmd.query).firstOrNull()?.first
            ?: return finishLocal(turn, "Hmm, I don't have anything saved that matches “${cmd.query}”.")
        memory.delete(match.id)
        return finishLocal(turn, "Okay, I've forgotten that: “${match.text}”.",
            card = CardMeta.undo(UndoSpec("restore_memory", CardMeta.memoryToJson(match))), cardText = "Forgot: “${match.text}”")
    }

    private suspend fun localRecall(turn: Turn, cmd: LocalCommand.Recall): AiReply? {
        if (cmd.soft && cmd.topic != null && memory.search(turn.profileId, cmd.topic, 3).isEmpty()) return null // let the model answer
        return finishLocal(turn, memory.recallText(turn.profileId, cmd.topic))
    }

    private suspend fun finishLocal(turn: Turn, text: String, card: String? = null, cardText: String? = null): AiReply {
        val reply = AiReply(text, Emotion.CALM, "memory", Expression.NORMAL)
        repo.addMessage(turn.conversationId, ChatMessage.Role.ASSISTANT, text, reply.emotion)
        if (card != null) repo.addMessage(turn.conversationId, ChatMessage.Role.TOOL, cardText ?: "", meta = card)
        return reply
    }

    // ── Helpers ──

    private suspend fun callModel(s: AppSettings, model: String, turns: List<ChatTurn>, allowFallback: Boolean): ChatResult = try {
        groq.chat(ChatRequest(model, turns, s.temperature, s.maxTokens))
    } catch (e: GroqError.ModelUnavailable) {
        val fb = s.fallbackModel
        if (allowFallback && fb.isNotBlank() && fb != model) { diag.count("model.fallbacks"); groq.chat(ChatRequest(fb, turns, s.temperature, s.maxTokens)) } else throw e
    }

    private fun toolResultsMessage(outcomes: List<ToolOutcome>) = buildString {
        append("[Results from the app. This is real data; rely only on it and say plainly if something failed.]\n")
        outcomes.forEach { o -> append("• ").append(o.tool).append(": ").append(if (o.ok) (o.data ?: o.message) else "FAILED — ${o.message}").append('\n') }
        append("Now answer the user using these results. Do not call read tools again.")
    }

    private suspend fun finish(turn: Turn, reply: AiReply, outcomes: List<ToolOutcome>, sources: List<String>, scheduleSummary: Boolean): AiReply {
        repo.addMessage(turn.conversationId, ChatMessage.Role.ASSISTANT, reply.text, reply.emotion, sources = sources)
        outcomes.filter { !(it.readOnly && it.ok) }.forEach { o ->
            val meta = o.confirm?.let { CardMeta.confirm(it) } ?: o.undo?.let { CardMeta.undo(it) }
            repo.addMessage(turn.conversationId, ChatMessage.Role.TOOL, if (o.ok) o.message else "⚠️ ${o.message}", meta = meta)
        }
        if (scheduleSummary) scope.launch { summarizer.maybeSummarize(turn.conversationId) }
        return reply
    }

    private companion object { const val HISTORY_CHAR_BUDGET = 6000 }
}

/** Local verifier: stops SAGO from claiming an action that the app didn't actually perform. */
object ReplyVerifier {
    private val claim = Regex("\\b(i'?ve|i have|i just|i'?ll go ahead and|done[,.!]?)\\b[^.!?\\n]{0,50}\\b(set|created|scheduled|added|saved|noted|marked)\\b[^.!?\\n]{0,50}\\b(reminder|routine|task|note|alarm)\\b", RegexOption.IGNORE_CASE)
    private val writeTools = setOf("create_reminder", "create_routine", "create_task", "create_note", "complete_task")

    fun check(text: String, outcomes: List<ToolOutcome>): String {
        val didSomething = outcomes.any { it.ok && it.tool in writeTools }
        return if (claim.containsMatchIn(text) && !didSomething) "$text\n(Heads-up: I wasn't actually able to do that, so nothing was saved or scheduled.)" else text
    }
}
