package com.sago.app.voice

import java.nio.ByteBuffer
import java.nio.ByteOrder

object Wav {
    /** Wraps 16-bit mono PCM in a standard 44-byte-header WAV container. */
    fun encode(pcm: ShortArray, sampleRate: Int): ByteArray {
        val dataLen = pcm.size * 2
        val buf = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        buf.put("RIFF".toByteArray()).putInt(36 + dataLen).put("WAVE".toByteArray())
        buf.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1).putInt(sampleRate).putInt(sampleRate * 2).putShort(2).putShort(16)
        buf.put("data".toByteArray()).putInt(dataLen)
        pcm.forEach { buf.putShort(it) }
        return buf.array()
    }
}
