package com.sago.app.reminders

import android.content.Context
import androidx.work.*
import com.sago.app.data.db.ReminderEntity
import java.util.concurrent.TimeUnit

/**
 * Schedules reminders and routines with WorkManager (survives restarts and reboots). WorkManager is battery-friendly
 * but not exact: during Doze a reminder can arrive a few minutes late.
 */
class ReminderScheduler(private val ctx: Context) {
    private val wm get() = WorkManager.getInstance(ctx)

    fun schedule(r: ReminderEntity) {
        val delay = (r.triggerAt - System.currentTimeMillis()).coerceAtLeast(0)
        val req = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS).setInputData(workDataOf("id" to r.id)).build()
        wm.enqueueUniqueWork("reminder-${r.id}", ExistingWorkPolicy.REPLACE, req)
    }

    fun cancel(id: Long) { wm.cancelUniqueWork("reminder-$id") }

    fun cancelAll() { wm.cancelAllWork() }

    /** Daily housekeeping: expire/merge memories, apply data retention, repair the search index. */
    fun scheduleMaintenance() {
        val req = PeriodicWorkRequestBuilder<MaintenanceWorker>(24, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).build()).build()
        wm.enqueueUniquePeriodicWork("sago-maintenance", ExistingPeriodicWorkPolicy.KEEP, req)
    }
}
