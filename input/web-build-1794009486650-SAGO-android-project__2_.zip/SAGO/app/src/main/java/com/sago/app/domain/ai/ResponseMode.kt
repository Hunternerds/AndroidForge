package com.sago.app.domain.ai

/** How SAGO shapes an answer. Chosen automatically from the message (or forced in Settings → AI → Reply style). */
enum class ResponseMode(val key: String, val label: String, val guidance: String) {
    CASUAL("casual", "Casual chat", "Reply conversationally in your texting style; usually one to three short sentences."),
    QUICK("quick", "Quick answers", "The user wants a quick answer: one or two short sentences, no preamble."),
    DETAILED("detailed", "Detailed explanations", "Give a clear, well-organised explanation in short spoken-friendly paragraphs (no markdown)."),
    TECHNICAL("technical", "Technical help", "Technical help: be precise and correct, give concrete steps, and keep any code short and in plain text."),
    TUTOR("tutor", "Learning & tutoring", "Teach step by step: one idea at a time, check understanding, and offer a tiny practice question."),
    BRAINSTORM("brainstorm", "Brainstorming", "Brainstorm: offer several distinct ideas briefly, then ask which one to explore."),
    PLANNING("planning", "Planning", "Planning: give an ordered, realistic plan with priorities or times, and offer to save tasks or reminders."),
    CREATIVE("creative", "Creative writing", "Creative writing: be vivid and original while respecting the requested style and length."),
    TRANSLATE("translate", "Translation", "Translate naturally, preserving tone and meaning; give only the translation unless asked to explain.");

    companion object {
        fun fromKey(key: String): ResponseMode? = entries.firstOrNull { it.key == key }

        /** Cheap local heuristic: no API call. */
        fun classify(text: String, studyMode: Boolean = false): ResponseMode {
            val t = text.lowercase()
            fun has(vararg re: String) = re.any { Regex(it).containsMatchIn(t) }
            return when {
                has("\\btranslate\\b", "how do you say .{1,40} in \\w+") -> TRANSLATE
                has("\\b(code|bug|error|exception|function|compile|compiler|stack ?trace|regex|sql|api|kotlin|python|javascript|android|gradle|crash)\\b") -> TECHNICAL
                studyMode || has("\\b(teach me|quiz me|homework|help me (learn|understand|study)|explain like)\\b") -> TUTOR
                has("\\b(plan|schedule|organi[sz]e|roadmap|to-?do|agenda|itinerary)\\b") -> PLANNING
                has("\\b(brainstorm|ideas?|suggest (some )?(ways|names)|what should i name)\\b") -> BRAINSTORM
                has("\\b(write (me )?a (story|poem|song)|story|poem|lyrics|roleplay|fan ?fic)\\b") -> CREATIVE
                has("\\b(explain|in detail|elaborate|why (does|do|is)|how (does|do) .{3,40} work)\\b") -> DETAILED
                has("\\b(quick(ly)?|briefly|short answer|tl;?dr|in one line|one word)\\b") || (t.length < 28 && t.endsWith("?") && has("^(what|who|when|where|how (many|much|old))")) -> QUICK
                else -> CASUAL
            }
        }
    }
}
