package com.sago.app.reminders

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.sago.app.MainActivity
import com.sago.app.R

object Notifier {
    const val CH_WAKE = "sago_wake_listening"
    const val CH_REMINDERS = "sago_reminders"
    const val CH_PROACTIVE = "sago_proactive"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_WAKE, ctx.getString(R.string.notif_channel_listening), NotificationManager.IMPORTANCE_LOW).apply {
            description = ctx.getString(R.string.notif_channel_listening_desc); setShowBadge(false)
        })
        nm.createNotificationChannel(NotificationChannel(CH_REMINDERS, ctx.getString(R.string.notif_channel_reminders), NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = ctx.getString(R.string.notif_channel_reminders_desc)
        })
        nm.createNotificationChannel(NotificationChannel(CH_PROACTIVE, ctx.getString(R.string.notif_channel_proactive), NotificationManager.IMPORTANCE_LOW).apply {
            description = ctx.getString(R.string.notif_channel_proactive_desc)
        })
    }

    fun canNotify(ctx: Context): Boolean = NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    /** @return false if notifications are blocked (the caller should say so rather than pretend it was delivered). */
    @SuppressLint("MissingPermission")
    fun post(ctx: Context, id: Int, channel: String, title: String, text: String): Boolean {
        if (!canNotify(ctx)) return false
        val open = PendingIntent.getActivity(
            ctx, id, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(ctx, channel).setSmallIcon(R.drawable.ic_stat_sago).setContentTitle(title).setContentText(text.lineSequence().first())
            .setStyle(NotificationCompat.BigTextStyle().bigText(text)).setContentIntent(open).setAutoCancel(true)
            .setPriority(if (channel == CH_REMINDERS) NotificationCompat.PRIORITY_DEFAULT else NotificationCompat.PRIORITY_LOW).build()
        return runCatching { NotificationManagerCompat.from(ctx).notify(id, n) }.isSuccess
    }
}
