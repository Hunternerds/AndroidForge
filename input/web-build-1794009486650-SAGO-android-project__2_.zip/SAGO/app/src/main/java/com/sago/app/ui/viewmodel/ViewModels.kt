package com.sago.app.ui.viewmodel

import android.net.Uri
import android.os.SystemClock
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.sago.app.AppContainer
import com.sago.app.data.ConversationHit
import com.sago.app.data.ImportResult
import com.sago.app.data.db.*
import com.sago.app.data.groq.*
import com.sago.app.data.prefs.*
import com.sago.app.domain.model.ChatMessage
import com.sago.app.domain.model.PickedImage
import com.sago.app.domain.proactive.Suggestion
import com.sago.app.domain.tools.CardMeta
import com.sago.app.domain.tools.TimeUtil
import com.sago.app.voice.AssistantState
import com.sago.app.voice.UiError
import com.sago.app.voice.VoiceInfo
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File

class SagoViewModelFactory(private val c: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when (modelClass) {
        ChatViewModel::class.java -> ChatViewModel(c)
        HistoryViewModel::class.java -> HistoryViewModel(c)
        OnboardingViewModel::class.java -> OnboardingViewModel(c)
        SettingsViewModel::class.java -> SettingsViewModel(c)
        LibraryViewModel::class.java -> LibraryViewModel(c)
        else -> throw IllegalArgumentException("Unknown ViewModel ${modelClass.name}")
    } as T
}

class ChatViewModel(private val c: AppContainer) : ViewModel() {
    val assistant = c.assistant
    val settings = c.settings.flow.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    val wakeStatus = c.wake.status
    val wakeDetail = c.wake.detail
    val online = c.connectivity.online
    val pendingAction = c.pendingAction

    @OptIn(ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<ChatMessage>> = assistant.activeConversation
        .flatMapLatest { id -> if (id == 0L) flowOf(emptyList()) else c.repo.messages(id).catch { emit(emptyList()) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Local, on-device suggestions for the empty chat (only when enabled, and built from saved data). */
    @OptIn(ExperimentalCoroutinesApi::class)
    val suggestions: StateFlow<List<Suggestion>> = combine(settings, assistant.activeConversation, assistant.state) { s, cid, st -> Triple(s, cid, st) }
        .mapLatest { (s, cid, st) -> if (cid == 0L && st == AssistantState.IDLE && s.proactiveSuggestions) c.suggestions.forProfile(s.activeProfile) else emptyList() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val draft = MutableStateFlow<List<PickedImage>>(emptyList())
    val attaching = MutableStateFlow(false)

    init {
        viewModelScope.launch {
            runCatching { c.ensureProfile() }
            c.dbResetNotice?.let { assistant.error.value = UiError(it) }
        }
    }

    fun send(text: String) { assistant.sendText(text.trim(), draft.value); draft.value = emptyList() }
    fun attach(uri: Uri) = loadImage { c.images.fromUri(uri) }
    fun attachFile(file: File) = loadImage { c.images.fromFile(file).also { file.delete() } }
    fun removeDraft(index: Int) { draft.value = draft.value.filterIndexed { i, _ -> i != index } }
    fun consumeAction() { c.pendingAction.value = null }

    fun onSuggestion(s: Suggestion) {
        when (s.kind) {
            "conversation" -> s.payload.toLongOrNull()?.let { assistant.openConversation(it) }
            else -> assistant.sendText(s.payload, emptyList())
        }
    }

    /** Confirm / Cancel / Undo buttons on tool result cards. */
    fun onCardAction(m: ChatMessage, accept: Boolean) {
        val card = CardMeta.parse(m.meta) ?: return
        viewModelScope.launch {
            val profile = settings.value.activeProfile
            val text = when {
                card.kind == "confirm" && accept -> c.toolActions.confirm(profile, card)
                card.kind == "confirm" -> "Cancelled."
                else -> "↩ " + c.toolActions.undo(card)
            }
            runCatching { c.repo.updateCard(m.id, text, null) }
        }
    }

    private fun loadImage(block: suspend () -> PickedImage) {
        if (draft.value.size >= 4) { assistant.error.value = UiError("You can attach up to 4 images at once."); return }
        viewModelScope.launch {
            attaching.value = true
            try { draft.value = draft.value + block() }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { assistant.error.value = UiError(e.message ?: "Couldn't load that image.") }
            finally { attaching.value = false }
        }
    }
}

class HistoryViewModel(private val c: AppContainer) : ViewModel() {
    @OptIn(ExperimentalCoroutinesApi::class)
    val conversations: StateFlow<List<ConversationEntity>> = c.settings.flow.map { it.activeProfile }.distinctUntilChanged()
        .flatMapLatest { c.repo.conversations(it).catch { emit(emptyList()) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val activeId = c.assistant.activeConversation

    val query = MutableStateFlow("")
    /** Natural-language search over past conversations (local full-text search, no network). */
    @OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
    val results: StateFlow<List<ConversationHit>> = query.debounce(250).mapLatest { q ->
        if (q.trim().length < 3) emptyList() else runCatching { c.repo.searchConversations(c.settings.snapshot().activeProfile, q) }.getOrDefault(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun open(id: Long) = c.assistant.openConversation(id)
    fun newChat() = c.assistant.newConversation()
    fun delete(id: Long) {
        viewModelScope.launch {
            runCatching { c.repo.deleteConversation(id) }
            if (c.assistant.activeConversation.value == id) c.assistant.newConversation()
        }
    }
}

sealed interface OnboardingState {
    data object Idle : OnboardingState
    data object Validating : OnboardingState
    data class Initializing(val step: String) : OnboardingState
    data class Error(val message: String) : OnboardingState
}

class OnboardingViewModel(private val c: AppContainer) : ViewModel() {
    val state = MutableStateFlow<OnboardingState>(OnboardingState.Idle)

    fun connect(rawKey: String, onDone: () -> Unit) {
        val key = rawKey.trim()
        if (key.isEmpty()) { state.value = OnboardingState.Error("Paste your Groq API key first."); return }
        viewModelScope.launch {
            try {
                state.value = OnboardingState.Validating
                val models = c.groq.listModels(key) // real request: a bad key or no network fails here, honestly
                state.value = OnboardingState.Initializing("Saving your key securely…")
                if (!c.saveApiKey(key)) throw IllegalStateException("Couldn't store the key in secure storage on this device.")
                state.value = OnboardingState.Initializing("Preparing SAGO…")
                c.ensureProfile()
                val chat = models.map { it.id }.filter { GroqClient.isChatModel(it) }
                if (chat.isEmpty()) throw IllegalStateException("Your Groq account returned no chat models.")
                val text = listOf("openai/gpt-oss-120b", "openai/gpt-oss-20b").firstOrNull { it in chat } ?: chat.first()
                val vision = chat.firstOrNull { GroqClient.looksVisionCapable(it) } ?: DEFAULT_VISION_MODEL
                c.settings.set(Keys.TEXT_MODEL, text)
                c.settings.set(Keys.VISION_MODEL, vision)
                c.settings.set(Keys.ONBOARDED, true)
                state.value = OnboardingState.Idle
                onDone()
            } catch (e: CancellationException) { throw e }
            catch (e: GroqError) { state.value = OnboardingState.Error(e.userMessage) }
            catch (e: Exception) { state.value = OnboardingState.Error(e.message ?: "Something went wrong.") }
        }
    }
}

data class TestResult(val ok: Boolean, val message: String)

class LibraryViewModel(private val c: AppContainer) : ViewModel() {
    private val settings = c.settings.flow.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    private val profile get() = settings.value.activeProfile

    @OptIn(ExperimentalCoroutinesApi::class)
    val entries: StateFlow<List<EntryEntity>> = settings.map { it.activeProfile }.distinctUntilChanged()
        .flatMapLatest { c.entries.observe(it).catch { emit(emptyList()) } }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    @OptIn(ExperimentalCoroutinesApi::class)
    val reminders: StateFlow<List<ReminderEntity>> = settings.map { it.activeProfile }.distinctUntilChanged()
        .flatMapLatest { c.remindersRepo.observe(it).catch { emit(emptyList()) } }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    @OptIn(ExperimentalCoroutinesApi::class)
    val documents: StateFlow<List<DocumentInfo>> = settings.map { it.activeProfile }.distinctUntilChanged()
        .flatMapLatest { c.docs.observe(it).catch { emit(emptyList()) } }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val message = MutableStateFlow<String?>(null)
    val busy = MutableStateFlow(false)
    val summary = MutableStateFlow<Pair<String, String>?>(null)

    fun addNote(title: String, body: String) { viewModelScope.launch { runCatching { c.entries.addNote(profile, title, body) } } }
    fun addTask(title: String, due: Long?) { viewModelScope.launch { runCatching { c.entries.addTask(profile, title, due) } } }
    fun toggleDone(e: EntryEntity) { viewModelScope.launch { runCatching { c.entries.setDone(e.id, !e.done) } } }
    fun editEntry(e: EntryEntity, title: String, body: String) { viewModelScope.launch { runCatching { c.entries.update(e.copy(title = title.take(120), body = body.take(4000))) } } }
    fun deleteEntry(id: Long) { viewModelScope.launch { runCatching { c.entries.delete(id) } } }

    fun addReminder(title: String, at: Long) {
        viewModelScope.launch {
            if (at < System.currentTimeMillis() + 30_000) { message.value = "Pick a time in the future."; return@launch }
            runCatching { c.remindersRepo.create(profile, "reminder", title, triggerAt = at) }.onFailure { message.value = "Couldn't save the reminder." }
        }
    }

    fun addRoutine(title: String, minute: Int, repeat: String, kind: String) {
        viewModelScope.launch {
            val first = TimeUtil.nextOccurrence(repeat, minute, System.currentTimeMillis())
            runCatching { c.remindersRepo.create(profile, kind, title, triggerAt = first, recurrence = repeat, minuteOfDay = minute) }.onFailure { message.value = "Couldn't save the routine." }
        }
    }

    fun setReminderEnabled(id: Long, on: Boolean) { viewModelScope.launch { runCatching { c.remindersRepo.setEnabled(id, on) } } }
    fun deleteReminder(id: Long) { viewModelScope.launch { runCatching { c.remindersRepo.delete(id) } } }

    fun importDocument(uri: Uri) {
        viewModelScope.launch {
            busy.value = true
            message.value = when (val r = c.docs.importUri(profile, uri)) {
                is ImportResult.Added -> "Added “${r.title}” to your vault." + (r.note?.let { " $it" } ?: "")
                is ImportResult.Duplicate -> "“${r.title}” is already in your vault."
                is ImportResult.Failed -> r.message
            }
            busy.value = false
        }
    }

    fun summarizeDocument(info: DocumentInfo) {
        viewModelScope.launch {
            busy.value = true
            try { summary.value = info.title to c.docs.summarize(info.id) }
            catch (e: GroqError) { message.value = e.userMessage }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { message.value = "Couldn't summarise: ${e.message}" }
            finally { busy.value = false }
        }
    }

    fun deleteDocument(id: Long) { viewModelScope.launch { runCatching { c.docs.delete(id) } } }
}

class SettingsViewModel(private val c: AppContainer) : ViewModel() {
    val settings = c.settings.flow.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    // AI
    val models = MutableStateFlow<List<GroqModel>>(emptyList())
    /** Unfiltered live list (includes speech models such as Whisper). */
    val allModels = MutableStateFlow<List<GroqModel>>(emptyList())
    val modelsBusy = MutableStateFlow(false)
    val testing = MutableStateFlow(false)
    val testResult = MutableStateFlow<TestResult?>(null)
    val keyMask = MutableStateFlow(c.maskedKey())
    val keyMessage = MutableStateFlow<TestResult?>(null)

    // Voice
    val voices = MutableStateFlow<List<VoiceInfo>>(emptyList())
    val modelState = c.wakeModel.state
    val wakeStatus = c.wake.status
    val wakeDetail = c.wake.detail
    val voiceTestMessage = MutableStateFlow<String?>(null)

    // Memory / profiles
    @OptIn(ExperimentalCoroutinesApi::class)
    val memories: StateFlow<List<MemoryEntity>> = c.settings.flow.map { it.activeProfile }.distinctUntilChanged()
        .flatMapLatest { c.memory.observe(it).catch { emit(emptyList()) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val profiles: StateFlow<List<ProfileEntity>> = c.repo.profiles().catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val exportMessage = MutableStateFlow<String?>(null)

    fun <T> set(key: Preferences.Key<T>, value: T) { viewModelScope.launch { c.settings.set(key, value) } }
    fun resetPrompt() { viewModelScope.launch { c.settings.remove(Keys.SYSTEM_PROMPT) } }

    fun refreshModels() {
        viewModelScope.launch {
            modelsBusy.value = true
            try { val all = c.groq.listModels(); allModels.value = all.sortedBy { it.id }; models.value = all.filter { GroqClient.isChatModel(it.id) }.sortedBy { it.id } }
            catch (e: GroqError) { testResult.value = TestResult(false, e.userMessage) }
            catch (e: CancellationException) { throw e }
            finally { modelsBusy.value = false }
        }
    }

    fun testConnection() {
        viewModelScope.launch {
            testing.value = true; testResult.value = null
            try {
                val s = settings.value
                val list = c.groq.listModels()
                allModels.value = list.sortedBy { it.id }
                models.value = list.filter { GroqClient.isChatModel(it.id) }.sortedBy { it.id }
                val t0 = SystemClock.elapsedRealtime()
                c.groq.chat(ChatRequest(s.textModel, listOf(ChatTurn("user", "Reply with the single word OK.")), 0f, 32, jsonMode = false))
                val ms = SystemClock.elapsedRealtime() - t0
                testResult.value = TestResult(true, "Connected. ${list.size} models available; “${s.textModel}” answered in $ms ms.")
            } catch (e: GroqError) { testResult.value = TestResult(false, e.userMessage) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { testResult.value = TestResult(false, e.message ?: "Test failed.") }
            finally { testing.value = false }
        }
    }

    fun saveKey(newKey: String) {
        val key = newKey.trim()
        if (key.isEmpty()) { keyMessage.value = TestResult(false, "Paste a key first."); return }
        viewModelScope.launch {
            keyMessage.value = TestResult(true, "Verifying with Groq…")
            try {
                c.groq.listModels(key)
                if (!c.saveApiKey(key)) { keyMessage.value = TestResult(false, "Couldn't store the key securely on this device."); return@launch }
                keyMask.value = c.maskedKey()
                keyMessage.value = TestResult(true, "Key verified and saved.")
                refreshModels()
            } catch (e: GroqError) { keyMessage.value = TestResult(false, e.userMessage) }
            catch (e: CancellationException) { throw e }
        }
    }

    fun loadVoices() { viewModelScope.launch { voices.value = c.tts.voices() } }

    /** Plays a sample with the voice currently selected, reporting honestly if the Groq voice isn't usable. */
    fun testVoice() {
        viewModelScope.launch {
            voiceTestMessage.value = null
            try {
                c.voice.speak("Hi, I'm Sago. This is how I sound.", com.sago.app.domain.model.Emotion.HAPPY, com.sago.app.domain.model.VoiceStyle(),
                    onNotice = { voiceTestMessage.value = it }, onFirstAudio = {})
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { voiceTestMessage.value = e.message ?: "Couldn't play the sample." }
        }
    }
    fun stopVoiceTest() = c.voice.stop()

    fun downloadVoiceModel() { viewModelScope.launch { c.wakeModel.download() } }
    fun deleteVoiceModel() { c.wakeModel.delete() }

    // Memory
    fun addMemory(text: String) { viewModelScope.launch { runCatching { c.memory.addManual(settings.value.activeProfile, text) } } }
    fun editMemory(m: MemoryEntity, text: String) { viewModelScope.launch { runCatching { c.memory.edit(m, text) } } }
    fun deleteMemory(id: Long) { viewModelScope.launch { runCatching { c.memory.delete(id) } } }
    fun clearMemories() { viewModelScope.launch { runCatching { c.memory.clear(settings.value.activeProfile) } } }
    fun consolidateMemories() { viewModelScope.launch { runCatching { c.memory.consolidate(settings.value.activeProfile) } } }

    fun createProfile(name: String) { viewModelScope.launch { runCatching { c.repo.createProfile(name) } } }
    fun switchProfile(id: String) { viewModelScope.launch { c.settings.set(Keys.ACTIVE_PROFILE, id); c.assistant.newConversation() } }
    fun deleteProfile(id: String) {
        viewModelScope.launch {
            val others = profiles.value.filter { it.id != id }
            if (others.isEmpty()) return@launch
            if (settings.value.activeProfile == id) switchProfile(others.first().id)
            runCatching { c.data.deleteProfile(id) }
        }
    }

    // Assistant (proactive)
    fun setProactiveNotifications(on: Boolean) {
        viewModelScope.launch {
            c.settings.set(Keys.PROACTIVE_NOTIFICATIONS, on)
            runCatching { c.remindersRepo.ensureBriefing(settings.value.activeProfile, settings.value.briefingMinute, on) }
        }
    }
    fun setBriefingTime(minute: Int) {
        viewModelScope.launch {
            c.settings.set(Keys.BRIEFING_MINUTE, minute)
            if (settings.value.proactiveNotifications) runCatching { c.remindersRepo.ensureBriefing(settings.value.activeProfile, minute, true) }
        }
    }

    // Diagnostics
    val diagnosticsReport = MutableStateFlow(c.diagnostics.report())
    val diagnosticsLogs = MutableStateFlow(c.diagnostics.recentLogs())
    fun refreshDiagnostics() { diagnosticsReport.value = c.diagnostics.report(); diagnosticsLogs.value = c.diagnostics.recentLogs() }

    // Privacy
    fun deleteConversations() {
        viewModelScope.launch { runCatching { c.repo.deleteAllConversations(settings.value.activeProfile) }; c.assistant.newConversation() }
    }

    /** Writes the current profile's data as JSON to a file the user picked. */
    fun exportData(uri: Uri) {
        viewModelScope.launch {
            exportMessage.value = try {
                val json = c.data.exportJson(settings.value.activeProfile)
                withContext(Dispatchers.IO) { c.appContext.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) } ?: error("Couldn't open the file") }
                "Exported to the file you chose. It doesn't include your API key or photos."
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { "Export failed: ${e.message}" }
        }
    }

    fun deleteApiKey(onDone: () -> Unit) {
        viewModelScope.launch {
            c.assistant.stop()
            c.clearApiKey()
            c.settings.set(Keys.ONBOARDED, false)
            c.settings.set(Keys.WAKE_ENABLED, false)
            keyMask.value = ""
            onDone()
        }
    }

    fun resetEverything(onDone: () -> Unit) {
        viewModelScope.launch {
            c.assistant.stop()
            runCatching { c.data.wipeAll() }
            c.wakeModel.delete()
            c.clearApiKey()
            c.settings.clearAll()
            keyMask.value = ""
            onDone()
        }
    }
}
