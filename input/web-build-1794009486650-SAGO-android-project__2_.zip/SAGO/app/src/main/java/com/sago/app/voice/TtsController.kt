package com.sago.app.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class VoiceInfo(val name: String, val label: String, val offline: Boolean)

/**
 * Android's built-in TextToSpeech used purely as a *synthesiser*: it renders text to a WAV file and [SpeechOutput]
 * plays it. Owning the playback is what makes real, amplitude-based lip-sync possible with any engine.
 */
class TtsController(private val context: Context) {
    private var tts: TextToSpeech? = null
    private val ids = AtomicInteger()
    private val waiters = ConcurrentHashMap<String, CancellableContinuation<Unit>>()

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) { finish(utteranceId, null) }
        @Deprecated("Deprecated in Java") override fun onError(utteranceId: String?) { finish(utteranceId, SpeechError("Text-to-speech failed.")) }
        override fun onError(utteranceId: String?, errorCode: Int) { finish(utteranceId, SpeechError("Text-to-speech failed (code $errorCode).")) }
        override fun onStop(utteranceId: String?, interrupted: Boolean) { finish(utteranceId, if (interrupted) SpeechError("Speech was interrupted.") else null) }
    }

    private fun finish(id: String?, error: SpeechError?) {
        val c = waiters.remove(id ?: return) ?: return
        if (!c.isActive) return
        runCatching { if (error == null) c.resume(Unit) else c.resumeWithException(error) }
    }

    private suspend fun ensureReady(): TextToSpeech? {
        tts?.let { return it }
        return suspendCancellableCoroutine { cont ->
            var engine: TextToSpeech? = null
            engine = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    engine?.setOnUtteranceProgressListener(listener)
                    engine?.setSpeechRate(1f); engine?.setPitch(1f)
                    tts = engine
                    if (cont.isActive) cont.resume(engine)
                } else if (cont.isActive) cont.resume(null)
            }
        }
    }

    suspend fun voices(): List<VoiceInfo> {
        val engine = ensureReady() ?: return emptyList()
        val lang = Locale.getDefault().language
        return runCatching {
            engine.voices.orEmpty().filter { it.locale.language == lang || it.locale.language == "en" }
                .sortedWith(compareBy({ it.locale.toString() }, { it.name }))
                .map { VoiceInfo(it.name, "${it.locale.displayName} · ${it.name}", !it.isNetworkConnectionRequired) }
        }.getOrDefault(emptyList())
    }

    /** Renders [text] to WAV bytes with the device voice. */
    suspend fun synthesize(text: String, voiceName: String): ByteArray {
        val engine = ensureReady() ?: throw SpeechError("Text-to-speech isn't available on this device. Install a TTS engine in Android settings.")
        runCatching {
            val chosen = engine.voices?.firstOrNull { it.name == voiceName }
            if (chosen != null) engine.setVoice(chosen) else if (engine.isLanguageAvailable(Locale.getDefault()) >= TextToSpeech.LANG_AVAILABLE) engine.setLanguage(Locale.getDefault()) else engine.setLanguage(Locale.US)
        }
        val id = "synth-${ids.incrementAndGet()}"
        val file = File(context.cacheDir, "$id.wav")
        try {
            suspendCancellableCoroutine<Unit> { cont ->
                waiters[id] = cont
                cont.invokeOnCancellation { waiters.remove(id); runCatching { engine.stop() } }
                if (engine.synthesizeToFile(text, null, file, id) != TextToSpeech.SUCCESS) { waiters.remove(id); cont.resumeWithException(SpeechError("Text-to-speech couldn't start.")) }
            }
            return file.readBytes()
        } finally { file.delete() }
    }

    fun shutdown() { runCatching { tts?.shutdown() }; tts = null }
}
