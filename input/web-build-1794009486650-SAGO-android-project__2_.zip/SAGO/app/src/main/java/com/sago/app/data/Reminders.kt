package com.sago.app.data

import com.sago.app.data.db.ReminderDao
import com.sago.app.data.db.ReminderEntity
import com.sago.app.domain.tools.TimeUtil
import com.sago.app.reminders.ReminderScheduler
import kotlinx.coroutines.flow.Flow

/** Reminders and routines: stored locally, scheduled with WorkManager, re-scheduled on every app start. */
class Reminders(private val dao: ReminderDao, private val scheduler: ReminderScheduler) {
    fun observe(profileId: String): Flow<List<ReminderEntity>> = dao.observe(profileId)
    suspend fun all(profileId: String) = dao.all(profileId)
    suspend fun get(id: Long) = dao.get(id)

    suspend fun create(
        profileId: String, kind: String, title: String, body: String = "", triggerAt: Long,
        recurrence: String = "none", minuteOfDay: Int = 0,
    ): ReminderEntity {
        val r = ReminderEntity(
            profileId = profileId, kind = kind, title = title, body = body, triggerAt = triggerAt, recurrence = recurrence,
            minuteOfDay = minuteOfDay, enabled = true, lastFiredAt = null, createdAt = System.currentTimeMillis(),
        )
        val saved = r.copy(id = dao.insert(r))
        scheduler.schedule(saved)
        return saved
    }

    suspend fun update(r: ReminderEntity) { dao.update(r); if (r.enabled) scheduler.schedule(r) else scheduler.cancel(r.id) }

    suspend fun setEnabled(id: Long, enabled: Boolean) {
        val r = dao.get(id) ?: return
        val next = if (enabled && r.triggerAt <= System.currentTimeMillis() && r.recurrence != "none")
            TimeUtil.nextOccurrence(r.recurrence, r.minuteOfDay, System.currentTimeMillis()) else r.triggerAt
        update(r.copy(enabled = enabled, triggerAt = next))
    }

    suspend fun delete(id: Long) { scheduler.cancel(id); dao.delete(id) }

    suspend fun clearProfile(profileId: String) { dao.all(profileId).forEach { scheduler.cancel(it.id) }; dao.clear(profileId) }

    /** WorkManager keeps its queue, but this repairs it after data clears, restores or force-stops. */
    suspend fun rescheduleAll() { dao.allEnabled().forEach { scheduler.schedule(it) } }

    /** Called when a reminder has been delivered: repeats get a new time, one-offs are switched off. */
    suspend fun markFired(r: ReminderEntity, now: Long) {
        val next = TimeUtil.nextAfterFire(r.recurrence, r.minuteOfDay, r.triggerAt, now)
        if (next > 0) update(r.copy(lastFiredAt = now, triggerAt = next)) else update(r.copy(lastFiredAt = now, enabled = false))
    }

    /** Creates, moves or removes the daily morning briefing routine. */
    suspend fun ensureBriefing(profileId: String, minuteOfDay: Int, enabled: Boolean) {
        val existing = dao.all(profileId).firstOrNull { it.kind == "briefing" }
        if (!enabled) { existing?.let { delete(it.id) }; return }
        val next = TimeUtil.nextOccurrence("daily", minuteOfDay, System.currentTimeMillis())
        if (existing == null) create(profileId, "briefing", "Morning briefing", triggerAt = next, recurrence = "daily", minuteOfDay = minuteOfDay)
        else update(existing.copy(minuteOfDay = minuteOfDay, triggerAt = next, enabled = true))
    }
}
