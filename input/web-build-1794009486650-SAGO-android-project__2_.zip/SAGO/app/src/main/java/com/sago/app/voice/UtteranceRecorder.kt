package com.sago.app.voice

import com.sago.app.wake.MicStream
import java.io.IOException
import kotlin.math.max

/**
 * Records ONE utterance from a [MicStream] using an adaptive energy gate for voice-activity detection:
 * it waits for speech, keeps recording through short pauses, and stops after [endSilenceMs] of quiet.
 * The raw PCM is returned so it can be sent to a high-accuracy recogniser.
 */
class UtteranceRecorder {

    /**
     * @param preRoll audio captured just before this call (the wake word and whatever followed it). When given,
     *   speech is considered already started, so "Sago, remember …" said in one breath isn't clipped.
     * @param onFrame called with every live frame (e.g. to feed a live-preview decoder).
     * @return the PCM (pre-roll first), or null if nothing was said / cancelled.
     */
    fun record(
        mic: MicStream, preRoll: ShortArray?, noSpeechMs: Long, maxMs: Long, endSilenceMs: Long = 1300,
        onFrame: (ShortArray, Int) -> Unit = { _, _ -> }, onLevel: (Float) -> Unit, cancelled: () -> Boolean,
    ): ShortArray? {
        val frames = ArrayList<ShortArray>()
        val lead = ArrayDeque<ShortArray>()           // quiet frames kept so the first syllable isn't clipped
        var speaking = preRoll != null
        var voicedFrames = 0
        var silenceMs = 0L
        var noise = 150f                              // adaptive noise floor (RMS)
        val started = System.currentTimeMillis()
        preRoll?.let { frames.add(it) }

        while (!cancelled()) {
            val n = mic.read()
            if (n < 0) throw IOException("Microphone read failed ($n)")
            if (n == 0) continue
            val frame = mic.buffer.copyOf(n)
            val rms = mic.lastRms
            val frameMs = n * 1000L / MicStream.SAMPLE_RATE
            onLevel((rms / 4000f).coerceIn(0f, 1f))
            onFrame(frame, n)

            val loud = rms > max(450f, noise * 3f)
            if (!speaking) {
                if (loud) {
                    speaking = true; voicedFrames = 1; silenceMs = 0
                    frames.addAll(lead); lead.clear(); frames.add(frame)
                } else {
                    noise = noise * 0.95f + rms * 0.05f
                    lead.addLast(frame); if (lead.size > 3) lead.removeFirst()
                    if (System.currentTimeMillis() - started > noSpeechMs) return null
                }
            } else {
                frames.add(frame)
                if (loud) { voicedFrames++; silenceMs = 0 } else silenceMs += frameMs
                if (silenceMs >= endSilenceMs) break
            }
            if (System.currentTimeMillis() - started > maxMs) break
        }
        if (cancelled() || !speaking) return null
        if (preRoll == null && voicedFrames < 3) return null   // under ~0.4 s of voice: a cough or a click

        val out = ShortArray(frames.sumOf { it.size }); var pos = 0
        frames.forEach { it.copyInto(out, pos); pos += it.size }
        return out
    }
}
