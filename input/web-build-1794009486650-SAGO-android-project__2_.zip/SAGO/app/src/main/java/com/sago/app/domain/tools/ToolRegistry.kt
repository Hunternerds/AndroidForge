package com.sago.app.domain.tools

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import com.sago.app.core.Connectivity
import com.sago.app.data.ChatRepository
import com.sago.app.data.DocumentRepository
import com.sago.app.data.EntryRepository
import com.sago.app.data.Reminders
import com.sago.app.data.groq.GroqClient
import com.sago.app.data.groq.GroqError
import com.sago.app.data.prefs.Keys
import com.sago.app.data.prefs.SettingsStore
import com.sago.app.domain.memory.MemoryEngine
import com.sago.app.domain.model.MemoryCandidate
import com.sago.app.domain.model.ToolCall
import com.sago.app.reminders.Notifier
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject

class ToolEnv(
    val ctx: Context, val memory: MemoryEngine, val entries: EntryRepository, val reminders: Reminders, val docs: DocumentRepository,
    val chats: ChatRepository, val groq: GroqClient, val settings: SettingsStore, val connectivity: Connectivity,
)

class ToolContext(val profileId: String, val conversationId: Long, val textModel: String, val allowWeb: Boolean)

abstract class Tool(val name: String, val help: String, val args: List<ToolArg>, val readOnly: Boolean, val timeoutMs: Long = 10_000) {
    abstract suspend fun run(env: ToolEnv, ctx: ToolContext, a: JSONObject): ToolOutcome
    protected fun ok(msg: String, data: String? = null, undo: UndoSpec? = null) = ToolOutcome(name, true, msg, data, undo, null, readOnly)
    protected fun fail(msg: String) = ToolOutcome(name, false, msg, readOnly = readOnly)
}

/**
 * The tool registry. Every call goes through: known tool? → schema validation → permission/limit checks → timeout →
 * a real result. Read tools return data for the model; safe local writes run immediately and come with an Undo;
 * destructive operations only produce a confirmation request.
 */
class ToolRegistry(private val env: ToolEnv) {
    private val categories = setOf("preference", "project", "goal", "routine", "fact", "relationship", "general")

    private val tools: List<Tool> = listOf(
        object : Tool("remember", "remember{text}", listOf(ToolArg("text", ArgType.TEXT, max = 160), ToolArg("category", ArgType.TEXT, false, allowed = categories)), false) {
            override suspend fun run(env: ToolEnv, ctx: ToolContext, a: JSONObject): ToolOutcome {
                val saved = env.memory.saveFromTool(ctx.profileId, MemoryCandidate(a.getString("text"), a.optString("category", "general"), 4, 0.9f))
                    ?: return fail("I couldn't save that to memory (it may be empty, too long or sensitive).")
                return ok("Saved to memory: “${saved.text}”", undo = UndoSpec("delete_memory", JSONObject().put("id", saved.id)))
            }
        },
        object : Tool("forget", "forget{query}", listOf(ToolArg("query", ArgType.TEXT, max = 160)), false) {
            override suspend fun run(env: ToolEnv, ctx: ToolContext, a: JSONObject): ToolOutcome {
                val best = env.memory.findToForget(ctx.profileId, a.getString("query")).firstOrNull()?.first ?: return fail("I don't have a saved memory matching that.")
                val prompt = "Forget “${best.text}”?"
                return ToolOutcome(name, true, prompt, confirm = ConfirmSpec("forget_memory", JSONObject().put("ids", JSONArray().put(best.id)), prompt))
            }
        },
        object : Tool("search_memory", "search_memory{query}", listOf(ToolArg("query", ArgType.TEXT, max = 200)), true) {
            override suspend fun run(env: ToolEnv, ctx: ToolContext, a: JSONObject): ToolOutcome {
                val r = env.memory.search(ctx.profileId, a.getString("query"))
                return ok("Searched memory", if (r.isEmpty()) "No saved memories match." else r.joinToString("\n") { "- ${it.text}" })
            }
        },
        object : Tool("search_notes", "search_notes{query}", listOf(ToolArg("query", ArgType.TEXT, max = 200)), true) {
            override suspend fun run(env: ToolEnv, ctx: ToolContext, a: JSONObject): ToolOutcome {
                val r = env.entries.search(ctx.profileId, a.getString("query"))
                return ok("Searched notes", if (r.isEmpty()) "No notes or tasks match." else r.joinToString("\n") { "- [${it.kind}${if (it.done) ", done" else ""}] ${it.title}: ${it.body.take(160)}" })
            }
        },
        object : Tool("search_documents", "search_documents{query}", listOf(ToolArg("query", ArgType.TEXT, max = 200)), true) {
            override suspend fun run(env: ToolEnv, ctx: ToolContext, a: JSONObject): ToolOutcome {
                val r = env.docs.retrieve(ctx.profileId, a.getString("query"), 4)
                return ok("Searched your documents", if (r.isEmpty()) "No documents match." else r.joinToString("\n") { "- ${it.title}: ${it.text}" })
            }
        },
        object : Tool("search_conversations", "search_conversations{query}", listOf(ToolArg("query", ArgType.TEXT, max = 200)), true) {
            override suspend fun run(env: ToolEnv, ctx: ToolContext, a: JSONObject): ToolOutcome {
                val r = env.chats.searchConversations(ctx.profileId, a.getString("query"))
                return ok("Searched past conversations", if (r.isEmpty()) "No past conversations match." else r.joinToString("\n") { "- “${it.title}”: ${it.snippet}" })
            }
        },
        object : Tool("create_note", "create_note{title,body}", listOf(ToolArg("title", ArgType.TEXT, max = 80), ToolArg("body", ArgType.TEXT, false, max = 2000)), false) {
            override suspend fun run(env: ToolEnv, ctx: ToolContext, a: JSONObject): ToolOutcome {
                val e = env.entries.addNote(ctx.profileId, a.getString("title"), a.optString("body", ""), "ai")
                return ok("Note saved: “${e.title}”", undo = UndoSpec("delete_entry", JSONObject().put("id", e.id)))
            }
        },
        object : Tool("create_task", "create_task{title,due?}", listOf(ToolArg("title", ArgType.TEXT, max = 120), ToolArg("due", ArgType.ISO_TIME, false)), false) {
            override suspend fun run(env: ToolEnv, ctx: ToolContext, a: JSONObject): ToolOutcome {
                val due = if (a.has("due")) a.getLong("due") else null
                val e = env.entries.addTask(ctx.profileId, a.getString("title"), due, "ai")
                return ok("Task added: “${e.title}”" + (due?.let { " (due ${TimeUtil.formatWhen(it)})" } ?: ""), undo = UndoSpec("delete_entry", JSONObject().put("id", e.id)))
            }
        },
        object : Tool("list_tasks", "list_tasks{}", emptyList(), true) {
            override suspend fun run(env: ToolEnv, ctx: ToolContext, a: JSONObject): ToolOutcome {
                val t = env.entries.openTasks(ctx.profileId, 12)
                return ok("Checked your tasks", if (t.isEmpty()) "No open tasks." else t.joinToString("\n") { "- ${it.title}" + (it.dueAt?.let { d -> " (due ${TimeUtil.formatWhen(d)})" } ?: "") })
            }
        },
        object : Tool("complete_task", "complete_task{title}", listOf(ToolArg("title", ArgType.TEXT, max = 120)), false) {
            override suspend fun run(env: ToolEnv, ctx: ToolContext, a: JSONObject): ToolOutcome {
                val t = env.entries.findOpenTask(ctx.profileId, a.getString("title")) ?: return fail("I couldn't find an open task matching “${a.getString("title")}”.")
                env.entries.setDone(t.id, true)
                return ok("Marked done: “${t.title}”", undo = UndoSpec("reopen_task", JSONObject().put("id", t.id)))
            }
        },
        object : Tool("create_reminder", "create_reminder{title,time(ISO local, e.g. 2026-11-05T09:00)}", listOf(ToolArg("title", ArgType.TEXT, max = 120), ToolArg("time", ArgType.ISO_TIME)), false) {
            override suspend fun run(env: ToolEnv, ctx: ToolContext, a: JSONObject): ToolOutcome {
                val at = a.getLong("time")
                if (at < System.currentTimeMillis() + 30_000) return fail("That time has already passed, so I didn't set the reminder.")
                val r = env.reminders.create(ctx.profileId, "reminder", a.getString("title"), triggerAt = at)
                val warn = if (!Notifier.canNotify(env.ctx)) " Notifications are blocked for SAGO, so enable them in Android settings or it won't show." else ""
                return ok("Reminder set for ${TimeUtil.formatWhen(at)}: “${r.title}”.$warn", undo = UndoSpec("cancel_reminder", JSONObject().put("id", r.id)))
            }
        },
        object : Tool("create_routine", "create_routine{title,time(HH:mm),repeat(daily|weekdays|weekly),action?(remind|briefing|review_tasks|review_projects|evening_summary)}",
            listOf(ToolArg("title", ArgType.TEXT, max = 120), ToolArg("time", ArgType.CLOCK), ToolArg("repeat", ArgType.TEXT, allowed = setOf("daily", "weekdays", "weekly")),
                ToolArg("action", ArgType.TEXT, false, allowed = setOf("remind", "briefing", "review_tasks", "review_projects", "evening_summary"))), false) {
            override suspend fun run(env: ToolEnv, ctx: ToolContext, a: JSONObject): ToolOutcome {
                val minute = a.getInt("time"); val repeat = a.getString("repeat")
                val kind = a.optString("action", "remind").let { if (it == "remind") "reminder" else it }
                val first = TimeUtil.nextOccurrence(repeat, minute, System.currentTimeMillis())
                val r = env.reminders.create(ctx.profileId, kind, a.getString("title"), triggerAt = first, recurrence = repeat, minuteOfDay = minute)
                val note = if (kind != "reminder") " (this one also needs “Suggestions & routines” on in Settings → Assistant to notify you)" else ""
                return ok("Routine saved: “${r.title}” $repeat at ${TimeUtil.formatClock(minute)}.$note", undo = UndoSpec("cancel_reminder", JSONObject().put("id", r.id)))
            }
        },
        object : Tool("read_calendar", "read_calendar{days?}", listOf(ToolArg("days", ArgType.INT, false, max = 14, min = 1)), true) {
            override suspend fun run(env: ToolEnv, ctx: ToolContext, a: JSONObject): ToolOutcome {
                if (ContextCompat.checkSelfPermission(env.ctx, Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED)
                    return fail("Calendar access isn't allowed yet. Enable it in Settings → Privacy.")
                val days = a.optInt("days", 1)
                val begin = System.currentTimeMillis(); val end = begin + days * 86_400_000L
                val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().also { ContentUris.appendId(it, begin); ContentUris.appendId(it, end) }.build()
                val lines = ArrayList<String>()
                env.ctx.contentResolver.query(uri, arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN), null, null, "${CalendarContract.Instances.BEGIN} ASC")?.use { c ->
                    while (c.moveToNext() && lines.size < 15) lines += "- ${c.getString(0).orEmpty().ifBlank { "(no title)" }} — ${TimeUtil.formatWhen(c.getLong(1))}"
                }
                return ok("Checked your calendar", if (lines.isEmpty()) "No events in the next $days day(s)." else lines.joinToString("\n"))
            }
        },
        object : Tool("web_research", "web_research{query}", listOf(ToolArg("query", ArgType.TEXT, max = 300)), true, timeoutMs = 45_000) {
            override suspend fun run(env: ToolEnv, ctx: ToolContext, a: JSONObject): ToolOutcome {
                if (!env.connectivity.online.value) return fail("I'm offline right now, so I can't look that up.")
                val model = if (ctx.textModel.startsWith("openai/gpt-oss")) ctx.textModel else "openai/gpt-oss-20b"
                val text = try { env.groq.research(a.getString("query"), model) }
                catch (e: GroqError.ModelUnavailable) { return fail("Web research needs the “$model” model, which isn't available on your Groq account.") }
                catch (e: GroqError.BadRequest) { return fail("Groq rejected the web search request for “$model”.") }
                return ok("Searched the web", text)
            }
        },
        object : Tool("set_setting", "set_setting{name(speak_replies|reply_style|show_emotion),value}",
            listOf(ToolArg("name", ArgType.TEXT, allowed = setOf("speak_replies", "reply_style", "show_emotion")), ToolArg("value", ArgType.TEXT, max = 20)), false) {
            override suspend fun run(env: ToolEnv, ctx: ToolContext, a: JSONObject): ToolOutcome {
                val name = a.getString("name"); val value = a.getString("value").lowercase(); val cur = env.settings.snapshot()
                fun bool() = when (value) { "true", "on", "yes" -> true; "false", "off", "no" -> false; else -> null }
                return when (name) {
                    "speak_replies" -> { val b = bool() ?: return fail("“value” must be on or off."); env.settings.set(Keys.SPEAK_REPLIES, b); ok("Spoken replies turned ${if (b) "on" else "off"}.", undo = UndoSpec("restore_setting", JSONObject().put("name", name).put("value", cur.speakReplies.toString()))) }
                    "show_emotion" -> { val b = bool() ?: return fail("“value” must be on or off."); env.settings.set(Keys.SHOW_EMOTION, b); ok("Emotion label turned ${if (b) "on" else "off"}.", undo = UndoSpec("restore_setting", JSONObject().put("name", name).put("value", cur.showEmotion.toString()))) }
                    else -> {
                        val valid = setOf("auto", "casual", "quick", "detailed", "technical", "tutor", "brainstorm", "planning", "creative", "translate")
                        if (value !in valid) return fail("Reply style must be one of ${valid.joinToString(", ")}.")
                        env.settings.set(Keys.REPLY_STYLE, value); ok("Reply style set to $value.", undo = UndoSpec("restore_setting", JSONObject().put("name", name).put("value", cur.replyStyle)))
                    }
                }
            }
        },
    )

    /** One compact line per tool for the system prompt. */
    fun help(allowWeb: Boolean): String = tools.filter { allowWeb || it.name != "web_research" }.joinToString("; ") { it.help }
    fun isReadOnly(name: String) = tools.firstOrNull { it.name == name }?.readOnly == true

    suspend fun run(calls: List<ToolCall>, ctx: ToolContext): List<ToolOutcome> {
        val out = ArrayList<ToolOutcome>(); val seen = HashSet<String>()
        for (call in calls.take(MAX_CALLS)) {
            val tool = tools.firstOrNull { it.name == call.tool }
            if (tool == null) { out += ToolOutcome(call.tool, false, "I tried to use a tool that doesn't exist (“${call.tool}”), so nothing happened."); continue }
            if (!seen.add(call.tool + call.args.toString())) continue
            if (tool.name == "web_research" && !ctx.allowWeb) { out += ToolOutcome(tool.name, false, "Web research is turned off in Settings → AI.", readOnly = true); continue }
            val validated = ToolValidator.validate(tool.args, call.args)
            if (validated.isFailure) { out += ToolOutcome(tool.name, false, "I couldn't run “${tool.name}”: ${validated.exceptionOrNull()?.message}.", readOnly = tool.readOnly); continue }
            val args = validated.getOrThrow()
            out += try { withTimeout(tool.timeoutMs) { tool.run(env, ctx, args) } }
            catch (e: TimeoutCancellationException) { ToolOutcome(tool.name, false, "“${tool.name}” took too long, so I stopped it.", readOnly = tool.readOnly) }
            catch (e: CancellationException) { throw e }
            catch (e: GroqError) { ToolOutcome(tool.name, false, e.userMessage, readOnly = tool.readOnly) }
            catch (e: Exception) { ToolOutcome(tool.name, false, "“${tool.name}” failed: ${e.message ?: e::class.simpleName}", readOnly = tool.readOnly) }
        }
        return out
    }

    companion object { const val MAX_CALLS = 3 }
}
