package com.sago.app.ui.screens

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sago.app.avatar.AvatarView
import com.sago.app.avatar.emotionColor
import com.sago.app.domain.model.ChatMessage
import com.sago.app.domain.model.Emotion
import com.sago.app.domain.model.PickedImage
import com.sago.app.domain.proactive.Suggestion
import com.sago.app.domain.tools.CardMeta
import com.sago.app.ui.components.Backdrop
import com.sago.app.ui.theme.LocalSagoUi
import com.sago.app.ui.theme.Palette
import com.sago.app.ui.viewmodel.ChatViewModel
import com.sago.app.voice.AssistantState
import com.sago.app.voice.UiError
import com.sago.app.wake.WakeStatus
import com.sago.app.wake.WakeWordService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    vm: ChatViewModel, onHistory: () -> Unit, onLibrary: () -> Unit, onSettings: () -> Unit, onAiSettings: () -> Unit, onVoiceSettings: () -> Unit,
) {
    val ctx = LocalContext.current
    val s by vm.settings.collectAsStateWithLifecycle()
    val avatar by vm.assistant.avatar.collectAsStateWithLifecycle()
    val state by vm.assistant.state.collectAsStateWithLifecycle()
    val mouth by vm.assistant.mouthOpen.collectAsStateWithLifecycle()
    val mouthLevel by vm.assistant.mouthLevel.collectAsStateWithLifecycle()
    val level by vm.assistant.micLevel.collectAsStateWithLifecycle()
    val partial by vm.assistant.partial.collectAsStateWithLifecycle()
    val transcribing by vm.assistant.transcribing.collectAsStateWithLifecycle()
    val error by vm.assistant.error.collectAsStateWithLifecycle()
    val messages by vm.messages.collectAsStateWithLifecycle()
    val suggestions by vm.suggestions.collectAsStateWithLifecycle()
    val draft by vm.draft.collectAsStateWithLifecycle()
    val attaching by vm.attaching.collectAsStateWithLifecycle()
    val wakeStatus by vm.wakeStatus.collectAsStateWithLifecycle()
    val wakeDetail by vm.wakeDetail.collectAsStateWithLifecycle()
    val online by vm.online.collectAsStateWithLifecycle()
    val action by vm.pendingAction.collectAsStateWithLifecycle()
    var input by rememberSaveable { mutableStateOf("") }
    val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    // Reduced motion: the in-app setting, or Android's "remove animations".
    val systemReduce = remember { runCatching { Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }.getOrDefault(false) }
    val animate = s.avatarAnimations && !s.reduceMotion && !systemReduce

    LaunchedEffect(wakeStatus) {
        if (wakeStatus == WakeStatus.ERROR || wakeStatus == WakeStatus.MODEL_MISSING || wakeStatus == WakeStatus.NO_PERMISSION)
            vm.assistant.error.value = UiError(wakeDetail.ifBlank { "Background listening stopped." })
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.assistant.startVoice()
        else vm.assistant.error.value = UiError("Microphone permission was denied. You can allow it later in Settings → Privacy, or keep typing.")
    }
    fun onMic() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.assistant.startVoice()
        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    // Shortcuts and the home-screen widget.
    LaunchedEffect(action) {
        when (action) {
            "voice" -> { vm.consumeAction(); onMic() }
            "new_chat" -> { vm.consumeAction(); vm.assistant.newConversation() }
            "library" -> { vm.consumeAction(); onLibrary() }
        }
    }

    var capturePath by rememberSaveable { mutableStateOf<String?>(null) }
    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        capturePath?.let { p -> if (ok) vm.attachFile(File(p)) else File(p).delete() }
    }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(4)) { uris -> uris.forEach(vm::attach) }
    fun onCamera() {
        try {
            val f = File(File(ctx.cacheDir, "captures").apply { mkdirs() }, "cap_${System.currentTimeMillis()}.jpg")
            capturePath = f.absolutePath
            takePicture.launch(FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f))
        } catch (e: ActivityNotFoundException) {
            vm.assistant.error.value = UiError("No camera app was found on this device. You can pick a photo instead.")
        } catch (e: Exception) {
            vm.assistant.error.value = UiError("Couldn't open the camera: ${e.message}")
        }
    }

    fun send() {
        if (input.isBlank() && draft.isEmpty()) return
        vm.send(input); input = ""
    }

    Box(Modifier.fillMaxSize()) {
        Backdrop(s.showBackground)
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            TopRow(
                wakeActive = wakeStatus == WakeStatus.LISTENING || wakeStatus == WakeStatus.ENGAGED,
                onHistory = onHistory, onLibrary = onLibrary, onNew = { vm.assistant.newConversation(); input = "" }, onSettings = onSettings,
                onStopListening = { WakeWordService.stop(ctx) },
            )

            Column(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                AvatarView(
                    ui = avatar, mouthOpen = mouth, mouthLevel = mouthLevel, micLevel = level, avatarSize = if (imeOpen) 84.dp else s.avatarSizeDp.dp,
                    animations = animate, emotionGlow = s.showEmotion,
                    modifier = Modifier.clickable(enabled = state != AssistantState.IDLE) { vm.assistant.stop() },
                )
                StatusLine(state, partial, transcribing, avatar.emotion, s.showEmotion, online)
            }

            MessageList(
                Modifier.weight(1f).fillMaxWidth(), messages, thinking = state == AssistantState.THINKING, suggestions = suggestions,
                onSuggestion = vm::onSuggestion, onCard = vm::onCardAction,
            )

            error?.let { e ->
                ErrorBanner(
                    e, onRetry = { vm.assistant.retry() }, onDismiss = { vm.assistant.dismissError() },
                    onSettings = { vm.assistant.dismissError(); if (e.openAiSettings) onAiSettings() else onVoiceSettings() },
                )
            }
            if (draft.isNotEmpty()) DraftRow(draft, vm::removeDraft)
            if (attaching) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp))

            InputBar(
                input = input, onInput = { input = it }, state = state, hasDraft = draft.isNotEmpty(),
                onSend = ::send, onMic = ::onMic, onStop = { vm.assistant.stop() }, onCamera = ::onCamera,
                onGallery = { pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopRow(wakeActive: Boolean, onHistory: () -> Unit, onLibrary: () -> Unit, onNew: () -> Unit, onSettings: () -> Unit, onStopListening: () -> Unit) {
    val ui = LocalSagoUi.current
    // Two icons on each side, so the title sits on the screen's true centre.
    Box(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
        Row(Modifier.align(Alignment.TopStart)) {
            IconButton(onHistory) { Icon(Icons.Default.History, "Conversation history", tint = ui.text) }
            IconButton(onLibrary) { Icon(Icons.Default.Checklist, "Library: notes, tasks and reminders", tint = ui.text) }
        }
        Row(Modifier.align(Alignment.TopEnd)) {
            IconButton(onNew) { Icon(Icons.Default.Add, "New conversation", tint = ui.text) }
            IconButton(onSettings) { Icon(Icons.Default.Settings, "Settings", tint = ui.text) }
        }
        Column(Modifier.align(Alignment.TopCenter).padding(top = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("SAGO", Modifier.padding(start = 3.dp), style = MaterialTheme.typography.titleLarge, color = ui.text, letterSpacing = 3.sp)
            if (wakeActive) {
                Surface(
                    onClick = onStopListening, shape = CircleShape, color = Color(0xFF14532D).copy(0.85f),
                    modifier = Modifier.padding(top = 2.dp).semantics { contentDescription = "Listening for the wake word. Tap to stop listening." },
                ) {
                    Row(Modifier.padding(horizontal = 10.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF4ADE80)))
                        Spacer(Modifier.width(6.dp))
                        Text("Listening for “Sago” · tap to stop", style = MaterialTheme.typography.labelSmall, color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusLine(state: AssistantState, partial: String, transcribing: Boolean, emotion: Emotion, showEmotion: Boolean, online: Boolean) {
    val ui = LocalSagoUi.current
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite }) {
        Box(Modifier.heightIn(min = 30.dp).padding(horizontal = 24.dp), contentAlignment = Alignment.Center) {
            when {
                state != AssistantState.IDLE && transcribing -> Text("Transcribing…", color = ui.subtext)
                state == AssistantState.LISTENING -> Text(partial.ifBlank { "Listening…" }, color = ui.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                state == AssistantState.THINKING -> Text("Thinking…", color = ui.subtext)
                state == AssistantState.SPEAKING -> Text("Speaking · tap me to interrupt", color = ui.subtext, style = MaterialTheme.typography.bodyMedium)
                showEmotion && emotion != Emotion.NEUTRAL -> Surface(shape = CircleShape, color = ui.glass, border = BorderStroke(1.dp, emotionColor(emotion).copy(0.7f))) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(emotionColor(emotion)))
                        Spacer(Modifier.width(6.dp))
                        Text(emotion.label, style = MaterialTheme.typography.labelSmall, color = ui.text)
                    }
                }
            }
        }
        if (!online) Text("Offline · chat needs internet, but notes, memory and history still work", style = MaterialTheme.typography.labelSmall, color = ui.subtext, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 24.dp))
    }
}

/** Fades the top edge of scrolling content so messages dissolve under the avatar instead of being cut off. */
private fun Modifier.fadeTop(height: Dp): Modifier = this
    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
    .drawWithContent {
        drawContent()
        drawRect(
            Brush.verticalGradient(listOf(Color.Transparent, Color.Black), startY = 0f, endY = height.toPx()),
            size = Size(size.width, height.toPx()), blendMode = BlendMode.DstIn,
        )
    }

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MessageList(
    modifier: Modifier, messages: List<ChatMessage>, thinking: Boolean, suggestions: List<Suggestion>,
    onSuggestion: (Suggestion) -> Unit, onCard: (ChatMessage, Boolean) -> Unit,
) {
    val ui = LocalSagoUi.current
    val listState = rememberLazyListState()
    val count = messages.size + if (thinking) 1 else 0
    LaunchedEffect(count) { if (count > 0) listState.animateScrollToItem(count - 1) }
    if (count == 0) {
        Column(modifier.padding(horizontal = 28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(
                "Say hi! Type below or tap the mic.\nTurn on the “Sago” wake word in Settings → Voice to talk hands-free.",
                color = ui.subtext, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center,
            )
            if (suggestions.isNotEmpty()) {
                Spacer(Modifier.height(14.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    suggestions.forEach { sg -> AssistChip(onClick = { onSuggestion(sg) }, label = { Text(sg.label, maxLines = 1, overflow = TextOverflow.Ellipsis) }) }
                }
            }
        }
        return
    }
    LazyColumn(modifier.fadeTop(28.dp), state = listState, contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 18.dp, bottom = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(messages, key = { it.id }) { if (it.role == ChatMessage.Role.TOOL) ToolCard(it, onCard) else Bubble(it) }
        if (thinking) item { ThinkingBubble() }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Bubble(m: ChatMessage) {
    val ui = LocalSagoUi.current
    val user = m.role == ChatMessage.Role.USER
    val maxBubble = (LocalConfiguration.current.screenWidthDp * 0.8f).dp
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        Surface(
            shape = RoundedCornerShape(18.dp, 18.dp, if (user) 18.dp else 4.dp, if (user) 4.dp else 18.dp),
            color = if (user) Palette.PinkDeep else ui.glass, contentColor = if (user) Color.White else ui.text,
            border = if (user) null else BorderStroke(1.dp, ui.glassBorder), modifier = Modifier.widthIn(max = maxBubble),
        ) {
            Column(Modifier.padding(horizontal = 13.dp, vertical = 9.dp)) {
                if (m.imagePaths.isNotEmpty()) {
                    val single = m.imagePaths.size == 1
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 6.dp)) {
                        m.imagePaths.forEach { ChatImage(it, if (single) 240.dp else 112.dp) }
                    }
                }
                if (m.text.isNotBlank()) SelectionContainer { Text(m.text, style = MaterialTheme.typography.bodyLarge) }
                if (m.sources.isNotEmpty()) Text("From your vault: " + m.sources.joinToString(", "), style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 4.dp).alpha(0.8f))
                Text(DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(m.createdAt)), style = MaterialTheme.typography.labelSmall, modifier = Modifier.alpha(0.65f).align(Alignment.End))
            }
        }
    }
}

/** Result of something SAGO actually did (or failed to do). Written by app code, never by the model. */
@Composable
private fun ToolCard(m: ChatMessage, onCard: (ChatMessage, Boolean) -> Unit) {
    val ui = LocalSagoUi.current
    val card = CardMeta.parse(m.meta)
    val failed = m.text.startsWith("⚠️")
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
        Surface(
            shape = RoundedCornerShape(14.dp), color = ui.glass, contentColor = ui.text,
            border = BorderStroke(1.dp, if (failed) MaterialTheme.colorScheme.error.copy(0.7f) else Palette.Pink.copy(0.5f)),
            modifier = Modifier.widthIn(max = (LocalConfiguration.current.screenWidthDp * 0.9f).dp),
        ) {
            Row(Modifier.padding(start = 12.dp, top = 4.dp, bottom = 4.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(if (failed) Icons.Default.Warning else Icons.Default.CheckCircle, null, tint = if (failed) MaterialTheme.colorScheme.error else Palette.Pink, modifier = Modifier.size(18.dp))
                Text(m.text.removePrefix("⚠️ "), Modifier.weight(1f).padding(horizontal = 8.dp, vertical = 6.dp), style = MaterialTheme.typography.bodyMedium)
                if (card?.kind == "confirm") {
                    TextButton({ onCard(m, true) }) { Text("Confirm") }
                    TextButton({ onCard(m, false) }) { Text("Cancel") }
                } else if (card?.kind == "undo") TextButton({ onCard(m, true) }) { Text("Undo") }
            }
        }
    }
}

@Composable
private fun ChatImage(path: String, size: Dp) {
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { runCatching { BitmapFactory.decodeFile(path)?.asImageBitmap() }.getOrNull() }
    }
    bmp?.let { Image(it, "Photo you shared", Modifier.widthIn(max = size).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.FillWidth) }
}

@Composable
private fun ThinkingBubble() {
    val ui = LocalSagoUi.current
    val t = rememberInfiniteTransition(label = "dots")
    Surface(shape = RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp), color = ui.glass, border = BorderStroke(1.dp, ui.glassBorder)) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            for (i in 0..2) {
                val a by t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(600, delayMillis = i * 160), RepeatMode.Reverse), label = "d$i")
                Box(Modifier.size(8.dp).alpha(a).clip(CircleShape).background(ui.text))
            }
        }
    }
}

@Composable
private fun ErrorBanner(e: UiError, onRetry: () -> Unit, onDismiss: () -> Unit, onSettings: () -> Unit) {
    Surface(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), shape = RoundedCornerShape(14.dp), color = Color(0xFF7F1D3A).copy(0.92f), contentColor = Color.White) {
        Column(Modifier.padding(12.dp)) {
            Text(e.message, style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                if (e.canRetry) TextButton(onRetry) { Text("Retry", color = Color.White) }
                if (e.openAiSettings) TextButton(onSettings) { Text("Open settings", color = Color.White) }
                TextButton(onDismiss) { Text("Dismiss", color = Color.White.copy(0.8f)) }
            }
        }
    }
}

@Composable
private fun DraftRow(images: List<PickedImage>, onRemove: (Int) -> Unit) {
    val ui = LocalSagoUi.current
    Row(Modifier.padding(horizontal = 14.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        images.forEachIndexed { i, img ->
            val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, img.savedPath) {
                value = withContext(Dispatchers.IO) { runCatching { BitmapFactory.decodeFile(img.savedPath)?.asImageBitmap() }.getOrNull() }
            }
            Box {
                Surface(shape = RoundedCornerShape(12.dp), color = ui.glass, border = BorderStroke(1.dp, ui.glassBorder)) {
                    bmp?.let { Image(it, "Attached photo ${i + 1}", Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop) } ?: Box(Modifier.size(56.dp))
                }
                IconButton({ onRemove(i) }, Modifier.size(24.dp).align(Alignment.TopEnd).background(Color.Black.copy(0.55f), CircleShape)) {
                    Icon(Icons.Default.Close, "Remove photo ${i + 1}", tint = Color.White, modifier = Modifier.size(14.dp))
                }
            }
        }
        Text(if (images.size > 1) "Ask me to compare them" else "Ask about this photo", style = MaterialTheme.typography.labelSmall, color = ui.subtext)
    }
}

@Composable
private fun InputBar(
    input: String, onInput: (String) -> Unit, state: AssistantState, hasDraft: Boolean,
    onSend: () -> Unit, onMic: () -> Unit, onStop: () -> Unit, onCamera: () -> Unit, onGallery: () -> Unit,
) {
    val ui = LocalSagoUi.current
    var menu by remember { mutableStateOf(false) }
    val busy = state != AssistantState.IDLE
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box {
            IconButton({ menu = true }) { Icon(Icons.Default.AddPhotoAlternate, "Attach photos", tint = ui.text) }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text("Take a photo") }, leadingIcon = { Icon(Icons.Default.PhotoCamera, null) }, onClick = { menu = false; onCamera() })
                DropdownMenuItem(text = { Text("Choose photos (up to 4)") }, leadingIcon = { Icon(Icons.Default.PhotoLibrary, null) }, onClick = { menu = false; onGallery() })
            }
        }
        TextField(
            value = input, onValueChange = onInput, modifier = Modifier.weight(1f), maxLines = 5,
            placeholder = { Text(if (hasDraft) "Ask about your photos…" else "Message SAGO", color = ui.subtext) },
            shape = RoundedCornerShape(24.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = ui.glass, unfocusedContainerColor = ui.glass, focusedTextColor = ui.text, unfocusedTextColor = ui.text,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, cursorColor = Palette.Pink,
            ),
        )
        Spacer(Modifier.width(8.dp))
        val (icon, desc, action) = when {
            busy -> Triple(Icons.Default.Stop, "Stop", onStop)
            input.isNotBlank() || hasDraft -> Triple(Icons.AutoMirrored.Filled.Send, "Send message", onSend)
            else -> Triple(Icons.Default.Mic, "Talk to SAGO", onMic)
        }
        FilledIconButton(action, Modifier.size(50.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = Palette.PinkDeep, contentColor = Color.White)) {
            Icon(icon, desc)
        }
    }
}
