package com.sago.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sago.app.avatar.AvatarMode
import com.sago.app.avatar.AvatarUi
import com.sago.app.avatar.AvatarView
import com.sago.app.avatar.Expression
import com.sago.app.ui.components.Backdrop
import com.sago.app.ui.components.GlassCard
import com.sago.app.ui.theme.LocalSagoUi
import com.sago.app.ui.viewmodel.OnboardingState
import com.sago.app.ui.viewmodel.OnboardingViewModel

@Composable
fun OnboardingScreen(vm: OnboardingViewModel, onDone: () -> Unit) {
    val ui = LocalSagoUi.current
    val state by vm.state.collectAsStateWithLifecycle()
    var key by rememberSaveable { mutableStateOf("") }
    var visible by rememberSaveable { mutableStateOf(false) }
    val uri = LocalUriHandler.current
    val busy = state is OnboardingState.Validating || state is OnboardingState.Initializing

    Box(Modifier.fillMaxSize()) {
        Backdrop(true)
        Column(
            Modifier.fillMaxSize().systemBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
        ) {
            AvatarView(AvatarUi(Expression.HAPPY, if (busy) AvatarMode.THINKING else AvatarMode.IDLE), false, 0f, 0f, 170.dp, true, false)
            Text("Hi, I'm SAGO", style = MaterialTheme.typography.headlineMedium, color = ui.text)
            Spacer(Modifier.height(4.dp))
            Text("Your voice-enabled AI companion. Let's get me connected.", color = ui.subtext, textAlign = TextAlign.Center)
            Spacer(Modifier.height(20.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Connect to Groq", style = MaterialTheme.typography.titleMedium, color = ui.text)
                Text(
                    "SAGO thinks using Groq. Paste your API key; it's checked with a real request and then stored encrypted on this device only.",
                    style = MaterialTheme.typography.bodyMedium, color = ui.subtext,
                )
                OutlinedTextField(
                    value = key, onValueChange = { key = it }, singleLine = true, enabled = !busy, label = { Text("Groq API key") },
                    visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton({ visible = !visible }) { Icon(if (visible) Icons.Default.VisibilityOff else Icons.Default.Visibility, if (visible) "Hide key" else "Show key") }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                (state as? OnboardingState.Error)?.let { Text(it.message, color = MaterialTheme.colorScheme.error) }
                when (val st = state) {
                    is OnboardingState.Validating -> Status("Checking your key with Groq…")
                    is OnboardingState.Initializing -> Status(st.step)
                    else -> Button({ vm.connect(key, onDone) }, Modifier.fillMaxWidth(), enabled = key.isNotBlank()) { Text("Connect") }
                }
                TextButton({ uri.openUri("https://console.groq.com/keys") }, enabled = !busy) { Text("Get a key at console.groq.com/keys") }
                Text(
                    "Usage is subject to your Groq account's limits and policies. SAGO never ships with a key and never uploads wake-word audio.",
                    style = MaterialTheme.typography.labelSmall, color = ui.subtext,
                )
            }
        }
    }
}

@Composable
private fun Status(text: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.5.dp)
        Spacer(Modifier.width(12.dp)); Text(text, color = LocalSagoUi.current.text)
    }
}
