package com.sago.app.domain.ai

import com.sago.app.avatar.Expression
import com.sago.app.domain.model.AiReply
import com.sago.app.domain.model.ChatMessage
import com.sago.app.domain.model.Emotion

/**
 * Emotion analysis, kept separate from rendering. The model reports an emotion and a face, but models often label a
 * clearly angry or shy message "normal". This reconciles the model's labels with cues in the text SAGO actually
 * wrote (emojis and explicit mood words), so the face matches what she says. It estimates the *tone of her reply*;
 * it is not a diagnosis of the user.
 */
object EmotionResolver {
    data class Resolved(val emotion: Emotion, val expression: Expression)

    private class Cue(val rank: Int, val emotion: Emotion, val expression: Expression, val emojis: List<String>, val words: Regex)

    // Listed in priority order; a higher rank means a stronger, more specific mood.
    private val cues = listOf(
        Cue(5, Emotion.FRUSTRATED, Expression.ANGRY, listOf("😤", "😠", "😡", "🤬", "💢", "😾"),
            Regex("\\b(so mad|i'?m mad|i am mad|angry|furious|annoyed|irritated|livid|hmph|offended)\\b")),
        Cue(4, Emotion.SAD, Expression.SLEEPY, listOf("😢", "😭", "😞", "😔", "💔", "🥲", "😿"),
            Regex("\\b(i'?m sad|so sad|feel sad|lonely|heartbroken|that hurts)\\b")),
        Cue(3, Emotion.SURPRISED, Expression.SURPRISED, listOf("😮", "😲", "🤯", "😱", "😯"),
            Regex("\\b(no way|wait what|omg|oh my god|whoa)\\b")),
        Cue(2, Emotion.HAPPY, Expression.BLUSHING, listOf("🥰", "😍", "😘", "💕", "💖", "💗", "💘", "🙈", "☺", "😳", "🫣", "😚"),
            Regex("\\b(blush|blushing|shy|embarrass\\w*|aww+|you'?re so sweet|i love you|miss you)\\b")),
        Cue(2, Emotion.PLAYFUL, Expression.PLAYFUL, listOf("😜", "😝", "😏", "😛", "😉", "😈", "🤭"),
            Regex("\\b(teasing|tease|just kidding|hehe|heh)\\b")),
        Cue(1, Emotion.HAPPY, Expression.HAPPY, listOf("😊", "😄", "😁", "😆", "😂", "🤣", "😀", "❤", "😻"),
            Regex("\\b(yay|so happy|so excited|can'?t wait)\\b")),
        Cue(1, Emotion.CURIOUS, Expression.THINKING, listOf("🤔", "🧐"), Regex("\\b(hmm+|i wonder|let me think)\\b")),
        Cue(1, Emotion.CALM, Expression.SLEEPY, listOf("😴", "🥱", "💤"), Regex("\\b(sleepy|so tired|yawn)\\b")),
        Cue(1, Emotion.SERIOUS, Expression.STUDY, listOf("📚", "🤓", "📝", "✏"), Regex("\\b(study mode|let'?s study|focus mode)\\b")),
    )

    private fun rankOf(e: Emotion) = when (e) {
        Emotion.FRUSTRATED -> 5; Emotion.SAD -> 4; Emotion.SURPRISED -> 3; Emotion.PLAYFUL -> 2
        Emotion.NEUTRAL -> 0; else -> 1
    }

    /** A mood word counts unless it is negated just before ("I'm not angry", "never mad"). */
    private fun hasWord(re: Regex, text: String): Boolean = re.findAll(text).any { m ->
        val before = text.substring((m.range.first - 14).coerceAtLeast(0), m.range.first)
        !Regex("\\b(not|never|no longer|isn'?t|aren'?t|don'?t|wasn'?t)\\b").containsMatchIn(before) && !before.contains("n't")
    }

    /** How the face should react to what the *user* just said, shown while SAGO is thinking. Empathetic, not mirroring. */
    fun reactionTo(userText: String): Expression? {
        val t = userText.lowercase()
        fun has(vararg e: String) = e.any { it in userText }
        return when {
            has("😢", "😭", "💔", "😞") || Regex("\\b(i'?m sad|feeling down|i feel (sad|awful|terrible)|rough day|i'?m stressed)\\b").containsMatchIn(t) -> Expression.SLEEPY
            has("😍", "🥰", "😘", "💕") || Regex("\\b(i love you|miss you|you'?re (so )?(cute|sweet|pretty))\\b").containsMatchIn(t) -> Expression.BLUSHING
            has("😂", "🤣", "😄", "😁") || Regex("\\b(haha+|lol|lmao)\\b").containsMatchIn(t) -> Expression.HAPPY
            has("😮", "😲", "🤯") || Regex("\\b(guess what|you won'?t believe|omg)\\b").containsMatchIn(t) -> Expression.SURPRISED
            has("😏", "😜", "😝") || Regex("\\b(flirt\\w*|tease|teasing)\\b").containsMatchIn(t) -> Expression.PLAYFUL
            else -> null
        }
    }

    fun resolve(reply: AiReply, studyMode: Boolean): Resolved {
        val text = reply.text.lowercase()
        // Candidate 1: the model's own labels (a NORMAL face with a clear emotion is treated as "not chosen").
        val modelExpr = if (reply.expression == Expression.NORMAL && reply.emotion.defaultExpression != Expression.NORMAL) reply.emotion.defaultExpression else reply.expression
        var best = Resolved(reply.emotion, modelExpr)
        var bestRank = rankOf(reply.emotion)

        // Candidate 2: cues in the written reply. Emojis are the most reliable signal, then mood words.
        val cue = cues.filter { c -> c.emojis.any { it in reply.text } || hasWord(c.words, text) }.maxByOrNull { it.rank }
        if (cue != null && cue.rank > bestRank) { best = Resolved(cue.emotion, cue.expression); bestRank = cue.rank }
        // Same rank but the model chose nothing specific: take the cue so the face isn't left on NORMAL.
        else if (cue != null && cue.rank == bestRank && best.expression == Expression.NORMAL) best = Resolved(cue.emotion, cue.expression)

        // "Study mode" stays visible while it's active, unless a stronger mood takes over.
        if (studyMode && bestRank <= 1 && best.emotion in setOf(Emotion.NEUTRAL, Emotion.CALM, Emotion.SERIOUS, Emotion.CURIOUS, Emotion.CONFUSED) &&
            best.expression in setOf(Expression.NORMAL, Expression.THINKING, Expression.SLEEPY, Expression.STUDY)
        ) best = Resolved(Emotion.SERIOUS, Expression.STUDY)
        return best
    }
}

/** Study mode is on after the user asks for it and stays on until they leave it. Derived from the chat itself. */
object StudyMode {
    private val on = Regex("\\bstudy mode\\b|\\blet'?s (study|focus)\\b|\\b(help me|time to) (study|revise)\\b|\\bstudying mode\\b", RegexOption.IGNORE_CASE)
    private val off = Regex("\\b(stop|exit|leave|end|done with|no more)\\b.{0,16}\\bstud(y|ying)\\b|\\bnormal mode\\b|\\bback to normal\\b|\\bbreak time\\b", RegexOption.IGNORE_CASE)

    fun isActive(history: List<ChatMessage>, currentUserText: String): Boolean {
        var active = false
        val userTexts = history.filter { it.role == ChatMessage.Role.USER }.map { it.text } + currentUserText
        for (t in userTexts) {
            if (off.containsMatchIn(t)) active = false else if (on.containsMatchIn(t)) active = true
        }
        return active
    }
}
