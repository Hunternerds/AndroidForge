package com.sago.app.voice

import android.content.Context
import android.media.*
import android.os.SystemClock
import com.sago.app.core.Diagnostics
import com.sago.app.data.groq.GroqClient
import com.sago.app.data.groq.GroqError
import com.sago.app.data.prefs.SettingsStore
import com.sago.app.domain.model.Emotion
import com.sago.app.domain.model.VoiceStyle
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.max
import kotlin.math.min

/**
 * Speech output 2.0. Text is split into sentences; each is synthesised (Groq's expressive Orpheus voice, or the device
 * voice) while the previous one is still playing, and played through AudioTrack. The avatar's mouth follows the
 * loudness of the audio that is actually playing, so lip-sync works with any engine. Cancel the calling coroutine to
 * interrupt instantly.
 */
class SpeechOutput(
    private val ctx: Context, private val tts: TtsController, private val groq: GroqClient,
    private val settings: SettingsStore, private val diag: Diagnostics,
) {
    val mouthOpen = MutableStateFlow(false)
    val mouthLevel = MutableStateFlow(0f)

    private val audio = ctx.getSystemService(AudioManager::class.java)
    private val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
    private var focus: AudioFocusRequest? = null
    @Volatile private var activeTrack: AudioTrack? = null

    /**
     * @param onNotice called (at most meaningful once) when the Groq voice can't be used and the device voice takes over.
     * @param onFirstAudio called when sound actually starts, so the UI can switch from "thinking" to "speaking".
     */
    suspend fun speak(text: String, emotion: Emotion, style: VoiceStyle, onNotice: (String) -> Unit, onFirstAudio: () -> Unit) {
        val clean = sanitize(text)
        if (clean.isBlank()) return
        val s = settings.snapshot()
        var useGroq = s.ttsEngine == "groq"
        val direction = direction(emotion)
        val prefix = if (useGroq && direction.isNotEmpty()) "[$direction] " else ""
        val pieces = split(clean, if (useGroq) 190 - prefix.length else 600)
        val pitch = (s.speechPitch * style.pitch).coerceIn(0.7f, 1.6f)
        val speed = (s.speechRate * style.rate).coerceIn(0.7f, 1.5f)
        requestFocus()
        try {
            coroutineScope {
                val clips = Channel<Clip>(1) // synthesise the next sentence while this one plays
                val producer = launch(Dispatchers.IO) {
                    try {
                        for (piece in pieces) {
                            var clip: Clip? = null
                            if (useGroq) {
                                try { clip = WavDecoder.decode(groq.speech(prefix + piece, s.groqVoice)) ?: throw SpeechError("The Groq voice returned audio SAGO can't play.") }
                                catch (e: GroqError) { useGroq = false; diag.count("tts.fallbacks"); onNotice(e.userMessage) }
                                catch (e: SpeechError) { useGroq = false; diag.count("tts.fallbacks"); onNotice(e.message.orEmpty()) }
                            }
                            if (clip == null) clip = WavDecoder.decode(tts.synthesize(piece, s.ttsVoice)) ?: throw SpeechError("The device voice produced audio SAGO can't play.")
                            clips.send(clip)
                        }
                    } finally { clips.close() }
                }
                var first = true
                try {
                    for (clip in clips) { if (first) { first = false; onFirstAudio() }; play(clip, pitch, speed) }
                } finally { producer.cancel() }
            }
        } finally {
            mouthOpen.value = false; mouthLevel.value = 0f
            abandonFocus()
        }
    }

    /** Immediately silences current playback (the coroutine is cancelled separately). */
    fun stop() { activeTrack?.let { runCatching { it.pause(); it.flush() } } }

    private suspend fun play(clip: Clip, pitch: Float, speed: Float) = withContext(Dispatchers.IO) {
        val mask = if (clip.channels == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
        val minBuf = AudioTrack.getMinBufferSize(clip.sampleRate, mask, AudioFormat.ENCODING_PCM_16BIT)
        val track = AudioTrack.Builder().setAudioAttributes(attrs)
            .setAudioFormat(AudioFormat.Builder().setSampleRate(clip.sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(mask).build())
            .setBufferSizeInBytes(max(minBuf, clip.sampleRate * clip.channels * 2 / 4)).setTransferMode(AudioTrack.MODE_STREAM).build()
        activeTrack = track
        val totalFrames = clip.pcm.size / clip.channels
        val framesPerWindow = (clip.sampleRate * clip.windowMs / 1000).coerceAtLeast(1)
        var ticker: Job? = null
        try {
            track.play()
            // Pitch/speed are applied at playback so the same voice can be made a little brighter or faster.
            runCatching { track.playbackParams = PlaybackParams().setPitch(pitch).setSpeed(speed) }
            ticker = launch { animateMouth(track, clip, framesPerWindow) }
            var off = 0
            while (off < clip.pcm.size) {
                ensureActive()
                val n = track.write(clip.pcm, off, min(CHUNK, clip.pcm.size - off))
                if (n < 0) throw SpeechError("Audio playback failed (code $n).")
                off += n
            }
            val deadline = SystemClock.elapsedRealtime() + (clip.durationMs / speed).toLong() + 1500
            while (isActive && track.playbackHeadPosition < totalFrames - 64 && SystemClock.elapsedRealtime() < deadline) delay(20)
        } finally {
            ticker?.cancel(); activeTrack = null
            runCatching { track.stop() }; track.release()
            mouthOpen.value = false; mouthLevel.value = 0f
        }
    }

    /** Samples the envelope at the audio's real playback position (with hysteresis so the mouth doesn't flutter). */
    private suspend fun animateMouth(track: AudioTrack, clip: Clip, framesPerWindow: Int) {
        var open = false; var changedAt = 0L
        while (true) {
            val idx = (track.playbackHeadPosition / framesPerWindow).coerceIn(0, clip.envelope.size - 1)
            val level = clip.envelope[idx]
            mouthLevel.value = level
            val want = if (open) level > 0.12f else level > 0.22f
            val now = SystemClock.elapsedRealtime()
            if (want != open && now - changedAt >= 55) { open = want; changedAt = now; mouthOpen.value = open }
            delay(20)
        }
    }

    private fun requestFocus() {
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener { if (it == AudioManager.AUDIOFOCUS_LOSS) stop() }.build()
        focus = req; audio.requestAudioFocus(req)
    }

    private fun abandonFocus() { focus?.let { audio.abandonAudioFocusRequest(it) }; focus = null }

    companion object {
        private const val CHUNK = 4096

        /** Orpheus "vocal directions": a bracketed hint at the start of the text that sets the delivery. */
        fun direction(e: Emotion): String = when (e) {
            Emotion.HAPPY -> "cheerful"; Emotion.EXCITED -> "excited"; Emotion.SAD -> "sad"; Emotion.SERIOUS -> "calm"
            Emotion.CURIOUS -> "curious"; Emotion.CONFUSED -> "unsure"; Emotion.FRUSTRATED -> "annoyed"; Emotion.CALM -> "warm"
            Emotion.SURPRISED -> "surprised"; Emotion.PLAYFUL -> "playful"; Emotion.NEUTRAL -> ""
        }

        /** Strips emoji, markdown symbols and URLs so they aren't read aloud. */
        fun sanitize(text: String): String = text
            .replace(Regex("https?://\\S+"), " link ")
            .replace(Regex("[\\p{So}\\u200d\\ufe0f]"), "")
            .replace(Regex("[*_#`~>|\\[\\]]+"), "")
            .replace(Regex("\\s+"), " ").trim()

        /** Greedily packs whole sentences into pieces of at most [max] characters; very long sentences are cut at commas or spaces. */
        fun split(text: String, max: Int): List<String> {
            val sentences = text.split(Regex("(?<=[.!?…])\\s+")).flatMap { s ->
                if (s.length <= max) listOf(s) else {
                    val parts = mutableListOf<String>(); var rest = s
                    while (rest.length > max) {
                        var cut = rest.lastIndexOf(',', max).takeIf { it > max / 3 } ?: rest.lastIndexOf(' ', max).takeIf { it > 0 } ?: max
                        parts += rest.substring(0, cut).trim(); rest = rest.substring(cut).trimStart(',', ' ')
                    }
                    if (rest.isNotBlank()) parts += rest
                    parts
                }
            }
            val out = mutableListOf<String>(); val cur = StringBuilder()
            for (s in sentences) {
                if (cur.isNotEmpty() && cur.length + s.length + 1 > max) { out += cur.toString(); cur.clear() }
                if (cur.isNotEmpty()) cur.append(' ')
                cur.append(s)
            }
            if (cur.isNotBlank()) out += cur.toString()
            return out.filter { it.isNotBlank() }
        }
    }
}
