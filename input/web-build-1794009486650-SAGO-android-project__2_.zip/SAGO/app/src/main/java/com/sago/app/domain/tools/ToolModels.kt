package com.sago.app.domain.tools

import org.json.JSONObject

enum class ArgType { TEXT, INT, BOOL, ISO_TIME, CLOCK }

data class ToolArg(
    val name: String, val type: ArgType, val required: Boolean = true,
    /** TEXT: max length. INT: max value. */
    val max: Int = 200, val min: Int = 0, val allowed: Set<String>? = null,
)

data class UndoSpec(val type: String, val payload: JSONObject)
data class ConfirmSpec(val type: String, val payload: JSONObject, val prompt: String)

/**
 * The real result of a tool run, produced by app code. [message] is what the user sees on the result card, so a
 * failure can never be reported as a success. [data] (read tools) is fed back to the model to answer from.
 */
data class ToolOutcome(
    val tool: String, val ok: Boolean, val message: String, val data: String? = null,
    val undo: UndoSpec? = null, val confirm: ConfirmSpec? = null, val readOnly: Boolean = false,
)

/** Validates AI-generated tool arguments against a schema. Never trusts the model's output. */
object ToolValidator {
    private val control = Regex("[\\u0000-\\u0008\\u000B\\u000C\\u000E-\\u001F]")

    /** @return cleaned arguments (times as epoch millis, clocks as minute-of-day) or an error message. */
    fun validate(spec: List<ToolArg>, args: JSONObject): Result<JSONObject> {
        val out = JSONObject()
        for (a in spec) {
            val raw = if (args.has(a.name) && !args.isNull(a.name)) args.get(a.name) else null
            val str = raw?.toString()?.replace(control, "")?.trim()
            if (str.isNullOrEmpty()) {
                if (a.required) return Result.failure(IllegalArgumentException("missing “${a.name}”"))
                continue
            }
            when (a.type) {
                ArgType.TEXT -> {
                    if (str.length > a.max) return Result.failure(IllegalArgumentException("“${a.name}” is too long"))
                    val v = str.lowercase()
                    if (a.allowed != null) { if (v !in a.allowed) return Result.failure(IllegalArgumentException("“${a.name}” must be one of ${a.allowed.joinToString("/")}")); out.put(a.name, v) }
                    else out.put(a.name, str)
                }
                ArgType.INT -> {
                    val n = str.toDoubleOrNull()?.toInt() ?: return Result.failure(IllegalArgumentException("“${a.name}” must be a number"))
                    if (n < a.min || n > a.max) return Result.failure(IllegalArgumentException("“${a.name}” must be between ${a.min} and ${a.max}"))
                    out.put(a.name, n)
                }
                ArgType.BOOL -> out.put(a.name, when (str.lowercase()) { "true", "yes", "on", "1" -> true; "false", "no", "off", "0" -> false
                    else -> return Result.failure(IllegalArgumentException("“${a.name}” must be true or false")) })
                ArgType.ISO_TIME -> out.put(a.name, TimeUtil.parseIso(str) ?: return Result.failure(IllegalArgumentException("“${a.name}” isn't a valid date and time")))
                ArgType.CLOCK -> out.put(a.name, TimeUtil.parseClock(str) ?: return Result.failure(IllegalArgumentException("“${a.name}” must look like 08:30")))
            }
        }
        return Result.success(out)
    }
}
