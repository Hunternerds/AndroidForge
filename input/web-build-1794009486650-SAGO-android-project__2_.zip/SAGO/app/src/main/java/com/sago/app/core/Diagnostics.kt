package com.sago.app.core

import android.os.Debug
import android.os.SystemClock
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Measures what actually happens (latency, failures, tokens, startup, wake-word frames) so optimisation can be based
 * on numbers. Logs never contain conversation text, memories or API keys; anything that looks like a key is redacted.
 */
class Diagnostics {
    private val created = SystemClock.elapsedRealtime()
    @Volatile var startupMs: Long = -1; private set

    private class Stat { var count = 0; var fails = 0; var totalMs = 0L; var maxMs = 0L }
    private val api = ConcurrentHashMap<String, Stat>()
    private val counters = ConcurrentHashMap<String, AtomicLong>()
    private val tokens = LongArray(3) // [calls with usage, prompt tokens, completion tokens]
    private val logs = ArrayDeque<String>()
    private val stamp = SimpleDateFormat("HH:mm:ss", Locale.US)

    fun markUiReady() { if (startupMs < 0) startupMs = SystemClock.elapsedRealtime() - created }

    fun api(name: String, ms: Long, ok: Boolean) {
        val s = api.getOrPut(name) { Stat() }
        synchronized(s) { s.count++; if (!ok) s.fails++; s.totalMs += ms; s.maxMs = maxOf(s.maxMs, ms) }
    }

    fun tokens(prompt: Int?, completion: Int?) {
        if (prompt == null) return
        synchronized(tokens) { tokens[0]++; tokens[1] += prompt.toLong(); tokens[2] += (completion ?: 0).toLong() }
    }

    fun count(name: String, n: Long = 1) { counters.getOrPut(name) { AtomicLong() }.addAndGet(n) }
    fun counter(name: String): Long = counters[name]?.get() ?: 0

    fun log(tag: String, message: String) {
        val line = "${stamp.format(Date())} [$tag] ${redact(message)}"
        synchronized(logs) { logs.addLast(line); while (logs.size > 200) logs.removeFirst() }
    }

    fun recentLogs(n: Int = 40): List<String> = synchronized(logs) { logs.toList().takeLast(n) }

    fun avgPromptTokens(): Int = synchronized(tokens) { if (tokens[0] == 0L) 0 else (tokens[1] / tokens[0]).toInt() }

    /** A plain-text report safe to share: numbers and short event names only. */
    fun report(): String = buildString {
        appendLine("SAGO diagnostics")
        appendLine("Startup to first screen: ${if (startupMs >= 0) "$startupMs ms" else "not measured yet"}")
        val rt = Runtime.getRuntime()
        appendLine("Java heap: ${(rt.totalMemory() - rt.freeMemory()) / 1_048_576} MB of ${rt.maxMemory() / 1_048_576} MB; native heap: ${Debug.getNativeHeapAllocatedSize() / 1_048_576} MB")
        appendLine()
        appendLine("Network calls")
        if (api.isEmpty()) appendLine("  none yet")
        api.toSortedMap().forEach { (k, s) ->
            synchronized(s) { appendLine("  $k: ${s.count} calls, avg ${if (s.count > 0) s.totalMs / s.count else 0} ms, max ${s.maxMs} ms, failed ${s.fails}") }
        }
        synchronized(tokens) { if (tokens[0] > 0) appendLine("  chat tokens: avg prompt ${tokens[1] / tokens[0]}, avg reply ${tokens[2] / tokens[0]} over ${tokens[0]} calls") }
        appendLine()
        appendLine("Events")
        if (counters.isEmpty()) appendLine("  none yet")
        counters.toSortedMap().forEach { (k, v) -> appendLine("  $k: ${v.get()}") }
        val frames = counter("wake.frames.total"); val skipped = counter("wake.frames.skipped")
        if (frames > 0) appendLine("  wake-word frames skipped while silent: ${skipped * 100 / frames}%")
        appendLine()
        appendLine("What the numbers suggest")
        suggestions().forEach { appendLine("  • $it") }
    }

    fun suggestions(): List<String> = buildList {
        val avgPrompt = avgPromptTokens()
        if (avgPrompt > 2500) add("Chat requests average $avgPrompt prompt tokens. Lowering Settings → AI → Conversation context would reduce usage.")
        api.forEach { (k, s) -> synchronized(s) { if (s.count >= 5 && s.fails * 100 / s.count >= 20) add("“$k” failed in ${s.fails * 100 / s.count}% of ${s.count} calls: check your connection or Groq limits.") } }
        if (counter("tts.fallbacks") > 0) add("The Groq voice fell back to the device voice ${counter("tts.fallbacks")} time(s).")
        if (counter("wake.empty") > 3) add("Wake word fired ${counter("wake.empty")} times with no request after it; lowering Sensitivity may reduce false activations.")
        if (isEmpty()) add("Nothing stands out yet. Use the app for a while and check again.")
    }

    companion object {
        private val keyPattern = Regex("gsk_[A-Za-z0-9]+|Bearer\\s+[A-Za-z0-9._-]+")
        fun redact(s: String) = s.replace(keyPattern, "[redacted]").take(300)
    }
}
