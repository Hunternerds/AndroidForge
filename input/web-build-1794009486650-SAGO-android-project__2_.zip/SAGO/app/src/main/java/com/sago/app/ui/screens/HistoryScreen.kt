package com.sago.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sago.app.data.db.ConversationEntity
import com.sago.app.ui.components.Backdrop
import com.sago.app.ui.components.ConfirmDialog
import com.sago.app.ui.theme.LocalSagoUi
import com.sago.app.ui.viewmodel.HistoryViewModel
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(vm: HistoryViewModel, onBack: () -> Unit) {
    val ui = LocalSagoUi.current
    val list by vm.conversations.collectAsStateWithLifecycle()
    val active by vm.activeId.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()
    var toDelete by remember { mutableStateOf<ConversationEntity?>(null) }
    val searching = query.trim().length >= 3

    Box(Modifier.fillMaxSize()) {
        Backdrop(true, heavy = true)
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = { Text("Conversations", fontWeight = FontWeight.Bold) },
                    navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                    actions = { IconButton({ vm.newChat(); onBack() }) { Icon(Icons.Default.Add, "New conversation") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent, titleContentColor = ui.text, navigationIconContentColor = ui.text, actionIconContentColor = ui.text),
                )
            },
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                OutlinedTextField(
                    query, { vm.query.value = it }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    placeholder = { Text("Search by meaning, e.g. “that trip we planned”") }, leadingIcon = { Icon(Icons.Default.Search, null) },
                    shape = RoundedCornerShape(24.dp),
                )
                when {
                    searching && results.isEmpty() -> Centered("No past conversation matches that.")
                    searching -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(results, key = { it.conversationId }) { hit ->
                            Surface(shape = RoundedCornerShape(16.dp), color = ui.glass, contentColor = ui.text, border = BorderStroke(1.dp, ui.glassBorder),
                                modifier = Modifier.fillMaxWidth().clickable { vm.open(hit.conversationId); onBack() }) {
                                Column(Modifier.padding(14.dp)) {
                                    Text(hit.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(hit.snippet, style = MaterialTheme.typography.bodyMedium, color = ui.subtext, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                    list.isEmpty() -> Centered("No conversations yet.\nStart one from the main screen and it will show up here.")
                    else -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(list, key = { it.id }) { c ->
                            Surface(
                                shape = RoundedCornerShape(16.dp), color = ui.glass, contentColor = ui.text,
                                border = BorderStroke(if (c.id == active) 2.dp else 1.dp, if (c.id == active) MaterialTheme.colorScheme.primary else ui.glassBorder),
                                modifier = Modifier.fillMaxWidth().clickable { vm.open(c.id); onBack() },
                            ) {
                                Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(c.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                                        Text("Updated " + DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(c.updatedAt)) + if (c.summary != null) " · summarised" else "", style = MaterialTheme.typography.bodyMedium, color = ui.subtext)
                                    }
                                    IconButton({ toDelete = c }) { Icon(Icons.Default.Delete, "Delete conversation", tint = ui.subtext) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    toDelete?.let { c ->
        ConfirmDialog("Delete conversation?", "“${c.title}” and all its messages will be permanently removed from this device.", "Delete", onConfirm = { vm.delete(c.id) }, onDismiss = { toDelete = null })
    }
}

@Composable
private fun Centered(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = LocalSagoUi.current.subtext, textAlign = TextAlign.Center)
    }
}
