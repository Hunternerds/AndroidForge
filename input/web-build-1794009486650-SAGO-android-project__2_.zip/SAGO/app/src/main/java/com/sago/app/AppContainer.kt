package com.sago.app

import android.app.Application
import com.sago.app.core.Connectivity
import com.sago.app.core.Diagnostics
import com.sago.app.core.SecureStore
import com.sago.app.data.*
import com.sago.app.data.db.SagoDatabase
import com.sago.app.data.db.SearchIndex
import com.sago.app.data.groq.GroqClient
import com.sago.app.data.prefs.DEFAULT_PROFILE_ID
import com.sago.app.data.prefs.SettingsStore
import com.sago.app.domain.ai.ConversationEngine
import com.sago.app.domain.ai.ConversationSummarizer
import com.sago.app.domain.memory.MemoryEngine
import com.sago.app.domain.proactive.BriefingComposer
import com.sago.app.domain.proactive.SuggestionEngine
import com.sago.app.domain.tools.ToolActions
import com.sago.app.domain.tools.ToolEnv
import com.sago.app.domain.tools.ToolRegistry
import com.sago.app.reminders.ReminderScheduler
import com.sago.app.vision.ImageProcessor
import com.sago.app.voice.*
import com.sago.app.wake.WakeCoordinator
import com.sago.app.wake.WakeWordModelManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/** Hand-wired dependency container (small enough that a DI framework would add more weight than value). Heavy parts are lazy. */
class AppContainer(private val app: Application) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    val diagnostics = Diagnostics()

    private val secure = SecureStore(app)
    @Volatile private var apiKey: String? = secure.getString(KEY_NAME)

    val settings = SettingsStore(app)
    val http = GroqClient.newHttpClient()
    val groq = GroqClient(http, { apiKey }, diagnostics)
    val connectivity = Connectivity(app)

    /** Set if a failed database upgrade forced a reset (a backup file is kept); the UI tells the user once. */
    @Volatile var dbResetNotice: String? = null
    val db: SagoDatabase by lazy { SagoDatabase.openSafely(app) { dbResetNotice = it } }
    val search = SearchIndex(app)
    val repo: ChatRepository by lazy { ChatRepository(db, search, diagnostics) }
    val memory: MemoryEngine by lazy { MemoryEngine(db.memories(), search) }
    val entries: EntryRepository by lazy { EntryRepository(db.entries(), search) }
    val scheduler = ReminderScheduler(app)
    val remindersRepo: Reminders by lazy { Reminders(db.reminders(), scheduler) }
    val images = ImageProcessor(app)
    val docs: DocumentRepository by lazy { DocumentRepository(app, db.documents(), search, groq, settings, images) }
    val briefing: BriefingComposer by lazy { BriefingComposer(db) }
    val suggestions: SuggestionEngine by lazy { SuggestionEngine(db) }
    val data: DataManager by lazy { DataManager(app, db, search, repo, remindersRepo, scheduler) }

    val toolEnv: ToolEnv by lazy { ToolEnv(app, memory, entries, remindersRepo, docs, repo, groq, settings, connectivity) }
    val toolRegistry: ToolRegistry by lazy { ToolRegistry(toolEnv) }
    val toolActions: ToolActions by lazy { ToolActions(toolEnv) }
    val summarizer: ConversationSummarizer by lazy { ConversationSummarizer(settings, groq, repo, diagnostics) }
    val engine: ConversationEngine by lazy { ConversationEngine(settings, groq, repo, memory, docs, toolRegistry, summarizer, connectivity, diagnostics, scope) }

    val tts = TtsController(app)
    val voice: SpeechOutput by lazy { SpeechOutput(app, tts, groq, settings, diagnostics) }
    val stt = SpeechRecognizerController(app)
    val speech = SpeechToText(settings, groq)
    val recorder = UtteranceRecorder()
    val wake = WakeCoordinator()
    val wakeModel = WakeWordModelManager(app, http)
    val assistant: AssistantController by lazy { AssistantController(app, scope, settings, engine, voice, stt, speech, recorder, wake) }

    /** Set by shortcuts and the widget (e.g. "voice", "new_chat", "library"); the UI consumes it. */
    val pendingAction = MutableStateFlow<String?>(null)

    /** Startup work, off the main thread: open the database, repair the search index, re-arm reminders, schedule housekeeping. */
    fun start() {
        scope.launch(Dispatchers.IO) {
            runCatching {
                db
                data.ensureIndexed()
                remindersRepo.rescheduleAll()
                memory.purgeExpired()
            }.onFailure { diagnostics.log("startup", "init failed: ${it::class.simpleName}") }
        }
        scheduler.scheduleMaintenance()
    }

    val appContext: android.content.Context get() = app

    fun hasApiKey(): Boolean = !apiKey.isNullOrBlank()
    fun appFilesDir(): java.io.File = app.filesDir
    fun maskedKey(): String = apiKey?.let { if (it.length > 10) it.take(4) + "••••••••" + it.takeLast(4) else "••••••••" }.orEmpty()

    /** @return false if the key couldn't be stored securely. */
    fun saveApiKey(key: String): Boolean {
        val ok = secure.putString(KEY_NAME, key.trim())
        if (ok) apiKey = key.trim()
        return ok
    }

    fun clearApiKey() { secure.remove(KEY_NAME); apiKey = null }

    suspend fun ensureProfile() = repo.ensureDefaultProfile(DEFAULT_PROFILE_ID, "Me")

    private companion object { const val KEY_NAME = "groq_api_key" }
}
