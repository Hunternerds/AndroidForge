package com.sago.app.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profiles ORDER BY createdAt") fun observeAll(): Flow<List<ProfileEntity>>
    @Query("SELECT * FROM profiles ORDER BY createdAt") suspend fun all(): List<ProfileEntity>
    @Query("SELECT COUNT(*) FROM profiles") suspend fun count(): Int
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(p: ProfileEntity)
    @Query("DELETE FROM profiles WHERE id = :id") suspend fun delete(id: String)
}

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations WHERE profileId = :profileId ORDER BY updatedAt DESC")
    fun observeAll(profileId: String): Flow<List<ConversationEntity>>
    @Query("SELECT * FROM conversations WHERE profileId = :profileId ORDER BY updatedAt DESC LIMIT :n")
    suspend fun latest(profileId: String, n: Int): List<ConversationEntity>
    @Query("SELECT * FROM conversations WHERE id = :id") suspend fun get(id: Long): ConversationEntity?
    @Query("SELECT * FROM conversations") suspend fun everything(): List<ConversationEntity>
    @Query("SELECT id FROM conversations WHERE profileId = :profileId") suspend fun idsFor(profileId: String): List<Long>
    @Query("SELECT id FROM conversations WHERE updatedAt < :cutoff") suspend fun idsOlderThan(cutoff: Long): List<Long>
    @Insert suspend fun insert(c: ConversationEntity): Long
    @Query("UPDATE conversations SET updatedAt = :t WHERE id = :id") suspend fun touch(id: Long, t: Long)
    @Query("UPDATE conversations SET summary = :summary, summarizedUpTo = :upTo WHERE id = :id") suspend fun setSummary(id: Long, summary: String, upTo: Long)
    @Query("UPDATE conversations SET title = :title, titleByAi = 1 WHERE id = :id") suspend fun setAiTitle(id: Long, title: String)
    @Query("DELETE FROM conversations WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM conversations WHERE profileId = :profileId") suspend fun deleteAllFor(profileId: String)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :cid ORDER BY createdAt, id")
    fun observe(cid: Long): Flow<List<MessageEntity>>
    @Query("SELECT * FROM (SELECT * FROM messages WHERE conversationId = :cid AND role != 'TOOL' ORDER BY createdAt DESC, id DESC LIMIT :limit) ORDER BY createdAt, id")
    suspend fun recent(cid: Long, limit: Int): List<MessageEntity>
    @Query("SELECT * FROM messages WHERE conversationId = :cid AND id > :afterId AND role != 'TOOL' ORDER BY id LIMIT :limit")
    suspend fun after(cid: Long, afterId: Long, limit: Int): List<MessageEntity>
    @Query("SELECT COUNT(*) FROM messages WHERE conversationId = :cid AND id > :afterId AND role != 'TOOL'")
    suspend fun countAfter(cid: Long, afterId: Long): Int
    @Query("SELECT * FROM messages WHERE conversationId = :cid ORDER BY id") suspend fun all(cid: Long): List<MessageEntity>
    @Query("SELECT * FROM messages WHERE id = :id") suspend fun get(id: Long): MessageEntity?
    @Query("SELECT * FROM messages WHERE role != 'TOOL'") suspend fun allIndexable(): List<MessageEntity>
    @Insert suspend fun insert(m: MessageEntity): Long
    @Query("UPDATE messages SET meta = :meta WHERE id = :id") suspend fun setMeta(id: Long, meta: String?)
    @Query("UPDATE messages SET text = :text, meta = :meta WHERE id = :id") suspend fun updateCard(id: Long, text: String, meta: String?)
    @Query("SELECT imagePath FROM messages WHERE imagePath IS NOT NULL AND conversationId IN (SELECT id FROM conversations WHERE profileId = :profileId)")
    suspend fun imagePathsFor(profileId: String): List<String>
    @Query("SELECT imagePath FROM messages WHERE imagePath IS NOT NULL AND conversationId = :cid")
    suspend fun imagePathsIn(cid: Long): List<String>
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories WHERE profileId = :profileId ORDER BY importance DESC, updatedAt DESC")
    fun observe(profileId: String): Flow<List<MemoryEntity>>
    @Query("SELECT * FROM memories WHERE profileId = :profileId") suspend fun all(profileId: String): List<MemoryEntity>
    @Query("SELECT * FROM memories WHERE id = :id") suspend fun get(id: Long): MemoryEntity?
    @Query("SELECT * FROM memories") suspend fun everything(): List<MemoryEntity>
    @Query("SELECT * FROM memories WHERE expiresAt IS NOT NULL AND expiresAt < :now") suspend fun expired(now: Long): List<MemoryEntity>
    @Insert suspend fun insert(m: MemoryEntity): Long
    @Update suspend fun update(m: MemoryEntity)
    @Query("UPDATE memories SET lastUsedAt = :t WHERE id IN (:ids)") suspend fun markUsed(ids: List<Long>, t: Long)
    @Query("DELETE FROM memories WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM memories WHERE profileId = :profileId") suspend fun clear(profileId: String)
}

@Dao
interface EntryDao {
    @Query("SELECT * FROM entries WHERE profileId = :profileId ORDER BY done, COALESCE(dueAt, 9223372036854775807), updatedAt DESC")
    fun observe(profileId: String): Flow<List<EntryEntity>>
    @Query("SELECT * FROM entries WHERE profileId = :profileId") suspend fun all(profileId: String): List<EntryEntity>
    @Query("SELECT * FROM entries") suspend fun everything(): List<EntryEntity>
    @Query("SELECT * FROM entries WHERE id = :id") suspend fun get(id: Long): EntryEntity?
    @Query("SELECT * FROM entries WHERE profileId = :profileId AND kind = 'task' AND done = 0 ORDER BY COALESCE(dueAt, 9223372036854775807) LIMIT :n")
    suspend fun openTasks(profileId: String, n: Int): List<EntryEntity>
    @Insert suspend fun insert(e: EntryEntity): Long
    @Update suspend fun update(e: EntryEntity)
    @Query("DELETE FROM entries WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM entries WHERE profileId = :profileId") suspend fun clear(profileId: String)
}

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders WHERE profileId = :profileId ORDER BY enabled DESC, triggerAt")
    fun observe(profileId: String): Flow<List<ReminderEntity>>
    @Query("SELECT * FROM reminders WHERE profileId = :profileId") suspend fun all(profileId: String): List<ReminderEntity>
    @Query("SELECT * FROM reminders WHERE enabled = 1") suspend fun allEnabled(): List<ReminderEntity>
    @Query("SELECT * FROM reminders WHERE id = :id") suspend fun get(id: Long): ReminderEntity?
    @Insert suspend fun insert(r: ReminderEntity): Long
    @Update suspend fun update(r: ReminderEntity)
    @Query("DELETE FROM reminders WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM reminders WHERE profileId = :profileId") suspend fun clear(profileId: String)
}

@Dao
interface DocumentDao {
    @Query("SELECT id, title, sizeBytes, createdAt, summary FROM documents WHERE profileId = :profileId ORDER BY createdAt DESC")
    fun observe(profileId: String): Flow<List<DocumentInfo>>
    @Query("SELECT * FROM documents WHERE id = :id") suspend fun get(id: Long): DocumentEntity?
    @Query("SELECT * FROM documents") suspend fun everything(): List<DocumentEntity>
    @Query("SELECT * FROM documents WHERE profileId = :profileId AND hash = :hash LIMIT 1") suspend fun findByHash(profileId: String, hash: String): DocumentEntity?
    @Insert suspend fun insert(d: DocumentEntity): Long
    @Query("UPDATE documents SET summary = :summary WHERE id = :id") suspend fun setSummary(id: Long, summary: String)
    @Query("DELETE FROM documents WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM documents WHERE profileId = :profileId") suspend fun clear(profileId: String)
}
