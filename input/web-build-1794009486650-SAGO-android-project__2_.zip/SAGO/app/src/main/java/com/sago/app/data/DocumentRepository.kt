package com.sago.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import com.sago.app.data.db.DocumentDao
import com.sago.app.data.db.DocumentEntity
import com.sago.app.data.db.DocumentInfo
import com.sago.app.data.db.SearchIndex
import com.sago.app.data.groq.ChatRequest
import com.sago.app.data.groq.ChatTurn
import com.sago.app.data.groq.GroqClient
import com.sago.app.data.prefs.SettingsStore
import com.sago.app.domain.ai.VaultSnippet
import com.sago.app.vision.ImageProcessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.security.MessageDigest

sealed interface ImportResult {
    data class Added(val title: String, val note: String? = null) : ImportResult
    data class Duplicate(val title: String) : ImportResult
    data class Failed(val message: String) : ImportResult
}

/**
 * The private knowledge vault: text files import directly; PDFs and photos are read with the vision model (the pages
 * are sent to Groq for that one step). Everything is stored on the device and indexed for full-text search.
 */
class DocumentRepository(
    private val ctx: Context, private val dao: DocumentDao, private val index: SearchIndex,
    private val groq: GroqClient, private val settings: SettingsStore, private val images: ImageProcessor,
) {
    fun observe(profileId: String): Flow<List<DocumentInfo>> = dao.observe(profileId)

    suspend fun importUri(profileId: String, uri: Uri): ImportResult = withContext(Dispatchers.IO) {
        val name = displayName(uri)
        val mime = ctx.contentResolver.getType(uri).orEmpty()
        val lower = name.lowercase()
        try {
            when {
                mime.startsWith("text/") || mime == "application/json" || lower.endsWith(".md") || lower.endsWith(".txt") || lower.endsWith(".csv") || lower.endsWith(".json") || lower.endsWith(".log") -> {
                    val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@withContext ImportResult.Failed("Couldn't open that file.")
                    if (bytes.size > MAX_BYTES) return@withContext ImportResult.Failed("That file is larger than 600 KB. Split it into smaller parts.")
                    addText(profileId, name, String(bytes, Charsets.UTF_8))
                }
                mime == "application/pdf" || lower.endsWith(".pdf") -> {
                    val pages = renderPdf(uri)
                    if (pages.isEmpty()) return@withContext ImportResult.Failed("Couldn't read any pages from that PDF.")
                    val note = if (pages.size >= MAX_PDF_PAGES) "Only the first $MAX_PDF_PAGES pages were read." else null
                    addOcr(profileId, name, pages, note)
                }
                mime.startsWith("image/") -> addOcr(profileId, name, listOf(images.fromUri(uri).jpeg), null)
                else -> ImportResult.Failed("SAGO can import text files, PDFs and photos. “$name” isn't one of those.")
            }
        } catch (e: kotlinx.coroutines.CancellationException) { throw e }
        catch (e: com.sago.app.data.groq.GroqError) { ImportResult.Failed(e.userMessage) }
        catch (e: Exception) { ImportResult.Failed("Couldn't import “$name”: ${e.message ?: "unknown problem"}") }
    }

    suspend fun addText(profileId: String, title: String, text: String): ImportResult {
        val clean = text.replace("\u0000", "").trim()
        if (clean.length < 20) return ImportResult.Failed("There wasn't any readable text in “$title”.")
        val hash = sha256(clean)
        dao.findByHash(profileId, hash)?.let { return ImportResult.Duplicate(it.title) }
        val doc = DocumentEntity(profileId = profileId, title = title.take(80), text = clean.take(MAX_CHARS), hash = hash, summary = null, sizeBytes = clean.length, createdAt = System.currentTimeMillis())
        val id = dao.insert(doc)
        index.replaceAll(profileId, "doc", id.toString(), doc.title, SearchIndex.chunk(doc.text))
        return ImportResult.Added(doc.title, if (clean.length > MAX_CHARS) "Only the first ${MAX_CHARS / 1000}k characters were stored." else null)
    }

    suspend fun delete(id: Long) { dao.delete(id); index.remove("doc", id.toString()) }
    suspend fun clearProfile(profileId: String) { dao.clear(profileId) }

    suspend fun summarize(id: Long): String {
        val doc = dao.get(id) ?: return "Document not found."
        doc.summary?.let { return it }
        val s = settings.snapshot()
        val res = groq.chat(ChatRequest(
            s.textModel,
            listOf(ChatTurn("system", "Summarize the document faithfully in under 120 words. Use only what the text says; do not add outside facts."), ChatTurn("user", doc.text.take(12_000))),
            0.2f, 320, jsonMode = false,
        ))
        val summary = res.text.replace(Regex("<think>.*?</think>", RegexOption.DOT_MATCHES_ALL), "").trim()
        dao.setSummary(id, summary)
        return summary
    }

    /** Best excerpts from documents and notes for [query], labelled S1, S2… so answers can cite them. */
    suspend fun retrieve(profileId: String, query: String, k: Int = 3): List<VaultSnippet> {
        val q = SearchIndex.tokens(query).toSet()
        if (q.isEmpty()) return emptyList()
        return index.query(profileId, query, listOf("doc", "note"), 30)
            .map { h -> h to SearchIndex.tokens(h.body).count { it in q } }
            .filter { it.second >= 1 }.sortedByDescending { it.second }
            .distinctBy { it.first.kind + it.first.ref }.take(k)
            .mapIndexed { i, (h, _) -> VaultSnippet("S${i + 1}", h.title, h.body.take(450)) }
    }

    private suspend fun addOcr(profileId: String, title: String, jpegs: List<ByteArray>, note: String?): ImportResult {
        val s = settings.snapshot()
        val text = StringBuilder()
        jpegs.chunked(4).forEach { batch ->
            val urls = batch.map { "data:image/jpeg;base64," + Base64.encodeToString(it, Base64.NO_WRAP) }
            val res = groq.chat(ChatRequest(
                s.visionModel,
                listOf(ChatTurn("user", "Transcribe all readable text from these images in reading order. Output only the text. If there is no readable text, output NO_TEXT.", urls)),
                0f, 1800, jsonMode = false,
            ))
            text.append(res.text.replace(Regex("<think>.*?</think>", RegexOption.DOT_MATCHES_ALL), "").trim()).append("\n\n")
        }
        val out = text.toString().replace("NO_TEXT", "").trim()
        if (out.length < 20) return ImportResult.Failed("No readable text was found in “$title”.")
        val result = addText(profileId, title, out)
        return if (result is ImportResult.Added && note != null) result.copy(note = note) else result
    }

    private fun renderPdf(uri: Uri): List<ByteArray> {
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return emptyList()
        val out = ArrayList<ByteArray>()
        pfd.use {
            PdfRenderer(it).use { renderer ->
                for (i in 0 until minOf(renderer.pageCount, MAX_PDF_PAGES)) {
                    renderer.openPage(i).use { page ->
                        val w = 1100; val h = (page.height * w / page.width.toFloat()).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.WHITE) }
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        out += ByteArrayOutputStream().also { bos -> bmp.compress(Bitmap.CompressFormat.JPEG, 70, bos) }.toByteArray()
                        bmp.recycle()
                    }
                }
            }
        }
        return out
    }

    private fun displayName(uri: Uri): String = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull() ?: uri.lastPathSegment ?: "Document"

    private fun sha256(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private companion object {
        const val MAX_BYTES = 600_000
        const val MAX_CHARS = 400_000
        const val MAX_PDF_PAGES = 8
    }
}
