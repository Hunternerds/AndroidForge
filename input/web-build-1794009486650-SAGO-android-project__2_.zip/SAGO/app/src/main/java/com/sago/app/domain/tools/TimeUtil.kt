package com.sago.app.domain.tools

import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale

object TimeUtil {
    private val zone get() = ZoneId.systemDefault()

    /** Accepts "2026-11-05T09:00", "2026-11-05T09:00:00+01:00", "2026-11-05 09:00" or a bare date (09:00 assumed). */
    fun parseIso(raw: String): Long? {
        val s = raw.trim().replace(' ', 'T')
        runCatching { return OffsetDateTime.parse(s).toInstant().toEpochMilli() }
        runCatching { return LocalDateTime.parse(s).atZone(zone).toInstant().toEpochMilli() }
        runCatching { return LocalDate.parse(s).atTime(9, 0).atZone(zone).toInstant().toEpochMilli() }
        return null
    }

    /** "08:30" or "8:30" → minute of day. */
    fun parseClock(raw: String): Int? {
        val m = Regex("^\\s*(\\d{1,2}):(\\d{2})\\s*$").find(raw) ?: return null
        val h = m.groupValues[1].toInt(); val min = m.groupValues[2].toInt()
        return if (h in 0..23 && min in 0..59) h * 60 + min else null
    }

    /** First occurrence of [minuteOfDay] strictly after [after] that satisfies [recurrence] (none → that day only). */
    fun nextOccurrence(recurrence: String, minuteOfDay: Int, after: Long): Long {
        var date = Instant.ofEpochMilli(after).atZone(zone).toLocalDate()
        repeat(9) {
            val cand = date.atTime(minuteOfDay / 60, minuteOfDay % 60).atZone(zone).toInstant().toEpochMilli()
            val okDay = recurrence != "weekdays" || date.dayOfWeek !in setOf(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY)
            if (cand > after && okDay) return cand
            date = date.plusDays(1)
        }
        return after + 86_400_000L
    }

    /** The next fire time after a reminder has just fired; -1 when it doesn't repeat. */
    fun nextAfterFire(recurrence: String, minuteOfDay: Int, previousTrigger: Long, now: Long): Long = when (recurrence) {
        "daily", "weekdays" -> nextOccurrence(recurrence, minuteOfDay, now)
        "weekly" -> { var t = previousTrigger; while (t <= now) t += 7 * 86_400_000L; t }
        else -> -1L
    }

    fun inQuietHours(now: Long, startMin: Int, endMin: Int): Boolean {
        val t = Instant.ofEpochMilli(now).atZone(zone).toLocalTime(); val m = t.hour * 60 + t.minute
        return if (startMin == endMin) false else if (startMin < endMin) m in startMin until endMin else (m >= startMin || m < endMin)
    }

    fun endOfQuiet(now: Long, endMin: Int): Long = nextOccurrence("daily", endMin, now)

    fun formatWhen(ms: Long): String = Instant.ofEpochMilli(ms).atZone(zone).format(DateTimeFormatter.ofPattern("EEE d MMM, HH:mm", Locale.getDefault()))
    fun formatClock(minuteOfDay: Int): String = "%02d:%02d".format(minuteOfDay / 60, minuteOfDay % 60)
}
