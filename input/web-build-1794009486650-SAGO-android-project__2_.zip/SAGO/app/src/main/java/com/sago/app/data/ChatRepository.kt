package com.sago.app.data

import android.os.SystemClock
import com.sago.app.core.Diagnostics
import com.sago.app.data.db.*
import com.sago.app.domain.model.ChatMessage
import com.sago.app.domain.model.Emotion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

data class ConversationHit(val conversationId: Long, val title: String, val snippet: String)

/** Conversations, messages and profiles. Every operation is scoped to a profile so data never crosses accounts. */
class ChatRepository(private val db: SagoDatabase, private val index: SearchIndex, private val diag: Diagnostics) {

    fun conversations(profileId: String): Flow<List<ConversationEntity>> = db.conversations().observeAll(profileId)

    fun messages(conversationId: Long): Flow<List<ChatMessage>> =
        db.messages().observe(conversationId).map { list -> list.map { it.toModel() } }

    suspend fun conversation(id: Long, profileId: String): ConversationEntity? =
        db.conversations().get(id)?.takeIf { it.profileId == profileId }

    suspend fun latestConversations(profileId: String, n: Int) = db.conversations().latest(profileId, n)

    suspend fun createConversation(profileId: String, firstText: String): Long {
        val now = System.currentTimeMillis()
        val title = firstText.trim().replace(Regex("\\s+"), " ").take(48).ifBlank { "New conversation" }
        return db.conversations().insert(ConversationEntity(profileId = profileId, title = title, createdAt = now, updatedAt = now))
    }

    suspend fun addMessage(
        conversationId: Long, role: ChatMessage.Role, text: String, emotion: Emotion? = null, imagePath: String? = null,
        sources: List<String> = emptyList(), meta: String? = null,
    ): Long {
        val t0 = SystemClock.elapsedRealtime()
        val now = System.currentTimeMillis()
        val id = db.messages().insert(
            MessageEntity(
                conversationId = conversationId, role = role.name, text = text, emotion = emotion?.name, imagePath = imagePath,
                createdAt = now, sources = sources.joinToString("|").ifBlank { null }, meta = meta,
            )
        )
        db.conversations().touch(conversationId, now)
        if (role != ChatMessage.Role.TOOL && text.length >= 12) {
            db.conversations().get(conversationId)?.let { c -> index.upsert(c.profileId, "conv", "$conversationId:$id", c.title, text) }
        }
        diag.api("db.addMessage", SystemClock.elapsedRealtime() - t0, true)
        return id
    }

    suspend fun message(id: Long): ChatMessage? = db.messages().get(id)?.toModel()
    suspend fun updateMeta(id: Long, meta: String?) = db.messages().setMeta(id, meta)
    suspend fun updateCard(id: Long, text: String, meta: String?) = db.messages().updateCard(id, text, meta)

    suspend fun recent(conversationId: Long, limit: Int): List<ChatMessage> {
        val t0 = SystemClock.elapsedRealtime()
        return db.messages().recent(conversationId, limit).map { it.toModel() }.also { diag.api("db.recent", SystemClock.elapsedRealtime() - t0, true) }
    }

    suspend fun after(conversationId: Long, afterId: Long, limit: Int): List<ChatMessage> =
        db.messages().after(conversationId, afterId, limit).map { it.toModel() }

    suspend fun countAfter(conversationId: Long, afterId: Long): Int = db.messages().countAfter(conversationId, afterId)
    suspend fun conversationById(id: Long): ConversationEntity? = db.conversations().get(id)
    suspend fun setSummary(id: Long, summary: String, upTo: Long) = db.conversations().setSummary(id, summary, upTo)

    suspend fun setAiTitle(id: Long, title: String) {
        val clean = title.trim().trim('"', '.', '“', '”').take(48)
        if (clean.length < 2) return
        db.conversations().setAiTitle(id, clean)
    }

    /** Natural-language search over past conversations. */
    suspend fun searchConversations(profileId: String, query: String, limit: Int = 5): List<ConversationHit> {
        val hits = index.query(profileId, query, listOf("conv"), 40)
        return hits.groupBy { it.ref.substringBefore(':') }.entries.take(limit).mapNotNull { (cid, list) ->
            val id = cid.toLongOrNull() ?: return@mapNotNull null
            ConversationHit(id, list.first().title, list.first().body.take(160))
        }
    }

    suspend fun deleteConversation(id: Long) = withContext(Dispatchers.IO) {
        db.messages().imagePathsIn(id).forEach { paths -> deleteImages(paths) }
        db.conversations().delete(id)
        index.removeRefPrefix("conv", "$id:")
    }

    suspend fun deleteAllConversations(profileId: String) = withContext(Dispatchers.IO) {
        db.messages().imagePathsFor(profileId).forEach { deleteImages(it) }
        db.conversations().idsFor(profileId).forEach { index.removeRefPrefix("conv", "$it:") }
        db.conversations().deleteAllFor(profileId)
    }

    /** Retention: removes conversations not touched since [cutoff]. @return how many were deleted. */
    suspend fun deleteOlderThan(cutoff: Long): Int {
        val ids = db.conversations().idsOlderThan(cutoff)
        ids.forEach { deleteConversation(it) }
        return ids.size
    }

    private fun deleteImages(joined: String) = joined.split('|').forEach { runCatching { File(it).delete() } }

    // ---- profiles ----
    fun profiles(): Flow<List<ProfileEntity>> = db.profiles().observeAll()
    suspend fun allProfiles(): List<ProfileEntity> = db.profiles().all()

    suspend fun ensureDefaultProfile(id: String, name: String) {
        if (db.profiles().count() == 0) db.profiles().insert(ProfileEntity(id, name, System.currentTimeMillis()))
    }

    suspend fun createProfile(name: String): String {
        val id = UUID.randomUUID().toString()
        db.profiles().insert(ProfileEntity(id, name.trim().take(24).ifBlank { "Profile" }, System.currentTimeMillis()))
        return id
    }

    suspend fun removeProfileRow(id: String) = db.profiles().delete(id)

    private fun MessageEntity.toModel() = ChatMessage(
        id = id, conversationId = conversationId,
        role = ChatMessage.Role.entries.firstOrNull { it.name == role } ?: ChatMessage.Role.ASSISTANT,
        text = text, emotion = emotion?.let { Emotion.parse(it) }, imagePath = imagePath, createdAt = createdAt,
        sources = sources?.split('|')?.filter { it.isNotBlank() }.orEmpty(), meta = meta,
    )
}
