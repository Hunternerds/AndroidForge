package com.sago.app.data.db

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class SearchHit(val kind: String, val ref: String, val title: String, val body: String)

/**
 * Local full-text search (SQLite FTS4) over memories, notes, documents and past conversations.
 * It lives in its own small database file, separate from Room, so it can be rebuilt from the main data at any
 * time and can never block a Room schema upgrade.
 */
class SearchIndex(context: Context) : SQLiteOpenHelper(context, "sago_search.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE VIRTUAL TABLE idx USING fts4(profile, kind, ref, title, body, tokenize=unicode61)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS idx"); onCreate(db)
    }

    suspend fun upsert(profile: String, kind: String, ref: String, title: String, body: String) = withContext(Dispatchers.IO) {
        runCatching {
            val db = writableDatabase
            db.beginTransaction()
            try {
                db.delete("idx", "kind = ? AND ref = ?", arrayOf(kind, ref))
                db.insert("idx", null, ContentValues().apply { put("profile", profile); put("kind", kind); put("ref", ref); put("title", title); put("body", body) })
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        }
        Unit
    }

    suspend fun replaceAll(profile: String, kind: String, ref: String, title: String, chunks: List<String>) = withContext(Dispatchers.IO) {
        runCatching {
            val db = writableDatabase
            db.beginTransaction()
            try {
                db.delete("idx", "kind = ? AND ref = ?", arrayOf(kind, ref))
                chunks.forEach { c -> db.insert("idx", null, ContentValues().apply { put("profile", profile); put("kind", kind); put("ref", ref); put("title", title); put("body", c) }) }
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        }
        Unit
    }

    suspend fun remove(kind: String, ref: String) = withContext(Dispatchers.IO) { runCatching { writableDatabase.delete("idx", "kind = ? AND ref = ?", arrayOf(kind, ref)) }; Unit }
    suspend fun removeRefPrefix(kind: String, prefix: String) = withContext(Dispatchers.IO) { runCatching { writableDatabase.delete("idx", "kind = ? AND ref LIKE ?", arrayOf(kind, "$prefix%")) }; Unit }
    suspend fun removeProfile(profile: String) = withContext(Dispatchers.IO) { runCatching { writableDatabase.delete("idx", "profile = ?", arrayOf(profile)) }; Unit }
    suspend fun clearAll() = withContext(Dispatchers.IO) { runCatching { writableDatabase.delete("idx", null, null) }; Unit }

    suspend fun count(kind: String): Int = withContext(Dispatchers.IO) {
        runCatching { readableDatabase.rawQuery("SELECT COUNT(*) FROM idx WHERE kind = ?", arrayOf(kind)).use { if (it.moveToFirst()) it.getInt(0) else 0 } }.getOrDefault(0)
    }

    /** Natural-language friendly: any meaningful word may match (prefix match), then the caller re-ranks. */
    suspend fun query(profile: String, text: String, kinds: List<String>, limit: Int = 20): List<SearchHit> = withContext(Dispatchers.IO) {
        val match = matchExpression(text) ?: return@withContext emptyList()
        val kindFilter = kinds.joinToString(",") { "'" + it.replace("'", "") + "'" }
        runCatching {
            readableDatabase.rawQuery(
                "SELECT kind, ref, title, body FROM idx WHERE idx MATCH ? AND profile = ? AND kind IN ($kindFilter) LIMIT $limit",
                arrayOf(match, profile),
            ).use { c ->
                buildList { while (c.moveToNext()) add(SearchHit(c.getString(0), c.getString(1), c.getString(2), c.getString(3))) }
            }
        }.getOrDefault(emptyList())
    }

    companion object {
        private val STOP = setOf("the", "and", "for", "that", "with", "this", "from", "are", "was", "has", "have", "you", "your", "what", "when", "how", "can", "not", "about", "tell", "know", "remember", "did", "does", "were", "any", "all", "our", "who", "why")

        fun tokens(text: String): List<String> =
            text.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 && it !in STOP }.distinct().take(8)

        fun matchExpression(text: String): String? =
            tokens(text).takeIf { it.isNotEmpty() }?.joinToString(" OR ") { "$it*" }

        fun chunk(text: String, size: Int = 700, overlap: Int = 80, maxChunks: Int = 400): List<String> {
            val clean = text.replace(Regex("[ \\t]+"), " ").trim()
            if (clean.length <= size) return listOf(clean).filter { it.isNotBlank() }
            val out = ArrayList<String>(); var i = 0
            while (i < clean.length && out.size < maxChunks) {
                var end = (i + size).coerceAtMost(clean.length)
                if (end < clean.length) { val brk = clean.lastIndexOfAny(charArrayOf('.', '\n', '!', '?'), end); if (brk > i + size / 2) end = brk + 1 }
                out += clean.substring(i, end).trim()
                if (end >= clean.length) break
                i = (end - overlap).coerceAtLeast(i + 1)
            }
            return out
        }
    }
}
