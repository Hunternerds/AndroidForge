package com.sago.app.reminders

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.sago.app.SagoApp

/** Daily housekeeping. Everything here is local; nothing is sent over the network. */
class MaintenanceWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val c = (applicationContext as SagoApp).container
        runCatching {
            c.memory.purgeExpired()
            c.repo.allProfiles().forEach { c.memory.consolidate(it.id) }
            val days = c.settings.snapshot().retentionDays
            if (days > 0) c.repo.deleteOlderThan(System.currentTimeMillis() - days * 86_400_000L)
            c.data.ensureIndexed()
        }.onFailure { c.diagnostics.log("maintenance", "failed: ${it::class.simpleName}") }
        return Result.success()
    }
}
