package com.sago.app.domain.tools

import com.sago.app.data.db.MemoryEntity
import com.sago.app.data.prefs.Keys
import org.json.JSONArray
import org.json.JSONObject

/** What a TOOL card in the chat can still do: wait for confirmation, or be undone. Stored as JSON in messages.meta. */
object CardMeta {
    data class Card(val kind: String, val specType: String, val payload: JSONObject, val prompt: String)

    fun undo(spec: UndoSpec): String = JSONObject().put("kind", "undo").put("type", spec.type).put("payload", spec.payload).toString()
    fun confirm(spec: ConfirmSpec): String = JSONObject().put("kind", "confirm").put("type", spec.type).put("payload", spec.payload).put("prompt", spec.prompt).toString()

    fun parse(meta: String?): Card? = runCatching {
        val j = JSONObject(meta ?: return null)
        Card(j.getString("kind"), j.getString("type"), j.optJSONObject("payload") ?: JSONObject(), j.optString("prompt"))
    }.getOrNull()

    fun memoryToJson(m: MemoryEntity): JSONObject = JSONObject().put("profileId", m.profileId).put("text", m.text).put("source", m.source)
        .put("createdAt", m.createdAt).put("updatedAt", m.updatedAt).put("lastUsedAt", m.lastUsedAt).put("category", m.category)
        .put("importance", m.importance).put("confidence", m.confidence.toDouble()).put("expiresAt", m.expiresAt ?: JSONObject.NULL)

    fun memoryFromJson(j: JSONObject) = MemoryEntity(
        profileId = j.getString("profileId"), text = j.getString("text"), source = j.getString("source"), createdAt = j.getLong("createdAt"),
        updatedAt = j.getLong("updatedAt"), lastUsedAt = j.getLong("lastUsedAt"), category = j.getString("category"),
        importance = j.getInt("importance"), confidence = j.getDouble("confidence").toFloat(), expiresAt = if (j.isNull("expiresAt")) null else j.getLong("expiresAt"),
    )
}

/** Executes the Confirm / Undo buttons on result cards. Every outcome is reported honestly. */
class ToolActions(private val env: ToolEnv) {

    /** @return the text the card should show afterwards. */
    suspend fun confirm(profileId: String, card: CardMeta.Card): String = try {
        when (card.specType) {
            "forget_memory" -> {
                val ids = card.payload.optJSONArray("ids") ?: JSONArray()
                val n = (0 until ids.length()).count { runCatching { env.memory.delete(ids.getLong(it)) }.isSuccess }
                if (n > 0) "Forgotten ($n memor${if (n == 1) "y" else "ies"})." else "Nothing was removed."
            }
            "clear_memories" -> { env.memory.clear(profileId); "All memories for this profile were erased." }
            else -> "I don't know how to do that any more."
        }
    } catch (e: Exception) { "That didn't work: ${e.message ?: "unknown problem"}" }

    suspend fun undo(card: CardMeta.Card): String = try {
        val p = card.payload
        when (card.specType) {
            "delete_memory" -> { env.memory.delete(p.getLong("id")); "Undone: memory removed." }
            "restore_memory" -> { env.memory.restore(CardMeta.memoryFromJson(p)); "Undone: memory restored." }
            "delete_entry" -> { env.entries.delete(p.getLong("id")); "Undone: removed." }
            "reopen_task" -> { env.entries.setDone(p.getLong("id"), false); "Undone: task reopened." }
            "cancel_reminder" -> { env.reminders.delete(p.getLong("id")); "Undone: reminder cancelled." }
            "restore_setting" -> {
                val name = p.getString("name"); val v = p.getString("value")
                when (name) {
                    "speak_replies" -> env.settings.set(Keys.SPEAK_REPLIES, v.toBoolean())
                    "show_emotion" -> env.settings.set(Keys.SHOW_EMOTION, v.toBoolean())
                    "reply_style" -> env.settings.set(Keys.REPLY_STYLE, v)
                }
                "Undone: setting restored."
            }
            else -> "I can't undo that."
        }
    } catch (e: Exception) { "Couldn't undo: ${e.message ?: "unknown problem"}" }
}
