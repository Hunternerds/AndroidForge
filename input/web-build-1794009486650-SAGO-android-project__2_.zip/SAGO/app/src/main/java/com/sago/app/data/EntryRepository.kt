package com.sago.app.data

import com.sago.app.data.db.EntryDao
import com.sago.app.data.db.EntryEntity
import com.sago.app.data.db.SearchIndex
import kotlinx.coroutines.flow.Flow

/** Notes and tasks (the "intelligent notes" store). Both are searchable and can be created by the user or by SAGO. */
class EntryRepository(private val dao: EntryDao, private val index: SearchIndex) {
    fun observe(profileId: String): Flow<List<EntryEntity>> = dao.observe(profileId)
    suspend fun get(id: Long) = dao.get(id)
    suspend fun openTasks(profileId: String, n: Int) = dao.openTasks(profileId, n)

    suspend fun addNote(profileId: String, title: String, body: String, source: String = "user"): EntryEntity =
        insert(EntryEntity(profileId = profileId, kind = "note", title = title.take(80), body = body.take(4000), done = false, dueAt = null, createdAt = now(), updatedAt = now(), source = source))

    suspend fun addTask(profileId: String, title: String, dueAt: Long?, source: String = "user"): EntryEntity =
        insert(EntryEntity(profileId = profileId, kind = "task", title = title.take(120), body = "", done = false, dueAt = dueAt, createdAt = now(), updatedAt = now(), source = source))

    suspend fun update(e: EntryEntity) { val u = e.copy(updatedAt = now()); dao.update(u); reindex(u) }
    suspend fun setDone(id: Long, done: Boolean) { dao.get(id)?.let { update(it.copy(done = done)) } }
    suspend fun delete(id: Long) { dao.delete(id); index.remove("note", id.toString()) }
    suspend fun clearProfile(profileId: String) { dao.clear(profileId); }

    /** Open task whose title best matches [title] (for "mark X as done"). */
    suspend fun findOpenTask(profileId: String, title: String): EntryEntity? {
        val q = SearchIndex.tokens(title).toSet(); val lower = title.lowercase().trim()
        return dao.openTasks(profileId, 100).map { t -> t to (SearchIndex.tokens(t.title).count { it in q } + if (t.title.lowercase().contains(lower)) 2 else 0) }
            .filter { it.second > 0 }.maxByOrNull { it.second }?.first
    }

    suspend fun search(profileId: String, query: String, limit: Int = 5): List<EntryEntity> {
        val ids = index.query(profileId, query, listOf("note"), 20).mapNotNull { it.ref.toLongOrNull() }.distinct()
        return ids.mapNotNull { dao.get(it) }.take(limit)
    }

    private suspend fun insert(e: EntryEntity): EntryEntity { val saved = e.copy(id = dao.insert(e)); reindex(saved); return saved }
    private suspend fun reindex(e: EntryEntity) = index.upsert(e.profileId, "note", e.id.toString(), e.title, "${e.title}. ${e.body}")
    private fun now() = System.currentTimeMillis()
}
