package com.sago.app.voice

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Decoded speech: PCM plus a loudness envelope (one value per [windowMs]) used to drive the avatar's mouth. */
class Clip(val pcm: ShortArray, val sampleRate: Int, val channels: Int, val envelope: FloatArray, val windowMs: Int) {
    val durationMs: Long get() = pcm.size / channels * 1000L / sampleRate
}

object WavDecoder {
    private const val WINDOW_MS = 25

    /** Supports 16-bit PCM WAV (mono or stereo), which is what both Groq's voice and Android's TTS produce. */
    fun decode(bytes: ByteArray): Clip? {
        if (bytes.size < 44) return null
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        if (bb.getInt(0) != 0x46464952 || bb.getInt(8) != 0x45564157) return null // "RIFF" … "WAVE"
        var pos = 12; var rate = 0; var ch = 0; var bits = 0; var tag = 0; var start = -1; var len = 0
        while (pos + 8 <= bytes.size) {
            val id = bb.getInt(pos); val size = bb.getInt(pos + 4); val body = pos + 8
            if (id == 0x20746d66 && body + 16 <= bytes.size) { // "fmt "
                tag = bb.getShort(body).toInt() and 0xFFFF; ch = bb.getShort(body + 2).toInt(); rate = bb.getInt(body + 4); bits = bb.getShort(body + 14).toInt()
            } else if (id == 0x61746164) { // "data"
                start = body; len = if (size <= 0 || body + size > bytes.size) bytes.size - body else size; break
            }
            if (size < 0) break
            pos = body + size + (size and 1)
        }
        if (start < 0 || bits != 16 || (tag != 1 && tag != 0xFFFE) || ch !in 1..2 || rate < 8000) return null
        val samples = len / 2 / ch * ch
        if (samples <= 0) return null
        val pcm = ShortArray(samples)
        bb.position(start); bb.asShortBuffer().get(pcm)
        return Clip(pcm, rate, ch, envelope(pcm, rate, ch), WINDOW_MS)
    }

    private fun envelope(pcm: ShortArray, rate: Int, ch: Int): FloatArray {
        val perWindow = (rate * WINDOW_MS / 1000) * ch
        val n = (pcm.size + perWindow - 1) / perWindow
        val rms = FloatArray(n) { w ->
            val from = w * perWindow; val to = minOf(pcm.size, from + perWindow)
            var sum = 0.0
            for (i in from until to) sum += pcm[i].toDouble() * pcm[i]
            Math.sqrt(sum / (to - from).coerceAtLeast(1)).toFloat()
        }
        // Normalise against this clip's own loud passages so quiet voices still animate; gate out near-silence.
        val sorted = rms.sortedArray()
        val ref = maxOf(sorted[(sorted.size * 0.92f).toInt().coerceAtMost(sorted.size - 1)], 250f)
        return FloatArray(n) { i -> (rms[i] / ref).coerceIn(0f, 1f).let { if (it < 0.08f) 0f else it } }
    }
}
