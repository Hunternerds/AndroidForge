package com.sago.app

import android.app.Application
import com.sago.app.reminders.Notifier

class SagoApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        Notifier.createChannels(this)
        container.start()
    }

    companion object { const val CHANNEL_WAKE = Notifier.CH_WAKE }
}
