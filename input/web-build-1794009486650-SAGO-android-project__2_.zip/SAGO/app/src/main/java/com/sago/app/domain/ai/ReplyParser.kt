package com.sago.app.domain.ai

import com.sago.app.avatar.Expression
import com.sago.app.domain.model.*
import org.json.JSONObject

/** Turns raw model output into an [AiReply]. Metadata never leaks into [AiReply.text]. */
object ReplyParser {
    private val thinkBlock = Regex("<think>.*?</think>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
    private val fence = Regex("^```(?:json)?\\s*|\\s*```$", RegexOption.IGNORE_CASE)

    fun parse(raw: String): AiReply {
        val cleaned = raw.replace(thinkBlock, "").trim().replace(fence, "").trim()
        val json = extractJson(cleaned)
        if (json != null) {
            val text = listOf("response", "reply", "text", "message").firstNotNullOfOrNull { k -> json.optString(k).takeIf { it.isNotBlank() } }
            val actions = parseActions(json)
            // A tool-only reply may legitimately have little or no text; the app reports the tool results itself.
            if (text != null || actions.isNotEmpty()) {
                val emotion = Emotion.parse(json.optString("emotion"))
                val voice = json.optJSONObject("voice")
                return AiReply(
                    text = tidy(text.orEmpty()),
                    emotion = emotion,
                    intent = json.optString("intent").ifBlank { "chat" },
                    expression = Expression.parse(json.optString("avatar")) ?: emotion.defaultExpression,
                    voice = VoiceStyle(
                        rate = when (voice?.optString("rate")?.lowercase()) { "slow" -> 0.9f; "fast" -> 1.12f; else -> 1f },
                        pitch = when (voice?.optString("pitch")?.lowercase()) { "low" -> 0.92f; "high" -> 1.08f; else -> 1f },
                    ),
                    memories = parseMemories(json),
                    actions = actions,
                    title = json.optString("title").trim().takeIf { it.length in 2..60 },
                    sourceIds = (0 until (json.optJSONArray("sources")?.length() ?: 0)).mapNotNull { json.optJSONArray("sources")?.optString(it)?.trim()?.takeIf { s -> s.matches(Regex("S\\d{1,2}")) } }.distinct(),
                )
            }
        }
        // Fallback: the model ignored the format. Show prose only, never raw JSON-looking metadata.
        val prose = cleaned.lines().filterNot { it.trim().startsWith("{") || it.trim().startsWith("\"emotion\"") }.joinToString("\n").trim()
        return AiReply(text = tidy(prose).ifBlank { "…" })
    }

    private fun parseMemories(json: JSONObject): List<MemoryCandidate> {
        val arr = json.optJSONArray("memories") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            when (val v = arr.opt(i)) {
                is String -> v.trim().takeIf { it.isNotEmpty() }?.let { MemoryCandidate(it) }
                is JSONObject -> v.optString("text").trim().takeIf { it.isNotEmpty() }?.let {
                    MemoryCandidate(
                        text = it, category = v.optString("category", "general").lowercase(),
                        importance = v.optInt("importance", 3).coerceIn(1, 5),
                        confidence = v.optDouble("confidence", 0.7).toFloat().coerceIn(0f, 1f),
                        expiresInDays = if (v.isNull("expires_in_days") || !v.has("expires_in_days")) null else v.optInt("expires_in_days").takeIf { d -> d > 0 },
                    )
                }
                else -> null
            }
        }.take(3)
    }

    private fun parseActions(json: JSONObject): List<ToolCall> {
        val arr = json.optJSONArray("actions") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val name = o.optString("tool").trim().takeIf { it.isNotEmpty() } ?: return@mapNotNull null
            ToolCall(name, o.optJSONObject("args") ?: JSONObject())
        }.take(3)
    }

    /** Models sometimes still emphasise with *asterisks*; they would show up as stray symbols in chat. */
    private fun tidy(s: String): String = s.replace("*", "").trim()

    private fun extractJson(s: String): JSONObject? {
        val start = s.indexOf('{'); val end = s.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        return runCatching { JSONObject(s.substring(start, end + 1)) }.getOrNull()
    }
}
