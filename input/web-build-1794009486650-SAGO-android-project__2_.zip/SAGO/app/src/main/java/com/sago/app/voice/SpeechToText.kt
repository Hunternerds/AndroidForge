package com.sago.app.voice

import com.sago.app.data.groq.GroqClient
import com.sago.app.data.groq.GroqError
import com.sago.app.data.prefs.SettingsStore
import com.sago.app.wake.MicStream
import java.util.Locale
import kotlin.math.sqrt

/**
 * Turns recorded PCM into text. "groq" uses Groq's Whisper models, which are far more accurate than the small
 * offline model. If the network call fails and an offline [fallback] transcript exists, that is used instead.
 */
class SpeechToText(private val settings: SettingsStore, private val groq: GroqClient) {

    /** @return the transcript, or null if nothing intelligible was heard. Throws [GroqError] when Groq fails and there's no fallback. */
    suspend fun transcribe(pcm: ShortArray, fallback: String?): String? {
        val s = settings.snapshot()
        if (s.sttEngine != "groq") return fallback?.takeIf { it.isNotBlank() }
        return try {
            val language = if (s.sttLanguage == "auto") null else Locale.getDefault().language
            val text = groq.transcribe(Wav.encode(pcm, MicStream.SAMPLE_RATE), s.sttModel, language, PROMPT)
            text.takeIf { it.isNotBlank() && !looksLikeSilenceHallucination(it, pcm) }
        } catch (e: GroqError) {
            val offline = fallback?.takeIf { it.isNotBlank() }
            val connectionIssue = e is GroqError.Network || e is GroqError.Timeout || e is GroqError.Server || e is GroqError.RateLimited
            if (offline != null && connectionIssue) offline else throw e
        }
    }

    /** Whisper sometimes invents stock phrases from near-silence; drop those when the audio was quiet. */
    private fun looksLikeSilenceHallucination(text: String, pcm: ShortArray): Boolean {
        val key = text.lowercase().filter { it.isLetter() || it == ' ' }.trim()
        if (key !in HALLUCINATIONS) return false
        var sum = 0.0
        for (v in pcm) sum += v.toDouble() * v
        return sqrt(sum / pcm.size.coerceAtLeast(1)) < 350.0
    }

    private companion object {
        // Spelling hint only: biases Whisper toward the name "Sago" (it would otherwise write "so go" / "Sego").
        const val PROMPT = "Sago"
        val HALLUCINATIONS = setOf("thank you", "thanks for watching", "you", "bye", "thanks", "thank you for watching")
    }
}
