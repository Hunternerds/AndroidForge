package com.sago.app.data.db

import androidx.room.*

@Entity(tableName = "profiles")
data class ProfileEntity(@PrimaryKey val id: String, val name: String, val createdAt: Long)

@Entity(tableName = "conversations", indices = [Index("profileId")])
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
    /** Compact summary of older messages; kept separately from long-term memories. */
    val summary: String? = null,
    /** Id of the last message already covered by [summary]. */
    val summarizedUpTo: Long = 0,
    val titleByAi: Boolean = false,
)

@Entity(
    tableName = "messages",
    foreignKeys = [ForeignKey(entity = ConversationEntity::class, parentColumns = ["id"], childColumns = ["conversationId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("conversationId")],
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: Long,
    /** USER, ASSISTANT, or TOOL (a result card produced by app code, never by the model). */
    val role: String,
    val text: String,
    val emotion: String? = null,
    /** One or more saved image paths separated by '|'. */
    val imagePath: String? = null,
    val createdAt: Long,
    /** Titles of vault sources an answer drew on, separated by '|'. */
    val sources: String? = null,
    /** JSON for TOOL cards: pending confirmation or undo information. */
    val meta: String? = null,
)

@Entity(tableName = "memories", indices = [Index("profileId")])
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: String,
    val text: String,
    /** "explicit" (Sago remember…), "auto" (model-suggested) or "manual" (added in Settings). */
    val source: String,
    val createdAt: Long,
    val updatedAt: Long,
    val lastUsedAt: Long,
    val category: String = "general",
    /** 1 (trivia) … 5 (core to the user). */
    val importance: Int = 3,
    /** 0..1: how sure SAGO is that this is accurate and lasting. */
    val confidence: Float = 0.8f,
    val expiresAt: Long? = null,
)

@Entity(tableName = "entries", indices = [Index("profileId")])
data class EntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: String,
    /** "note" or "task". */
    val kind: String,
    val title: String,
    val body: String,
    val done: Boolean,
    val dueAt: Long?,
    val createdAt: Long,
    val updatedAt: Long,
    /** "user" or "ai". */
    val source: String,
)

@Entity(tableName = "reminders", indices = [Index("profileId")])
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: String,
    /** reminder | briefing | review_tasks | review_projects | evening_summary */
    val kind: String,
    val title: String,
    val body: String,
    /** Next time (epoch ms) this should fire. */
    val triggerAt: Long,
    /** none | daily | weekdays | weekly */
    val recurrence: String,
    val minuteOfDay: Int,
    val enabled: Boolean,
    val lastFiredAt: Long?,
    val createdAt: Long,
)

@Entity(tableName = "documents", indices = [Index("profileId")])
data class DocumentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: String,
    val title: String,
    val text: String,
    val hash: String,
    val summary: String?,
    val sizeBytes: Int,
    val createdAt: Long,
)

/** Light projection for lists, so full document text isn't loaded just to show titles. */
data class DocumentInfo(val id: Long, val title: String, val sizeBytes: Int, val createdAt: Long, val summary: String?)
