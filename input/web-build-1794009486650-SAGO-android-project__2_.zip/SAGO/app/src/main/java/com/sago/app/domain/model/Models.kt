package com.sago.app.domain.model

import com.sago.app.avatar.Expression

enum class Emotion(val label: String) {
    HAPPY("Happy"), EXCITED("Excited"), SAD("Sad"), SERIOUS("Serious"), CURIOUS("Curious"),
    CONFUSED("Confused"), FRUSTRATED("Frustrated"), CALM("Calm"), SURPRISED("Surprised"),
    PLAYFUL("Playful"), NEUTRAL("Neutral");

    /** Default face for this emotion; the model may override with a more specific one. */
    val defaultExpression: Expression
        get() = when (this) {
            HAPPY, EXCITED -> Expression.HAPPY
            SAD, CALM -> Expression.SLEEPY
            SERIOUS -> Expression.STUDY
            CURIOUS, CONFUSED -> Expression.THINKING
            FRUSTRATED -> Expression.ANGRY
            SURPRISED -> Expression.SURPRISED
            PLAYFUL -> Expression.PLAYFUL
            NEUTRAL -> Expression.NORMAL
        }

    companion object {
        fun parse(raw: String?): Emotion = entries.firstOrNull { it.name.equals(raw?.trim(), ignoreCase = true) } ?: NEUTRAL
    }
}

/** Optional delivery hints from the model; applied as multipliers on the user's own speech settings. */
data class VoiceStyle(val rate: Float = 1f, val pitch: Float = 1f)

/** A memory suggested by the model (or entered by the user) before it is stored. */
data class MemoryCandidate(
    val text: String,
    val category: String = "general",
    val importance: Int = 3,
    val confidence: Float = 0.7f,
    val expiresInDays: Int? = null,
)

/** A tool invocation proposed by the model. It is validated and executed by app code, never trusted blindly. */
data class ToolCall(val tool: String, val args: org.json.JSONObject)

/** Structured, parsed model reply. Only [text] is ever shown or spoken; the rest is metadata. */
data class AiReply(
    val text: String,
    val emotion: Emotion = Emotion.NEUTRAL,
    val intent: String = "chat",
    val expression: Expression = Expression.NORMAL,
    val voice: VoiceStyle = VoiceStyle(),
    val memories: List<MemoryCandidate> = emptyList(),
    val actions: List<ToolCall> = emptyList(),
    val title: String? = null,
    val sourceIds: List<String> = emptyList(),
)

data class ChatMessage(
    val id: Long,
    val conversationId: Long,
    val role: Role,
    val text: String,
    val emotion: Emotion?,
    val imagePath: String?,
    val createdAt: Long,
    val sources: List<String> = emptyList(),
    val meta: String? = null,
) {
    enum class Role { USER, ASSISTANT, TOOL }
    val imagePaths: List<String> get() = imagePath?.split('|')?.filter { it.isNotBlank() }.orEmpty()
}

data class PickedImage(val jpeg: ByteArray, val savedPath: String)
