package com.sago.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import java.io.File

@Database(
    entities = [
        ProfileEntity::class, ConversationEntity::class, MessageEntity::class, MemoryEntity::class,
        EntryEntity::class, ReminderEntity::class, DocumentEntity::class,
    ],
    version = 2,
    exportSchema = false,
)
abstract class SagoDatabase : RoomDatabase() {
    abstract fun profiles(): ProfileDao
    abstract fun conversations(): ConversationDao
    abstract fun messages(): MessageDao
    abstract fun memories(): MemoryDao
    abstract fun entries(): EntryDao
    abstract fun reminders(): ReminderDao
    abstract fun documents(): DocumentDao

    companion object {
        /** v1 → v2: memory 2.0 fields, conversation summaries, tool cards, notes/tasks, reminders, vault documents. Existing data is kept. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                listOf(
                    "ALTER TABLE memories ADD COLUMN category TEXT NOT NULL DEFAULT 'general'",
                    "ALTER TABLE memories ADD COLUMN importance INTEGER NOT NULL DEFAULT 3",
                    "ALTER TABLE memories ADD COLUMN confidence REAL NOT NULL DEFAULT 0.8",
                    "ALTER TABLE memories ADD COLUMN expiresAt INTEGER",
                    "ALTER TABLE messages ADD COLUMN sources TEXT",
                    "ALTER TABLE messages ADD COLUMN meta TEXT",
                    "ALTER TABLE conversations ADD COLUMN summary TEXT",
                    "ALTER TABLE conversations ADD COLUMN summarizedUpTo INTEGER NOT NULL DEFAULT 0",
                    "ALTER TABLE conversations ADD COLUMN titleByAi INTEGER NOT NULL DEFAULT 0",
                    "CREATE TABLE IF NOT EXISTS entries (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, profileId TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL, done INTEGER NOT NULL, dueAt INTEGER, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, source TEXT NOT NULL)",
                    "CREATE INDEX IF NOT EXISTS index_entries_profileId ON entries (profileId)",
                    "CREATE TABLE IF NOT EXISTS reminders (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, profileId TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL, triggerAt INTEGER NOT NULL, recurrence TEXT NOT NULL, minuteOfDay INTEGER NOT NULL, enabled INTEGER NOT NULL, lastFiredAt INTEGER, createdAt INTEGER NOT NULL)",
                    "CREATE INDEX IF NOT EXISTS index_reminders_profileId ON reminders (profileId)",
                    "CREATE TABLE IF NOT EXISTS documents (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, profileId TEXT NOT NULL, title TEXT NOT NULL, text TEXT NOT NULL, hash TEXT NOT NULL, summary TEXT, sizeBytes INTEGER NOT NULL, createdAt INTEGER NOT NULL)",
                    "CREATE INDEX IF NOT EXISTS index_documents_profileId ON documents (profileId)",
                ).forEach { db.execSQL(it) }
            }
        }

        private fun build(context: Context): SagoDatabase =
            Room.databaseBuilder(context, SagoDatabase::class.java, "sago.db").addMigrations(MIGRATION_1_2).build()

        /**
         * Opens the database; if an upgrade ever fails, the old file is kept as sago.db.bak and a fresh database is
         * created, so the app still starts instead of crashing in a loop.
         * @param onReset called with a short explanation when a reset was necessary.
         */
        fun openSafely(context: Context, onReset: (String) -> Unit = {}): SagoDatabase {
            val db = build(context)
            return try {
                db.openHelper.writableDatabase
                db
            } catch (e: Exception) {
                runCatching { db.close() }
                val file = context.getDatabasePath("sago.db")
                runCatching { if (file.exists()) file.copyTo(File(file.parentFile, "sago.db.bak"), overwrite = true) }
                context.deleteDatabase("sago.db")
                onReset("Your local data couldn't be upgraded and was reset (a backup copy was kept on the device).")
                build(context).also { it.openHelper.writableDatabase }
            }
        }
    }
}
