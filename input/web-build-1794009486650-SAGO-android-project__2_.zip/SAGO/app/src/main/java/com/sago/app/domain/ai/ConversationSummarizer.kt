package com.sago.app.domain.ai

import com.sago.app.core.Diagnostics
import com.sago.app.data.ChatRepository
import com.sago.app.data.groq.ChatRequest
import com.sago.app.data.groq.ChatTurn
import com.sago.app.data.groq.GroqClient
import com.sago.app.data.prefs.SettingsStore
import com.sago.app.domain.model.ChatMessage
import kotlinx.coroutines.CancellationException
import java.util.concurrent.ConcurrentHashMap

/**
 * Keeps long conversations affordable: once enough new messages pile up, older ones are folded into a short summary
 * stored with the conversation (separate from long-term memories). Later requests send the summary plus only the
 * newest messages, and reopening an old conversation restores its context from the summary.
 */
class ConversationSummarizer(
    private val settings: SettingsStore, private val groq: GroqClient, private val repo: ChatRepository, private val diag: Diagnostics,
) {
    private val running = ConcurrentHashMap.newKeySet<Long>()

    suspend fun maybeSummarize(conversationId: Long) {
        if (!running.add(conversationId)) return
        try {
            val convo = repo.conversationById(conversationId) ?: return
            if (repo.countAfter(conversationId, convo.summarizedUpTo) < TRIGGER) return
            val batch = repo.after(conversationId, convo.summarizedUpTo, 60).dropLast(KEEP_RECENT)
            if (batch.size < 6) return
            val transcript = batch.joinToString("\n") { "${if (it.role == ChatMessage.Role.USER) "User" else "SAGO"}: ${it.text.take(400)}" }.take(7000)
            val s = settings.snapshot()
            val res = groq.chat(ChatRequest(
                s.textModel,
                listOf(
                    ChatTurn("system", "You maintain a compact summary of a chat between a user and SAGO. Merge the previous summary with the new messages into one summary under 140 words. Keep decisions, facts the user gave, open tasks or plans, and ongoing topics. Drop small talk. Output plain text only."),
                    ChatTurn("user", "Previous summary: ${convo.summary ?: "none"}\n\nNew messages:\n$transcript"),
                ), 0.2f, 300, jsonMode = false,
            ))
            val text = res.text.replace(Regex("<think>.*?</think>", RegexOption.DOT_MATCHES_ALL), "").trim()
            if (text.length >= 20) { repo.setSummary(conversationId, text.take(900), batch.last().id); diag.count("summaries.created") }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { diag.log("summary", "failed: ${e::class.simpleName}") }
        finally { running.remove(conversationId) }
    }

    private companion object { const val TRIGGER = 18; const val KEEP_RECENT = 6 }
}
