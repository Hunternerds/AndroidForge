package com.sago.app.data

import android.content.Context
import com.sago.app.data.db.SagoDatabase
import com.sago.app.data.db.SearchIndex
import com.sago.app.reminders.ReminderScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Cross-cutting data operations: index repair, profile deletion, full wipe and JSON export. */
class DataManager(
    private val ctx: Context, private val db: SagoDatabase, private val index: SearchIndex,
    private val repo: ChatRepository, private val reminders: Reminders, private val scheduler: ReminderScheduler,
) {
    /** The search index is derived data. If it is empty but data exists (first run after an update), rebuild it. */
    suspend fun ensureIndexed() {
        if (index.count("memory") == 0) db.memories().everything().forEach { index.upsert(it.profileId, "memory", it.id.toString(), it.category, it.text) }
        if (index.count("note") == 0) db.entries().everything().forEach { index.upsert(it.profileId, "note", it.id.toString(), it.title, "${it.title}. ${it.body}") }
        if (index.count("doc") == 0) db.documents().everything().forEach { index.replaceAll(it.profileId, "doc", it.id.toString(), it.title, SearchIndex.chunk(it.text)) }
        if (index.count("conv") == 0) {
            val convs = db.conversations().everything().associateBy { it.id }
            db.messages().allIndexable().forEach { m ->
                if (m.text.length >= 12) convs[m.conversationId]?.let { c -> index.upsert(c.profileId, "conv", "${c.id}:${m.id}", c.title, m.text) }
            }
        }
    }

    suspend fun deleteProfile(id: String) {
        reminders.clearProfile(id)
        db.entries().clear(id); db.documents().clear(id); db.memories().clear(id)
        repo.deleteAllConversations(id)
        index.removeProfile(id)
        repo.removeProfileRow(id)
    }

    /** Erases everything SAGO stores on the device (the caller also removes the API key and settings). */
    suspend fun wipeAll() {
        scheduler.cancelAll()
        withContext(Dispatchers.IO) {
            runCatching { db.clearAllTables() }
            runCatching { File(ctx.filesDir, "images").deleteRecursively() }
        }
        index.clearAll()
    }

    /** All of one profile's data as JSON. Never includes the API key. Photos aren't included. */
    suspend fun exportJson(profileId: String): String = withContext(Dispatchers.IO) {
        val root = JSONObject().put("app", "SAGO").put("exportedAt", System.currentTimeMillis())
        root.put("profile", db.profiles().all().firstOrNull { it.id == profileId }?.name ?: profileId)
        root.put("memories", JSONArray().also { a -> db.memories().all(profileId).forEach { m ->
            a.put(JSONObject().put("text", m.text).put("category", m.category).put("importance", m.importance).put("confidence", m.confidence.toDouble())
                .put("source", m.source).put("created", m.createdAt).put("updated", m.updatedAt).put("expires", m.expiresAt ?: JSONObject.NULL))
        } })
        root.put("notesAndTasks", JSONArray().also { a -> db.entries().all(profileId).forEach { e ->
            a.put(JSONObject().put("kind", e.kind).put("title", e.title).put("body", e.body).put("done", e.done).put("due", e.dueAt ?: JSONObject.NULL).put("created", e.createdAt))
        } })
        root.put("reminders", JSONArray().also { a -> db.reminders().all(profileId).forEach { r ->
            a.put(JSONObject().put("kind", r.kind).put("title", r.title).put("next", r.triggerAt).put("repeat", r.recurrence).put("enabled", r.enabled))
        } })
        root.put("documents", JSONArray().also { a -> db.documents().everything().filter { it.profileId == profileId }.forEach { d ->
            a.put(JSONObject().put("title", d.title).put("summary", d.summary ?: JSONObject.NULL).put("text", d.text).put("created", d.createdAt))
        } })
        root.put("conversations", JSONArray().also { a -> db.conversations().idsFor(profileId).forEach { cid ->
            val c = db.conversations().get(cid) ?: return@forEach
            a.put(JSONObject().put("title", c.title).put("created", c.createdAt).put("updated", c.updatedAt).put("summary", c.summary ?: JSONObject.NULL)
                .put("messages", JSONArray().also { ms -> db.messages().all(cid).forEach { m -> ms.put(JSONObject().put("role", m.role).put("text", m.text).put("time", m.createdAt)) } }))
        } })
        root.toString(2)
    }
}
