package com.sago.app.domain.memory

/**
 * Recognises "Sago remember …" and common speech-recognition variants.
 *
 * Typed or manual-mic text only accepts clear spellings of "Sago". Text captured right after the offline
 * wake-word fired contains the wake audio itself, which a general speech model often mishears
 * ("say go", "so go"…), so those sessions use a broader alias list.
 */
sealed interface LocalCommand {
    data class Remember(val info: String) : LocalCommand
    data class Forget(val query: String, val all: Boolean) : LocalCommand
    /** [soft] = phrased like a casual question ("do you remember …?"); if nothing is stored the model answers instead. */
    data class Recall(val topic: String?, val soft: Boolean = false) : LocalCommand
}

object MemoryCommandParser {
    private const val STRICT = "(?:hey\\s+)?(?:sago|sago's|saigo|sagu)"
    private const val BROAD = "(?:hey\\s+)?(?:sago|sago's|saigo|sagu|sigo|sega|segue|say\\s*go|so\\s*go|sa\\s*go|see\\s*go)"
    private val strictPrefix = Regex("^\\s*$STRICT\\b[\\s,.:;!?-]*", RegexOption.IGNORE_CASE)
    private val broadPrefix = Regex("^\\s*$BROAD\\b[\\s,.:;!?-]*", RegexOption.IGNORE_CASE)
    private val rememberPart = Regex(
        "^(?:please\\s+|can you\\s+|could you\\s+)?(?:remember|memorize|memorise)(?:\\s+that)?\\b[\\s,.:;-]*(.+)$",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL),
    )

    private val leadInThenBroad = Regex("^.{0,40}?\\b$BROAD\\b[\\s,.:;!?-]*", RegexOption.IGNORE_CASE)

    /**
     * For text captured right after the offline wake word fired: the capture includes a little audio from before
     * the wake word, so drop everything up to and including the (possibly misheard) "Sago".
     */
    fun dropThroughWake(text: String): String = text.replace(leadInThenBroad, "").trim().ifBlank { text.trim() }

    /** True when the transcript contains nothing but the wake word (user paused after saying "Sago"). */
    fun isOnlyWake(text: String): Boolean = text.replace(leadInThenBroad, "").isBlank()

    /** Removes a leading wake word so it never reaches the model. [viaWake] enables the broader alias list. */
    fun stripWake(text: String, viaWake: Boolean): String {
        val stripped = text.replace(if (viaWake) broadPrefix else strictPrefix, "").trim()
        return stripped.ifBlank { text.trim() }
    }

    /**
     * @param viaWake true when the offline wake word already fired for this utterance, so a bare
     * "remember …" is accepted. Otherwise the text must start with "Sago".
     * @return the information to remember, or null if this isn't a memory command.
     */
    fun parse(text: String, viaWake: Boolean): String? {
        val prefix = if (viaWake) broadPrefix else strictPrefix
        if (!viaWake && !prefix.containsMatchIn(text)) return null
        val rest = text.replace(prefix, "").trim()
        val info = rememberPart.find(rest)?.groupValues?.get(1)?.trim()?.trimEnd('.', '!', ' ')
        return info?.takeIf { it.length >= 3 }
    }

    private val recallRegex = Regex("^(?:what|which)\\s+(?:do|did|have|all)\\s+you\\s+(?:remember|know|saved?|stored?)(?:\\s+about\\s+(.+?))?\\s*[?.!]*$", RegexOption.IGNORE_CASE)
    private val doYouRemember = Regex("^do you (?:still )?remember\\s+(.+?)\\s*[?.!]*$", RegexOption.IGNORE_CASE)
    private val showMemories = Regex("^(?:show|list|open)\\s+(?:me\\s+)?(?:my\\s+|all\\s+)?(?:saved\\s+)?memories\\s*[?.!]*$", RegexOption.IGNORE_CASE)
    private val forgetPart = Regex(
        "^(?:please\\s+)?(?:forget|stop remembering|(?:delete|remove|erase)\\s+(?:the\\s+)?(?:memory|note)\\s+(?:about|of|that))\\s*(?:that|about)?\\s*(.+)$",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL),
    )
    private val allWords = Regex("^(?:all|everything|all of it|all memories|everything about me|all my memories)$", RegexOption.IGNORE_CASE)
    private val selfWords = setOf("me", "myself", "us", "my life", "you know about me")

    /**
     * Understands "Sago remember …", "Sago forget …", "what do you remember about me?" and natural variants.
     * Remember/forget need the wake word (or a wake-word session); recall questions work anywhere.
     */
    fun parseCommand(text: String, viaWake: Boolean): LocalCommand? {
        val t = text.trim()
        val prefix = if (viaWake) broadPrefix else strictPrefix
        val hasWake = prefix.containsMatchIn(t)
        val rest = t.replace(prefix, "").trim()

        recallRegex.find(rest)?.let { m ->
            val topic = m.groupValues.getOrNull(1)?.trim()?.trimEnd('?', '.', '!', ' ')
            return LocalCommand.Recall(topic?.takeUnless { it.isBlank() || it.lowercase() in selfWords })
        }
        if (showMemories.matches(rest)) return LocalCommand.Recall(null)
        doYouRemember.find(rest)?.let { m ->
            val topic = m.groupValues[1].trim()
            if (topic.length >= 3) return LocalCommand.Recall(topic.takeUnless { it.lowercase() in selfWords }, soft = true)
        }
        if (!viaWake && !hasWake) return null
        rememberPart.find(rest)?.groupValues?.get(1)?.trim()?.trimEnd('.', '!', ' ')?.takeIf { it.length >= 3 }?.let { return LocalCommand.Remember(it) }
        forgetPart.find(rest)?.groupValues?.get(1)?.trim()?.trimEnd('.', '!', '?', ' ')?.takeIf { it.length >= 3 }?.let { q ->
            return LocalCommand.Forget(q, allWords.matches(q))
        }
        return null
    }
}
