package com.sago.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.background
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.sago.app.AppContainer
import com.sago.app.data.prefs.AppSettings
import com.sago.app.ui.screens.*
import com.sago.app.ui.theme.Palette
import com.sago.app.ui.theme.SagoTheme
import com.sago.app.ui.viewmodel.*

@Composable
fun SagoRoot(container: AppContainer) {
    val settings by produceState<AppSettings?>(null) { container.settings.flow.collect { value = it } }
    val s = settings
    if (s == null) { Box(Modifier.fillMaxSize().background(Palette.Plum)); return }

    SagoTheme(s.theme) {
        val factory = remember { SagoViewModelFactory(container) }
        val nav = rememberNavController()
        val chatVm: ChatViewModel = viewModel(factory = factory)
        val historyVm: HistoryViewModel = viewModel(factory = factory)
        val onboardingVm: OnboardingViewModel = viewModel(factory = factory)
        val settingsVm: SettingsViewModel = viewModel(factory = factory)
        val libraryVm: LibraryViewModel = viewModel(factory = factory)
        LaunchedEffect(Unit) { container.diagnostics.markUiReady() }
        val start = remember { if (s.onboarded && container.hasApiKey()) "main" else "onboarding" }

        fun signedOut() { nav.navigate("onboarding") { popUpTo(0) { inclusive = true }; launchSingleTop = true } }

        NavHost(nav, startDestination = start) {
            composable("onboarding") {
                OnboardingScreen(onboardingVm) { nav.navigate("main") { popUpTo(0) { inclusive = true } } }
            }
            composable("main") {
                MainScreen(
                    chatVm, onHistory = { nav.navigate("history") }, onLibrary = { nav.navigate("library") }, onSettings = { nav.navigate("settings") },
                    onAiSettings = { nav.navigate("settings/ai") }, onVoiceSettings = { nav.navigate("settings/voice") },
                )
            }
            composable("library") { LibraryScreen(libraryVm) { nav.popBackStack() } }
            composable("history") { HistoryScreen(historyVm) { nav.popBackStack() } }
            composable("settings") { SettingsHubScreen({ nav.popBackStack() }) { nav.navigate(it) } }
            composable("settings/ai") { AiSettingsScreen(settingsVm) { nav.popBackStack() } }
            composable("settings/voice") { VoiceSettingsScreen(settingsVm) { nav.popBackStack() } }
            composable("settings/appearance") { AppearanceSettingsScreen(settingsVm) { nav.popBackStack() } }
            composable("settings/memory") { MemorySettingsScreen(settingsVm) { nav.popBackStack() } }
            composable("settings/assistant") { AssistantSettingsScreen(settingsVm) { nav.popBackStack() } }
            composable("settings/diagnostics") { DiagnosticsScreen(settingsVm) { nav.popBackStack() } }
            composable("settings/privacy") { PrivacySettingsScreen(settingsVm, { nav.popBackStack() }, ::signedOut) }
        }
    }
}
