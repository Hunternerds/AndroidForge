package com.sago.app.ui.screens

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.text.format.DateFormat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sago.app.data.db.EntryEntity
import com.sago.app.data.db.ReminderEntity
import com.sago.app.domain.tools.TimeUtil
import com.sago.app.ui.components.Backdrop
import com.sago.app.ui.components.ConfirmDialog
import com.sago.app.ui.theme.LocalSagoUi
import com.sago.app.ui.viewmodel.LibraryViewModel
import java.util.Calendar

private fun pickDateTime(ctx: Context, onPicked: (Long) -> Unit) {
    val cal = Calendar.getInstance()
    DatePickerDialog(ctx, { _, y, m, d ->
        TimePickerDialog(ctx, { _, h, min -> cal.set(y, m, d, h, min, 0); onPicked(cal.timeInMillis) }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), DateFormat.is24HourFormat(ctx)).show()
    }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
}

private fun pickTime(ctx: Context, minute: Int, onPicked: (Int) -> Unit) {
    TimePickerDialog(ctx, { _, h, m -> onPicked(h * 60 + m) }, minute / 60, minute % 60, DateFormat.is24HourFormat(ctx)).show()
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun LibraryScreen(vm: LibraryViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val ui = LocalSagoUi.current
    val entries by vm.entries.collectAsStateWithLifecycle()
    val reminders by vm.reminders.collectAsStateWithLifecycle()
    val documents by vm.documents.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val summary by vm.summary.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var addEntry by remember { mutableStateOf(false) }
    var editEntry by remember { mutableStateOf<EntryEntity?>(null) }
    var addReminder by remember { mutableStateOf(false) }
    var addRoutine by remember { mutableStateOf(false) }
    var deleteDoc by remember { mutableStateOf<Long?>(null) }

    LaunchedEffect(message) { message?.let { snackbar.showSnackbar(it); vm.message.value = null } }

    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun ensureNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(vm::importDocument) }

    Box(Modifier.fillMaxSize()) {
        Backdrop(true, heavy = true)
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbar) },
            topBar = {
                TopAppBar(
                    title = { Text("Library", fontWeight = FontWeight.Bold) },
                    navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent, titleContentColor = ui.text, navigationIconContentColor = ui.text),
                )
            },
            floatingActionButton = {
                if (tab == 0) FloatingActionButton({ addEntry = true }) { Icon(Icons.Default.Add, "Add a note or task") }
                if (tab == 2) FloatingActionButton({ importer.launch(arrayOf("text/*", "application/pdf", "image/*", "application/json")) }) { Icon(Icons.Default.UploadFile, "Add a document") }
            },
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                TabRow(selectedTabIndex = tab, containerColor = Color.Transparent, contentColor = ui.text) {
                    listOf("Notes & tasks", "Reminders", "Documents").forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, maxLines = 1) }) }
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                when (tab) {
                    0 -> if (entries.isEmpty()) Empty("No notes or tasks yet.\nTap + to add one, or ask SAGO: “add a task to call the bank”.")
                    else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(entries, key = { it.id }) { e ->
                            Row(Modifier.fillMaxWidth().clickable { editEntry = e }, verticalAlignment = Alignment.CenterVertically) {
                                if (e.kind == "task") Checkbox(e.done, { vm.toggleDone(e) }) else Icon(Icons.Default.StickyNote2, null, Modifier.padding(12.dp), tint = ui.subtext)
                                Column(Modifier.weight(1f)) {
                                    Text(e.title, color = ui.text, textDecoration = if (e.done) TextDecoration.LineThrough else null, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    val sub = listOfNotNull(e.dueAt?.let { "Due ${TimeUtil.formatWhen(it)}" }, e.body.takeIf { it.isNotBlank() }?.take(80), if (e.source == "ai") "added by SAGO" else null).joinToString(" · ")
                                    if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodyMedium, color = ui.subtext, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                }
                                IconButton({ vm.deleteEntry(e.id) }) { Icon(Icons.Default.Delete, "Delete ${e.title}", tint = ui.subtext) }
                            }
                        }
                    }
                    1 -> Column {
                        Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button({ ensureNotifications(); addReminder = true }) { Icon(Icons.Default.Alarm, null); Spacer(Modifier.width(6.dp)); Text("Reminder") }
                            OutlinedButton({ ensureNotifications(); addRoutine = true }) { Icon(Icons.Default.Repeat, null); Spacer(Modifier.width(6.dp)); Text("Routine") }
                        }
                        Text("Reminders you set always notify. Briefings and check-ins also need “Notifications” switched on in Settings → Assistant. Timing can be a few minutes off while the phone is idle.", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.labelSmall, color = ui.subtext)
                        if (reminders.isEmpty()) Empty("No reminders or routines yet.\nTry: “Sago, remind me tomorrow at 9 to call mum” or “every evening remind me to review my projects”.")
                        else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(reminders, key = { it.id }) { r ->
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(r.title, color = ui.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        Text(describe(r), style = MaterialTheme.typography.bodyMedium, color = ui.subtext)
                                    }
                                    Switch(r.enabled, { vm.setReminderEnabled(r.id, it) })
                                    IconButton({ vm.deleteReminder(r.id) }) { Icon(Icons.Default.Delete, "Delete ${r.title}", tint = ui.subtext) }
                                }
                            }
                        }
                    }
                    else -> if (documents.isEmpty()) Empty("Your vault is empty.\nTap the upload button to add text files, PDFs or photos of documents. They stay on this device, and SAGO can answer from them and say which parts came from your files.")
                    else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(documents, key = { it.id }) { d ->
                            Surface(shape = RoundedCornerShape(16.dp), color = ui.glass, contentColor = ui.text, border = BorderStroke(1.dp, ui.glassBorder)) {
                                Row(Modifier.padding(start = 14.dp, top = 6.dp, bottom = 6.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(d.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text("${d.sizeBytes / 1000 + 1} KB of text" + (d.summary?.let { " · summarised" } ?: ""), style = MaterialTheme.typography.bodyMedium, color = ui.subtext)
                                    }
                                    IconButton({ vm.summarizeDocument(d) }, enabled = !busy) { Icon(Icons.Default.Summarize, "Summarise ${d.title}") }
                                    IconButton({ deleteDoc = d.id }) { Icon(Icons.Default.Delete, "Delete ${d.title}") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (addEntry) EntryDialog(null, ctx, { title, body, task, due -> if (task) vm.addTask(title, due) else vm.addNote(title, body) }) { addEntry = false }
    editEntry?.let { e -> EntryDialog(e, ctx, { title, body, _, _ -> vm.editEntry(e, title, body) }) { editEntry = null } }
    if (addReminder) ReminderDialog(ctx, { t, at -> vm.addReminder(t, at) }) { addReminder = false }
    if (addRoutine) RoutineDialog(ctx, { t, m, r, k -> vm.addRoutine(t, m, r, k) }) { addRoutine = false }
    deleteDoc?.let { id -> ConfirmDialog("Delete document?", "It will be removed from your vault and search.", "Delete", onConfirm = { vm.deleteDocument(id) }, onDismiss = { deleteDoc = null }) }
    summary?.let { (title, text) ->
        AlertDialog(onDismissRequest = { vm.summary.value = null }, title = { Text(title) }, text = { Text(text) }, confirmButton = { TextButton({ vm.summary.value = null }) { Text("Close") } })
    }
}

private fun describe(r: ReminderEntity): String {
    val what = when (r.kind) {
        "briefing" -> "Morning briefing"; "review_tasks" -> "Task review"; "review_projects" -> "Project check-in"; "evening_summary" -> "Evening wrap-up"
        else -> if (r.recurrence == "none") "Reminder" else "Routine"
    }
    val when_ = if (r.recurrence == "none") TimeUtil.formatWhen(r.triggerAt) else "${r.recurrence} at ${TimeUtil.formatClock(r.minuteOfDay)}"
    return "$what · $when_" + if (!r.enabled) " · off" else ""
}

@Composable
private fun Empty(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = LocalSagoUi.current.subtext, textAlign = androidx.compose.ui.text.style.TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun EntryDialog(existing: EntryEntity?, ctx: Context, onSave: (String, String, Boolean, Long?) -> Unit, onDismiss: () -> Unit) {
    var task by remember { mutableStateOf(existing?.kind == "task") }
    var title by remember { mutableStateOf(existing?.title.orEmpty()) }
    var body by remember { mutableStateOf(existing?.body.orEmpty()) }
    var due by remember { mutableStateOf(existing?.dueAt) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(if (existing == null) "Add to library" else "Edit") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (existing == null) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(!task, { task = false }, label = { Text("Note") }); FilterChip(task, { task = true }, label = { Text("Task") })
                }
                OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (!task) OutlinedTextField(body, { body = it }, label = { Text("Details") }, minLines = 3, maxLines = 8, modifier = Modifier.fillMaxWidth())
                if (task && existing == null) TextButton({ pickDateTime(ctx) { due = it } }) { Text(due?.let { "Due ${TimeUtil.formatWhen(it)}" } ?: "Set due date (optional)") }
            }
        },
        confirmButton = { TextButton({ if (title.isNotBlank()) { onSave(title.trim(), body.trim(), task, due); onDismiss() } }, enabled = title.isNotBlank()) { Text("Save") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun ReminderDialog(ctx: Context, onSave: (String, Long) -> Unit, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var at by remember { mutableStateOf<Long?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("New reminder") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Remind me to…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedButton({ pickDateTime(ctx) { at = it } }) { Icon(Icons.Default.Event, null); Spacer(Modifier.width(6.dp)); Text(at?.let { TimeUtil.formatWhen(it) } ?: "Choose date and time") }
            }
        },
        confirmButton = { TextButton({ onSave(title.trim(), at!!); onDismiss() }, enabled = title.isNotBlank() && at != null) { Text("Save") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RoutineDialog(ctx: Context, onSave: (String, Int, String, String) -> Unit, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var minute by remember { mutableIntStateOf(20 * 60) }
    var repeat by remember { mutableStateOf("daily") }
    var kind by remember { mutableStateOf("reminder") }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("New routine") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedButton({ pickTime(ctx, minute) { minute = it } }) { Icon(Icons.Default.Schedule, null); Spacer(Modifier.width(6.dp)); Text("At ${TimeUtil.formatClock(minute)}") }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("daily", "weekdays", "weekly").forEach { r -> FilterChip(repeat == r, { repeat = r }, label = { Text(r) }) } }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("reminder" to "Remind me", "briefing" to "Briefing", "review_tasks" to "Review tasks", "review_projects" to "Review projects", "evening_summary" to "Evening wrap-up")
                        .forEach { (k, label) -> FilterChip(kind == k, { kind = k }, label = { Text(label) }) }
                }
            }
        },
        confirmButton = { TextButton({ onSave(title.trim(), minute, repeat, kind); onDismiss() }, enabled = title.isNotBlank()) { Text("Save") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}
