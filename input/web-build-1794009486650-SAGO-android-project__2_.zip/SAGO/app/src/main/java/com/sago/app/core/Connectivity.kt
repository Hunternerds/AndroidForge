package com.sago.app.core

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.flow.MutableStateFlow

/** Tracks whether the device has internet, so the UI can say which features need it. */
class Connectivity(context: Context) {
    private val cm = context.getSystemService(ConnectivityManager::class.java)
    val online = MutableStateFlow(check())

    init {
        runCatching {
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { online.value = check() }
                override fun onLost(network: Network) { online.value = check() }
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { online.value = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) }
            })
        }
    }

    private fun check(): Boolean = runCatching {
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }.getOrDefault(true)
}
