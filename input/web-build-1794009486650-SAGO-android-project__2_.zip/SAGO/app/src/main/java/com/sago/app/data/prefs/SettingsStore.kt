package com.sago.app.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.*
import java.io.IOException

private val Context.sagoDataStore: DataStore<Preferences> by preferencesDataStore("sago_settings")

object Keys {
    val ONBOARDED = booleanPreferencesKey("onboarded")
    val TEXT_MODEL = stringPreferencesKey("text_model")
    val VISION_MODEL = stringPreferencesKey("vision_model")
    val SYSTEM_PROMPT = stringPreferencesKey("system_prompt")
    val TEMPERATURE = floatPreferencesKey("temperature")
    val MAX_TOKENS = intPreferencesKey("max_tokens")
    val HISTORY_LIMIT = intPreferencesKey("history_limit")
    val AUTO_MEMORY = booleanPreferencesKey("auto_memory")
    val SPEAK_REPLIES = booleanPreferencesKey("speak_replies")
    val TTS_VOICE = stringPreferencesKey("tts_voice")
    val SPEECH_RATE = floatPreferencesKey("speech_rate")
    val SPEECH_PITCH = floatPreferencesKey("speech_pitch")
    val PREFER_OFFLINE_STT = booleanPreferencesKey("offline_stt")
    val STT_ENGINE = stringPreferencesKey("stt_engine")
    val STT_MODEL = stringPreferencesKey("stt_model")
    val STT_LANGUAGE = stringPreferencesKey("stt_language")
    val WAKE_ENABLED = booleanPreferencesKey("wake_enabled")
    val WAKE_SENSITIVITY = floatPreferencesKey("wake_sensitivity")
    val FOLLOW_UP_SECONDS = intPreferencesKey("follow_up_seconds")
    val TTS_ENGINE = stringPreferencesKey("tts_engine")
    val GROQ_VOICE = stringPreferencesKey("groq_voice")
    val REDUCE_MOTION = booleanPreferencesKey("reduce_motion")
    val REPLY_STYLE = stringPreferencesKey("reply_style")
    val FALLBACK_MODEL = stringPreferencesKey("fallback_model")
    val TOOLS_ENABLED = booleanPreferencesKey("tools_enabled")
    val ALLOW_WEB = booleanPreferencesKey("allow_web")
    val PROACTIVE_SUGGESTIONS = booleanPreferencesKey("proactive_suggestions")
    val PROACTIVE_NOTIFICATIONS = booleanPreferencesKey("proactive_notifications")
    val BRIEFING_MINUTE = intPreferencesKey("briefing_minute")
    val QUIET_START = intPreferencesKey("quiet_start")
    val QUIET_END = intPreferencesKey("quiet_end")
    val RETENTION_DAYS = intPreferencesKey("retention_days")
    val KEEP_AWAKE = booleanPreferencesKey("keep_awake")
    val BATTERY_SAVER = booleanPreferencesKey("battery_saver")
    val THEME = stringPreferencesKey("theme")
    val SHOW_EMOTION = booleanPreferencesKey("show_emotion")
    val AVATAR_ANIM = booleanPreferencesKey("avatar_anim")
    val AVATAR_SIZE = intPreferencesKey("avatar_size_dp")
    val SHOW_BACKGROUND = booleanPreferencesKey("show_bg")
    val ACTIVE_PROFILE = stringPreferencesKey("active_profile")
    val ACTIVE_CONVERSATION = longPreferencesKey("active_conversation")
}

const val DEFAULT_TEXT_MODEL = "openai/gpt-oss-120b"
const val DEFAULT_VISION_MODEL = "qwen/qwen3.6-27b"
const val DEFAULT_STT_MODEL = "whisper-large-v3-turbo"
const val DEFAULT_PROFILE_ID = "default"

data class AppSettings(
    val onboarded: Boolean = false,
    val textModel: String = DEFAULT_TEXT_MODEL,
    val visionModel: String = DEFAULT_VISION_MODEL,
    /** Empty = use the built-in SAGO personality prompt. */
    val systemPrompt: String = "",
    val temperature: Float = 0.8f,
    val maxTokens: Int = 700,
    val historyLimit: Int = 12,
    val autoMemory: Boolean = true,
    val speakReplies: Boolean = true,
    val ttsVoice: String = "",
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.08f,
    val preferOfflineStt: Boolean = false,
    /** "groq" = Groq Whisper (most accurate, uploads the short recording); "device" = Android / offline Vosk. */
    val sttEngine: String = "groq",
    val sttModel: String = DEFAULT_STT_MODEL,
    /** "device" = use the phone language; "auto" = let Whisper detect it. */
    val sttLanguage: String = "device",
    val wakeEnabled: Boolean = false,
    val wakeSensitivity: Float = 0.5f,
    val followUpSeconds: Int = 6,
    /** "groq" = natural Orpheus voice from Groq (internet); "device" = Android's built-in voice. */
    val ttsEngine: String = "groq",
    val groqVoice: String = "autumn",
    val reduceMotion: Boolean = false,
    /** auto | casual | quick | detailed | technical | tutor | brainstorm | planning | creative | translate */
    val replyStyle: String = "auto",
    val fallbackModel: String = "openai/gpt-oss-20b",
    val toolsEnabled: Boolean = true,
    val allowWeb: Boolean = true,
    val proactiveSuggestions: Boolean = true,
    val proactiveNotifications: Boolean = false,
    val briefingMinute: Int = 510,
    val quietStart: Int = 1320,
    val quietEnd: Int = 450,
    /** 0 = keep conversations forever. */
    val retentionDays: Int = 0,
    val keepAwake: Boolean = true,
    val batterySaver: Boolean = false,
    val theme: String = "dark",
    val showEmotion: Boolean = true,
    val avatarAnimations: Boolean = true,
    val avatarSizeDp: Int = 210,
    val showBackground: Boolean = true,
    val activeProfile: String = DEFAULT_PROFILE_ID,
    val activeConversation: Long = 0L,
)

class SettingsStore(private val context: Context) {
    val flow: Flow<AppSettings> = context.sagoDataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            val d = AppSettings()
            AppSettings(
                onboarded = p[Keys.ONBOARDED] ?: d.onboarded,
                textModel = p[Keys.TEXT_MODEL] ?: d.textModel,
                visionModel = p[Keys.VISION_MODEL] ?: d.visionModel,
                systemPrompt = p[Keys.SYSTEM_PROMPT] ?: d.systemPrompt,
                temperature = p[Keys.TEMPERATURE] ?: d.temperature,
                maxTokens = p[Keys.MAX_TOKENS] ?: d.maxTokens,
                historyLimit = p[Keys.HISTORY_LIMIT] ?: d.historyLimit,
                autoMemory = p[Keys.AUTO_MEMORY] ?: d.autoMemory,
                speakReplies = p[Keys.SPEAK_REPLIES] ?: d.speakReplies,
                ttsVoice = p[Keys.TTS_VOICE] ?: d.ttsVoice,
                speechRate = p[Keys.SPEECH_RATE] ?: d.speechRate,
                speechPitch = p[Keys.SPEECH_PITCH] ?: d.speechPitch,
                preferOfflineStt = p[Keys.PREFER_OFFLINE_STT] ?: d.preferOfflineStt,
                sttEngine = p[Keys.STT_ENGINE] ?: d.sttEngine,
                sttModel = p[Keys.STT_MODEL] ?: d.sttModel,
                sttLanguage = p[Keys.STT_LANGUAGE] ?: d.sttLanguage,
                wakeEnabled = p[Keys.WAKE_ENABLED] ?: d.wakeEnabled,
                wakeSensitivity = p[Keys.WAKE_SENSITIVITY] ?: d.wakeSensitivity,
                followUpSeconds = p[Keys.FOLLOW_UP_SECONDS] ?: d.followUpSeconds,
                ttsEngine = p[Keys.TTS_ENGINE] ?: d.ttsEngine,
                groqVoice = p[Keys.GROQ_VOICE] ?: d.groqVoice,
                reduceMotion = p[Keys.REDUCE_MOTION] ?: d.reduceMotion,
                replyStyle = p[Keys.REPLY_STYLE] ?: d.replyStyle,
                fallbackModel = p[Keys.FALLBACK_MODEL] ?: d.fallbackModel,
                toolsEnabled = p[Keys.TOOLS_ENABLED] ?: d.toolsEnabled,
                allowWeb = p[Keys.ALLOW_WEB] ?: d.allowWeb,
                proactiveSuggestions = p[Keys.PROACTIVE_SUGGESTIONS] ?: d.proactiveSuggestions,
                proactiveNotifications = p[Keys.PROACTIVE_NOTIFICATIONS] ?: d.proactiveNotifications,
                briefingMinute = p[Keys.BRIEFING_MINUTE] ?: d.briefingMinute,
                quietStart = p[Keys.QUIET_START] ?: d.quietStart,
                quietEnd = p[Keys.QUIET_END] ?: d.quietEnd,
                retentionDays = p[Keys.RETENTION_DAYS] ?: d.retentionDays,
                keepAwake = p[Keys.KEEP_AWAKE] ?: d.keepAwake,
                batterySaver = p[Keys.BATTERY_SAVER] ?: d.batterySaver,
                theme = p[Keys.THEME] ?: d.theme,
                showEmotion = p[Keys.SHOW_EMOTION] ?: d.showEmotion,
                avatarAnimations = p[Keys.AVATAR_ANIM] ?: d.avatarAnimations,
                avatarSizeDp = p[Keys.AVATAR_SIZE] ?: d.avatarSizeDp,
                showBackground = p[Keys.SHOW_BACKGROUND] ?: d.showBackground,
                activeProfile = p[Keys.ACTIVE_PROFILE] ?: d.activeProfile,
                activeConversation = p[Keys.ACTIVE_CONVERSATION] ?: d.activeConversation,
            )
        }

    suspend fun snapshot(): AppSettings = flow.first()

    suspend fun <T> set(key: Preferences.Key<T>, value: T) {
        runCatching { context.sagoDataStore.edit { it[key] = value } }
    }

    suspend fun <T> remove(key: Preferences.Key<T>) {
        runCatching { context.sagoDataStore.edit { it.remove(key) } }
    }

    suspend fun clearAll() { runCatching { context.sagoDataStore.edit { it.clear() } } }
}
