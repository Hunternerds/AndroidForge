package com.sago.app.domain.memory

import com.sago.app.data.db.MemoryDao
import com.sago.app.data.db.MemoryEntity
import com.sago.app.data.db.SearchIndex
import com.sago.app.domain.model.MemoryCandidate
import kotlinx.coroutines.flow.Flow

/**
 * Long-term memory 2.0: local-first, per profile, independent of chat history.
 * Each memory has a category, importance (1–5), confidence (0–1) and an optional expiry. Memories are de-duplicated,
 * merged, updated when a fact changes, expired when temporary, and only a few relevant ones are sent per request.
 */
class MemoryEngine(private val dao: MemoryDao, private val index: SearchIndex) {

    fun observe(profileId: String): Flow<List<MemoryEntity>> = dao.observe(profileId)

    /** "Sago remember …": always saved (the user explicitly asked), still normalised and de-duplicated. */
    suspend fun saveExplicit(profileId: String, raw: String): MemoryEntity? =
        save(profileId, MemoryCandidate(raw, importance = 4, confidence = 1f), "explicit", allowSensitive = true)

    /** Model-suggested memory: filtered hard for sensitivity, value and confidence. */
    suspend fun saveAuto(profileId: String, c: MemoryCandidate): Boolean {
        if (c.importance <= 1 || c.confidence < 0.5f) return false
        return save(profileId, c, "auto", allowSensitive = false) != null
    }

    /** Used by the model-facing "remember" tool: filtered like automatic memory, but returns the saved entity so it can be undone. */
    suspend fun saveFromTool(profileId: String, c: MemoryCandidate): MemoryEntity? = save(profileId, c, "auto", allowSensitive = false)

    suspend fun addManual(profileId: String, raw: String): MemoryEntity? =
        save(profileId, MemoryCandidate(raw, importance = 3, confidence = 1f), "manual", allowSensitive = true)

    private suspend fun save(profileId: String, c: MemoryCandidate, source: String, allowSensitive: Boolean): MemoryEntity? {
        val text = normalise(c.text)
        if (text.length < 4 || text.length > MAX_LEN) return null
        if (!allowSensitive && SensitiveFilter.isSensitive(text)) return null
        val category = c.category.takeIf { it in CATEGORIES && it != "general" } ?: categorise(text)
        val importance = c.importance.coerceIn(1, 5)
        val confidence = c.confidence.coerceIn(0f, 1f)
        val now = System.currentTimeMillis()
        // Temporary context (e.g. "today", "tomorrow") is kept briefly and then expires on its own.
        val days = c.expiresInDays ?: if (isTemporary(text)) 2 else null
        val expiresAt = days?.let { now + it.coerceIn(1, 365) * 86_400_000L }

        val existing = dao.all(profileId).filter { it.expiresAt == null || it.expiresAt > now }
        val newTokens = tokens(text)
        val newKey = subjectKey(text)
        val match = existing.firstOrNull { jaccard(tokens(it.text), newTokens) >= 0.75 }
            ?: newKey?.let { k -> existing.firstOrNull { subjectKey(it.text) == k } }
        if (match != null) {
            val merged = match.copy(
                text = if (source == "auto" && match.source == "explicit") match.text else text,
                updatedAt = now, importance = maxOf(match.importance, importance), confidence = maxOf(match.confidence, confidence),
                category = if (match.category == "general") category else match.category,
                expiresAt = if (match.expiresAt == null || expiresAt == null) null else maxOf(match.expiresAt, expiresAt),
            )
            dao.update(merged); reindex(merged)
            return merged
        }
        val entity = MemoryEntity(
            profileId = profileId, text = text, source = source, createdAt = now, updatedAt = now, lastUsedAt = now,
            category = category, importance = importance, confidence = confidence, expiresAt = expiresAt,
        )
        val saved = entity.copy(id = dao.insert(entity))
        reindex(saved)
        prune(profileId)
        return saved
    }

    /** A handful of short memories ranked by relevance to the current message. No embeddings, no network. */
    suspend fun relevant(profileId: String, query: String, limit: Int = 6, charBudget: Int = 700): List<String> {
        val now = System.currentTimeMillis()
        val all = runCatching { dao.all(profileId) }.getOrDefault(emptyList()).filter { it.expiresAt == null || it.expiresAt > now }
        if (all.isEmpty()) return emptyList()
        val q = tokens(query)
        val ftsIds = index.query(profileId, query, listOf("memory"), 10).mapNotNull { it.ref.toLongOrNull() }.toSet()
        val scored = all.map { m ->
            val overlap = tokens(m.text).count { it in q }
            val pref = if (m.category == "preference" && m.importance >= 4 || PREFERENCE_HINT.containsMatchIn(m.text)) 1.5 else 0.0
            val recency = 1.0 / (1.0 + (now - m.updatedAt) / (30.0 * 86_400_000))
            val fts = if (m.id in ftsIds) 1.0 else 0.0
            m to (overlap * 2.0 + pref + fts + m.importance * 0.25 + m.confidence * 0.3 + recency * 0.3)
        }.sortedByDescending { it.second }
        val picked = mutableListOf<MemoryEntity>(); var chars = 0
        for ((m, score) in scored) {
            if (picked.size >= limit || chars + m.text.length > charBudget) break
            if (score < 2.0) continue // unrelated notes aren't worth the tokens
            picked += m; chars += m.text.length
        }
        if (picked.isNotEmpty()) runCatching { dao.markUsed(picked.map { it.id }, now) }
        return picked.map { it.text }
    }

    /** Memories matching [query], best first (used by the search tool and "what do you remember about …"). */
    suspend fun search(profileId: String, query: String, limit: Int = 6): List<MemoryEntity> {
        val now = System.currentTimeMillis()
        val all = dao.all(profileId).filter { it.expiresAt == null || it.expiresAt > now }
        val q = tokens(query)
        val fts = index.query(profileId, query, listOf("memory"), 12).mapNotNull { it.ref.toLongOrNull() }.toSet()
        return all.map { m -> m to (tokens(m.text).count { it in q } * 2.0 + (if (m.id in fts) 1.0 else 0.0) + m.importance * 0.1) }
            .filter { it.second >= 1.0 }.sortedByDescending { it.second }.take(limit).map { it.first }
    }

    /** Candidates for "Sago forget …" with a match score (0–1). */
    suspend fun findToForget(profileId: String, query: String): List<Pair<MemoryEntity, Double>> {
        val q = tokens(query); val lowerQ = query.lowercase().trim()
        return dao.all(profileId).map { m ->
            val overlap = if (q.isEmpty()) 0.0 else tokens(m.text).count { it in q }.toDouble() / q.size
            val substring = if (lowerQ.length >= 4 && m.text.lowercase().contains(lowerQ)) 1.0 else 0.0
            m to maxOf(overlap, substring)
        }.filter { it.second >= 0.5 }.sortedByDescending { it.second }.take(3)
    }

    /** Local, offline answer to "what do you remember about me?". [topic] narrows it. */
    suspend fun recallText(profileId: String, topic: String?): String {
        val now = System.currentTimeMillis()
        val list = if (topic.isNullOrBlank()) dao.all(profileId).filter { it.expiresAt == null || it.expiresAt > now }.sortedByDescending { it.importance * 10 + it.confidence }
        else search(profileId, topic, 10)
        if (list.isEmpty()) return if (topic.isNullOrBlank()) "I don't have anything saved about you yet. Tell me something and say “Sago remember …” 💭" else "I don't have anything saved about “$topic” yet."
        val labels = linkedMapOf("preference" to "Preferences", "project" to "Projects", "goal" to "Goals", "routine" to "Routines", "relationship" to "People", "fact" to "Facts", "general" to "Other")
        return buildString {
            append(if (topic.isNullOrBlank()) "Here's what I remember about you:" else "Here's what I remember about “$topic”:")
            labels.forEach { (cat, label) ->
                val items = list.filter { it.category == cat }.take(5)
                if (items.isNotEmpty()) { append("\n\n").append(label).append(":"); items.forEach { append("\n• ").append(it.text) } }
            }
        }
    }

    suspend fun edit(entity: MemoryEntity, newText: String) {
        val t = normalise(newText)
        if (t.length >= 2) { val e = entity.copy(text = t.take(MAX_LEN), updatedAt = System.currentTimeMillis()); dao.update(e); reindex(e) }
    }

    suspend fun delete(id: Long) { dao.delete(id); index.remove("memory", id.toString()) }
    suspend fun clear(profileId: String) { dao.clear(profileId); index.removeProfile(profileId) }

    /** Puts a deleted memory back (undo). */
    suspend fun restore(e: MemoryEntity): MemoryEntity { val saved = e.copy(id = dao.insert(e.copy(id = 0))); reindex(saved); return saved }

    /** Maintenance: drop expired context, merge near-duplicates, forget stale low-value auto-memories. @return changes made. */
    suspend fun consolidate(profileId: String): Int {
        val now = System.currentTimeMillis(); var changes = 0
        dao.all(profileId).filter { it.expiresAt != null && it.expiresAt < now }.forEach { delete(it.id); changes++ }
        val sorted = dao.all(profileId).sortedWith(compareByDescending<MemoryEntity> { it.importance }.thenByDescending { it.updatedAt })
        val removed = HashSet<Long>()
        for (i in sorted.indices) {
            val a = sorted[i]; if (a.id in removed) continue
            val ta = tokens(a.text)
            for (j in i + 1 until sorted.size) {
                val b = sorted[j]
                if (b.id in removed || b.category != a.category || jaccard(ta, tokens(b.text)) < 0.6) continue
                val merged = a.copy(updatedAt = maxOf(a.updatedAt, b.updatedAt), confidence = maxOf(a.confidence, b.confidence), importance = maxOf(a.importance, b.importance))
                dao.update(merged); reindex(merged); delete(b.id); removed += b.id; changes++
            }
        }
        val staleBefore = now - 90 * 86_400_000L
        dao.all(profileId).filter { it.source == "auto" && it.importance <= 2 && it.lastUsedAt < staleBefore }.forEach { delete(it.id); changes++ }
        return changes
    }

    suspend fun purgeExpired(): Int { val ex = dao.expired(System.currentTimeMillis()); ex.forEach { delete(it.id) }; return ex.size }

    private suspend fun reindex(m: MemoryEntity) = index.upsert(m.profileId, "memory", m.id.toString(), m.category, m.text)

    private suspend fun prune(profileId: String) {
        val all = dao.all(profileId)
        if (all.size <= MAX_ENTRIES) return
        all.filter { it.source == "auto" }.sortedWith(compareBy<MemoryEntity> { it.importance }.thenBy { it.lastUsedAt }).take(all.size - MAX_ENTRIES).forEach { delete(it.id) }
    }

    private fun tokens(s: String): Set<String> = s.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 && it !in STOP }.toSet()
    private fun jaccard(a: Set<String>, b: Set<String>): Double = if (a.isEmpty() || b.isEmpty()) 0.0 else a.intersect(b).size.toDouble() / a.union(b).size
    private fun subjectKey(s: String): String? =
        Regex("^(?:user's|my)\\s+(.{3,40}?)\\s+(?:is|are|was)\\s+", RegexOption.IGNORE_CASE).find(s)?.groupValues?.get(1)?.lowercase()
    private fun isTemporary(s: String) =
        Regex("\\b(today|tonight|tomorrow|right now|this (morning|afternoon|evening|week)|currently feeling|at the moment)\\b", RegexOption.IGNORE_CASE).containsMatchIn(s)

    companion object {
        /** "my project is StudyOS" → "User's project is StudyOS". Keeps the stored note third-person and compact. */
        fun normalise(raw: String): String {
            var s = raw.trim().replace(Regex("\\s+"), " ").trim('"', '“', '”', ' ', '.')
            s = s.replace(Regex("^that\\s+", RegexOption.IGNORE_CASE), "")
            s = when {
                s.matches(Regex("(?i)^my\\s+.*")) -> "User's " + s.drop(3)
                s.matches(Regex("(?i)^i\\s*(am|'m)\\s+.*")) -> "User is " + s.replace(Regex("(?i)^i\\s*(am|'m)\\s+"), "")
                s.matches(Regex("(?i)^i\\s+(prefer|like|love|hate|use|want|need|work|live)\\b.*")) ->
                    s.replace(Regex("(?i)^i\\s+(prefer|like|love|hate|use|want|need|work|live)\\b")) { "User " + it.groupValues[1].lowercase() + "s" }
                s.matches(Regex("(?i)^i\\s+have\\b.*")) -> s.replace(Regex("(?i)^i\\s+have\\b"), "User has")
                else -> s
            }
            return s.replaceFirstChar { it.uppercase() }.take(MAX_LEN + 20)
        }

        fun categorise(text: String): String = when {
            Regex("\\b(project|app|building|developing|working on|startup|thesis|website)\\b", RegexOption.IGNORE_CASE).containsMatchIn(text) -> "project"
            Regex("\\b(prefers?|likes?|loves?|hates?|favou?rite|always|never|short answers|call me)\\b", RegexOption.IGNORE_CASE).containsMatchIn(text) -> "preference"
            Regex("\\b(goal|wants? to|plans? to|trying to|aims? to|dream)\\b", RegexOption.IGNORE_CASE).containsMatchIn(text) -> "goal"
            Regex("\\b(every (day|morning|evening|night|week)|daily|weekly|usually|routine)\\b", RegexOption.IGNORE_CASE).containsMatchIn(text) -> "routine"
            Regex("\\b(mom|mother|dad|father|sister|brother|friend|wife|husband|girlfriend|boyfriend|partner|dog|cat|boss)\\b", RegexOption.IGNORE_CASE).containsMatchIn(text) -> "relationship"
            else -> "general"
        }

        const val MAX_LEN = 160
        const val MAX_ENTRIES = 200
        val CATEGORIES = setOf("preference", "project", "goal", "routine", "fact", "relationship", "general")
        private val PREFERENCE_HINT = Regex("\\b(prefer|short answers|call me|my name|tone|answer)", RegexOption.IGNORE_CASE)
        private val STOP = setOf("the", "and", "for", "that", "with", "this", "from", "are", "was", "has", "have", "user", "users", "his", "her", "their", "about", "you", "your", "what", "when", "how", "can", "not")
    }
}

/** Blocks automatic saving of sensitive data. Only an explicit "Sago remember…" can store such things. */
object SensitiveFilter {
    private val patterns = listOf(
        "password", "passcode", "passphrase", "\\bpin\\b", "\\botp\\b", "api key", "secret", "token", "credit card", "card number", "cvv",
        "\\bssn\\b", "social security", "passport", "bank account", "\\biban\\b", "routing number", "salary", "diagnos", "medication",
        "prescription", "disease", "illness", "therapy", "religio", "political", "sexual", "home address", "phone number", "e-?mail",
        "\\d{9,}", "@[a-z0-9.-]+\\.[a-z]{2,}",
    ).map { Regex(it, RegexOption.IGNORE_CASE) }

    fun isSensitive(text: String) = patterns.any { it.containsMatchIn(text) }
}
