package com.sago.app.reminders

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.sago.app.SagoApp
import com.sago.app.domain.tools.TimeUtil

/** Delivers one reminder or routine, then schedules its next occurrence (if it repeats). */
class ReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val c = (applicationContext as SagoApp).container
        val id = inputData.getLong("id", -1)
        val r = c.remindersRepo.get(id) ?: return Result.success()
        if (!r.enabled) return Result.success()
        val s = c.settings.snapshot()
        val now = System.currentTimeMillis()
        val proactive = r.kind != "reminder"

        if (proactive) {
            // Proactive messages are opt-in and never arrive during quiet hours. Reminders the user asked for always do.
            if (!s.proactiveNotifications) { c.remindersRepo.markFired(r.copy(lastFiredAt = r.lastFiredAt), now); return Result.success() }
            if (TimeUtil.inQuietHours(now, s.quietStart, s.quietEnd)) {
                c.remindersRepo.update(r.copy(triggerAt = TimeUtil.endOfQuiet(now, s.quietEnd))); return Result.success()
            }
        }
        val (title, body) = c.briefing.compose(r)
        val delivered = Notifier.post(applicationContext, 2000 + (r.id % 5000).toInt(), if (proactive) Notifier.CH_PROACTIVE else Notifier.CH_REMINDERS, title, body)
        c.diagnostics.count(if (delivered) "reminders.delivered" else "reminders.blocked")
        c.remindersRepo.markFired(r, now)
        return Result.success()
    }
}
