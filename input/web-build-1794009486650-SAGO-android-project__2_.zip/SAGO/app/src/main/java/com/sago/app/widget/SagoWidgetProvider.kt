package com.sago.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.sago.app.MainActivity
import com.sago.app.R

/** Home-screen widget: talk, start a new chat, or open the library. Each button just opens SAGO with that action. */
class SagoWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_sago)
            views.setOnClickPendingIntent(R.id.widget_talk, action(context, "com.sago.app.action.VOICE", 1))
            views.setOnClickPendingIntent(R.id.widget_chat, action(context, "com.sago.app.action.NEW_CHAT", 2))
            views.setOnClickPendingIntent(R.id.widget_library, action(context, "com.sago.app.action.LIBRARY", 3))
            manager.updateAppWidget(id, views)
        }
    }

    private fun action(ctx: Context, action: String, code: Int): PendingIntent =
        PendingIntent.getActivity(ctx, code, Intent(ctx, MainActivity::class.java).setAction(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
}
