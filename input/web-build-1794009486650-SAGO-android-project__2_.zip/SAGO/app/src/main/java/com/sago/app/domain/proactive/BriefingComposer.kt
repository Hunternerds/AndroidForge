package com.sago.app.domain.proactive

import com.sago.app.data.db.ReminderEntity
import com.sago.app.data.db.SagoDatabase
import com.sago.app.domain.tools.TimeUtil
import java.time.LocalDate
import java.time.ZoneId

/**
 * Writes notification text for reminders and routines from local data only. It never invents commitments:
 * it lists what is actually stored (tasks, reminders, projects) and says so plainly when there is nothing.
 */
class BriefingComposer(private val db: SagoDatabase) {

    suspend fun compose(r: ReminderEntity): Pair<String, String> = when (r.kind) {
        "reminder" -> "Reminder" to (if (r.body.isNotBlank()) "${r.title}\n${r.body}" else r.title)
        "briefing" -> "Good morning ☀️" to morning(r.profileId)
        "review_tasks" -> "Task review" to tasks(r.profileId)
        "review_projects" -> "Project check-in" to projects(r.profileId)
        "evening_summary" -> "Evening wrap-up" to evening(r.profileId)
        else -> "SAGO" to r.title
    }

    private suspend fun morning(profile: String): String {
        val now = System.currentTimeMillis()
        val endOfDay = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val reminders = db.reminders().all(profile).filter { it.enabled && it.kind == "reminder" && it.triggerAt in now until endOfDay }.sortedBy { it.triggerAt }
        val tasks = db.entries().openTasks(profile, 3)
        val projects = db.memories().all(profile).filter { it.category == "project" }.sortedByDescending { it.updatedAt }.take(2)
        val lines = mutableListOf<String>()
        if (reminders.isNotEmpty()) lines += "Today: " + reminders.take(3).joinToString("; ") { "${it.title} (${TimeUtil.formatWhen(it.triggerAt).substringAfterLast(", ")})" }
        if (tasks.isNotEmpty()) lines += "Open tasks: " + tasks.joinToString("; ") { it.title }
        if (projects.isNotEmpty()) lines += "Ongoing: " + projects.joinToString("; ") { it.text }
        return if (lines.isEmpty()) "Nothing is scheduled for today. Want to plan something together?" else lines.joinToString("\n") + "\nWant to pick one up?"
    }

    private suspend fun tasks(profile: String): String {
        val t = db.entries().openTasks(profile, 6)
        return if (t.isEmpty()) "No open tasks. Nice and clear!" else t.joinToString("\n") { "• " + it.title + (it.dueAt?.let { d -> " (due ${TimeUtil.formatWhen(d)})" } ?: "") }
    }

    private suspend fun projects(profile: String): String {
        val p = db.memories().all(profile).filter { it.category == "project" }.sortedByDescending { it.updatedAt }.take(4)
        return if (p.isEmpty()) "I don't have any ongoing projects saved yet. Tell me about one and say “Sago remember …”." else p.joinToString("\n") { "• " + it.text } + "\nWant to continue one?"
    }

    private suspend fun evening(profile: String): String {
        val start = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val convs = db.conversations().latest(profile, 6).filter { it.updatedAt >= start }
        val open = db.entries().openTasks(profile, 50).size
        val parts = mutableListOf<String>()
        parts += if (convs.isEmpty()) "We didn't chat today." else "Today we talked about: " + convs.take(3).joinToString("; ") { it.title }
        if (open > 0) parts += "You still have $open open task${if (open == 1) "" else "s"}."
        return parts.joinToString("\n")
    }
}
