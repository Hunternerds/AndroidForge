package com.sago.app.wake

import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.IOException

/**
 * Offline wake-word detection on top of Vosk.
 *
 * [awaitWake] runs a *grammar-restricted* recogniser that can only output "sago" (plus a few phonetic variants)
 * or [unk]. It is tiny, fully on-device, and never sends audio anywhere. What the user says AFTER the wake word is
 * recorded from the same microphone stream (no hand-off gap) and transcribed separately for accuracy.
 *
 * All methods block; call them from a background dispatcher.
 */
class VoskWakeEngine(modelPath: String) : AutoCloseable {
    private val model: Model

    init {
        LibVosk.setLogLevel(LogLevel.WARNINGS)
        model = Model(modelPath)
    }

    /** @return true if the wake word was heard, false if [shouldStop] asked us to yield the microphone. */
    fun awaitWake(mic: MicStream, sensitivity: Float, shouldStop: () -> Boolean): Boolean {
        val needed = when { sensitivity > 0.75f -> 1; sensitivity > 0.35f -> 2; else -> 3 }
        val minPeak = (1200 - 900 * sensitivity).toInt()          // energy gate: ignore near-silent "hallucinations"
        val recent = IntArray(6); var ri = 0
        var consecutive = 0
        Recognizer(model, MicStream.SAMPLE_RATE.toFloat(), GRAMMAR).use { rec ->
            while (!shouldStop()) {
                val n = mic.read()
                if (n < 0) throw IOException("Microphone read failed ($n)")
                if (n == 0) continue
                recent[ri++ % recent.size] = mic.lastPeak
                val energetic = recent.max() >= minPeak
                val isFinal = rec.acceptWaveForm(mic.buffer, n)
                val text = if (isFinal) field(rec.result, "text") else field(rec.partialResult, "partial")
                val padded = " $text "
                val hit = WAKE_WORDS.any { " $it " in padded }
                if (hit && energetic) consecutive++ else if (!hit) consecutive = 0
                if (consecutive >= needed || (isFinal && hit && energetic)) return true
            }
        }
        return false
    }

    /**
     * A full-vocabulary live decoder used only for the on-screen preview while the user speaks, and as an
     * offline fallback transcript if the accurate (Groq Whisper) transcription can't be reached.
     */
    fun newDecoder(): LiveDecoder = LiveDecoder(Recognizer(model, MicStream.SAMPLE_RATE.toFloat()))

    inner class LiveDecoder internal constructor(private val rec: Recognizer) : AutoCloseable {
        private val done = StringBuilder()
        private var partial = ""

        fun feed(samples: ShortArray, len: Int) {
            if (rec.acceptWaveForm(samples, len)) {
                val t = field(rec.result, "text")
                if (t.isNotBlank()) done.append(t).append(' ')
                partial = ""
            } else partial = field(rec.partialResult, "partial")
        }

        /** Text heard so far, for display. */
        fun display(): String = (done.toString() + partial).trim()

        /** Flushes the decoder and returns the complete offline transcript. */
        fun finish(): String = (done.toString() + field(rec.finalResult, "text")).trim()

        override fun close() { runCatching { rec.close() } }
    }

    override fun close() { runCatching { model.close() } }

    private fun field(json: String, key: String): String = runCatching { JSONObject(json).optString(key) }.getOrDefault("").trim()

    private companion object {
        // Phonetic variants widen recognition of "Sago" (/ˈseɪɡoʊ/) across accents; all map to the one wake word.
        val WAKE_WORDS = setOf("sago", "saigo", "say go")
        const val GRAMMAR = "[\"sago\", \"saigo\", \"say go\", \"[unk]\"]"
    }
}
