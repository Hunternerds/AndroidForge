package com.sago.app.domain.proactive

import com.sago.app.data.db.SagoDatabase

data class Suggestion(val label: String, val kind: String, val payload: String)

/** In-app, on-device suggestions shown on the empty chat. They are built only from saved data, never invented. */
class SuggestionEngine(private val db: SagoDatabase) {
    suspend fun forProfile(profileId: String): List<Suggestion> = runCatching {
        val out = mutableListOf<Suggestion>()
        val now = System.currentTimeMillis()
        val tasks = db.entries().openTasks(profileId, 20)
        if (tasks.isNotEmpty()) {
            val overdue = tasks.count { it.dueAt != null && it.dueAt < now }
            out += Suggestion(if (overdue > 0) "$overdue overdue task${if (overdue == 1) "" else "s"}" else "${tasks.size} open task${if (tasks.size == 1) "" else "s"}", "prompt", "What's on my task list?")
        }
        db.conversations().latest(profileId, 5).firstOrNull { now - it.updatedAt < 7 * 86_400_000L && db.messages().countAfter(it.id, 0) >= 4 }
            ?.let { out += Suggestion("Continue: ${it.title}", "conversation", it.id.toString()) }
        db.memories().all(profileId).filter { it.category == "project" && (it.expiresAt == null || it.expiresAt > now) }.maxByOrNull { it.updatedAt }
            ?.let { out += Suggestion("Pick up: ${it.text.removePrefix("User's ").take(36)}", "prompt", "Let's continue with this project: ${it.text}") }
        val next = db.reminders().all(profileId).filter { it.enabled && it.kind == "reminder" && it.triggerAt > now }.minByOrNull { it.triggerAt }
        if (next != null && next.triggerAt - now < 86_400_000L) out += Suggestion("Next: ${next.title.take(30)}", "prompt", "What reminders do I have coming up?")
        out.take(3)
    }.getOrDefault(emptyList())
}
