package com.sago.app.data.groq

import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.io.InterruptedIOException
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class GroqModel(val id: String, val ownedBy: String, val contextWindow: Int?)

data class ChatTurn(val role: String, val text: String, val imageDataUrls: List<String> = emptyList())

data class ChatRequest(
    val model: String,
    val turns: List<ChatTurn>,
    val temperature: Float,
    val maxTokens: Int,
    val jsonMode: Boolean = true,
)

data class ChatResult(val text: String, val promptTokens: Int?, val completionTokens: Int?)

/**
 * Thin OkHttp client for Groq's OpenAI-compatible API (https://api.groq.com/openai/v1).
 * Handles timeouts, bounded retries with exponential backoff, rate limits and per-model parameter fallbacks.
 */
class GroqClient(private val http: OkHttpClient, private val apiKey: () -> String?) {

    /** Remembers when a model rejected optional parameters so we don't repeat failing requests. */
    private data class Compat(val extras: Boolean = true, val json: Boolean = true)
    private val compat = ConcurrentHashMap<String, Compat>()

    suspend fun listModels(keyOverride: String? = null): List<GroqModel> {
        val key = keyOverride ?: apiKey() ?: throw GroqError.MissingKey()
        val req = Request.Builder().url("$BASE/models").header("Authorization", "Bearer $key").get().build()
        return withRetry {
            val body = execute(req)
            val arr = JSONObject(body).optJSONArray("data") ?: JSONArray()
            (0 until arr.length()).map { arr.getJSONObject(it) }
                .filter { it.optBoolean("active", true) }
                .map { GroqModel(it.getString("id"), it.optString("owned_by"), it.optInt("context_window").takeIf { c -> c > 0 }) }
        }
    }

    /** Speech-to-text via Groq's OpenAI-compatible Whisper endpoint. [wav] is a complete WAV file. */
    suspend fun transcribe(wav: ByteArray, model: String, language: String?, prompt: String?): String {
        val key = apiKey() ?: throw GroqError.MissingKey()
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("file", "speech.wav", wav.toRequestBody("audio/wav".toMediaType()))
            .addFormDataPart("model", model)
            .addFormDataPart("response_format", "json")
            .addFormDataPart("temperature", "0")
            .apply {
                if (!language.isNullOrBlank()) addFormDataPart("language", language)
                if (!prompt.isNullOrBlank()) addFormDataPart("prompt", prompt)
            }.build()
        val req = Request.Builder().url("$BASE/audio/transcriptions").header("Authorization", "Bearer $key").post(body).build()
        return withRetry { JSONObject(execute(req, model)).optString("text").trim() }
    }

    suspend fun chat(request: ChatRequest): ChatResult {
        var state = compat[request.model] ?: Compat()
        var attempt = 0
        while (true) {
            try {
                return doChat(request, state)
            } catch (e: GroqError.BadRequest) {
                // Some models reject reasoning / JSON-mode parameters. Degrade gracefully, once per model.
                if (!e.paramRelated) throw e
                state = when {
                    state.extras -> state.copy(extras = false)
                    state.json && request.jsonMode -> state.copy(json = false)
                    else -> throw e
                }
                compat[request.model] = state
            } catch (e: GroqError.RateLimited) {
                if (++attempt > MAX_RETRIES) throw e
                delay((e.retryAfterMs ?: backoff(attempt)).coerceAtMost(15_000))
            } catch (e: GroqError.Server) {
                if (++attempt > MAX_RETRIES) throw e
                delay(backoff(attempt))
            } catch (e: GroqError.Network) {
                if (++attempt > MAX_RETRIES) throw e
                delay(backoff(attempt))
            }
        }
    }

    private suspend fun doChat(r: ChatRequest, c: Compat): ChatResult {
        val key = apiKey() ?: throw GroqError.MissingKey()
        val messages = JSONArray()
        r.turns.forEach { t ->
            val m = JSONObject().put("role", t.role)
            if (t.imageDataUrls.isEmpty()) m.put("content", t.text)
            else {
                val parts = JSONArray().put(JSONObject().put("type", "text").put("text", t.text))
                t.imageDataUrls.forEach { url ->
                    parts.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", url)))
                }
                m.put("content", parts)
            }
            messages.put(m)
        }
        val body = JSONObject()
            .put("model", r.model).put("messages", messages)
            .put("temperature", r.temperature.toDouble()).put("max_completion_tokens", r.maxTokens)
        if (r.jsonMode && c.json) body.put("response_format", JSONObject().put("type", "json_object"))
        if (c.extras) {
            when {
                r.model.startsWith("openai/gpt-oss") -> { body.put("reasoning_effort", "low"); body.put("include_reasoning", false) }
                r.model.contains("qwen") -> body.put("reasoning_effort", "none")
            }
        }
        val req = Request.Builder().url("$BASE/chat/completions").header("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        val json = JSONObject(execute(req, r.model))
        val choice = json.optJSONArray("choices")?.optJSONObject(0) ?: throw GroqError.EmptyReply()
        val content = choice.optJSONObject("message")?.optString("content").orEmpty()
        if (content.isBlank()) throw GroqError.EmptyReply()
        val usage = json.optJSONObject("usage")
        return ChatResult(content, usage?.optInt("prompt_tokens"), usage?.optInt("completion_tokens"))
    }

    private suspend fun <T> withRetry(block: suspend () -> T): T {
        var attempt = 0
        while (true) {
            try { return block() }
            catch (e: GroqError.Network) { if (++attempt > MAX_RETRIES) throw e; delay(backoff(attempt)) }
            catch (e: GroqError.Server) { if (++attempt > MAX_RETRIES) throw e; delay(backoff(attempt)) }
            catch (e: GroqError.RateLimited) { if (++attempt > MAX_RETRIES) throw e; delay((e.retryAfterMs ?: backoff(attempt)).coerceAtMost(15_000)) }
        }
    }

    private suspend fun execute(req: Request, model: String = ""): String {
        val resp = try { http.newCall(req).await() }
        catch (e: InterruptedIOException) { throw GroqError.Timeout() }
        catch (e: IOException) { throw GroqError.Network(e) }
        resp.use {
            val text = it.body?.string().orEmpty()
            if (it.isSuccessful) return text
            throw mapError(it.code, text, it.header("Retry-After"), model)
        }
    }

    private fun mapError(code: Int, body: String, retryAfter: String?, model: String): GroqError {
        val msg = runCatching { JSONObject(body).optJSONObject("error")?.optString("message") }.getOrNull().orEmpty()
        val errCode = runCatching { JSONObject(body).optJSONObject("error")?.optString("code") }.getOrNull().orEmpty()
        val lower = msg.lowercase()
        return when {
            code == 401 || code == 403 -> GroqError.InvalidKey()
            code == 404 || (code == 400 && ("model" in lower) && listOf("decommission", "not found", "does not exist", "not supported", "no longer").any { it in lower }) ->
                GroqError.ModelUnavailable(model.ifBlank { "selected" })
            code == 413 -> GroqError.PayloadTooLarge()
            code == 429 -> GroqError.RateLimited(retryAfter?.toDoubleOrNull()?.let { (it * 1000).toLong() })
            code == 400 -> GroqError.BadRequest(
                msg.ifBlank { "bad request" },
                paramRelated = errCode == "json_validate_failed" ||
                    listOf("response_format", "reasoning", "json", "include_reasoning", "unsupported", "unknown parameter", "not support").any { it in lower },
            )
            code in 500..599 -> GroqError.Server(code)
            else -> GroqError.Unknown("HTTP $code ${msg.take(120)}")
        }
    }

    private fun backoff(attempt: Int): Long = (700L * (1L shl (attempt - 1))) + (0..250).random()

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) { if (cont.isActive) cont.resumeWithException(e) }
            override fun onResponse(call: Call, response: Response) { cont.resume(response) }
        })
        cont.invokeOnCancellation { runCatching { cancel() } }
    }

    companion object {
        const val BASE = "https://api.groq.com/openai/v1"
        private const val MAX_RETRIES = 3

        fun newHttpClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(java.time.Duration.ofSeconds(10))
            .readTimeout(java.time.Duration.ofSeconds(60))
            .writeTimeout(java.time.Duration.ofSeconds(30))
            .callTimeout(java.time.Duration.ofSeconds(80))
            .build()

        /** Groq's /models list mixes in speech, safety and other non-chat models; keep chat-capable ones. */
        fun isChatModel(id: String): Boolean {
            val l = id.lowercase()
            return listOf("whisper", "tts", "guard", "orpheus", "playai", "embed", "safeguard", "prompt-guard").none { it in l }
        }

        /** Groq doesn't flag image support in /models, so combine a known list with name patterns. */
        fun looksVisionCapable(id: String): Boolean {
            val l = id.lowercase()
            return l in KNOWN_VISION || listOf("vision", "llama-4-scout", "llama-4-maverick", "qwen3.6", "qwen3.8").any { it in l }
        }

        // Verified against console.groq.com/docs/vision (Nov 2026). The list in Settings is always live.
        private val KNOWN_VISION = setOf("qwen/qwen3.6-27b", "qwen/qwen3.8-27b")
    }
}
