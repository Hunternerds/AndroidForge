package com.sago.app.ui.viewmodel

import android.net.Uri
import android.os.SystemClock
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.sago.app.AppContainer
import com.sago.app.data.db.ConversationEntity
import com.sago.app.data.db.MemoryEntity
import com.sago.app.data.db.ProfileEntity
import com.sago.app.data.groq.*
import com.sago.app.data.prefs.*
import com.sago.app.domain.model.ChatMessage
import com.sago.app.domain.model.PickedImage
import com.sago.app.voice.UiError
import com.sago.app.voice.VoiceInfo
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File

class SagoViewModelFactory(private val c: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when (modelClass) {
        ChatViewModel::class.java -> ChatViewModel(c)
        HistoryViewModel::class.java -> HistoryViewModel(c)
        OnboardingViewModel::class.java -> OnboardingViewModel(c)
        SettingsViewModel::class.java -> SettingsViewModel(c)
        else -> throw IllegalArgumentException("Unknown ViewModel ${modelClass.name}")
    } as T
}

class ChatViewModel(private val c: AppContainer) : ViewModel() {
    val assistant = c.assistant
    val settings = c.settings.flow.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    val wakeStatus = c.wake.status
    val wakeDetail = c.wake.detail

    @OptIn(ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<ChatMessage>> = assistant.activeConversation
        .flatMapLatest { id -> if (id == 0L) flowOf(emptyList()) else c.repo.messages(id).catch { emit(emptyList()) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val draft = MutableStateFlow<PickedImage?>(null)
    val attaching = MutableStateFlow(false)

    init { viewModelScope.launch { runCatching { c.ensureProfile() } } }

    fun send(text: String) { assistant.sendText(text.trim(), draft.value); draft.value = null }
    fun attach(uri: Uri) = loadImage { c.images.fromUri(uri) }
    fun attachFile(file: File) = loadImage { c.images.fromFile(file).also { file.delete() } }
    fun clearDraft() { draft.value = null }

    private fun loadImage(block: suspend () -> PickedImage) {
        viewModelScope.launch {
            attaching.value = true
            try { draft.value = block() }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { assistant.error.value = UiError(e.message ?: "Couldn't load that image.") }
            finally { attaching.value = false }
        }
    }
}

class HistoryViewModel(private val c: AppContainer) : ViewModel() {
    @OptIn(ExperimentalCoroutinesApi::class)
    val conversations: StateFlow<List<ConversationEntity>> = c.settings.flow.map { it.activeProfile }.distinctUntilChanged()
        .flatMapLatest { c.repo.conversations(it).catch { emit(emptyList()) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val activeId = c.assistant.activeConversation

    fun open(id: Long) = c.assistant.openConversation(id)
    fun newChat() = c.assistant.newConversation()
    fun delete(id: Long) {
        viewModelScope.launch {
            runCatching { c.repo.deleteConversation(id) }
            if (c.assistant.activeConversation.value == id) c.assistant.newConversation()
        }
    }
}

sealed interface OnboardingState {
    data object Idle : OnboardingState
    data object Validating : OnboardingState
    data class Initializing(val step: String) : OnboardingState
    data class Error(val message: String) : OnboardingState
}

class OnboardingViewModel(private val c: AppContainer) : ViewModel() {
    val state = MutableStateFlow<OnboardingState>(OnboardingState.Idle)

    fun connect(rawKey: String, onDone: () -> Unit) {
        val key = rawKey.trim()
        if (key.isEmpty()) { state.value = OnboardingState.Error("Paste your Groq API key first."); return }
        viewModelScope.launch {
            try {
                state.value = OnboardingState.Validating
                val models = c.groq.listModels(key) // real request: a bad key or no network fails here, honestly
                state.value = OnboardingState.Initializing("Saving your key securely…")
                if (!c.saveApiKey(key)) throw IllegalStateException("Couldn't store the key in secure storage on this device.")
                state.value = OnboardingState.Initializing("Preparing SAGO…")
                c.ensureProfile()
                val chat = models.map { it.id }.filter { GroqClient.isChatModel(it) }
                if (chat.isEmpty()) throw IllegalStateException("Your Groq account returned no chat models.")
                val text = listOf("openai/gpt-oss-120b", "openai/gpt-oss-20b").firstOrNull { it in chat } ?: chat.first()
                val vision = chat.firstOrNull { GroqClient.looksVisionCapable(it) } ?: DEFAULT_VISION_MODEL
                c.settings.set(Keys.TEXT_MODEL, text)
                c.settings.set(Keys.VISION_MODEL, vision)
                c.settings.set(Keys.ONBOARDED, true)
                state.value = OnboardingState.Idle
                onDone()
            } catch (e: CancellationException) { throw e }
            catch (e: GroqError) { state.value = OnboardingState.Error(e.userMessage) }
            catch (e: Exception) { state.value = OnboardingState.Error(e.message ?: "Something went wrong.") }
        }
    }
}

data class TestResult(val ok: Boolean, val message: String)

class SettingsViewModel(private val c: AppContainer) : ViewModel() {
    val settings = c.settings.flow.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    // AI
    val models = MutableStateFlow<List<GroqModel>>(emptyList())
    /** Unfiltered live list (includes speech models such as Whisper). */
    val allModels = MutableStateFlow<List<GroqModel>>(emptyList())
    val modelsBusy = MutableStateFlow(false)
    val testing = MutableStateFlow(false)
    val testResult = MutableStateFlow<TestResult?>(null)
    val keyMask = MutableStateFlow(c.maskedKey())
    val keyMessage = MutableStateFlow<TestResult?>(null)

    // Voice
    val voices = MutableStateFlow<List<VoiceInfo>>(emptyList())
    val modelState = c.wakeModel.state
    val wakeStatus = c.wake.status
    val wakeDetail = c.wake.detail

    // Memory / profiles
    @OptIn(ExperimentalCoroutinesApi::class)
    val memories: StateFlow<List<MemoryEntity>> = c.settings.flow.map { it.activeProfile }.distinctUntilChanged()
        .flatMapLatest { c.memory.observe(it).catch { emit(emptyList()) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val profiles: StateFlow<List<ProfileEntity>> = c.repo.profiles().catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun <T> set(key: Preferences.Key<T>, value: T) { viewModelScope.launch { c.settings.set(key, value) } }
    fun resetPrompt() { viewModelScope.launch { c.settings.remove(Keys.SYSTEM_PROMPT) } }

    fun refreshModels() {
        viewModelScope.launch {
            modelsBusy.value = true
            try { val all = c.groq.listModels(); allModels.value = all.sortedBy { it.id }; models.value = all.filter { GroqClient.isChatModel(it.id) }.sortedBy { it.id } }
            catch (e: GroqError) { testResult.value = TestResult(false, e.userMessage) }
            catch (e: CancellationException) { throw e }
            finally { modelsBusy.value = false }
        }
    }

    fun testConnection() {
        viewModelScope.launch {
            testing.value = true; testResult.value = null
            try {
                val s = settings.value
                val list = c.groq.listModels()
                allModels.value = list.sortedBy { it.id }
                models.value = list.filter { GroqClient.isChatModel(it.id) }.sortedBy { it.id }
                val t0 = SystemClock.elapsedRealtime()
                c.groq.chat(ChatRequest(s.textModel, listOf(ChatTurn("user", "Reply with the single word OK.")), 0f, 32, jsonMode = false))
                val ms = SystemClock.elapsedRealtime() - t0
                testResult.value = TestResult(true, "Connected. ${list.size} models available; “${s.textModel}” answered in $ms ms.")
            } catch (e: GroqError) { testResult.value = TestResult(false, e.userMessage) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { testResult.value = TestResult(false, e.message ?: "Test failed.") }
            finally { testing.value = false }
        }
    }

    fun saveKey(newKey: String) {
        val key = newKey.trim()
        if (key.isEmpty()) { keyMessage.value = TestResult(false, "Paste a key first."); return }
        viewModelScope.launch {
            keyMessage.value = TestResult(true, "Verifying with Groq…")
            try {
                c.groq.listModels(key)
                if (!c.saveApiKey(key)) { keyMessage.value = TestResult(false, "Couldn't store the key securely on this device."); return@launch }
                keyMask.value = c.maskedKey()
                keyMessage.value = TestResult(true, "Key verified and saved.")
                refreshModels()
            } catch (e: GroqError) { keyMessage.value = TestResult(false, e.userMessage) }
            catch (e: CancellationException) { throw e }
        }
    }

    fun loadVoices() { viewModelScope.launch { voices.value = c.tts.voices() } }

    fun testVoice() {
        viewModelScope.launch {
            val s = settings.value
            runCatching { c.tts.speak("Hi, I'm Sago. This is how I sound.", s.speechRate, s.speechPitch, s.ttsVoice) }
        }
    }
    fun stopVoiceTest() = c.tts.stop()

    fun downloadVoiceModel() { viewModelScope.launch { c.wakeModel.download() } }
    fun deleteVoiceModel() { c.wakeModel.delete() }

    // Memory
    fun addMemory(text: String) { viewModelScope.launch { runCatching { c.memory.addManual(settings.value.activeProfile, text) } } }
    fun editMemory(m: MemoryEntity, text: String) { viewModelScope.launch { runCatching { c.memory.edit(m, text) } } }
    fun deleteMemory(id: Long) { viewModelScope.launch { runCatching { c.memory.delete(id) } } }
    fun clearMemories() { viewModelScope.launch { runCatching { c.memory.clear(settings.value.activeProfile) } } }

    fun createProfile(name: String) { viewModelScope.launch { runCatching { c.repo.createProfile(name) } } }
    fun switchProfile(id: String) {
        viewModelScope.launch { c.settings.set(Keys.ACTIVE_PROFILE, id); c.assistant.newConversation() }
    }
    fun deleteProfile(id: String) {
        viewModelScope.launch {
            val others = profiles.value.filter { it.id != id }
            if (others.isEmpty()) return@launch
            if (settings.value.activeProfile == id) switchProfile(others.first().id)
            runCatching { c.repo.deleteProfile(id) }
        }
    }

    // Privacy
    fun deleteConversations() {
        viewModelScope.launch { runCatching { c.repo.deleteAllConversations(settings.value.activeProfile) }; c.assistant.newConversation() }
    }

    fun deleteApiKey(onDone: () -> Unit) {
        viewModelScope.launch {
            c.assistant.stop()
            c.clearApiKey()
            c.settings.set(Keys.ONBOARDED, false)
            c.settings.set(Keys.WAKE_ENABLED, false)
            keyMask.value = ""
            onDone()
        }
    }

    fun resetEverything(onDone: () -> Unit) {
        viewModelScope.launch {
            c.assistant.stop()
            withContext(Dispatchers.IO) {
                runCatching { c.db.clearAllTables() }
                runCatching { File(c.appFilesDir(), "images").deleteRecursively() }
            }
            c.wakeModel.delete()
            c.clearApiKey()
            c.settings.clearAll()
            keyMask.value = ""
            onDone()
        }
    }
}
