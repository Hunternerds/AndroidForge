package com.sago.app.domain.ai

import android.util.Base64
import com.sago.app.avatar.Expression
import com.sago.app.data.ChatRepository
import com.sago.app.data.groq.*
import com.sago.app.data.prefs.SettingsStore
import com.sago.app.domain.memory.MemoryCommandParser
import com.sago.app.domain.memory.MemoryEngine
import com.sago.app.domain.model.AiReply
import com.sago.app.domain.model.ChatMessage
import com.sago.app.domain.model.Emotion
import com.sago.app.domain.model.PickedImage

/** A user message that has been stored and is waiting for (or retrying) a reply. */
data class Turn(
    val conversationId: Long,
    val profileId: String,
    val userMessageId: Long,
    val text: String,
    val image: PickedImage?,
    val viaWake: Boolean,
)

/**
 * The single AI engine shared by typed chat and voice. Order of work:
 * store user message → handle "Sago remember" → select relevant memories → trimmed history → Groq → parse → store.
 */
class ConversationEngine(
    private val settings: SettingsStore,
    private val groq: GroqClient,
    private val repo: ChatRepository,
    private val memory: MemoryEngine,
) {
    suspend fun begin(conversationId: Long, text: String, image: PickedImage?, viaWake: Boolean): Turn {
        val s = settings.snapshot()
        val shown = MemoryCommandParser.stripWake(text, viaWake)
        val cid = conversationId.takeIf { it != 0L && repo.conversation(it, s.activeProfile) != null }
            ?: repo.createConversation(s.activeProfile, shown)
        val mid = repo.addMessage(cid, ChatMessage.Role.USER, shown, imagePath = image?.savedPath)
        return Turn(cid, s.activeProfile, mid, text, image, viaWake)
    }

    suspend fun complete(turn: Turn): AiReply {
        val s = settings.snapshot()
        val cleanText = MemoryCommandParser.stripWake(turn.text, turn.viaWake)

        // 1) Explicit memory command is saved immediately, before any network call.
        val command = MemoryCommandParser.parse(turn.text, turn.viaWake)
        val saved = command?.let { runCatching { memory.saveExplicit(turn.profileId, it) }.getOrNull() }

        // 2) Compact context: few relevant memories + bounded history.
        val memories = runCatching { memory.relevant(turn.profileId, cleanText) }.getOrDefault(emptyList())
        val window = runCatching { repo.recent(turn.conversationId, maxOf(s.historyLimit + 1, 40)) }.getOrDefault(emptyList())
            .filter { it.id != turn.userMessageId }
        val history = window.takeLast(s.historyLimit)
        val studyMode = StudyMode.isActive(window, cleanText)
        // Mood continuity: tell the model how it felt in its last message so it doesn't reset every turn.
        val mood = window.lastOrNull { it.role == ChatMessage.Role.ASSISTANT }?.emotion
        var budget = HISTORY_CHAR_BUDGET
        val trimmed = history.asReversed().takeWhile { budget -= it.text.length; budget > 0 }.asReversed()

        val system = PromptBuilder.system(
            personality = PersonalityDefaults.resolve(s.systemPrompt),
            memories = memories, autoMemory = s.autoMemory && command == null, justSaved = saved, hasImage = turn.image != null, mood = mood,
        )
        val turns = buildList {
            add(ChatTurn("system", system))
            trimmed.forEach { add(ChatTurn(if (it.role == ChatMessage.Role.USER) "user" else "assistant", if (it.imagePath != null) "[shared an image] ${it.text}" else it.text)) }
            val urls = turn.image?.let { listOf("data:image/jpeg;base64," + Base64.encodeToString(it.jpeg, Base64.NO_WRAP)) }.orEmpty()
            add(ChatTurn("user", cleanText.ifBlank { "What do you see in this image?" }, urls))
        }
        val model = if (turn.image != null) s.visionModel else s.textModel

        // 3) Ask Groq. If a memory was just saved and Groq is unreachable, still confirm honestly.
        val result = try {
            groq.chat(ChatRequest(model, turns, s.temperature, s.maxTokens))
        } catch (e: GroqError) {
            if (saved != null) return finish(turn, AiReply("Got it — I've saved that to memory. I couldn't reach Groq for a proper reply though.", Emotion.CALM, "memory", Expression.HAPPY))
            if (turn.image != null && e is GroqError.ModelUnavailable) {
                throw GroqError.Unknown("image analysis isn't available because the vision model “$model” can't be used. Choose another vision model in Settings → AI.")
            }
            throw e
        }
        val parsed = ReplyParser.parse(result.text)
        val look = EmotionResolver.resolve(parsed, studyMode)
        val reply = parsed.copy(emotion = look.emotion, expression = look.expression)

        // 4) Auto-memory from the same response (no extra API call), hard-filtered.
        if (s.autoMemory && command == null) reply.memories.forEach { runCatching { memory.saveAuto(turn.profileId, it) } }
        return finish(turn, reply)
    }

    private suspend fun finish(turn: Turn, reply: AiReply): AiReply {
        repo.addMessage(turn.conversationId, ChatMessage.Role.ASSISTANT, reply.text, reply.emotion)
        return reply
    }

    private companion object { const val HISTORY_CHAR_BUDGET = 6000 }
}
